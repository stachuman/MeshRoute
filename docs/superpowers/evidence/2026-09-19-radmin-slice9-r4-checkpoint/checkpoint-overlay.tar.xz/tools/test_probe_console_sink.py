#!/usr/bin/env python3
# MeshRoute — tools/test_probe_console_sink.py
# Author: Stanislaw Kozicki <cgpsmapper@gmail.com>
#
# ★★ THE AUTO-DISCOVERED WRAPPER FOR tools/probe_console_sink/ (remote-admin v2 slice 0a, [[B208]]).
#
# WHY IT EXISTS. `tools/probe_console_sink/run.sh` has been a committed, hand-run instrument since §B95: nothing in
# `python3 -m unittest discover -s tools` executed it, so a reduction inside it — a dropped profile, a control that
# quietly stopped applying, a check count that fell — could not fail any sweep. Slice 0a made that gap material by
# putting the whole console help behind it. ⇒ this file runs the probe FOR REAL and asserts its DERIVED pins.
#
# ⛔ WHAT IT IS NOT: it does not re-implement a single check. It runs the real runner and asserts four things the
#    runner cannot assert about itself:
#      1. the PINS line's counts — an anti-reduction pin, exact in BOTH directions (see PIN_* below), AND that the
#         runner now applies the same judgment itself before PASS ([[B294]]);
#      2. that every negative control actually produced a RED result (no STAYED GREEN / INSTRUMENT FAILURE / NOT
#         APPLIED anywhere in the output);
#      3. that `--no-neg` is visibly probe-only and NEVER prints PASS; and
#      4. that the md5s the binary printed are the md5s of the files on disk right now — i.e. the run measured the
#         checkout, not a copy.
#    Plus the anti-vacuity behaviour of the §0g PROJECTION ORACLE (`gen_command_inventory.primary_names`), which is
#    what the no-command-lost proof now rests on since [[B291]] retired the frozen `help_baseline.json`.
"""Wrapper selftests for the §B95/§0a console-sink + help probe."""

from __future__ import annotations

import hashlib
import os
import re
import subprocess
import sys
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
PROBE_DIR = os.path.join(HERE, "probe_console_sink")

sys.path.insert(0, PROBE_DIR)
sys.path.insert(0, HERE)
import ble_guard as BG              # noqa: E402
import gen_command_inventory as GEN  # noqa: E402

# ★ THE DERIVED PINS. Every one of these was COUNTED from a real run, never chosen; each is exact in both directions
#   so that adding a check is a deliberate act and removing one cannot pass silently.
# ★★ §0g/[[B294]]: THE RUNNER NOW ENFORCES THE SAME PINS ITSELF, before it prints PASS. This file is deliberately
#   kept as an INDEPENDENT SECOND READER — it re-derives the numbers from the runner's stdout and additionally pins
#   that the runner performs that judgment (test_the_runner_enforces_its_own_pins).
#     profiles   — len(gen_command_inventory.PROFILES); the six real board macro sets.
#     checks     — the summed `N total` the probe binary prints per profile: 120 on EVERY profile (52 §B95 sink rows
#                  + 68 §0g help rows), so 120*6 = 720. §0a's 972 is retired with the per-topic rows that scaled it.
#     ⚠⚠ THREE MORE PINS RE-DERIVED 2026-09-06 BY §RADMIN SLICE 4, each fully attributed and each a GROWTH with
#        ⛔ not one existing row removed:
#          structural 39 -> 50  (+11: S40..S50, the two CONTROLLER stores' DEVICE BOUNDARY — the boot report's
#                      single gated call and its ordering after the mount, its zero writes and zero draws, the
#                      residency ruling as a COUNT (exactly ONE public book) plus its complement (⛔ no resident
#                      keyring), no Node link, the typed wrappers' no-crossing slot binding, [[B317]]'s probe
#                      list, the two write-set pins that make `regen`'s `preserved` warning a proven claim, and
#                      the CLIENT guard's OWN `admin-client` envelope)
#          ble_guard  480 -> 905 (+425: the extractor answers the same question a THIRD time, for R-RA-30's
#                      SUB-VERB split. 85 corpus lines x 5 assertions — the fifth, D4, is the one a whole-family
#                      guard cannot express: a RULED PUBLIC form must NOT be refused.)
#          controls   78 -> 99  (+21: 5 executed-row sabotages of the client guard — including the TOO-WIDE
#                      direction — 6 extraction REFUSALS, and 10 structural sabotages, one per new row bar S41/S49
#                      which S-C40b and S-C48 already redden)
#     ⚠⚠ THREE PINS RE-DERIVED 2026-09-06 BY §RADMIN SLICE 3, each fully attributed and each a GROWTH with ⛔ not
#        one prior row dropped:
#          structural 29 -> 39  (+10: S30..S39, the two target stores' DEVICE BOUNDARY — the boot report's single
#                                ACCEPT-gated call and its position after the filesystem mount, its read-only-ness,
#                                the no-resident-state and no-Node rules, the typed wrappers' slot binding, the
#                                UNCHANGED self-heal probe list ([[B317]]), regen's and leave's unchanged write
#                                sets, and factory_erase's wholesale erasure)
#          ble_guard  212 -> 480 (+268: the extractor is GENERALIZED to a SECOND family — R-RA-29's whole-family
#                                `admin` refusal — 67 corpus lines x 4 assertions. The help family's 53 x 4 = 212
#                                are UNCHANGED and still executed.)
#          controls   58 -> 78  (+20: 3 executed-row sabotages of the admin guard, 6 extraction REFUSALS, and 11
#                                device-boundary sabotages, one per new structural claim.)
#     structural — the row count structural.py reports (S1..S39; §0b/[[B279]] added S21, the boot sink owner;
#                  §RADMIN-0c added S22..S29 — the two one-call `fw_main.cpp` adapters, the seam's ROUTER-FIRST
#                  single fork, its refusal to re-choose a sink, the no-borrowed-body/no-static rule, the HEX send
#                  handle no executed check can see, and the two [[B298]] comment-census rows).
#     ble_guard  — the executed BLE console_only rows, SUMMED OVER BOTH FAMILIES since §RADMIN slice 3:
#                  help  53 corpus lines x 4 assertions (B1..B4) = 212  (UNCHANGED)
#                  admin 67 corpus lines x 4 assertions (A1..A4) = 268  (R-RA-29's whole-family refusal)
#                  212 + 268 = 480. ⚠ THE READER BELOW MUST SUM BOTH: this wrapper's first cut parsed only
#                  the FIRST `…-GUARD rows=…` line and compared the help family's 212 against a pin of 480,
#                  which is a pin nobody parsed — the exact defect these wrappers exist to catch, found by
#                  QA on the Slice 3 gate.
#     ownership  — §RADMIN-0c: one ownership.py row per REAL product profile (6), each requiring the router-owned
#                  and parser-owned primary-form sets to be DISJOINT, non-empty, complete and at their counts.
#     own_ctl    — ownership.py's own controls (3): a synthetic collision, a deleted router form, an emptied
#                  parser surface — each REFUSED.
#     controls   — negctl's own CONTROLS-TOTAL: 8 sink + 16 source + 6 B214 + 13 help rendered-index + 2 help
#                  structural + 3 router + 5 oracle + 3 BLE executed + 2 BLE structural = 58. (§0b/[[B279]] took
#                  the source family 5 -> 6 with X12, the control that reddens S21; §RADMIN-0c took it 6 -> 16 with
#                  X13..X22, the controls that redden S22..S29.)
# ⛔⛔ THE PINS ARE **READ FROM `run.sh`**, NOT DUPLICATED HERE — corrected 2026-09-07 by §RADMIN SLICE 5 after
#    this wrapper failed for the SECOND time in the same way (Slice 3's STOP-7 repaired the identical shape in
#    this exact file). A literal copy of a pin is a SECOND pin: the moment a slice legitimately re-pins the
#    probe, the two disagree and the sweep fails for a reason that has nothing to do with the probe's health.
# ★ AND THE CHECK GOT STRONGER, NOT LOOSER. Duplicated literals only ever asserted "the probe printed what this
#   file remembers". Reading `run.sh` asserts the property that actually matters: **the runner PRINTS exactly the
#   pins it ENFORCES.** A runner that printed `structural=52` while comparing against 50 — i.e. a pin that no
#   longer guards anything — passed the old form and fails this one. `test_probe_custody_usb.py` already reads
#   its sibling this way (it asserts `run.sh` both declares and compares its pins); this is that idiom applied.
# ⛔ A DELIBERATE RE-PIN THEREFORE HAPPENS IN **ONE** PLACE, `run.sh`, WITH ITS DERIVATION — which is where the
#   reviewed contract lives. This file no longer has an opinion about the values, only about their consistency.
def _run_sh_pins() -> dict:
    """The pins the runner DECLARES, parsed from its own source. Refuses loudly rather than defaulting."""
    with open(os.path.join(PROBE_DIR, "run.sh"), encoding="utf-8") as fh:
        text = fh.read()
    simple = dict(re.findall(r"(?m)^(PIN_[A-Z_]+|CHECKS_PER_PROFILE)=(\d+)$", text))
    # `PIN_CHECKS` is DERIVED in the runner (per-profile x profiles); reproduce that derivation rather than
    # re-typing its product, so the two cannot drift either.
    if "PIN_CHECKS" not in simple:
        m = re.search(r"(?m)^PIN_CHECKS=\$\(\(CHECKS_PER_PROFILE \* PIN_PROFILES\)\)$", text)
        assert m, "run.sh: PIN_CHECKS is neither a literal nor the expected CHECKS_PER_PROFILE * PIN_PROFILES"
        simple["PIN_CHECKS"] = str(int(simple["CHECKS_PER_PROFILE"]) * int(simple["PIN_PROFILES"]))
    out = {k: int(v) for k, v in simple.items()}
    for required in ("PIN_PROFILES", "PIN_CHECKS", "PIN_STRUCTURAL", "PIN_BLE_GUARD",
                     "PIN_OWNERSHIP", "PIN_OWN_CTL", "PIN_CONTROLS"):
        assert required in out, f"run.sh no longer declares {required} — the pin it names cannot be checked"
    return out


_PINS = _run_sh_pins()
PIN_PROFILES = _PINS["PIN_PROFILES"]
PIN_CHECKS = _PINS["PIN_CHECKS"]
PIN_STRUCTURAL = _PINS["PIN_STRUCTURAL"]
PIN_BLE_GUARD = _PINS["PIN_BLE_GUARD"]
PIN_OWNERSHIP = _PINS["PIN_OWNERSHIP"]
PIN_OWN_CTL = _PINS["PIN_OWN_CTL"]
PIN_CONTROLS = _PINS["PIN_CONTROLS"]

UNUSABLE = ("STAYED GREEN", "INSTRUMENT FAILURE", "CONTROL NOT APPLIED", "PROBE BUILD FAILED")


def _md5_8(path):
    with open(path, "rb") as fh:
        return hashlib.md5(fh.read()).hexdigest()[:8]


class TestProbeRunner(unittest.TestCase):
    """The real runner, run for real. ~25 s: the two invocations are shared by every test in the class."""

    full = None
    noneg = None

    @classmethod
    def setUpClass(cls):
        cls.full = subprocess.run(["bash", os.path.join(PROBE_DIR, "run.sh")],
                                  capture_output=True, text=True, cwd=ROOT)
        cls.noneg = subprocess.run(["bash", os.path.join(PROBE_DIR, "run.sh"), "--no-neg"],
                                   capture_output=True, text=True, cwd=ROOT)

    def test_the_default_gate_passes(self):
        self.assertEqual(0, self.full.returncode, self.full.stdout[-4000:] + self.full.stderr[-2000:])
        self.assertIn("PASS: probe + structural + controls all green", self.full.stdout)

    def test_the_derived_pins(self):
        m = re.search(r"PINS profiles=(\d+) checks=(\d+) structural=(\d+) ble_guard=(\d+) ownership=(\d+) "
                      r"ownership_controls=(\d+) controls=(\d+) unusable_controls=(\d+)", self.full.stdout)
        self.assertIsNotNone(m, "the runner must print its derived pins")
        (profiles, checks, structural, ble_guard, ownership, own_ctl,
         controls, unusable) = (int(g) for g in m.groups())
        self.assertEqual(PIN_OWNERSHIP, ownership,
                         "the router/parser ownership gate lost or gained a product profile")
        self.assertEqual(PIN_OWN_CTL, own_ctl,
                         "an ownership control (collision / missing form / emptied surface) was dropped")
        self.assertEqual(PIN_BLE_GUARD, ble_guard,
                         "the executed BLE help-refusal check gained or lost rows")
        self.assertEqual(PIN_PROFILES, profiles, "a product profile was added or dropped from the probe matrix")
        self.assertEqual(PIN_CHECKS, checks,
                         "the probe's total check count moved — a reduction must never still report PASS; "
                         "if checks were added deliberately, re-derive PIN_CHECKS from the run")
        self.assertEqual(PIN_STRUCTURAL, structural, "structural.py gained or lost a row")
        self.assertEqual(PIN_CONTROLS, controls, "a negative control was added or removed")
        self.assertEqual(0, unusable)

    def test_the_probe_matrix_matches_the_generator_matrix(self):
        """One profile list, not two: the runner's PROFILES and the generator's must name the same builds."""
        with open(os.path.join(PROBE_DIR, "run.sh"), encoding="utf-8") as fh:
            run_sh = fh.read()
        block = run_sh.split("PROFILES=(", 1)[1].split(")\n", 1)[0]
        named = set(re.findall(r'"([a-z_]+)\|', block))
        self.assertEqual(set(GEN.PROFILES), named)

    def test_every_profile_was_compared_against_the_source_projection(self):
        """§0g: the oracle is the GENERATED INVENTORY, and every profile must actually have been compared to it."""
        rows = re.findall(r"primary names (\w+): (\d+) rendered == (\d+) projected", self.full.stdout)
        self.assertEqual(PIN_PROFILES, len(rows), "every profile must be compared against the inventory projection")
        for prof, rendered, projected in rows:
            self.assertEqual(rendered, projected, f"{prof}: rendered and projected name counts differ")
            self.assertGreater(int(projected), 0,
                               f"{prof}: an EMPTY projection would compare clean against anything")
        # ...and the numbers the runner reported must be the ones the generator produces right now, independently.
        for prof, rendered, _projected in rows:
            rows_now, _n, _v, _r = GEN.build_rows(ROOT)
            self.assertEqual(int(rendered), len(GEN.primary_names(rows_now, GEN.PROFILES[prof])),
                             f"{prof}: the runner's count disagrees with a fresh projection")

    def test_no_control_was_unusable(self):
        for line in self.full.stdout.split("\n"):
            for bad in UNUSABLE:
                self.assertNotIn(bad, line, f"unusable control: {line.strip()}")

    def test_every_response_fits_the_stage_with_headroom_reported(self):
        sizes = re.findall(r"HELP-LARGEST (\S+(?: \S+)?) (\d+) B \(stage (\d+) B\)", self.full.stdout)
        self.assertEqual(PIN_PROFILES, len(sizes))
        for name, n, stage in sizes:
            self.assertLess(int(n), int(stage), f"the largest response ({name}) does not fit the console stage")

    def test_the_run_measured_the_checkout(self):
        want_sink = _md5_8(os.path.join(ROOT, "src", "console_sink.h"))
        want_help = _md5_8(os.path.join(ROOT, "src", "firmware_help.h"))
        self.assertIn(f"sink md5 = {want_sink}", self.full.stdout)
        self.assertIn(f"help md5 = {want_help}", self.full.stdout)
        # PIN_PROFILES per-profile banners + the one the runner prints up front, before any build.
        self.assertEqual(PIN_PROFILES + 1, self.full.stdout.count(f"help md5 = {want_help}"),
                         "every profile build must report the checked-out help header")

    def test_the_ble_refusal_was_measured_not_asserted(self):
        """The owner-ruled BLE refusals are EXECUTED, not grepped — and BOTH families are read, not just the first.

        §0a (2026-09-04): help must not be transferred by BLE.
        R-RA-29 (2026-09-06): the WHOLE remote-admin target family is refused over BLE.

        ⚠⚠ WHY THIS READS A TABLE AND NOT ONE REGEX. Its first cut did `re.search(r"BLE-GUARD rows=…")` and
        compared that ONE match against `PIN_BLE_GUARD`. When §RADMIN slice 3 added the admin family the pin moved
        to 480 while the regex still returned the help family's 212 — so the wrapper compared 212 against 480 and
        the sweep went red, which is the LUCKY outcome. The unlucky one is the mirror: a pin that no reader parses
        is a pin that measures nothing. ⇒ every family the runner prints is read, each must report `failed=0`,
        and their SUM is what the pin is compared against.
        """
        self.assertIn("BLE help-refusal (EXECUTED", self.full.stdout)
        rows_by_family, checks_by_family, failed_by_family = {}, {}, {}
        for fam, r, c, f in re.findall(
                r"(?m)^\s*(BLE|ADMIN|CLIENT)-GUARD rows=(\d+) checks=(\d+) failed=(\d+)", self.full.stdout):
            rows_by_family[fam] = int(r)
            checks_by_family[fam] = int(c)
            failed_by_family[fam] = int(f)
        self.assertEqual({"BLE", "ADMIN", "CLIENT"}, set(checks_by_family),
                         "all THREE executed guard families must report their own denominators — a missing family "
                         "is a silently unmeasured owner ruling (R-RA-29 target, R-RA-30 controller)")
        for fam, failed in failed_by_family.items():
            self.assertEqual(0, failed, "%s-GUARD reported %d failed executed check(s)" % (fam, failed))
        for fam, rows in rows_by_family.items():
            self.assertGreaterEqual(rows, 40, "%s: an almost-empty corpus would prove nothing" % fam)
        self.assertEqual(PIN_BLE_GUARD, sum(checks_by_family.values()),
                         "the pin is the SUM over every executed family (help + admin + client), not one "
                         "family's count; "
                         "derived: %s" % checks_by_family)
        # ...and each family must state WHICH condition text it measured.
        self.assertIn("extracted help guard: ", self.full.stdout)
        self.assertIn("extracted admin guard: ", self.full.stdout)
        self.assertIn("extracted client guard: ", self.full.stdout)

    def test_the_runner_enforces_its_own_pins(self):
        """[[B294]]: running the gate DIRECTLY must refuse a shrunken measurement instead of printing PASS.

        The selftest drops one profile, so every probe binary the child launched still prints `0 failed` while the
        observed profile/check counts fall — the exact hole where a green probe used to carry a green gate.
        """
        r = subprocess.run(["bash", os.path.join(PROBE_DIR, "run.sh"), "--pin-selftest"],
                           capture_output=True, text=True, cwd=ROOT)
        self.assertEqual(0, r.returncode, r.stdout[-4000:] + r.stderr[-2000:])
        self.assertIn("SELFTEST OK", r.stdout)
        self.assertNotIn("PASS: probe + structural + controls all green", r.stdout,
                         "the selftest must never share the gate's PASS wording")
        self.assertIn("STILL GREEN, runner refused", r.stdout,
                      "the F4 shape — green probe binaries, shrunken coverage — must be demonstrated")

    def test_no_neg_is_visibly_probe_only_and_never_claims_pass(self):
        self.assertEqual(0, self.noneg.returncode)
        self.assertIn("PROBE-ONLY", self.noneg.stdout)
        self.assertNotIn("PASS:", self.noneg.stdout,
                         "--no-neg must never print a gate result — the controls did not run")
        self.assertNotIn("negative controls (each MUST fail)", self.noneg.stdout)


class TestBleGuard(unittest.TestCase):
    """The BLE refusal's extractor. It is the one link in that proof that is text, so it must be fail-loud."""

    FW = os.path.join(ROOT, "src", "fw_main.cpp")

    def test_the_real_guard_extracts_and_covers_the_whole_help_family(self):
        with open(self.FW, encoding="utf-8") as fh:
            cond = BG.extract_guard(fh.read())
        self.assertIn('"help"', cond)
        self.assertIn("'?'", cond)
        self.assertRegex(cond, r"len\s*>\s*4\s*&&\s*line\s*\[\s*4\s*\]\s*==\s*' '")

    def test_extraction_refuses_when_the_refusal_is_gone(self):
        with open(self.FW, encoding="utf-8") as fh:
            text = fh.read()
        with self.assertRaises(BG.GuardError):
            BG.extract_guard(text.replace(BG.REFUSAL_CALL, "write_err(out, cap, \"help\", \"gone\")"))

    def test_extraction_refuses_a_DUPLICATED_refusal(self):
        with open(self.FW, encoding="utf-8") as fh:
            text = fh.read()
        with self.assertRaises(BG.GuardError):
            BG.extract_guard(text.replace('        return ' + BG.REFUSAL_CALL + ';',
                                          '        return ' + BG.REFUSAL_CALL + ';\n        (void)'
                                          + BG.REFUSAL_CALL + ';', 1))

    def test_a_commented_out_refusal_is_not_extracted(self):
        with open(self.FW, encoding="utf-8") as fh:
            text = fh.read()
        with self.assertRaises(BG.GuardError):
            BG.extract_guard(text.replace('        return ' + BG.REFUSAL_CALL + ';',
                                          '        // return ' + BG.REFUSAL_CALL + ';', 1))

    def test_the_corpus_covers_every_owner_topic_in_the_leaky_shapes(self):
        rows = dict(BG.corpus())
        for t in BG.RETIRED_TOPIC_WORDS:
            for shape in (f"help {t}", f"help  {t}", f"help {t} x", f"help {t}x"):
                self.assertTrue(rows[shape], f"{shape} must be refused on BLE")
        for through in ("helpful", "hel", "status", ""):
            self.assertFalse(rows[through], f"{through} must NOT be swallowed by the help guard")


class TestPrimaryProjectionOracle(unittest.TestCase):
    """§0g: the completeness proof now rests on the GENERATED projection, so a vacuous oracle would void the gate.

    (This class replaces TestHelpManifest, retired with `help_manifest.py`/`help_baseline.json` under [[B291]].)
    """

    @classmethod
    def setUpClass(cls):
        cls.rows, _n, _v, _r = GEN.build_rows(ROOT)

    def test_every_profile_projects_a_non_empty_sorted_unique_name_set(self):
        for prof, macros in GEN.PROFILES.items():
            names = GEN.primary_names(self.rows, macros)
            self.assertGreater(len(names), 40, f"{prof}: an almost-empty projection proves nothing")
            self.assertEqual(sorted(set(names), key=lambda n: n.encode()), names,
                             f"{prof}: the projection must be bytewise sorted and unique")

    def test_an_empty_row_set_REFUSES_instead_of_projecting_nothing(self):
        with self.assertRaises(GEN.GeneratorError):
            GEN.primary_projection([], GEN.PROFILES["full_headless"])

    def test_the_gate_evaluator_refuses_a_macro_that_is_not_a_profile_axis(self):
        with self.assertRaises(GEN.GeneratorError):
            GEN.eval_gate("MR_FEAT_NOT_A_PROFILE_AXIS", GEN.PROFILES["gateway"])

    def test_the_gate_evaluator_agrees_with_the_real_gates(self):
        self.assertTrue(GEN.eval_gate("MR_N_LAYERS < 2", GEN.PROFILES["mobile"]))
        self.assertFalse(GEN.eval_gate("MR_N_LAYERS < 2", GEN.PROFILES["gateway"]))
        self.assertTrue(GEN.eval_gate("MR_FEAT_OLED", GEN.PROFILES["full_oled"]))

    def test_the_feature_gates_really_separate_the_profiles(self):
        """A projection identical on every profile would silently stop testing availability at all."""
        full = set(GEN.primary_names(self.rows, GEN.PROFILES["full_oled"]))
        gw = set(GEN.primary_names(self.rows, GEN.PROFILES["gateway"]))
        mob = set(GEN.primary_names(self.rows, GEN.PROFILES["mobile"]))
        self.assertEqual({"mobile", "team", "ui"}, full - gw)
        # ★ §RADMIN slice 3 (R-RA-8): `acl` and `admin-id` are ACCEPT-only, so a MOBILE build advertises neither.
        #   That asymmetry IS the product gate, and pinning it here is what makes the two mobile profiles'
        #   UNCHANGED router counts (38 / 39) a measurement rather than a coincidence.
        self.assertEqual({"acl", "admin-id", "ui"}, full - mob)

    def test_the_punctuation_alias_is_not_a_second_command(self):
        names = GEN.primary_names(self.rows, GEN.PROFILES["full_headless"])
        self.assertIn("help", names)
        self.assertNotIn("?", names)

    def test_the_console_token_parser_surface_is_included(self):
        """Surface 3's seven names never reach dispatch(); dropping that surface loses them silently (42 vs 49)."""
        names = set(GEN.primary_names(self.rows, GEN.PROFILES["full_headless"]))
        for n in ("send", "send_channel", "send_layer", "peerkey", "peername", "reqpubkey", "resolve"):
            self.assertIn(n, names)


if __name__ == "__main__":
    unittest.main()
