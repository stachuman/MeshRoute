// MeshRoute — lib/core/node_mac.cpp  (R3 MAC data plane — TX / send path)
// Author: Stanislaw Kozicki <cgpsmapper@gmail.com>
//
// The sender side of the RTS-CTS-DATA-ACK handshake: the send queue drain
// (become_free), flight issue + RTS (re)transmit, the DATA transmit with the
// §7.6 hop-budget derivation, and the timeout-start helpers. RTS/CTS/ACK ride
// routing_sf; only DATA rides the chosen data_sf. The RX-side frame handlers are
// in node_mac_rx.cpp; the R4 duty/anti-spam plane is in node_budget.cpp.
// Behaviour mirrors dv_dual_sf.lua. Part of the Node class (declared in node.h).
// See docs/specs/2026-05-30-r3-data-plane-design.md.
#include "node.h"

#include "frame_codec.h"
#include "airtime.h"
#include "mac_wait_windows.h"

#include <span>

namespace MESHROUTE_NS {

uint16_t Node::peek_next_ctr(uint8_t dst) const {
    uint16_t c = 0;
    const auto it = _active->_peer_send_counter.find(dst);
    if (it != _active->_peer_send_counter.end()) c = it->second;
    if (c < _active->_peer_ctr_floor) c = _active->_peer_ctr_floor;   // D7: resume above the pre-reboot per-peer high-water (no (sender_hash,ctr) dedup-collision)
    return (c >= 65535) ? 1 : static_cast<uint16_t>(c + 1);           // wraps 65535->1 (NOT a rand site)
}

uint16_t Node::next_ctr(uint8_t dst) {
    const uint16_t c = peek_next_ctr(dst);
    _active->_peer_send_counter[dst] = c;
    return c;
}

uint8_t Node::select_data_sf(uint8_t rts_sf_index, int16_t rx_snr_q4) const {
    // Adaptive DATA-SF: resolve the requester's sf_index to a candidate SF set, then pick the fastest
    // SF the link SNR supports (Lua sf_index_to_bitmap :3027 + select_data_sf :3043). ANY(3) -> our full
    // allowed_sf_bitmap; pinned 0..2 -> that singleton (M-broadcast / forced SF). allowed_sf_bitmap==0
    // means "unconfigured" -> NO data SF: returns 0, and callers refuse to send / ignore the RTS (no silent
    // fallback — a misconfigured node must fail loud, not run on a hidden default). PURE (no rand).
    uint16_t bitmap = _cfg.allowed_sf_bitmap;
    if (rts_sf_index != 3 /*ANY*/) {                          // pinned: the index-th allowed SF
        uint16_t pin = 0; uint8_t seen = 0;
        for (uint8_t sf = 5; sf <= 12; ++sf)
            if (bitmap & (1u << sf)) { if (seen++ == rts_sf_index) { pin = static_cast<uint16_t>(1u << sf); break; } }
        if (pin) bitmap = pin;                                // out-of-range index -> keep full set (Lua :3035)
    }
    return protocol::select_data_sf_for_snr(rx_snr_q4, bitmap, protocol::sf_margin_q4);  // 0 if sf_list empty
}

uint32_t Node::airtime_routing_ms(uint16_t len) const {
    return airtime_ms(_cfg.routing_sf, active_bw_hz(), active_cr(), protocol::preamble_sym, len);
}
// ★★★ OWNER-RULED 2026-08-10 — READ THIS FIRST; IT REVERSES THE INSTRUCTION THAT FOLLOWED IT FOR TWO DAYS.
//   REPORTED FORM, no quotation (a blockquote here was withdrawn as NOT the owner's exact words):
//   **the owner ruled that Lua parity is NOT a final MeshRoute jitter requirement, and that [[B158]] stays open
//   until MeshRoute-native jitter has been independently measured and selected.** (owner-rulings-ledger §1.13)
// ⛔⛔ SO DO **NOT** READ THE NEXT PARAGRAPH AS *"leave this alone, it is parity"*. That WAS the recorded
//   disposition for about an hour on 2026-08-10 and it is **WITHDRAWN**. What is owed is not a constant tweak:
// ★★ THIS ONE HELPER CONTROLS **FOUR UNRELATED POLICIES**, so retuning any one silently retunes the other three:
//     (1) fresh DM origination spreading      -> node_mac.cpp:316 (app DMs, nav_enabled only)
//     (2) same-hop RTS/ACK retry spreading    -> node_cascade.cpp:365/398 via retry_backoff_window()
//     (3) BUSY_RX release spreading           -> node_mac_rx.cpp:2077 (short-busy same-hop wait)
//     (4) the DEFAULT LBT RELEASE BACKOFF     -> node.cpp:508/913, `lbt_backoff_ms = max(1, retry_jitter_ms()/2)`
//   ⇒ ★ (4) is the coupling to break FIRST: today, changing retry jitter resizes LBT backoff behind your back.
//   THE OWED ARC (ledger §1.13 carries the full metric list): split into four behaviour-identical semantic helpers
//   (`dm_origination_jitter_ms` / `same_hop_retry_jitter_ms(crypted)` / `busy_rx_release_jitter_ms` /
//   `lbt_release_jitter_ms`); define `rts_contention_quantum_ms = airtime_routing_ms(unicast_rts_wire_len(true))`
//   = the 11-B RTS airtime, **the SCALE, NOT the window**; then sweep `K = 1,2,3,4,6` on a **FLAT** window across
//   the 36 scenarios + the 24-seed saturated twin + metal. ⛔ K=3 is a CANDIDATE, NOT a conclusion, and must not be
//   picked from one deterministic corpus run (s16 is chaotic and non-monotone). ⛔ NO SECOND BEB LAYER: the CTS
//   timeout already expands x4 and a 24-seed experiment showed added exponential jitter REDUCED delivery
//   (consistent with `protocol::retry_backoff_max_shift == 0`, i.e. the window is already flat).
// ---- the historical parity rationale, retained because it explains the CURRENT value, not the future one ----
// 3*airtime(routing, Lua RTS_LEN=8) — a TIMING constant from the Lua, NOT a description of the C++ wire,
// so the retry rand RANGE matches the Lua and the lua-vs-meshroute streams stay aligned. The contract is
// written at node.h:100-103; ⚠ changing this is a cross-engine PARITY decision, never an incidental bug fix —
// but per the ruling above, parity is no longer a REASON TO REFUSE the change, only a consequence to measure.
// ⛔ CORRECTED 2026-08-10 (§HYBRID-RTS-S5, V1): this comment read *"NOT the 7-B C++ wire"*. The C++ unicast
//    RTS has been 10 B plaintext / 11 B crypted since §hybrid-rts S1, and `parse_rts` REJECTS a 7-B frame
//    outright — so the sentence described a frame that no longer exists.
// ✖ KNOWN UNDER-PRICE, MEASURED AND DELIBERATELY LEFT (the mark-done-vs-missing rule). Against the frame that
//   actually flies this is short by `3*(a(10) - a(8))`, swept over the full supported grid
//   (SF 5..12 x BW {62.5k,125k,250k,500k} x CR 5..8 = 128 cells):
//     · **worst −789 ms** at SF11 / BW 62.5 kHz / CR 4/8;
//     · it differs from the accurate price on **66 of 128** cells, and is EXACT on the other 62;
//     · ★ **+0 ms at BOTH of the corpus's two dominant routing cells** — SF8/BW62.5k (3*177 either way,
//       9 413 frames) and `s18`'s SF8/BW125k (3*88, 8 999 frames) — which is why the parity decision is not
//       urgent. ⚠ It is NOT free everywhere in the corpus: the third-most-used cell, SF9/BW62.5k/CR5
//       (1 530 frames — `s16_dense_gateway`'s second gateway leaf), is short by **−123 ms**.
//   ⇒ The consequence is the RETRY JITTER RANGE only (`node_mac.cpp:299`, `node_mac_rx.cpp:2077`,
//   `node_cascade.cpp:365/398` via `retry_backoff_window`, and the derived `_lbt_backoff_ms` /
//   `flood_lbt_max_defer_ms` at `node.cpp:508/510`), never a response-wait: `start_rts_timeout` prices the real
//   frame through `unicast_rts_wire_len`/`terminal_cts_wire_len`. Full ledger: BASELINE.md §HYBRID-RTS-S5.
uint32_t Node::retry_jitter_ms() const { return 3 * airtime_routing_ms(8); }

// Build + enqueue an app DATA. `tx_event` separates an app send ("tx_enqueue", the dm_delivery
// record-creation key) from an internal protocol DATA like the E2E ack ("e2e_ack_tx") that must NOT
// be counted as an app DM.
uint16_t Node::enqueue_data(uint8_t dst, const uint8_t* body, uint8_t body_len, uint8_t flags, [[maybe_unused]] const char* tx_event, bool app_dm, uint8_t type, CryptIntent crypt, uint32_t override_dst_hash, uint32_t override_source_hash, uint8_t addr_len, Plane plane, SendDispatch* out_dispatch) {
    // ★★★ §CUSTODY-B (2026-08-30) — THE GENERIC USER-SEND LIFECYCLE GATE FOR THIS ORIGINATION (design §6.2(5)).
    //     Derived ONCE here, from the ONE trait authority, and consulted at every `send_failed` report below.
    // ⛔ `app_dm` IS NOT THIS QUESTION and must not be reused as it (design §6.1): `app_dm` is an ENCODING input —
    //    it decides DST_HASH/SOURCE_HASH prefixing and the crypto path — and `DATA_TYPE_TEAM_KEY_GRANT` (0xA2) is
    //    PROTOCOL-INTERNAL yet travels this function with `app_dm = true` because it genuinely needs the
    //    application seal (`do_send` → here). That single type is why the whole refusal ladder below is reachable
    //    with an internal type at all, and why the gate is a TRAIT question rather than an `app_dm` question.
    // ⚠ WHAT IS SUPPRESSED IS THE **GENERIC** FAMILY ONLY — the `send_failed` Push and the emit that carries the
    //   same name. Every CAUSE-SPECIFIC emit below (`team_key_grant_refused`, `location_refused`, `e2e_*`) still
    //   fires: C2's fail-loud is preserved, and §6.2(6) requires the protocol-specific result to survive intact.
    //   The grant additionally keeps its OWN typed synchronous contract (`TeamKeyGrantTx`, node.cpp), which is
    //   what the operator actually reads — the generic push was a second, weaker signal wearing a user-send name.
    const bool generic_lifecycle = data_type_traits(type).generic_send_lifecycle;
    // R6.1 §6.4 join-participation gate: an un-synced managed joiner must CONFIG_PULL before it originates app DMs (no
    // pre-membership pollution). Inert for UNMANAGED/adopted nodes (leaf_config_synced()). Internal DATA (app_dm=false:
    // E2E acks, forwards) is NEVER gated — only originations.
    if (app_dm && !leaf_config_synced()) {
        if (generic_lifecycle) {
            MR_EMIT("send_failed", EF_I("dst", dst), EF_S("reason", "joining"));
            push_send_failed(SendFailReason::joining, dst, /*ctr=*/0);
        }
        return 0;
    }
    // §mobile: a mobile is reachable for a REPLY only via a valid HOME (it stamps origin=home_id, and the home last-miles
    // the reverse leg). Originating a reply-expecting DM (E2E_ACK_REQ) to a NON-team target while we have no routable home
    // would stamp origin=_node_id — a mobile LOCAL id no static node can route to -> the target floods RREQ for it (storm)
    // and the ack never returns. FAIL LOUD instead. A team dst is routable on the team plane; a registered
    // mobile (home_id set, not self) makes the reverse-ack work. Gated on is_mobile -> a static node is byte-identical.
    // §team-parity T1 (spec §3/T1): "a team dst" is now decided by the send's PLANE, not by is_team_peer alone. The
    // is_team_peer-only form was the same chicken-and-egg as node.cpp's send guard: an off-grid member sending
    // `-t <unheard-id> -a` was refused mobile_no_home here even though the reply leg it worries about is the TEAM
    // plane, which needs no home at all — the reverse ack routes by _rt_team (the RREQ lays the reverse path at every
    // relay). `plane` is already a parameter of enqueue_data, so no signature change (U1).
    // ★★ §team-parity T6 CORRECTION (2026-07-28). T1 wrote here that "the origin it stamps is the team_local_id, which
    // every teammate CAN route" as though it were a standing property. IT WAS NOT TRUE WHEN T1 WROTE IT: stamp_origin
    // had no team-plane exception, so a HOMED member stamped its HOME's STATIC node id (measured live in s28/s29 as
    // origin=101) and its reverse ack was addressed on the STATIC plane — the R3 violation §11 was ruled on. ⇒ T6
    // ESTABLISHES the property this guard rests on; it does not restate one. stamp_origin (node.h) now stamps
    // team_local_id() for exactly the flights this guard admits, because both use flight_is_team_plane(plane, dst) —
    // the same predicate, so the gate cannot admit a send whose ack has no routable return address.
    // ★★ FIXED 2026-07-28 (§ack-gate-plane; T6 named this, T7 refused it under C1, it is closed here). The arm was
    // `plane == Plane::TEAM || is_team_peer(dst)` — an UNQUALIFIED is_team_peer. Since `Plane::AUTO` is unreachable
    // from real firmware (lib/console/console_parse.cpp:259 emits only TEAM or GLOBAL, and the companion/BLE
    // transports share that parser), that second arm could fire ONLY for a GLOBAL flight ⇒ a plain
    // `send <id-that-collides-a-teammate's-team-id> -a` from a mobile with NO routable home was admitted as "team"
    // when §6.4 says it must fail loud. It was a DEFAULT-PATH bug on metal, not a corner case.
    // ⇒ now `flight_is_team_plane(plane, dst)` — rt_find's dispatch predicate VERBATIM (node.h:189/node_routing.cpp:22),
    // so the ack gate and the routing decision cannot disagree, which is the property T6 established for stamp_origin
    // three lines below (:101). The three now share ONE predicate.
    // ★ IT IS A STRICT NARROWING — exactly one input cell changes, GLOBAL + is_team_peer(dst):
    //     plane=TEAM               -> admitted before and after
    //     plane=AUTO,  peer true   -> admitted before and after
    //     plane=AUTO,  peer false  -> gated before and after
    //     plane=GLOBAL, peer false -> gated before and after
    //     plane=GLOBAL, peer TRUE  -> ADMITTED before / GATED now      <-- the whole delta
    // and gating it is CORRECT, not merely stricter: for that cell stamp_origin's flight_is_team_plane() is false, so
    // the flight stamps `mob ? home_id : _node_id`, and the second conjunct below has already established there is NO
    // routable home — so the stamped origin is 0 or our own mobile LOCAL id, i.e. an address no static node can route.
    // rt_find(dst, GLOBAL) meanwhile routes on the STATIC _rt. The E2E ack therefore CANNOT return: refusing loud is
    // the whole reason this guard exists.
    // ⚠⚠ CORRECTED 2026-09-04 (remote-admin v2 Slice 0d, R-RA-12). ⛔ THE OLD CLAIM IS KEPT VISIBLE because it is the
    // sentence the paragraph's "no internal caller is affected" rested on: *"No internal caller is affected — the ONLY
    // producers of Plane::GLOBAL on a DM flight are console_parse.cpp:259 and the sim wrapper; every lib/core
    // enqueue_data/do_send call passes AUTO or TEAM (node_mac.cpp:371/:555 and node_channel.cpp:47 hand GLOBAL to
    // stamp_origin directly, not through here)."* ⇒ THAT CENSUS IS FALSE, and V1 says so twice over:
    //   · it was ALREADY false before 0d — §CUSTODY-F's notice originator (`node_cascade.cpp`,
    //     `enqueue_data(..., Plane::GLOBAL, ...)`) and its hash-addressed twin (`node_mac_rx.cpp`,
    //     `send_by_hash(..., Plane::GLOBAL, ...)`) both landed 2026-08-31, both in lib/core, both GLOBAL; and
    //   · Slice 0d adds FOUR more in `node_hashlocate.cpp` — the three registered-mobile MOBILE_SEND wrapper arms and
    //     the cached-home arm — because a mobile's home is only ever a static node (R-RA-12 / D-0d-1).
    // ⓘ WHAT THE CENSUS WAS STANDING IN FOR, restated as the property that actually holds — the TRUTH TABLE ABOVE IS
    //   UNCHANGED; only the inventory of who reaches it moved:
    //   · the two custody producers pass `app_dm = false` (cascade) or `flags = 0` with no `DATA_FLAG_E2E_ACK_REQ`
    //     (both), so neither reaches this `if` at all;
    //   · 0d's arms 1-3 are inside `_my_mobile_reg.active`, so the LAST conjunct (not the plane term) decides them —
    //     unchanged under either plane; and
    //   · 0d's arm 4 IS the first real internal producer to reach the truth table's one delta cell
    //     (`GLOBAL + is_team_peer(dst)`), and reaching it is CORRECT: that sender is an unregistered mobile with no
    //     routable home, which this guard already refused on every NON-colliding send. GLOBAL only makes the
    //     colliding send agree with it, instead of admitting a DM whose E2E ack can never return.
    // ⛔ Do not re-derive a "who produces GLOBAL" list from this comment: grep the source (V1).
    // Static reduction: on a static node the whole guard is dead (`_cfg.is_mobile` is false); with MR_FEAT_TEAM 0
    // flight_is_team_plane() returns false unconditionally (node.h:193), leaving the pre-T1 `!false` shape, and a
    // mobile on AUTO reads exactly the pre-T1 `!is_team_peer(dst)`.
    // Build profiles: the whole block is MR_FEAT_MOBILE-gated (absent on the three gateway_* envs, which also set
    // MR_FEAT_TEAM 0); Plane is an ungated enum in node_carriers.h, so the term compiles identically wherever
    // this block compiles at all.
#if MR_FEAT_MOBILE
    if (app_dm && (flags & DATA_FLAG_E2E_ACK_REQ) && _cfg.is_mobile && !flight_is_team_plane(plane, dst)
        && !(_my_mobile_reg.active && _my_mobile_reg.home_id != 0 && _my_mobile_reg.home_id != _node_id)) {
        if (generic_lifecycle) {   // §CUSTODY-B §6.2(5) — see the gate's derivation at the top of this function
            MR_EMIT("send_failed", EF_I("dst", dst), EF_S("reason", "mobile_no_home"));
            push_send_failed(SendFailReason::mobile_no_home, dst, /*ctr=*/0);
        }
        return 0;
    }
#endif
    const uint16_t ctr = next_ctr(dst);
    TxItem item{};
    // §team-parity T6: the ONE site where the plane is genuinely variable — thread the caller's `plane` + `dst` so a
    // TEAM-plane DM stamps team_local_id(). Static reduction: AUTO-to-a-non-teammate / GLOBAL / any static node ⇒
    // flight_is_team_plane() false ⇒ the pre-T6 `mob ? home_id : _node_id` verbatim.
    stamp_origin(item, plane, dst); item.dst = dst; item.ctr = ctr; item.ctr_lo = static_cast<uint8_t>(ctr & 0x0F);
    item.flags = flags; item.type = type;
    item.addr_len = addr_len;   // §mobile: 1 => `dst` is a hosted mobile's LOCAL id -> route as a direct 1-hop last-mile (node_mac.cpp:529). 0 for every normal origination (byte-identical).
    item.plane = plane;         // Wave 2: the addressing plane forced by the caller (AUTO for every existing caller -> byte-identical)
    // Inner = [dst_key_hash32 (4 B LE, iff DST_HASH)][origin][body] — NO payload-flags byte. DST_HASH (L2c
    // verify-on-delivery) is default-on for app DMs when we know the recipient's stable key (id_bind) — when
    // present, set the byte-1 HEADER flag (item.flags) and prefix the hash. Else plain ([origin][body]). NOT for
    // internal DATA (E2E acks): app_dm=false.
    // ⛔ V1 (2026-09-05): this note used to add *"and the +4 B still fits the inner buffer"*. That clause described
    //   the [[B296]] fit-check and is GONE with it — the cap reserves the field instead (see the block below).
    // Decide the optional inner fields, then build the bytes via the shared pack_unicast_inner (Slice 4b — the
    // single source of inner byte ORDER). Inner = [dst_key_hash32 (iff DST_HASH)][origin][source_hash (iff
    // SOURCE_HASH)][body]. DST_HASH (L2c verify-on-delivery) is on for an app DM whenever we KNOW the recipient's
    // stable key; SOURCE_HASH carries the sender's STABLE key_hash32 AFTER origin (the 8-bit origin is
    // reassignable). NOT for internal DATA (E2E acks): app_dm=false. NO CROSS_LAYER here — that path is Slice 4d
    // (origination) / 4c (bridge).
    // ★★★ R-RA-25 (owner, 2026-09-05) — **NEITHER FIELD IS OPTIONAL-FOR-SIZE ANY MORE. THAT WAS [[B296]].**
    //   Both decisions used to carry a `… + body_len <= max_payload_bytes_hard_cap` term, so a body the (then 239-B)
    //   admission cap let through was made to fit by DROPPING identity instead of refusing: at 233..236 the carrier
    //   lost SOURCE_HASH (receiver `sender_hash` = 0 — inbox dedup and cross-layer E2E-ack identity gone), and at
    //   237..239 it lost DST_HASH too, i.e. **a by-HASH send silently became a by-ID send** and could be delivered
    //   to whoever holds that id. Reproduced by execution against the native core before the fix.
    //   ⇒ The cap now RESERVES both fields (`protocol::dm_max_body_bytes` = 241 - 4 - 1 - 4 = 232) and these two
    //   decisions are UNCONDITIONAL, exactly as the cross-layer sibling `enqueue_cross_layer` has always set
    //   `DST_HASH|SOURCE_HASH` (:641). An over-long body is REFUSED — synchronously at `on_command`, and by the
    //   pack backstop below — never quietly downgraded.
    // ⓘ "DERIVABLE" IS NARROW, AND DELIBERATELY SO (R-RA-25 addendum 1): the ONLY destination-hash sources are the
    //   caller's `override_dst_hash` and the two lookups THIS function already performs. No new lookup, no new
    //   override parameter, and in particular the hosted-mobile last-mile enqueue (node_hashlocate.cpp:1820) keeps
    //   its current hash-less shape — putting DST_HASH on those flights is a wire change on corpus-exercised
    //   traffic and would be its own ruled slice. A genuine by-ID send to an id we hold no binding for therefore
    //   still airs WITHOUT DST_HASH — and gains not one byte of extra body for it.
    uint32_t dh = 0;
    if (override_dst_hash) {                                    // §mobile 3c: carry the QUERIED (mobile) hash M so the home last-mile-forwards (dst_hash != home's key) instead of consuming
        dh = override_dst_hash; item.flags |= DATA_FLAG_DST_HASH;
    } else if (app_dm && (key_hash_of_id(dst, dh) || team_key_of_id(dst, dh))) {   // §enc: a team peer's key isn't in _id_bind (static plane) -> fall back to the team-scoped key cache so an ENCRYPTED send BY team_local_id gets DST_HASH (and a plaintext team DM gains verify-on-delivery). team_key_of_id is false for a static node / non-team-peer dst -> s18 byte-identical.
        item.flags |= DATA_FLAG_DST_HASH;
    }
    if (app_dm) item.flags |= DATA_FLAG_SOURCE_HASH;            // R-RA-25: MANDATORY on every application carrier
    // E2E SEAL (Phase 1 §4): when this node originates an app DM with e2e_dm on, the inner is SEALED (CRYPTED).
    // CRYPTED requires the cleartext dst_key_hash32 (DST_HASH) AND the recipient's AUTHORITATIVE pubkey. If either
    // is missing -> FAIL LOUD (emit e2e_no_pubkey, do NOT enqueue — NEVER cleartext). [#38b: park + HARD WANT_PUBKEY.]
    // §8b: per-message crypt — `def` follows the node's e2e_dm; `on`/`off` force this single DM CRYPTED/plain.
    // (s18: a default send with e2e_dm off -> want_crypt=false -> plain, byte-identical to before.)
    // ★ §loc-per-send (2026-07-31): HOISTED above the LOCATION gate below, which needs to know whether this DM will be
    // sealed BEFORE it decides. One expression, read by both (U1) — it used to be computed *after* the location gate,
    // which is the structural reason register-B0's leak existed at all: the gate could not have consulted it.
    const bool want_crypt = (crypt == CryptIntent::on)  ? true
                          : (crypt == CryptIntent::off) ? false
                                                        : _cfg.e2e_dm;
    // The one and only condition under which this frame's inner is SEALED (the `if` that guards the seal block below).
    // Named once so the LOCATION gate and the seal cannot disagree about what "sealed" means.
    const bool will_seal = app_dm && want_crypt;
    // ★★ LOCATION — a PER-SEND request (`send -l`), 2026-07-31 §loc-per-send / open-bug-register B0. Originally an
    // opt-in CONFIG toggle (2026-06-14 spec §3) gated on `app_dm && _cfg.loc_in_dm && has-a-fix && it-fits` — with NO
    // crypt check, and `want_crypt` computed BELOW it — so a PLAINTEXT DM from a node with the toggle on aired a 6-B
    // position IN THE CLEAR (frame_codec.cpp's unsealed pack path). That was a LIVE privacy leak, and the toggle is
    // gone: `NodeConfig::loc_in_dm`, `cfg set loc_dm`, the NV field and the app-facing binary TLV were all removed.
    // The intent now rides the caller's DATA_FLAG_LOCATION bit (console `-l` -> Command.u.send.flags -> do_send ->
    // here); `item.flags = flags` above has already copied it, so this gate's whole job is to VALIDATE OR REFUSE.
    // TWO REFUSALS here, both loud (C2), because the operator EXPLICITLY asked to share a position and must never be
    // left believing one was shared when it was not (owner ruling 2026-07-30: refuse the send — do not silently omit
    // the location, and never send it in clear):
    //   (1) the DM will NOT be sealed  -> `unsealable`   — THE fix. The remedy is `-e`, `cfg set e2e_dm 1`, or
    //                                                      acquiring the peer's key (`reqpubkey`/QR). There is no
    //                                                      "turn location off" escape to advertise any more, because
    //                                                      there is no longer anything to turn off.
    //   (2) no fix ((0,0))             -> `no_location`  — you asked for a position and this node has none.
    // Ordering is deliberate: the CONFIDENTIALITY refusal is tested first, so a `-l` send that is both unsealed and
    // fix-less reports the leak it would have caused rather than the missing fix.
    // ★★ (3) — "the +6 B does not fit" — HAS NO BRANCH HERE, AND THAT IS THE MEASURED RESULT, NOT AN OMISSION.
    // The old code dropped the location SILENTLY when it did not fit (best-effort). Making that loud is the point of
    // the flag, and it now happens STRUCTURALLY one step below instead of in a gate of its own: a `-l` DM is sealed BY
    // CONSTRUCTION (refusal (1)), the 6 bytes go INSIDE e2e_seal_inner's plaintext, and if they do not fit, the SEAL
    // fails `SealOutcome::too_large` -> `push_send_failed(too_large)` and the WHOLE SEND is refused. Nothing is ever
    // dropped quietly, which is exactly the guarantee that was wanted.
    // ⇒ A DEDICATED gate here would be DEAD CODE. Measured by sweeping body_len 200..239 through this very function
    // (sealed, DST_HASH+SOURCE_HASH set, cap = max_payload_bytes_hard_cap = 241):
    //     a `-l` send airs up to body_len 208 and is refused `too_large` from 211 up — BY THE SEAL, whose bound is
    //     4 (aad) + 1 (origin) + 4 (source_hash) + 6 (loc) + body + 16 (tag) <= 241  ⇒  body <= 210;
    //     an unsealed-layout gate here would test after_origin + 4 + 6 + body <= 241 ⇒ body <= 226, i.e. it could only
    //     ever fire ABOVE 226 — 16 bytes past where the seal has already refused. It can never be reached.
    // And it must NOT be "fixed" by re-deriving the sealed bound here: that would fork a SECOND copy of the seal's size
    // arithmetic (U1) purely to improve an error string. ⓘ THE MEASURED NUMBERS ABOVE (208 / 214) ARE THE **FIXED**
    // ONES. They were written when the cap handed to e2e_seal_inner was 241 and two silent bands sat just above them;
    // both are CLOSED as of 2026-08-28 and the sweep now shows exactly two outcomes per length, air or a loud refusal:
    //   (a) [[B20]] body_len 215-216 (209-210 with `-l`) — e2e_seal_inner USED to succeed (inner <= 241) while the
    //       assembled CRYPTED frame, 8 (hdr) + inner + 8 (nonce-seed trailer), exceeded lora_max_frame_bytes, so
    //       pack_data refused at TX time and NO send_failed was pushed at all. Root cause: max_payload_bytes_hard_cap
    //       subtracts data_inner_overhead = 6 (a 4-byte MAC) while a CRYPTED trailer is 8, so the cap was 2 B too
    //       generous for a sealed DM. FIXED at the seal call below by passing `data_inner_cap(item.flags, type)` —
    //       the packer's own bound — instead of the buffer's size; the band now refuses `too_large` like 217 does.
    //   (b) [[B21]] body_len 237-239 — the DST_HASH fit-check above drops the flag for SIZE, so the
    //       `!(item.flags & DATA_FLAG_DST_HASH)` branch below fired. It emitted `e2e_no_pubkey` (a key we HELD) and
    //       returned WITHOUT push_send_failed. FIXED at that branch: it now splits on `dh` and pushes on both arms.
    // ⚠ A seal can also fail for non-size reasons (no_pubkey / no_identity / bad_rng). Those refuse loud on their own and
    // report the SEAL cause — NOT this rule — which is what the operator needs to chase.
    if (flags & DATA_FLAG_LOCATION) {
        if (!will_seal) {                                        // (1) would air the position in CLEAR -> REFUSE
            MR_EMIT("location_refused", EF_I("dst", dst), EF_I("ctr", ctr), EF_S("reason", "unsealed"));
            if (generic_lifecycle) push_send_failed(SendFailReason::unsealable, dst, ctr);   // §CUSTODY-B §6.2(5)
            return ctr;                                          // not enqueued — matches the sibling CRYPTED refusals (return ctr so the app correlates)
        }
        if (_cfg.lat_e7 == 0 && _cfg.lon_e7 == 0) {              // (2) no fix -> REFUSE (never send the position-less DM silently)
            MR_EMIT("location_refused", EF_I("dst", dst), EF_I("ctr", ctr), EF_S("reason", "no_fix"));
            if (generic_lifecycle) push_send_failed(SendFailReason::no_location, dst, ctr);   // §CUSTODY-B §6.2(5)
            return ctr;
        }
    }
    // §team-ch-key T-K3 (C2): a TEAM KEY GRANT carries a PRIVATE key in its body, so it may leave this node ONLY
    // sealed. Enforced HERE, at the one choke point every same-layer origination passes, rather than trusting each
    // caller: team_key_grant_send already forces CryptIntent::on, but a future caller passing `def` on a node with
    // e2e_dm OFF would otherwise air the team's content key in the clear. Refuse the whole send — there is no
    // cleartext fallback for this type, ever. (The sibling refusals: enqueue_cross_layer, and send_by_hash's
    // delegate branch. Together they make "a TEAM_KEY_GRANT frame is always sealed" structural instead of conventional.)
    if (type == DATA_TYPE_TEAM_KEY_GRANT && !want_crypt) {
        MR_EMIT("team_key_grant_refused", EF_I("dst", dst), EF_S("reason", "plaintext"));
        // §CUSTODY-B §6.2(5): the grant is INTERNAL, so `generic_lifecycle` is false here BY CONSTRUCTION and this
        // push is now unreachable — the loud emit above and `TeamKeyGrantTx`'s own typed answer carry the refusal.
        if (generic_lifecycle) push_send_failed(SendFailReason::unsealable, dst, /*ctr=*/0);
        return 0;   // ⚠ 0, unlike the sibling CRYPTED refusals below which `return ctr` so the app can correlate: this
                    // one is UNREACHABLE from the only caller (team_key_grant_send forces CryptIntent::on), so there is
                    // no in-flight handle to correlate — a non-zero ctr here would read to that caller as "airborne".
    }
    if (will_seal) {   // §loc-per-send: `app_dm && want_crypt`, named once above so the LOCATION gate tests the SAME condition (U1)
        if (!(item.flags & DATA_FLAG_DST_HASH)) {                          // no dst hash -> can't derive the nonce/key
            // ★★ §B21 (2026-08-28) — **TWO DIFFERENT CONDITIONS LAND HERE AND THE ARM REPORTED ONE OF THEM FOR
            // BOTH, ASYNCHRONOUSLY REPORTING NEITHER.** `dh` is written by the DST_HASH lookup above BEFORE the
            // (then-present) size term was evaluated (`&&` short-circuits left-to-right), so it distinguishes them:
            //   · dh == 0 — the lookup FAILED: we hold no key for `dst`. `no_pubkey` is TRUE; the remedy is
            //               `reqpubkey`/a QR scan. This is the arm the old emit named.
            //   · dh != 0 — the lookup SUCCEEDED and the **fit** term `4 + 1 + body_len <= 241` failed, i.e. from
            //               body_len 237 up the DST_HASH flag was dropped for SIZE. The key is fine; the body is
            //               too big. Reporting `no_pubkey` sent the operator after a key he already had.
            // ★ AND BOTH ARMS NOW **PUSH**. Neither did: this `return ctr` was the only refusal in the whole seal
            // block without a `push_send_failed`, so its sibling `SealOutcome::no_pubkey` twenty lines below
            // reported to the app while this one did not. That silence was the second half of B21.
            // ⛔⛔ STATE-OF-PLAY 2026-09-05 (Slice 0h / R-RA-25), stated IN CODE rather than left to be rediscovered:
            //   **the `key_known == true` arm is now UNREACHABLE, BY CONSTRUCTION, and it is KEPT anyway.** The size
            //   term that produced it is gone ([[B296]]): `dh != 0` now implies `DATA_FLAG_DST_HASH` is set, so a
            //   frame entering this branch necessarily has `dh == 0`. ⓘ Nothing is lost — the condition it reported
            //   (`too_large`) is now answered EARLIER and more loudly: `on_command` refuses body > 232 synchronously,
            //   and the seal's own `SealOutcome::too_large` (twenty lines below) still owns every shape it admits.
            //   ⛔ It is NOT deleted here: removing a live-looking refusal is a separate decision from the field
            //   ruling (C1), and the branch remains the honest answer if a future caller ever reaches this function
            //   with DST_HASH cleared while holding a key. ⚠ Consequence for the tests: the §B21 237/238/239 band
            //   now refuses at the COMMAND boundary (no ctr, no push), and `test_node_r3.cpp` says so in place.
            const bool key_known = (dh != 0);
            if (key_known) {
                MR_EMIT("e2e_seal_too_large", EF_I("dst", dst), EF_I("ctr", ctr), EF_I("body_len", body_len));
                if (generic_lifecycle) push_send_failed(SendFailReason::too_large, dst, ctr);   // §CUSTODY-B §6.2(5)
            } else {
                MR_EMIT("e2e_no_pubkey", EF_I("dst", dst), EF_I("ctr", ctr), EF_I("reason_no_dst_hash", 1));
                if (generic_lifecycle) push_send_failed(SendFailReason::no_pubkey, dst, ctr);   // §CUSTODY-B §6.2(5)
            }
            return ctr;                                                    // not enqueued (fail loud, no cleartext)
        }
        item.flags |= DATA_FLAG_CRYPTED;                                   // SOURCE_HASH (+ the per-send LOCATION, validated above) already decided
        uint8_t seed[8];
        SealOutcome oc = SealOutcome::ok;
        // ★★ §B20 (2026-08-28) — **THE CAP IS THE FRAME'S, NOT THE BUFFER'S.** This argument was
        // `sizeof item.inner` (== protocol::max_payload_bytes_hard_cap, 241), a constant derived from the 4-B MAC.
        // The flag ORed in one line above makes this frame CRYPTED, whose trailer is **8**, so pack_data can carry
        // only `data_inner_cap(item.flags, type)` — 239, or 238 once a TYPE byte is emitted. Those 2 (or 3) bytes
        // WERE register [[B20]]: the seal accepted a 215/216-B body, pack_data refused it at TX time
        // (node_mac.cpp's `dlen == 0` bail), and the app was told NOTHING — the send simply vanished after the RTS
        // had already burned airtime. Asking the packer's own formula refuses at the EXACT carrier boundary for
        // EVERY shape (typed/untyped, located or not) instead of at one hand-written number, and the refusal is
        // the seal's existing loud one: SealOutcome::too_large -> send_failed{too_large}, nothing enqueued.
        // ⓘ BOTH bounds are kept and the STRICTER wins: `data_inner_cap` is "what fits on the air",
        // `sizeof item.inner` is "what fits in the carrier's buffer". They answer different questions; today the
        // frame bound is the tighter one for a CRYPTED DM and the buffer bound is the tighter one if the frame
        // budget ever grows. Neither may be dropped for being redundant right now.
        const size_t frame_cap = data_inner_cap(item.flags, type);
        const size_t seal_cap  = frame_cap < sizeof item.inner ? frame_cap : sizeof item.inner;
        const size_t n = e2e_seal_inner(item.inner, seal_cap, seed, item.flags, dh, item.origin, ctr,
                                        _key_hash32, _cfg.lat_e7, _cfg.lon_e7, body, body_len, oc);   // §mobile: item.origin (stamp_origin) = home_id for a registered mobile so the SEALED inner origin is the ROUTABLE home, not our node_id (== _node_id for a static node -> byte-identical). The reverse-ack routes to this origin.
        if (n == 0) {                                                      // seal failed -> FAIL LOUD distinctly, NEVER cleartext
            switch (oc) {
                case SealOutcome::no_pubkey:                               // E2E §5: NO auto-query. Key acquisition is USER-driven:
                    MR_EMIT("e2e_no_pubkey", EF_I("dst", dst), EF_I("ctr", ctr), EF_I("hash", static_cast<int64_t>(dh)));  // warn + drop; the
                    if (generic_lifecycle) push_send_failed(SendFailReason::no_pubkey, dst, ctr);       // §CUSTODY-B §6.2(5); user
                    break;                                                 // requests on-air (reqpubkey) or scans a QR (peerkey). NEVER cleartext.
                case SealOutcome::no_identity:                            // R3: no crypto identity -> fail loud, no flood
                    MR_EMIT("e2e_no_identity", EF_I("dst", dst), EF_I("ctr", ctr));
                    if (generic_lifecycle) push_send_failed(SendFailReason::no_identity, dst, ctr);   // §CUSTODY-B §6.2(5)
                    break;
                case SealOutcome::too_large:                              // R2: oversize for CRYPTED -> fail loud + send_failed, NO flood
                    MR_EMIT("e2e_seal_too_large", EF_I("dst", dst), EF_I("ctr", ctr), EF_I("body_len", body_len));
                    if (generic_lifecycle) push_send_failed(SendFailReason::too_large, dst, ctr);   // §CUSTODY-B §6.2(5)
                    break;
                case SealOutcome::bad_rng:                                // R7: crypto RNG returned a degenerate seed -> fail loud, no flood
                    MR_EMIT("e2e_bad_rng", EF_I("dst", dst), EF_I("ctr", ctr));
                    if (generic_lifecycle) push_send_failed(SendFailReason::bad_rng, dst, ctr);   // §CUSTODY-B §6.2(5)
                    break;
                // §w4-switchenum (2026-07-26): cross_layer/ok are now EXPLICIT (was `default:`) so -Wswitch guards this
                // mapping. Verified at source, and the two are NOT unreachable for the same reason:
                //   • cross_layer IS a genuine n==0 outcome of e2e_seal_inner (node_hashlocate.cpp:381-382 sets it
                //     FIRST, then returns 0 on DATA_FLAG_CROSS_LAYER). It cannot arrive HERE only because no
                //     enqueue_data caller passes CROSS_LAYER — the cross-layer paths build their TxItem directly
                //     (node_mac.cpp:322 enqueue_cross_layer / :498 the mobile-XL wrapper) and never seal. A future
                //     caller threading CROSS_LAYER into enqueue_data would land here, hence: keep failing loud.
                //   • ok is unreachable by ARITHMETIC: e2e_seal_inner sets it only beside `return total`, and
                //     total = 4 (aad) + pt_len>=1 + 16 (tag) > 0, so oc==ok implies n!=0 and this block is skipped.
                // Same emit as the old default -> byte-identical. oc is a local written only by e2e_seal_inner (no
                // cast from an external integer), so dropping `default:` removes no reachable path.
                case SealOutcome::cross_layer:
                case SealOutcome::ok:
                    MR_EMIT("e2e_seal_failed", EF_I("dst", dst), EF_I("ctr", ctr));
                    break;
            }
            return ctr;                                                    // not enqueued, never cleartext
        }
        item.inner_len = static_cast<uint8_t>(n);
        for (int i = 0; i < 8; ++i) item.nonce_seed[i] = seed[i];
    } else {
        const size_t plain_n =
            pack_unicast_inner(std::span<uint8_t>(item.inner, sizeof item.inner), item.flags, dh,
                               /*layer_ids*/ nullptr, /*n_layers*/ 0, /*cur*/ 0, item.origin,   // §mobile: item.origin (stamp_origin) = home_id for a registered mobile -> the INNER origin is the ROUTABLE home, so the target's E2E-ack routes to the home (which last-miles it), not to our static-invisible node_id. == _node_id for a static node -> s18 byte-identical.
                               override_source_hash ? override_source_hash : _key_hash32,   // §mobile delegate: the HOME re-originating for its mobile stamps SOURCE_HASH = the mobile's hash so the target's E2E-ack routes back to the mobile (0 = our own hash, byte-identical)
                               body, body_len, _cfg.lat_e7, _cfg.lon_e7);   // ✖ MISSING / DEAD BY CONSTRUCTION (§loc-per-send): this is the UNSEALED arm, and the
                                                                            // LOCATION gate above REFUSES any `-l` send that would land here, so pack_unicast_inner
                                                                            // can no longer see DATA_FLAG_LOCATION on a DM and never writes these two. The lat/lon
                                                                            // args are RETAINED deliberately: pack_unicast_inner is SHARED (frame_codec.cpp's
                                                                            // unsealed LOCATION pack path is still live for its other callers/tests), so removing
                                                                            // the parameter here is a codec cleanup slice of its own, not part of the leak fix (C1).
        // ★★★ R-RA-25 / [[B296]] shape 3 — **THE PLAINTEXT ARM NOW CHECKS ITS PACKER, LIKE EVERY SIBLING DOES.**
        //   This return value was DISCARDED. `pack_unicast_inner` answers 0 on overflow, so a wrapper body that no
        //   longer fit its own inner was stored as `inner_len = 0`, ADMITTED to the queue, and aired an RTS — after
        //   which `pack_data` refused and the TX-time `dlen == 0` bail (:2232) dropped it, deliberately silently
        //   ([[B268]]). "A success that isn't", one layer down. ⛔ A zero-length inner is never admitted again.
        // ⓘ THE OWNERSHIP IS THE SEALED SIBLING'S, COPIED DELIBERATELY AND NOT INVENTED (the `if (key_known)` / `SealOutcome::too_large` arms above): a named
        //   cause-specific emit ALWAYS, `push_send_failed(too_large)` only when this TYPE owns the generic user-send
        //   lifecycle (§CUSTODY-B §6.2(5) — an INTERNAL type must not get an orphan `send_failed`), the minted `ctr`
        //   RETURNED so the app can correlate the refusal with its handle, and NOTHING enqueued or pumped.
        // ⓘ `too_large` is the TRUE and ONLY condition here, unlike the TX-time bail: `pack_unicast_inner`'s single
        //   failure mode is the size term (`frame_codec.cpp` — it computes the prefix, then refuses when
        //   prefix + body exceeds the span), so this is not [[B21]]'s "confident, wrong condition" repeated.
        if (plain_n == 0) {
            MR_EMIT("dm_inner_too_large", EF_I("dst", dst), EF_I("ctr", ctr), EF_I("body_len", body_len),
                    EF_I("flags", item.flags), EF_I("type", type));
            if (generic_lifecycle) push_send_failed(SendFailReason::too_large, dst, ctr);   // §CUSTODY-B §6.2(5)
            return ctr;                                                    // not enqueued, no RTS, no zero inner
        }
        item.inner_len = static_cast<uint8_t>(plain_n);
    }
    item.enqueue_time_ms = _hal.now();                   // first-enqueue time (cascade-requeue total-age cap)
    // Inc 3 back-off: a warn'd ACK (a downstream neighbour says we're near its airtime cap) parks new DM
    // originations until the warn window expires, relieving that neighbour. The hard receiver-side airtime
    // drop is the backstop; this is the polite sender-side half. next_attempt_ms gates the dequeue.
    if (_ack_warn_until > _hal.now()) {
        item.next_attempt_ms = _ack_warn_until;
        MR_EMIT("origination_backoff_ack_warn", EF_I("origin", item.origin), EF_I("dst", item.dst),
                EF_I("ctr", item.ctr), EF_I("until_ms", _ack_warn_until));
    }
    // NAV companion (nav_enabled): jitter a fresh own-DM origination by rand(0, retry_jitter) so two nodes
    // originating at the same moment don't fire their RTS in the same airtime window — the one collision NAV
    // can't prevent (no RTS is decoded, so neither sets the other's NAV). App DMs only (E2E acks are responses).
    if (app_dm && _cfg.nav_enabled) {
        const uint64_t base = item.next_attempt_ms > _hal.now() ? item.next_attempt_ms : _hal.now();
        item.next_attempt_ms = base + static_cast<uint32_t>(_hal.rand_range(0, static_cast<int>(retry_jitter_ms()) + 1));
    }
    // ★★★★ §UI-16 N6b (2026-08-24) — THE ADMISSION IS NOW **REPORTED**, AND ⛔ NOTHING ELSE HERE MOVED. The
    //      condition, the store, the emit and the returned `ctr` are BYTE-FOR-BYTE the pre-existing behaviour: a
    //      full queue still drops the frame silently and still returns the minted counter, because changing that
    //      is a behaviour change and this slice is not one (C1). What changed is that the `if`'s own answer — the
    //      fact this function has always computed and always discarded — is handed to a caller that asked for it.
    // ⛔ THE `ctr` IS NOT THE ADMISSION AND NEVER WAS: it is minted at :154, above every bail, so a dropped frame
    //    carries a perfectly ordinary non-zero handle. That is the exact misreading N6's first cut inherited.
    const bool admitted = _active->_tx_queue_n < kTxQueueCap;
    if (admitted) _active->_tx_queue[_active->_tx_queue_n++] = item;
    if (out_dispatch) {
        out_dispatch->admit = admitted ? SendDispatch::Admit::queued : SendDispatch::Admit::refused;
        out_dispatch->dst   = item.dst;   // ★ the SEND-TIME resolved id — the same value push_send_aired_if_owned reports
        // ⓘ ZEROING THE HANDLE ON A REFUSAL IS **DEFENCE IN DEPTH, AND IT IS MEASURED AS SUCH, ⛔ NOT CLAIMED AS
        //   TESTED** (the `push_send_aired_if_owned` `inner_len < 6` precedent): its mutation — publish `ctr`
        //   unconditionally — leaves the native suite GREEN, because `team_key_grant_send` writes `out_ctr` /
        //   `out_dst` ONLY on the `queued` arm, so no public seam can observe a handle attached to a refused
        //   dispatch. It stays because a future consumer reading `dsp` directly must not find one.
        out_dispatch->ctr   = admitted ? ctr : uint16_t{0};   // ⛔ a refused frame has NO flight, so it gets NO handle
    }
    MR_EMIT(tx_event, EF_I("origin", item.origin), EF_I("dst", item.dst),
            EF_I("ctr", item.ctr), EF_I("depth", _active->_tx_queue_n));
    // ★ E2E-ack DEADLINE (shelf item (i)): a same-layer -a ORIGINATION arms an emit-free deadline (byte-neutral when the
    // ack arrives). SKIP the home re-originating for a mobile (override_source_hash!=0 — the MOBILE awaits the ack, not us)
    // and the ack itself (type==E2E_ACK). A DELEGATED wrapper (MOBILE_SEND) or a hosted-mobile last-mile (addr_len==1) can
    // have its reverse-ack return same-layer OR cross-layer after a home/gateway hop -> wildcard key=0 + the larger tier.
    if (app_dm && (flags & DATA_FLAG_E2E_ACK_REQ) && override_source_hash == 0 && type != DATA_TYPE_E2E_ACK) {
        const bool delegated = (type == DATA_TYPE_MOBILE_SEND) || (addr_len == 1);
        e2e_ack_arm(/*key=*/delegated ? 0u : dst, /*is_xl=*/false, /*dst=*/delegated ? uint8_t{0} : dst, ctr,
                    delegated ? protocol::e2e_ack_deadline_xl_ms : protocol::e2e_ack_deadline_ms);
    }
    become_free();
    return ctr;
}

// ---- E2E-ack DEADLINE (shelf item (i), 2026-07-24) -------------------------------------------------------------------
// The positive-only e2e receipt gains a firmware patience budget: ARM (emit-free) when a -a send mints its ctr, CLEAR
// (emit-free) on the matching send_e2e_acked, EXPIRE -> send_failed{e2e_ack_timeout}. Timer = ONE earliest-deadline
// one-shot re-armed on change (the park_reflood_arm idiom). Derivation + the contract semantic: protocol_constants.h.
bool Node::e2e_ack_ring_full() const {
    for (uint8_t i = 0; i < cap_pending_e2e_acks; ++i) if (!_pending_e2e_acks[i].used) return false;
    return true;
}

void Node::e2e_ack_arm(uint32_t key, bool is_xl, uint8_t dst, uint16_t ctr, uint32_t budget_ms) {
    for (uint8_t i = 0; i < cap_pending_e2e_acks; ++i) {
        PendingE2eAck& e = _pending_e2e_acks[i];
        if (e.used) continue;
        e.key = key; e.is_xl = is_xl; e.dst = dst; e.ctr = ctr; e.used = true;
        e.deadline_ms = _hal.now() + budget_ms;
        e2e_ack_deadline_arm_timer();
        return;
    }
    // Full at ARM time: the command path already pre-refuses an app -a send (err_ack_ring_full); only a parked-send drain
    // can reach here saturated. Skip tracking (the send still flew — reverts to today's silence) LOUD, NEVER evict-oldest.
    MR_EMIT("e2e_ack_untracked_ring_full", EF_I("dst", dst), EF_I("ctr", ctr));
}

void Node::e2e_ack_clear(uint8_t acker_origin, uint16_t acked_ctr, uint32_t sender_hash) {
    // Mirror EXACTLY what send_e2e_acked carries {dst=acker origin, ctr=acked, sender_hash} (node_mac_rx.cpp): an XL ack
    // has sender_hash set -> match key==sender_hash; a same-layer ack has sender_hash==0 -> match dst==acker origin; a
    // wildcard entry (key==0, delegated) matches on ctr alone (its reverse-ack can arrive same-layer OR XL). A LATE ack
    // (after expiry) finds no entry -> harmless no-op (no double-free / stale slot).
    for (uint8_t i = 0; i < cap_pending_e2e_acks; ++i) {
        PendingE2eAck& e = _pending_e2e_acks[i];
        if (!e.used || e.ctr != acked_ctr) continue;
        bool hit;
        if      (e.key == 0) hit = true;                                    // wildcard (delegated) — ctr alone
        else if (e.is_xl)    hit = (sender_hash != 0 && e.key == sender_hash);
        else                 hit = (sender_hash == 0 && e.key == acker_origin);
        if (hit) { e.used = false; e2e_ack_deadline_arm_timer(); return; }
    }
}

void Node::e2e_ack_deadline_arm_timer() {
    uint64_t earliest = ~0ull;
    for (uint8_t i = 0; i < cap_pending_e2e_acks; ++i)
        if (_pending_e2e_acks[i].used && _pending_e2e_acks[i].deadline_ms < earliest) earliest = _pending_e2e_acks[i].deadline_ms;
    if (earliest == ~0ull) { _hal.cancel(kE2eAckDeadlineTimerId); return; }
    const uint64_t now = _hal.now();
    (void)_hal.after(earliest > now ? static_cast<uint32_t>(earliest - now) : 0, kE2eAckDeadlineTimerId);
}

void Node::e2e_ack_deadline_fire() {
    const uint64_t now = _hal.now();
    for (uint8_t i = 0; i < cap_pending_e2e_acks; ++i) {
        PendingE2eAck& e = _pending_e2e_acks[i];
        if (!e.used || e.deadline_ms > now) continue;
        // The -a send's DATA_TYPE_E2E_ACK never returned within the budget. SEMANTIC: delivery was never CONFIRMED (not
        // that it failed) — the DM may have arrived + the ack died returning; a LATE ack still fires send_e2e_acked (this
        // entry is already gone -> that clear is a harmless no-op). Mirror the existing send_failed emit+push shape.
        MR_EMIT("send_failed", EF_I("dst", e.dst), EF_I("ctr", e.ctr), EF_S("reason", "e2e_ack_timeout"));
        push_send_failed(SendFailReason::e2e_ack_timeout, e.dst, e.ctr);
        e.used = false;
    }
    e2e_ack_deadline_arm_timer();
}

// E2E/PRIORITY ride the wire via `flags`; the E2E ACK behaviour lives in do_post_ack + send_e2e_ack.
uint16_t Node::do_send(uint8_t dst, const uint8_t* body, uint8_t body_len, uint8_t flags, CryptIntent crypt, uint32_t override_dst_hash, uint8_t type, uint32_t override_source_hash, Plane plane, SendDispatch* out_dispatch) {
    return enqueue_data(dst, body, body_len, flags, "tx_enqueue", /*app_dm=*/true, type, crypt, override_dst_hash, override_source_hash, /*addr_len=*/0, plane, out_dispatch);   // app DM (dm_delivery record key); DST_HASH default-on (or the §3c mobile override); §mobile delegate: type/override_source_hash for MOBILE_SEND + the home re-originate; Wave 2: plane forced by the caller
}

// ---- Slice 4d: cross-layer DM origination -------------------------------------------------------------------
// Two-pass gateway selection (Lua select_gateway_for_layer dv:5168). A gateway "bridges target_leaf" if a 1-hop
// _gw_schedules record serves it OR a multi-hop _bridged_layers row (type-4 TLV) maps gw->target_leaf. Pass 1 prefers
// a gw with a LIVE ROUTE (best by fewest hops, then score); Pass 2 falls back to a known-but-unrouted gw (the caller
// enqueues toward it; issue_send's no-route path fires a ROUTE_QUERY). The schedule-defer is the NEXT-HOP's job, NOT
// selection's — `_gw_schedules` is consulted here only for the membership test, never for timing.
uint8_t Node::select_gateway_for_leaf(uint8_t target_leaf) {
    prune_aged_bridged_layers(_hal.now());
    auto bridges_target = [&](uint8_t gw) -> bool {
        if (const GatewaySchedule* s = find_gw_schedule(gw))                                  // 1-hop: direct neighbour's schedule
            for (uint8_t r = 0; r < s->n_rec; ++r) if (s->rec[r].leaf_id == target_leaf) return true;
        for (uint8_t i = 0; i < protocol::cap_bridged_layers; ++i)                            // multi-hop: propagated TLV
            if (_bridged_layers[i].valid && _bridged_layers[i].gw_id == gw && _bridged_layers[i].dest_leaf == target_leaf) return true;
        return false;
    };
    // Pass 1 — a gateway WITH a live route (preferred): best (fewest hops, then best score).
    uint8_t best_gw = 0, best_hops = 0; int16_t best_score = 0;
    for (uint8_t i = 0; i < _active->_rt_count; ++i) {
        const RtEntry& e = _active->_rt[i];
        if (e.dest == _node_id || e.n == 0) continue;
        if (!bridges_target(e.dest)) continue;
        const RtCandidate& pc = e.candidates[0];
        if (best_gw == 0 || pc.hops < best_hops || (pc.hops == best_hops && pc.score > best_score)) {
            best_gw = e.dest; best_hops = pc.hops; best_score = pc.score;
        }
    }
    if (best_gw != 0) return best_gw;
    // Pass 2 — known-to-bridge but UNROUTED (fallback). Direct-neighbour schedule first (no rt route yet)...
    for (uint8_t i = 0; i < protocol::cap_gateway_neighbor_schedules; ++i) {
        const GatewaySchedule& s = _gw_schedules[i];
        if (!s.valid) continue;
        for (uint8_t r = 0; r < s.n_rec; ++r) if (s.rec[r].leaf_id == target_leaf) return s.gw_node_id;
    }
    // ...then a propagated row, WITH the on-layer seen-guard (Lua dv:5234): only trust a TLV entry for a gw we've
    // actually heard on OUR leaf (an authoritative id_bind). Rejects a cross-layer TLV LEAK — a gw that lives on a
    // DIFFERENT leaf whose mapping propagated in via a dual-layer gateway; unreachable from here.
    for (uint8_t i = 0; i < protocol::cap_bridged_layers; ++i) {
        const BridgedLayer& bl = _bridged_layers[i];
        if (!bl.valid || bl.dest_leaf != target_leaf) continue;
        uint32_t kh = 0;
        if (key_hash_of_id(bl.gw_id, kh)) return bl.gw_id;   // heard on our leaf -> trustworthy
    }
    return 0;
}

// Build + enqueue a CROSS_LAYER DM along an explicit layer-path (layer_ids[0..n_layers-1], cursor at `cur` = the
// next layer to enter), routed (MAC dst) to gateway gw_node. The inner carries the FULL path (immutable in transit;
// only the cursor advances, so the destination can reverse it for the 4e E2E ack) + dst_hash + SOURCE_HASH (REQUIRED
// for that reversed ack). pack_unicast_inner's size-first overflow is the cross-layer fit-check (returns 0 -> fail loud).
bool Node::enqueue_cross_layer(uint8_t gw_node, uint32_t dst_hash, const uint8_t* layer_ids, uint8_t n_layers, uint8_t cur, const uint8_t* body, uint8_t body_len, uint8_t flags, uint16_t* out_ctr, uint8_t type, uint32_t override_source_hash) {
    // §CUSTODY-B §6.2(5): the generic user-send lifecycle gate for this origination, from the ONE trait
    // authority. Reachable with an internal type via the same `do_send`-shaped path `enqueue_data` documents
    // (the TEAM_KEY_GRANT refusal below IS that case). Cause-specific emits stay; only the generic push goes.
    const bool generic_lifecycle = data_type_traits(type).generic_send_lifecycle;
    // §S4: the old v1 "no cleartext XL when e2e_dm on" choke is LIFTED. Cross-layer confidentiality now rides
    // DATA_TYPE_SEALED_RELAY (a PLAINTEXT-framed frame carrying a SEALED body — routed here like any XL DM), so the
    // no-downgrade guarantee is enforced at the COMMAND level instead (node.cpp send_layer: want_crypt -> the sealed
    // relay, never a cleartext app DM). The only genuinely-cleartext frames reaching here under e2e_dm are the reverse
    // E2E ACK (send_xl_ack) — cleartext BY PARITY with same-layer acks, which already carry (dst_hash, acked_ctr) in
    // clear; sealing acks is out of scope — and the sealed-relay frame itself (confidential content). Both are correct.
    // §team-ch-key T-K3 (C2): a TEAM KEY GRANT may NEVER ride a cross-layer frame in v1. This is not caution — it is
    // arithmetic on the existing crypto core: e2e_seal_inner REFUSES DATA_FLAG_CROSS_LAYER outright
    // (node_hashlocate.cpp:382, "v1: same-layer CRYPTED only"), and this function hard-sets CROSS_LAYER on every frame
    // it builds, so a TEAM_KEY_GRANT arriving here could only ever be CLEARTEXT — i.e. the team's private content key on the
    // air in plain sight. The XL confidentiality substitute, DATA_TYPE_SEALED_RELAY, cannot help: it OCCUPIES the very
    // TYPE byte the grant needs (node.cpp:1304 sets etype = SEALED_RELAY), so a sealed XL grant has nowhere left to say
    // it is a grant. ⇒ REFUSE. ★ The reachable caller is send_by_hash's mobile_home_find cross-layer arm
    // (node_hashlocate.cpp:1083), which drops the CryptIntent entirely — a pre-existing cleartext downgrade for ANY
    // `-e` DM to a mobile whose home sits on another layer, reported to QA and deliberately NOT fixed here (C1).
    if (type == DATA_TYPE_TEAM_KEY_GRANT) {
        MR_EMIT("team_key_grant_refused", EF_I("dst", gw_node), EF_S("reason", "cross_layer"));
        if (generic_lifecycle) push_send_failed(SendFailReason::unsealable, gw_node, /*ctr=*/0);   // §CUSTODY-B §6.2(5): internal ⇒ unreachable; the emit above is the loud refusal
        return false;                                // fail loud, before next_ctr burns a counter
    }
    // ★★ §loc-per-send (2026-07-31, register B0): a CROSS-LAYER frame CANNOT carry a location, so a `-l` send that
    // reaches here is REFUSED — never silently stripped. This is the SAME structural-choke-point idiom as the TEAM_KEY_GRANT
    // guard above, and it exists because the alternative is failure mode (2) of the owner's ruling: "the app believes it
    // shared a position it did not." Two independent reasons XL cannot carry it, both verified at source, not assumed:
    //   (a) PLAINTEXT XL — the `item.flags` assignment below MASKS the caller's word down to
    //       CROSS_LAYER|DST_HASH|SOURCE_HASH|E2E_ACK_REQ, and pack_unicast_inner is called with lat/lon = 0 ("v1 scope:
    //       cross-layer DMs carry NO location"). So DATA_FLAG_LOCATION was ALREADY being dropped here, silently.
    //   (b) SEALED XL — a confidential XL DM rides DATA_TYPE_SEALED_RELAY, whose body is
    //       [seal_ctr 2][seed8 8][ct‖tag] with NO flags word on the wire: build_sealed_relay_body hard-codes the seal
    //       flags to DST_HASH|SOURCE_HASH with lat/lon = 0, and the receiver's e2e_open_relay hard-codes the matching
    //       SOURCE_HASH on the open side. Setting LOCATION on one side only would make the peer read the 6 position
    //       bytes as message TEXT. Carrying it needs a SEALED_RELAY body-format change — its own slice (C1).
    // ✖ MISSING, stated so it is not mistaken for done: `send_layer -l` and a `-l` DM to a peer whose home is on another
    // layer therefore REFUSE rather than work. The command-level twin in node.cpp's send_layer verb refuses earlier (so
    // the operator gets a synchronous error instead of only a push); this one is the backstop every OTHER cross-layer
    // origination passes — notably send_by_hash's mobile_home_find arm, which has no command-level fork of its own.
    if (flags & DATA_FLAG_LOCATION) {
        MR_EMIT("location_refused", EF_I("dst", gw_node), EF_S("reason", "cross_layer"));
        if (generic_lifecycle) push_send_failed(SendFailReason::unsealable, gw_node, /*ctr=*/0);   // §CUSTODY-B §6.2(5)
        return false;                                // fail loud, before next_ctr burns a counter
    }
    TxItem item{};
    const uint16_t ctr = next_ctr(gw_node);          // MAC ctr vs the next-hop gateway (= the e2e (source_hash, ctr) identity)
    // §team-parity T6: EXPLICITLY GLOBAL — decided per-caller, not swept. A cross-layer DM is a STATIC-infrastructure
    // flight by construction: it is MAC-addressed to a bridging GATEWAY (`gw_node`, a global id resolved from
    // _rt/_gw_schedules) and carries an inner layer PATH. There is no team plane above a gateway.
    // ★ PROVEN, not assumed (the reachability audit T6 was asked for): `Plane::TEAM` CANNOT reach this function.
    //   (a) send_by_hash's `if (plane == Plane::TEAM)` block (node_hashlocate.cpp:990) RETURNS in all three arms;
    //   (b) on_command's send_layer verb forks at node.cpp:1261 (`if (_cfg.is_mobile)`) and RETURNS in every arm via
    //       delegate_send_layer — so a mobile, hence EVERY team member (mr_features.h:47 makes MR_FEAT_TEAM imply
    //       MR_FEAT_MOBILE, and a team member is is_mobile), never reaches originate_layer_path;
    //   (c) send_xl_ack forks the same way for a registered mobile (:503).
    //   ⇒ the reachable callers are a STATIC node, a HOME re-originating for its mobile (reply_to_hash != 0), and an
    //   OFF-GRID mobile — and for the last one `mob` is false, so pre-T6 already stamped `_node_id`, which off-grid IS
    //   the team_local_id. So GLOBAL here is VALUE-identical to pre-T6 on every reachable path, not merely inert.
    // Forcing GLOBAL rather than passing AUTO also closes a latent §18 hazard: `gw_node` is an 8-bit id that could
    // numerically collide a teammate's team_local_id, and AUTO would then have stamped our team id on a gateway frame.
    // Static reduction: Plane::GLOBAL ⇒ flight_is_team_plane() false ⇒ the pre-T6 expression verbatim, on every build.
    stamp_origin(item, Plane::GLOBAL, gw_node); item.dst = gw_node; item.ctr = ctr; item.ctr_lo = static_cast<uint8_t>(ctr & 0x0F);
    item.type = type;   // §GapB: a re-originated E2E-ack stamps DATA_TYPE_E2E_ACK (0 = a normal cross-layer DM, byte-identical)
    item.flags = static_cast<uint8_t>(DATA_FLAG_CROSS_LAYER | DATA_FLAG_DST_HASH | DATA_FLAG_SOURCE_HASH
                                      | (flags & DATA_FLAG_E2E_ACK_REQ));   // 4d/e2e: honor the app's E2E-ack request -> Y acks over the reversed path (4e)
    const size_t n = pack_unicast_inner(std::span<uint8_t>(item.inner, sizeof item.inner), item.flags, dst_hash,
                                        layer_ids, n_layers, cur, _node_id,
                                        override_source_hash ? override_source_hash : _key_hash32,   // §GapB delegate: the HOME re-originating for its mobile stamps SOURCE_HASH = the mobile's hash so the far recipient's ack routes back to the mobile (0 = our own hash -> byte-identical)
                                        body, body_len,
                                        /*lat_e7*/ 0, /*lon_e7*/ 0);   // v1 scope: cross-layer DMs carry NO location
                                                                       // (same-layer DM + M only; cross-layer = documented follow-up)
                                                                       // ★ §loc-per-send: this used to be a SILENT drop of the
                                                                       // caller's LOCATION bit; the guard at the top of this
                                                                       // function now REFUSES that send instead, so these two
                                                                       // zeros are reached only with LOCATION provably clear.
    if (n == 0) return false;                         // overflow (228-B body cap with the layer-path) -> fail loud
    item.inner_len = static_cast<uint8_t>(n);
    item.enqueue_time_ms = _hal.now();
    if (_active->_tx_queue_n >= kTxQueueCap) return false;
    _active->_tx_queue[_active->_tx_queue_n++] = item;
    if (out_ctr) *out_ctr = ctr;                     // the app's correlation token (returned in CmdResult.ctr)
    // ★ E2E-ack DEADLINE (cross-layer tier): arm the TRUE originator only. The home re-originating for its mobile passes
    // override_source_hash!=0 (the MOBILE awaits the ack) and send_xl_ack passes type==E2E_ACK (it IS an ack) — both skip.
    // The reversed XL ack is CROSS_LAYER carrying source_hash == dst_hash (the far target's key) -> match by key==sender_hash.
    if ((flags & DATA_FLAG_E2E_ACK_REQ) && override_source_hash == 0 && type != DATA_TYPE_E2E_ACK)
        e2e_ack_arm(/*key=*/dst_hash, /*is_xl=*/true, /*dst=*/0, ctr, protocol::e2e_ack_deadline_xl_ms);
    MR_EMIT("tx_enqueue_xl", EF_I("origin", item.origin), EF_I("dst", gw_node), EF_I("ctr", ctr),
            EF_I("target_layer", layer_ids[cur]), EF_I("depth", _active->_tx_queue_n));   // the next layer to enter (cur < n_layers, caller-guaranteed)
    become_free();                                   // 4a defers the RTS to the gateway's window on our leaf
    return true;
}

// Originate a cross-layer DM: select a bridging gateway (schedule-verified) + enqueue. NO gateway serves the target
// leaf -> err_no_gateway (fail loud, send_failed). A gateway IS known but UNROUTED -> 4d.2 (user 2026-06-13: park +
// reactive ROUTE_QUERY): enqueue anyway; issue_send's no-route path defers the origination (park in _deferred + an
// expanding-ring RREQ for G via emit_route_request) and try_drain_deferred re-flies it when a route to G appears
// (the Lua Pass-2; an EXPLICIT recovery, not a silent fallback — it ages out to send_failed on the deferred TTL).
uint16_t Node::send_cross_layer(uint8_t dst_node, uint32_t dst_hash, uint8_t target_layer, const uint8_t* body, uint8_t body_len, uint8_t flags, CryptIntent crypt, uint8_t type, uint32_t override_source_hash) {
    // §CUSTODY-B §6.2(5): the generic user-send lifecycle gate for this origination, from the ONE trait
    // authority. Reachable with an internal type via the same `do_send`-shaped path `enqueue_data` documents
    // (the TEAM_KEY_GRANT refusal below IS that case). Cause-specific emits stay; only the generic push goes.
    const bool generic_lifecycle = data_type_traits(type).generic_send_lifecycle;
    // ★★ §xl-crypt-intent (2026-07-29) — THE CONFIDENTIALITY FIX. Both callers used to pass no intent at all, so
    // `send 0x<hash> -e` to a mobile whose home sits on another layer aired the text IN THE CLEAR with no refusal.
    // The seal decision lives HERE, at the one choke point every mobile_home_find / parked-XL origination passes,
    // rather than in each caller (the enqueue_data / enqueue_cross_layer / send_by_hash idiom T-K3 established).
    // WHY SEALED_RELAY and not a CRYPTED frame: e2e_seal_inner refuses DATA_FLAG_CROSS_LAYER outright
    // (node_hashlocate.cpp:382 — the crypto core is same-layer-only) and enqueue_cross_layer hard-sets that flag, so a
    // CRYPTED cross-layer frame CANNOT exist. DATA_TYPE_SEALED_RELAY is the existing substitute: a plaintext-FRAMED DM
    // whose BODY is sealed to dst_hash under our own identity, routed/bridged/last-miled exactly like any typed
    // plaintext DM. build_sealed_relay_body seals with flags DST_HASH|SOURCE_HASH (NOT cross-layer), so the refusal
    // above does not apply to it, and enqueue_cross_layer stamps SOURCE_HASH = _key_hash32 — the same hash the seal
    // carries inside — which is what the recipient's directed e2e_open_relay needs. This is byte-for-byte the transport
    // `send_layer -e` already uses (node.cpp CmdKind::send_layer) and s27 exercises end-to-end to a HOSTED mobile.
    // ★★ §xl-deleg-ack (2026-07-30) — THE DELIVERY FIX, and it is the SAME structural failure one layer up: this
    // function used to take no `override_source_hash` either, so the delegation identity was discarded here the way
    // the crypt intent was. It is now MANDATORY and threaded to enqueue_cross_layer (which has always accepted it —
    // originate_layer_path passes it), which also makes enqueue_cross_layer's `override_source_hash == 0` guard skip
    // arming an E2E-ack deadline on the HOME: the MOBILE is the one awaiting that ack, not us. The caller-side half
    // (the ctr_H->ctr_M map) rides the RETURN value; see node_hashlocate.cpp's mobile_home_find arm.
    const bool want_crypt = (crypt == CryptIntent::on)  ? true
                          : (crypt == CryptIntent::off) ? false
                                                        : _cfg.e2e_dm;
    // ★ §xl-deleg-ack, C2 backstop for a combination THIS SLICE made expressible for the first time. Sealing here uses
    // OUR identity (build_sealed_relay_body seals with `_key_hash32`) while override_source_hash puts the MOBILE's hash
    // in the clear SOURCE_HASH — and the recipient's e2e_open_relay derives the ECDH from the CLEAR hash. So
    // "seal as us, claim to be the mobile" produces a frame that can never open: a Poly1305 tag failure and a SILENT
    // drop, i.e. the very outcome this slice exists to remove. UNREACHABLE TODAY, measured: the only caller passing a
    // non-zero override_source_hash is node_mac_rx.cpp's delegated re-origination, which hard-codes CryptIntent::off
    // (the MOBILE already sealed). Refuse loud rather than emit an unopenable frame if that line ever changes.
    if (want_crypt && override_source_hash != 0) {
        MR_EMIT("xl_send_deleg_seal_conflict", EF_I("target_layer", target_layer),
                EF_I("src_hash", static_cast<int64_t>(override_source_hash)));
        if (generic_lifecycle) push_send_failed(SendFailReason::unsealable, dst_node, /*ctr=*/0);   // §CUSTODY-B §6.2(5)
        return 0;
    }
    // sbody/sblen/stype = what actually flies (send_by_hash's own idiom, U3). `rbody` is STACK, not `static`: the seal
    // arm is unreachable from the cramped do_post_ack frame (ADDENDUM 4) — its only caller there is the home's delegated
    // re-origination, which passes CryptIntent::off — so the deep frame only occurs on the on_command path, where
    // node.cpp's send_layer already seals into a same-sized stack buffer. A `static` would cost 255 B of RAM per build.
    const uint8_t* sbody = body; uint8_t sblen = body_len; uint8_t stype = type;
    uint8_t rbody[protocol::max_payload_bytes_hard_cap];
    if (want_crypt) {
        // A TYPED send cannot also be a SEALED_RELAY: the frame has ONE type byte and the relay spends it (the same
        // arithmetic T-K3 recorded for the team key grant). REFUSE — never downgrade to cleartext, never strip the type.
        // The one type reachable here today is DATA_TYPE_TEAM_KEY_GRANT (team_key_grant_send forces CryptIntent::on);
        // it was already refused one level down by enqueue_cross_layer's TEAM_KEY_GRANT guard, which stays as the backstop for
        // originate_layer_path. This guard generalises it to EVERY type, so a future typed+crypted XL send cannot leak.
        if (type != 0) {
            MR_EMIT("xl_send_unsealable", EF_I("type", type), EF_I("target_layer", target_layer),
                    EF_I("dst_hash", static_cast<int64_t>(dst_hash)));
            if (generic_lifecycle) push_send_failed(SendFailReason::unsealable, dst_node, /*ctr=*/0);   // §CUSTODY-B §6.2(5)
            return 0;
        }
        SealOutcome oc = SealOutcome::ok;
        const uint8_t rn = build_sealed_relay_body(dst_hash, body, body_len, rbody, sizeof rbody, oc);
        if (rn == 0) {                               // no pubkey / no identity / too large / bad rng -> FAIL LOUD, NEVER cleartext
            MR_EMIT("e2e_xl_seal_failed", EF_I("dst_hash", static_cast<int64_t>(dst_hash)), EF_I("oc", static_cast<int>(oc)));
            if (generic_lifecycle)   // §CUSTODY-B §6.2(5)
            push_send_failed((oc == SealOutcome::no_pubkey)   ? SendFailReason::no_pubkey
                           : (oc == SealOutcome::no_identity) ? SendFailReason::no_identity
                           : (oc == SealOutcome::bad_rng)     ? SendFailReason::bad_rng
                                                              : SendFailReason::too_large,
                             dst_node, /*ctr=*/0);
            return 0;
        }
        sbody = rbody; sblen = rn; stype = DATA_TYPE_SEALED_RELAY;   // fall into the SINGLE gateway-select/enqueue tail
    }
    const uint8_t target_leaf = static_cast<uint8_t>(target_layer & 0x0F);
    const uint8_t gw = select_gateway_for_leaf(target_leaf);
    if (gw == 0) {                                   // no gateway serves the target leaf at all -> fail loud
        MR_EMIT("xl_send_no_gateway", EF_I("target_layer", target_layer), EF_I("dst_hash", static_cast<int64_t>(dst_hash)));
        if (generic_lifecycle) push_send_failed(SendFailReason::no_route, dst_node, /*ctr=*/0);   // §CUSTODY-B §6.2(5)
        return 0;
    }
    // gw != 0: enqueue regardless of route. A live route -> issue_send fires (4a defers to G's window). No route ->
    // issue_send -> defer_send parks it + RREQs G (4d.2 park+reactive), re-flown by try_drain_deferred on the route.
    const uint8_t ids[2] = { active_layer_id(), target_layer };   // the 2-element path [our_layer, target_layer], cur=1
    // §xl-deleg-ack: out_ctr was `nullptr` — the ctr the DM actually flew with was DISCARDED, which is why the caller
    // could not build the ctr_H->ctr_M map entry its same-layer sibling builds from do_send's return. Capture + return it.
    uint16_t out_ctr = 0;
    if (!enqueue_cross_layer(gw, dst_hash, ids, /*n_layers*/ 2, /*cur*/ 1, sbody, sblen, flags, &out_ctr, /*type=*/stype, override_source_hash)) {
        MR_EMIT("xl_send_too_large", EF_I("target_layer", target_layer), EF_I("gw", gw));
        if (generic_lifecycle) push_send_failed(SendFailReason::too_large, dst_node, /*ctr=*/0);   // §CUSTODY-B §6.2(5)
        return 0;                                    // enqueue_cross_layer leaves out_ctr untouched on failure; 0 = nothing flew
    }
    return out_ctr;
}

// Explicit-path origination (console/companion send_layer, §5): the user supplied the DESTINATION layer path
// (hops[0..hop_count-1]); we PREPEND our own active layer as path[0] (cur=1, so the first layer entered is hops[0]),
// then route (MAC dst) to a gateway serving hops[0]'s leaf. NO H-query — the path is explicit. Multi-gateway transit
// then "just works": the 4c.1 bridge advances `cur` at each gateway along the preserved path. Fail loud (send_failed
// Push) if no gateway serves hops[0] or the inner overflows. The handler validated the path (hop_count <= max-1,
// each layer != 0, hops[0] != our layer) before calling, so building path[1+hop_count] stays in bounds.
CmdCode Node::originate_layer_path(uint32_t dst_hash, const uint8_t* hops, uint8_t hop_count, const uint8_t* body, uint8_t body_len, uint8_t flags, uint16_t& out_ctr, uint8_t type, uint32_t override_source_hash) {
    out_ctr = 0;
    uint8_t path[protocol::gw_env_max_hops] = {};
    path[0] = active_layer_id();
    for (uint8_t i = 0; i < hop_count; ++i) path[1 + i] = hops[i];
    const uint8_t n_layers = static_cast<uint8_t>(1 + hop_count);
    const uint8_t first_leaf = static_cast<uint8_t>(hops[0] & 0x0F);     // hops[0] = the first layer to enter (cur=1)
    const uint8_t gw = select_gateway_for_leaf(first_leaf);
    if (gw == 0) {                                                       // no gateway serves the first hop's leaf -> fail loud
        MR_EMIT("xl_send_no_gateway", EF_I("target_layer", hops[0]), EF_I("dst_hash", static_cast<int64_t>(dst_hash)));
        return CmdCode::err_no_gateway;                                  // SYNCHRONOUS (the app holds the CmdResult handle); NO orphan push
    }
    if (!enqueue_cross_layer(gw, dst_hash, path, n_layers, /*cur*/ 1, body, body_len, flags, &out_ctr, type, override_source_hash)) {
        MR_EMIT("xl_send_too_large", EF_I("target_layer", hops[0]), EF_I("gw", gw));
        return CmdCode::err_too_large;
    }
    return CmdCode::queued;                                              // out_ctr now holds the correlation token
}

// End-to-end ACK: a tiny DATA back to the DM's origin carrying the acked ctr. Typed by the frame TYPE
// (DATA_TYPE_E2E_ACK -> APP byte), NOT a byte-1 flag. Emits e2e_ack_tx (NOT tx_enqueue) so dm_delivery
// doesn't miscount the ack as an app DM; it routes home on the reverse path F discovery laid toward the origin.
void Node::send_e2e_ack(uint8_t to_origin, uint16_t acked_ctr, uint32_t sender_hash) {
    const uint8_t body[2] = { static_cast<uint8_t>(acked_ctr & 0xFF), static_cast<uint8_t>(acked_ctr >> 8) };
    // §mobile: the DM's sender is one of MY hosted mobiles (sender_hash matches its stable key). A registered mobile
    // stamps origin=home_id (== MY id when it DMs its own home) -> acking `to_origin` is a self-send that never leaves.
    // Re-address the E2E-ack as a direct last-mile DM to the mobile's LOCAL id (addr_len=1), the way the host relays TO
    // a mobile (do_post_ack §3a). Gated on sender_hash!=0 + a match -> a static node (no _mobile_reg) is byte-identical.
    if (sender_hash != 0)
        for (uint8_t i = 0; i < _active->_mobile_reg_n; ++i)
            if (_active->_mobile_reg[i].key_hash32 == sender_hash) {
                (void)enqueue_data(_active->_mobile_reg[i].mobile_local_id, body, 2, /*flags=*/0, "e2e_ack_tx",
                                   /*app_dm=*/false, DATA_TYPE_E2E_ACK, CryptIntent::def,
                                   /*override_dst_hash=*/0, /*override_source_hash=*/0, /*addr_len=*/1);
                return;
            }
    // §GapB p3 (ack unification): the acked DM's SENDER differs from its origin -> `origin` is a mobile's home-stamped id
    // and `sender_hash` is the MOBILE itself. Address the ack "to the home, FOR the mobile" by attaching the mobile's
    // stable hash as DST_HASH (the correct "for whom" field — NOT the old SOURCE_HASH mark). The home's generic
    // hosted-mobile last-mile fork (node_mac_rx.cpp) then last-miles it to the mobile (with the ctr_H->ctr_M rewrite),
    // the SAME path every hosted-mobile DM takes. A STATIC sender has source_hash == key_hash_of_id(origin) -> gate FALSE
    // -> plain ack (byte-identical; s18 has no mobiles so this never fires). Unknown origin key -> plain ack.
    uint32_t oh = 0;
    if (sender_hash != 0 && key_hash_of_id(to_origin, oh) && oh != sender_hash) {
        (void)enqueue_data(to_origin, body, 2, /*flags=*/0, "e2e_ack_tx",
                           /*app_dm=*/false, DATA_TYPE_E2E_ACK, CryptIntent::def,
                           /*override_dst_hash=*/sender_hash);   // DST_HASH = the mobile's hash -> the home last-miles it (generic :699 fork)
        return;
    }
    (void)enqueue_data(to_origin, body, 2, /*flags=*/0, "e2e_ack_tx", /*app_dm=*/false, DATA_TYPE_E2E_ACK);
}

// §GapB (2026-07-18): the cross-layer E2E ack, UNIFIED onto the normal send machinery — "an E2E ack IS a normal DM
// from receiver to sender, NO ack-specific addressing." The inbound DM `dm` preserved the full layer-path (§0.10), so
// the recipient REVERSES it and sends type=E2E_ACK, body=acked_ctr, to (reversed path, dm.source_hash). A STATIC
// recipient originates directly via enqueue_cross_layer (retiring the old hand-built parallel origination); a MOBILE
// recipient DELEGATES through its home (delegate_send_layer) — a mobile must never self-originate an XL frame (the
// local-id-origin plane leak). Best-effort: no reverse gateway/route -> DROP loud (the sender's DM retry recovers it).
void Node::send_xl_ack(const data_unicast_inner& dm, uint16_t acked_ctr) {
    if (!dm.has_cross_layer || dm.n_layers < 2) return;                  // not a cross-layer DM (caller gated, defensive)
    if (!dm.has_source_hash || dm.source_hash == 0) {                    // no stable sender key -> can't address the ack. FAIL LOUD.
        MR_EMIT("xl_ack_no_source", EF_I("acked_ctr", acked_ctr));
        return;
    }
    // Reverse the preserved path: [A,B] -> [B,A]; the recipient sits on rev[0], the ORIGINAL sender X on rev[n-1].
    uint8_t rev[protocol::gw_env_max_hops] = {};
    for (uint8_t i = 0; i < dm.n_layers; ++i) rev[i] = dm.layer_ids[dm.n_layers - 1 - i];
    const uint8_t abody[2] = { static_cast<uint8_t>(acked_ctr & 0xFF), static_cast<uint8_t>(acked_ctr >> 8) };
#if MR_FEAT_MOBILE
    if (_cfg.is_mobile && _my_mobile_reg.active) {   // MOBILE recipient -> delegate the ack to the home (own layer rev[0] stripped)
        (void)delegate_send_layer(dm.source_hash, rev + 1, static_cast<uint8_t>(dm.n_layers - 1),
                                  DATA_TYPE_E2E_ACK, abody, 2, /*flags=*/0);
        return;
    }
#endif
    // STATIC recipient -> the normal XL origination (enqueue_cross_layer), best-effort: no reverse gateway/route -> DROP
    // loud (never park/flood an ack). enqueue_cross_layer's e2e_dm choke keeps a cleartext ack off the air when e2e_dm on.
    const uint8_t target_leaf = static_cast<uint8_t>(rev[1] & 0x0F);      // the next layer to enter (cur=1)
    const uint8_t gw = select_gateway_for_leaf(target_leaf);
    if (gw == 0 || rt_find(gw) == nullptr) {
        MR_EMIT("xl_ack_no_gateway", EF_I("target_leaf", target_leaf), EF_I("acked_ctr", acked_ctr), EF_I("to_hash", static_cast<int64_t>(dm.source_hash)));
        return;
    }
    if (enqueue_cross_layer(gw, dm.source_hash, rev, dm.n_layers, /*cur*/ 1, abody, 2, /*flags=*/0,
                            /*out_ctr=*/nullptr, /*type=*/DATA_TYPE_E2E_ACK, /*override_source_hash=*/0))
        MR_EMIT("xl_e2e_ack_tx", EF_I("to_hash", static_cast<int64_t>(dm.source_hash)), EF_I("gw", gw), EF_I("acked_ctr", acked_ctr));
}

#if MR_FEAT_MOBILE
// §S1: a REGISTERED mobile delegates a cross-layer send to its HOME. The wrapper is DATA_TYPE_MOBILE_SEND to home_id
// carrying the EXISTING cross-layer path block (n|cur|ids) via DATA_FLAG_CROSS_LAYER (so the home's parse_unicast_inner
// extracts the path for free), the target as DST_HASH, the mobile as SOURCE_HASH, and the body PREFIXED by an
// enclosed-type byte (0 = plain DM, DATA_TYPE_E2E_ACK = a delegated ack) so the home re-originates with that TYPE
// (§1b-4). `hops` = the DESTINATION path (the mobile's own layer NOT prepended — the home prepends it + re-validates).
// The wire is byte-identical to today's SAME-LAYER wrapper only when there is NO path (that path stays in send_by_hash).
uint16_t Node::delegate_send_layer(uint32_t dst_hash, const uint8_t* hops, uint8_t hop_count, uint8_t enclosed_type,
                                   const uint8_t* body, uint8_t body_len, uint8_t flags) {
    if (!_my_mobile_reg.active) return 0;                                // no home to delegate to
    if (hop_count == 0 || hop_count > protocol::gw_env_max_hops - 1) return 0;   // the home prepends its own layer -> 1+hop_count must fit
    if (static_cast<size_t>(body_len) + 1 > protocol::max_payload_bytes_hard_cap) return 0;
    const uint8_t home = _my_mobile_reg.home_id;
    TxItem item{};
    const uint16_t ctr = next_ctr(home);
    // ★ §team-parity T6: EXPLICITLY GLOBAL — and here the home-billing is DELIBERATE, not incidental. This is the
    // MOBILE_SEND wrapper: it is addressed TO OUR HOME (`item.dst = home`, DATA_FLAG_MS_ENCLOSED_TYPE), the home STRIPS
    // it and RE-ORIGINATES under its OWN origin/ctr, and *anti-spam bills the home* by design (hosting implies consenting
    // to the mobile's share — same ruling as the channel-post wrapper, node_channel.cpp:~370). The wrapper's leg is
    // MOBILE→HOME; it is NOT the team-plane leg whose reverse ack the §11 measurement found broken, so stamping
    // team_local_id() here would MISBILL anti-spam and hand the home an origin in a namespace its re-origination does not
    // use. The far target's ack routes back by the mobile's SOURCE_HASH, never by this origin.
    // Static reduction: Plane::GLOBAL ⇒ flight_is_team_plane() false ⇒ the pre-T6 expression verbatim (this whole
    // function is MR_FEAT_MOBILE-gated, so it is absent on the three gateway_* envs).
    stamp_origin(item, Plane::GLOBAL, home);   // registered mobile -> origin = home_id, mobile_src = true (the same identity the same-layer wrapper uses)
    item.dst = home; item.ctr = ctr; item.ctr_lo = static_cast<uint8_t>(ctr & 0x0F);
    item.type = DATA_TYPE_MOBILE_SEND;
    item.flags = static_cast<uint8_t>(DATA_FLAG_CROSS_LAYER | DATA_FLAG_DST_HASH | DATA_FLAG_SOURCE_HASH
                                      | (flags & (DATA_FLAG_E2E_ACK_REQ | DATA_FLAG_PRIORITY)));
    // ✖ MISSING (§loc-per-send, 2026-07-31): this mask drops DATA_FLAG_LOCATION and the pack below passes lat/lon = 0, so
    // a delegated cross-layer send carries NO location — the same v1 limitation as enqueue_cross_layer, for the same two
    // reasons (the wrapper is PLAINTEXT, and a sealed XL body has no flags word). NO guard is added here, deliberately:
    // both reachable callers are already refused upstream — on_command's send_layer verb rejects `-l` synchronously
    // (node.cpp), and send_xl_ack passes flags = 0 — so a guard would be unreachable code standing in for a rule that is
    // enforced where the operator can see it. If a future caller threads a user flags word in here, it needs the
    // enqueue_cross_layer guard's twin.
    uint8_t wbody[protocol::max_payload_bytes_hard_cap];
    wbody[0] = enclosed_type;                                            // the enclosed TYPE (§1b-4 threading)
    for (uint8_t i = 0; i < body_len; ++i) wbody[1 + i] = body[i];
    const size_t n = pack_unicast_inner(std::span<uint8_t>(item.inner, sizeof item.inner), item.flags, dst_hash,
                                        hops, hop_count, /*cur*/ 0, item.origin, _key_hash32,
                                        wbody, static_cast<uint8_t>(body_len + 1), /*lat_e7*/ 0, /*lon_e7*/ 0);
    if (n == 0) return 0;                                                // overflow -> fail loud (caller sees ctr 0)
    item.inner_len = static_cast<uint8_t>(n);
    item.enqueue_time_ms = _hal.now();
    if (_active->_tx_queue_n >= kTxQueueCap) return 0;
    _active->_tx_queue[_active->_tx_queue_n++] = item;
    MR_EMIT("mobile_delegate_xl", EF_I("home", home), EF_I("ctr", ctr), EF_I("enclosed_type", enclosed_type),
            EF_I("dst_hash", static_cast<int64_t>(dst_hash)));
    // ★ E2E-ack DEADLINE (cross-layer/delegated tier): the MOBILE is the true originator awaiting the far target's ack.
    // The wrapper always carries an explicit path -> the home re-originates cross-layer + the far target's send_xl_ack
    // returns CROSS_LAYER carrying source_hash == dst_hash -> match by key==sender_hash. SKIP when THIS delegation IS an
    // ack (enclosed_type==E2E_ACK, e.g. a mobile recipient delegating its own reverse-ack — no E2E_ACK_REQ flag anyway).
    if ((flags & DATA_FLAG_E2E_ACK_REQ) && enclosed_type != DATA_TYPE_E2E_ACK)
        e2e_ack_arm(/*key=*/dst_hash, /*is_xl=*/true, /*dst=*/0, ctr, protocol::e2e_ack_deadline_xl_ms);
    become_free();
    return ctr;
}
#endif

void Node::become_free() {
    if (_active->_pending_tx || _active->_pending_rx) return;              // half-duplex serialize
    if (_active->_tx_queue_n == 0) return;
    // Drain the FIRST item whose backoff has elapsed (next_attempt_ms <= now). The
    // Lua scans (not head-only) so a fresh send isn't blocked behind a backing-off
    // cascade-requeue, and the next_attempt_ms gate means a concurrent become_free
    // can't skip a requeue's backoff. Items with next_attempt_ms==0 are always ready,
    // so a queue without requeues behaves as plain FIFO.
    const uint64_t now = _hal.now();
    uint8_t  pick = _active->_tx_queue_n;                          // sentinel = none ready
    uint64_t soonest = UINT64_MAX;
    for (uint8_t i = 0; i < _active->_tx_queue_n; ++i) {
        if (_active->_tx_queue[i].next_attempt_ms <= now) { pick = i; break; }
        if (_active->_tx_queue[i].next_attempt_ms < soonest) soonest = _active->_tx_queue[i].next_attempt_ms;
    }
    if (pick == _active->_tx_queue_n) {                            // none ready -> wake at the soonest backoff
        (void)_hal.after(static_cast<uint32_t>(soonest - now), kQueueWakeupTimerId);
        return;
    }
    // Slice 3 DM burst floor (MF9): space our OWN DM originations >= dm_min_interval_ms. Living inside the
    // own-origin guard auto-exempts forwards (is_forward) + channel floods (is_channel_m); PROTOCOL-INTERNAL
    // DATA is exempt by TYPE so a gateway's cross-layer ack-confirms never self-throttle. The flat per-window
    // self-cap (Inc 4) was removed here — the duty plane governs own-origination volume; this is just a UX floor.
    // NOTE: we only CHECK here (defer-in-place); the _last_dm_origin_ms STAMP is set in issue_send at the point
    // the DM actually transmits, so a picked-but-deferred DM (no route yet) never falsely arms the floor.
    //
    // ★★★ §CUSTODY-B (2026-08-30) — THIS IS THE **CHECK** HALF OF THE DM FLOOR AND IT NOW ASKS THE ONE TRAIT
    //     AUTHORITY (design §6.2(4)). It used to spell out `{E2E_ACK, REMOTE_CMD, REMOTE_RESP}` by hand, and
    //     `issue_send`'s STAMP half spelled the SAME three out a second time (A0 matrix §3.2 duplication #1:
    //     identical today, not drifted — which is luck, not structure). ⛔ THE TWO HALVES MUST ASK THE SAME
    //     QUESTION: a type exempt from the CHECK but not the STAMP arms a floor nothing can ever trip, and the
    //     reverse silently throttles a protocol answer. One authority is what makes that impossible rather than
    //     merely currently-true. ⚠ THE SET WIDENS, deliberately: every `0x80..0xBF` value is now exempt, so the
    //     hash/mobile answers (0x88/0x89/0x8B/0x90..0x96) and the team-key grant (0xA2) stop being paced by a
    //     USER-DM floor they were never the subject of. ⛔ §6.3: this is the ONLY thing `internal` buys here —
    //     duty, LBT, queue capacity, cascade retries and route availability all still bind exactly as before.
    {
        TxItem& pt = _active->_tx_queue[pick];
        const bool exempt_type = data_type_traits(pt.type).internal;
        if (pt.origin == _node_id && !pt.is_forward && !pt.is_channel_m && !exempt_type
            && _last_dm_origin_ms != 0 && now - _last_dm_origin_ms < _cfg.dm_min_interval_ms) {
            const uint64_t until = _last_dm_origin_ms + _cfg.dm_min_interval_ms;
            pt.next_attempt_ms = until;                         // defer in place
            const uint32_t next_ms = static_cast<uint32_t>(until - now);
            MR_EMIT("send_blocked", EF_S("kind", "dm"), EF_S("reason", "min_interval"),
                    EF_I("next_ms", next_ms), EF_I("dst", pt.dst), EF_I("ctr", pt.ctr));
            // Slice 6a: the MR_EMIT above is device-stripped telemetry — this Push is the send_blocked signal the
            // companion actually receives. The DM burst floor is always a min-interval block (kind=dm).
            emit_send_blocked(/*channel=*/false, SendFailReason::min_interval, next_ms);
            become_free();                                      // re-pick (skips the now-deferred item)
            return;
        }
    }
    TxItem item = _active->_tx_queue[pick];
    for (uint8_t i = pick + 1; i < _active->_tx_queue_n; ++i) _active->_tx_queue[i - 1] = _active->_tx_queue[i];
    --_active->_tx_queue_n;
    issue_send(item);
}

// ---- M-broadcast (channel gossip) fire-and-forget tx (dv:6997/7044/7389) ----------------------
// chosen_data_sf = max(allowed_sf_bitmap) — largest SF = most robust = most receivers decode it.
uint8_t Node::max_data_sf() const {
    // NOTE (per-layer-bw 2026-07-04): reads the SWAP-MIRRORED _cfg.allowed_sf_bitmap (activate_layer stamps the ACTIVE
    // layer's bitmap into this scalar), so it stays active-layer-coherent WITH active_bw_hz()/active_cr() — the airtime
    // sites that pair them (channel_capacity_C, exchange_airtime_ms) resolve SF and BW/CR for the SAME active leaf. If a
    // refactor ever froze this scalar at layer-0, that coherence would break — keep the mirror.
    const uint16_t bitmap = _cfg.allowed_sf_bitmap;             // 0 -> no data SF (returns 0; origination refused upstream)
    for (uint8_t sf = 12; sf >= 5; --sf) if (bitmap & (1u << sf)) return sf;
    return 0;
}
// The RTS sf_index that pins that max SF (its rank in the ascending allowed set) so a receiver resolves it
// via select_data_sf — no CTS needed to communicate the choice. (Assumes <=3 allowed SFs, like the Lua.)
uint8_t Node::max_data_sf_index() const {
    const uint16_t bitmap = _cfg.allowed_sf_bitmap;
    if (bitmap == 0) return 3;                                   // ANY (receiver picks) — no pinned singleton
    uint8_t count = 0;
    for (uint8_t sf = 5; sf <= 12; ++sf) if (bitmap & (1u << sf)) ++count;
    return static_cast<uint8_t>(count - 1);                     // ascending -> the highest SF is the last index
}
// Set up the fire-and-forget flight on the just-installed _active->_pending_tx, then fire the RTS. No CTS wait
// (the SF is in the RTS), no ACK wait (failures recover via the next BCN-digest cascade).
void Node::issue_m_broadcast() {
    if (!_active->_pending_tx) return;
    PendingTx& pt = *_active->_pending_tx;
    pt.m_broadcast = true; pt.awaiting_cts = false; pt.awaiting_ack = false;
    pt.chosen_data_sf = max_data_sf();                          // sender picks the SF; advertised in the RTS
    tx_m_broadcast_rts();
}
// Pack + TX the M_BROADCAST RTS (sf_index pinned to the max SF + the channel_msg_id low-16), then arm
// the RTS->DATA gap directly (kCtsToDataGapTimerId -> do_data_tx) — skipping the CTS round-trip.
void Node::tx_m_broadcast_rts() {
    if (!_active->_pending_tx) return;
    PendingTx& pt = *_active->_pending_tx;
    if (pt.inner_len < 6) { _hal.log("M-broadcast RTS inner_len < 6 — refusing tx"); _active->_pending_tx.reset(); become_free(); return; }   // fail loud: M inner is [id4|ch|fl|body]; <6 underflows inner_len-6
    rts_in rin{};
    rin.leaf_id = _cfg.leaf_id; rin.src = _node_id; rin.ctr_lo = pt.ctr_lo;
    rin.sf_index = max_data_sf_index();
    rin.cr_adv = rts_cr_encode(active_cr());   // §rts-cr: the CR we will transmit the M frame at (the RTS is packed on the ACTIVE leaf, so this is the leaf's effective CR)
    rin.mobile_src = pt.mobile_src;   // §mobile 6.3: carry the TEAM-channel mark onto the M_BROADCAST/FLOOD RTS-M so a static overhearer skips it (0 on a normal channel -> byte-identical)
    // payload_len announces the BODY length of the lean M frame to follow (pt.inner = [id 4][ch 1][fl 1][body]).
    // The overhearer sizes its retune window as airtime(payload_len + M_FRAME_HDR_LEN) = the full 7+body M frame.
    rin.payload_len = static_cast<uint8_t>(pt.inner_len - 6);
    if (pt.flood) {                                            // FLOOD RTS-M (43 B): id + 32-B coverage bitmap
        // FAIL LOUD (gate refinement #1): an all-zero bitmap is a VALID 43-B frame that makes every receiver
        // see all-neighbours-unmarked -> a rebroadcast storm. A legit flood always has >=1 bit set (the
        // originator's own + neighbours, or OR'd coverage), so a zero bitmap is a bug — refuse to transmit.
        bool any = false; for (uint8_t i = 0; i < 32; ++i) if (pt.flood_bitmap[i]) { any = true; break; }
        if (!any) {
            _hal.log("FLOOD RTS zero bitmap — refusing tx");
            MR_EMIT("flood_zero_bitmap_refused", EF_I("ctr", pt.ctr));
            _active->_pending_tx.reset(); become_free(); return;
        }
        rin.next = 0xFF; rin.dst = pt.hop_left;                // §3.1: next=0xFF (broadcast), dst slot = hop_left
        rin.rts_flags = static_cast<uint8_t>(RTS_FLAG_M_BROADCAST | RTS_FLAG_FLOOD);
        rin.flood_channel_msg_id = m_inner_id(pt.inner);
        rin.flood_bitmap = std::span<const uint8_t>(pt.flood_bitmap, 32);
        uint8_t fbuf[43];
        const size_t fl = pack_rts(rin, std::span<uint8_t>(fbuf, sizeof(fbuf)));
        if (fl == 0) { _hal.log("FLOOD RTS pack failed"); _active->_pending_tx.reset(); become_free(); return; }
        MR_EMIT("rts_tx", EF_I("next", 0xFF), EF_I("ctr", pt.ctr), EF_B("flood", true));
        tx_initiating(fbuf, fl, static_cast<int16_t>(_cfg.routing_sf), LbtKind::rts, pt.flight_gen);
        return;
    }
    rin.next = pt.next; rin.dst = pt.dst; rin.rts_flags = RTS_FLAG_M_BROADCAST;
    rin.m_payload_id_lo16 = static_cast<uint16_t>((pt.inner[2] << 8) | pt.inner[3]);   // low-16 of the BE id
    uint8_t buf[11];                                            // ⓘ 9 B is written (RTS base 7 + id_lo16 2); the
                                                                // buffer is deliberately oversized. ⛔ CORRECTED
                                                                // 2026-08-08 (§hybrid-rts S1, V1): this comment
                                                                // read "RTS(8) + id_lo16(2)" — the SAME phantom
                                                                // 8-byte RTS that start_rts_timeout priced. The
                                                                // M-broadcast RTS base is 7 B, and pack_rts
                                                                // writes exactly 9.
    const size_t l = pack_rts(rin, std::span<uint8_t>(buf, sizeof(buf)));
    if (l == 0) { _hal.log("M-broadcast RTS pack failed"); return; }
    MR_EMIT("rts_tx", EF_I("dst", pt.dst), EF_I("next", pt.next), EF_I("ctr", pt.ctr));
    tx_initiating(buf, l, static_cast<int16_t>(_cfg.routing_sf), LbtKind::rts, pt.flight_gen);
    // The RTS->DATA gap is armed in start_rts_timeout (the actual-TX hand-off, after any LBT/duty defer = the
    // Lua's on_handed, dv:7032) — NOT here at issue. Arming at issue desyncs the DATA when the RTS is deferred:
    // it fires while the RTS is still on air (self_tx_in_flight -> data_tx_blocked) and BEFORE overhearers
    // receive the full RTS + retune to the data SF, so they're never on the SF when the DATA-M lands.
}

void Node::issue_send(const TxItem& item) {
    // A new flight is going live -> drop any stale BUSY_RX nack-wait left armed for a
    // torn-down prior flight, so its timer can't spuriously re-RTS this one on a 4-bit
    // ctr_lo collision (issue_send is the only choke point that installs a new _active->_pending_tx).
    clear_nack_wait();
    // Build the flight first so pick_next_cascade_hop sees previous_hop (forwarders
    // must not loop back upstream) + the empty alts_tried set.
    PendingTx pt{};
    pt.origin = item.origin; pt.dst = item.dst;
    pt.ctr_lo = item.ctr_lo; pt.ctr = item.ctr; pt.flags = item.flags; pt.type = item.type;
    pt.inner_len = item.inner_len;
    for (uint8_t i = 0; i < item.inner_len; ++i) pt.inner[i] = item.inner[i];
    for (int i = 0; i < 8; ++i) pt.nonce_seed[i] = item.nonce_seed[i];   // CRYPTED: carry the 8-B nonce-seed to the DATA trailer
    pt.chosen_data_sf = 0; pt.retries_left = effective_rts_max_retries(item.requeue_count);
    pt.awaiting_cts = true; pt.awaiting_ack = false;
    pt.alts_tried_n = 0;
    pt.previous_hop = item.previous_hop; pt.has_previous_hop = item.is_forward;
    pt.addr_len = item.addr_len; pt.mobile_src = item.mobile_src;   // §mobile 3a: carry the mobile marks TxItem -> flight -> RTS
    pt.plane = item.plane;   // Wave 2: carry the addressing plane TxItem -> flight -> route dispatch below (AUTO for every existing caller)
    pt.requeue_count = item.requeue_count; pt.enqueue_time_ms = item.enqueue_time_ms;
    pt.fwd_remaining = item.fwd_remaining; pt.fwd_committed = item.fwd_committed;   // hop budget (forwarder)
    pt.flood = item.flood; pt.hop_left = item.hop_left;                             // channel FLOOD: the 43-B RTS-M tail
    for (uint8_t i = 0; i < 32; ++i) pt.flood_bitmap[i] = item.flood_bitmap[i];
    pt.is_gw_relay = item.is_gw_relay;                                              // Slice 4c.2: thread the cross-layer relay marker -> the RTS sets RTS_FLAG_RELAY

    // A channel FLOOD is a TRUE broadcast (next=0xFF, no unicast route) -> skip route selection (which would
    // find no route and drop/defer) and fire the fire-and-forget flight directly.
    if (item.flood) {
        pt.next = 0xFF;
        pt.flight_gen = ++_flight_gen;
        _active->_pending_tx = pt;
        issue_m_broadcast();
        return;
    }

    // Wave 2: route by the flight's PLANE. AUTO = dispatch on is_team_peer (today's behaviour, byte-identical); TEAM =
    // the team plane (pick_next_cascade_hop -> rt_find(_,TEAM) -> _rt_team); GLOBAL = never the team plane (a registered
    // mobile reaches the mesh via its home; a static node cascades on _rt), even for an id that collides a teammate's.
    const bool team_route = (pt.plane == Plane::TEAM) || (pt.plane == Plane::AUTO && is_team_peer(pt.dst));
    const uint8_t first = (pt.addr_len == 1) ? pt.dst     // §mobile 3a Fix 4: a mobile-next (local-id) is a DIRECT 1-hop send to the registrar — NEVER rt_find'd (a local-id can collide a global id). addr_len==0 for every normal TxItem.
                        : team_route ? pick_next_cascade_hop(pt)   // §6.4: a TEAM-plane dst routes via _rt_team. A dual (registered) member must NOT push it through the static home_id.
                        : mobile_registered() ? mobile_home_id()   // §mobile 3b: a REGISTERED MOBILE is a leaf -> reach the mesh through its 1-hop home_node (no global route table). Inert for a static/unregistered node (and compiled out on a static/gateway build -> falls through to cascade).
                        : pick_next_cascade_hop(pt);     // first SELECTABLE candidate (skips previous_hop)
    if (first == 0) {
        // No usable route yet. A FORWARDER drops (dv_dual_sf.lua:7041-7048 — it
        // can't hold someone else's transit); an ORIGINATOR defers the message
        // until a beacon installs a route or the defer-TTL expires (dv:7049-7052).
        if (item.is_forward) {
            MR_EMIT("send_no_route", EF_I("dst", item.dst));
            // A normal forwarder DROPS here (it can't hold someone else's transit; dv:7041-7048) — it falls through
            // to the return below. DELIBERATE EXCEPTION (gateway reactive route-pull, spec 2026-06-21 §4): a GATEWAY
            // relaying a CROSS-LAYER transit DM is effectively the ORIGINATOR on the far layer (it is injecting the
            // DM there), so when it has no far-layer route it must NOT drop. Instead it (1) reactively PULLs the full
            // table — REQ_SYNC with force=true to bypass the route-rich guard (the gateway is route-rich but missing
            // THIS one far-layer dst), which makes far-layer neighbours reply with full "sync" beacons it hears
            // in-window; and (2) DEFERs the leg (park + retry via try_drain_deferred) so the DM is delivered once the
            // pulled route lands — no first-packet loss. Bounded by the existing send_defer_ttl giveup.
            // DO NOT "fix" this back to a drop: dropping loses the first DM to every new far-layer dst (the s15
            // cross-layer 58%->90% gap; spec §2). The pull is rate-limited (req_sync_retry_ms) so a miss-storm can't
            // flood the air.
            if (item.is_gw_relay) { send_req_sync_q("gw_relay_no_route", /*force=*/true); defer_send(item); }
        } else {
            // Wave-4 antidote (reactive route-pull, ORIGINATOR site): a stable route we missed during the discovery
            // window is NEVER re-advertised passively — steady-state beacons are dirty-only, so a peer's converged
            // route to our dst never reaches us again. Mirror the gw_relay pull above: fire a force REQ_SYNC (bypasses
            // the route-rich guard; rate-limited to one per req_sync_retry_ms by _last_req_sync_tx_ms) so a neighbour
            // replies with a full-table "sync" beacon carrying the missing route, THEN defer so the parked send
            // re-flies via try_drain_deferred once the route lands. Without this an originator that missed the window
            // simply defers→giveup forever (the s19 B→A starvation class; investigation 2026-07-22 §s19).
            // ✔ §team-parity T4 (§3/T4): the antidote is now PLANE-AWARE. A TEAM originator with no `_rt_team` route
            // fires a TEAM-scoped pull (opcode team_sync, scoped by the team_id on the wire, answered only by same-team
            // members per I7) alongside the team RREQ that defer_send / try_drain_deferred raise — the two convergence
            // mechanisms compose exactly as they do on the static plane. Reusing the flight's OWN `team_route` decision
            // (computed above) means the pull and the route lookup can never disagree about which plane is missing a
            // route (U1); a fresh predicate here would be the field-drop rot.
            // Static reduction: team_route==false for every static, every GLOBAL and every AUTO flight to a non-team
            // peer ⇒ `send_req_sync_q("originator_no_route", true)`, the pre-T4 call.
            // Build profiles: under MR_FEAT_TEAM 0 (the three gateway_* envs) is_team_peer() stubs false (node.h:132)
            // and a Plane::TEAM send is refused at node.cpp:1138, so team_route is false there for every flight — and
            // send_req_sync_q's own team arm is compile-time-false regardless, so the pull stays static twice over.
            send_req_sync_q("originator_no_route", /*force=*/true, /*team_plane=*/team_route);
            defer_send(item);                         // originator: hold until a beacon installs a route (dv:7049-7052)
        }
        return;
    }
    // Slice 4a (the deferred 3e.2b): if the resolved next-hop is a learned, time-multiplexing GATEWAY, HOLD the RTS
    // until its window on OUR leaf opens (dv:7331). gateway_schedule_defer_ms returns 0 for a non-gateway / unknown
    // next-hop (send now), or up to a full window_period_ms when the gateway is away on its other leaf — it isn't
    // listening on our leaf then, so firing now just burns airtime. Re-queue with a next_attempt_ms COMPOSED as
    // max() against any backoff already on the item (ack-warn / self-cap) — never shorten an existing hold. NOT for
    // channel gossip (is_channel_m is fire-and-forget; a gateway skips channels anyway). issue_send's ONLY caller is
    // become_free, which just removed this item, so the queue always has room to re-add it.
    // ⓘ [[B159]]: an acceptance-time deadline check STOOD HERE and was REMOVED, deliberately and by measurement.
    // It bounded when an attempt was ACCEPTED, not when a frame was AIRED — QG showed an RTS can be LBT- or
    // DUTY-deferred after passing it and air far beyond the bound. The enforcement therefore moved to where the
    // frame actually meets the HAL (`rts_handoff_deadline_cancel`, node_cascade.cpp), and once it was there this
    // check became unmutatable redundancy: deleting it left the ENTIRE native suite green, the same test that
    // condemned the two earlier prospective checks. Keeping a check no mutation can kill is how a codebase
    // accumulates reassuring dead guards, so it is gone rather than demoted to a "cheap early refusal".
    if (!item.is_channel_m) {
        if (const uint32_t defer = gateway_schedule_defer_ms(first); defer > 0) {
            // NOTE (Wave-4): the s15 cross-layer window-livelock (a sender phase-locking into a never-opening window
            // off a stale/degenerate schedule anchor) is fixed at the SOURCE — the gateway periodically re-advertises
            // its schedule (node.cpp maybe_emit_gateway_beacon, gw_schedule_readvert_ms) so every listening neighbour
            // re-anchors. A sender-side reactive REQ_SYNC pull here was measured redundant (the gateway can only hear
            // the pull during the same window the stale phase can't find), so it is deliberately NOT added.
            TxItem held = item;
            const uint64_t until = _hal.now() + defer;
            if (held.next_attempt_ms < until) held.next_attempt_ms = until;   // compose: never clobber an earlier-armed backoff
            if (_active->_tx_queue_n < kTxQueueCap) _active->_tx_queue[_active->_tx_queue_n++] = held;
            MR_EMIT("tx_gateway_schedule_defer", EF_I("dst", item.dst), EF_I("next", first),
                    EF_I("ctr", item.ctr), EF_I("defer_ms", defer));
            become_free();                               // re-service: pick another ready item, else arm kQueueWakeupTimerId for the soonest
            return;
        }
    }
    pt.next = first;
    pt.flight_gen = ++_flight_gen;                       // #A redo: a NEW flight identity (cascade_to_alt keeps it; a requeue re-installs here -> new gen)
    _active->_pending_tx = pt;
    if (item.is_channel_m) { issue_m_broadcast(); return; }   // channel gossip (pull-response): fire-and-forget M-broadcast
    // Slice 3 DM burst floor (MF9): stamp _last_dm_origin_ms only when our OWN DM actually commits to a flight
    // (route resolved, RTS about to fly) — NOT at become_free pick-time, so a picked-but-deferred (no-route) DM
    // doesn't falsely arm the floor. Forwards / channel floods / protocol-internal DATA are exempt (never throttled).
    // ★★★ §CUSTODY-B — THE **STAMP** HALF, and it asks the SAME authority as the CHECK half in `become_free`
    //     (node_mac.cpp, tagged §CUSTODY-B). ⛔ Do not re-spell the set here: the whole point of the trait is that
    //     these two can no longer drift apart. §18.2.7 mutates each half INDEPENDENTLY back to its historical
    //     exact-type list, and both arms must go RED.
    {
        const bool exempt_type = data_type_traits(item.type).internal;
        if (item.origin == _node_id && !item.is_forward && !item.is_channel_m && !exempt_type)
            _last_dm_origin_ms = _hal.now();
    }
    tx_rts_retry();                                      // packs+emits the RTS + start_rts_timeout
}

void Node::tx_rts_retry() {
    if (!_active->_pending_tx) return;
    PendingTx& pt = *_active->_pending_tx;
    pt.awaiting_cts = true; pt.awaiting_ack = false; pt.chosen_data_sf = 0;
    rts_in rin{};
    rin.leaf_id = _cfg.leaf_id; rin.src = _node_id; rin.next = pt.next; rin.ctr_lo = pt.ctr_lo;
    // DM RTS; the M-broadcast RTS is tx_m_broadcast_rts. Slice 4c.2: a gateway's cross-layer re-inject sets RTS_FLAG_RELAY
    // so the receiver exempts it from the originator anti-spam (node_mac_rx :40/:199) — G is relaying, not a 1st-hop origination.
    rin.dst = pt.dst; rin.sf_index = 3 /*ANY*/; rin.rts_flags = pt.is_gw_relay ? RTS_FLAG_RELAY : 0;
    rin.cr_adv = rts_cr_encode(active_cr());   // §rts-cr: the CR the DATA will fly at -> the receiver sizes its DATA wait for OUR cr, not its own
    // §mobile 3a: addr_len=1 on a host's last-mile forward to a mobile; §6.4: also when the NEXT hop is a team peer, so the
    // receiver's mark-accept treats `next` as a team-plane local-id (its team_local_id==node_id off-grid). All 0 on a normal
    // TxItem -> identical wire.
    // ★ §team-parity T8 (2026-07-28): `&& flight_is_team_plane(pt.plane, pt.dst)` — the WIRE plane must be the plane the
    // flight was ROUTED on. It is the SAME expression `issue_send` already used to pick the table (`team_route`,
    // node_mac.cpp:767) and the SAME one stamp_origin uses to pick the origin namespace (node.h:865), so all three now
    // agree by construction. Without it this predicate was decided by the NEXT HOP alone while stamp_origin was decided
    // by the PLANE, and the two diverge for any flight routed on the STATIC plane whose next hop happens to be a team
    // peer (GLOBAL, or AUTO to a non-team-peer dst, resolved through `_rt`): the frame went out addr_len=1 /
    // src=team_local_id() — i.e. AS a team-plane frame — carrying the STATIC origin stamp_origin correctly chose for a
    // static flight. The receiver then reads for_team_data=true with a valid non-zero `from`, and the DATA-origin learn
    // (node_mac_rx.cpp:694) installs `_rt_team[<static id>]` + the `_team_peer` bit — invariant A2/I2 breached.
    // ⚠ WHY THIS IS THE SENDER'S JOB AND CANNOT BE THE RECEIVER'S: team local ids come from team-DAD's 17..254 draw
    // (node_mobile.cpp:191) and static node_ids are 1..254 — ONE numeric space with NO discriminator, and neither RTS nor
    // plain DATA carries a team_id (invariant I9). So "is this origin a team-namespace id?" is UNDECIDABLE at the
    // receiver; only the originator knows which plane it meant. Closing origination closes the class: a RELAY never
    // calls stamp_origin (it copies `pa.origin`, node_mac_rx.cpp:1198), so it can only propagate a mis-stamp, not create
    // one. Relay reduction: a forward's TxItem leaves `plane` at AUTO, and `is_team_peer(pt.dst)` is exactly what
    // `team_route` required for the forward to resolve on `_rt_team` at all -> the predicate is unchanged for every
    // legitimate team relay. MEASURED reachable, seam-free, before the fix: `_rt[55].next = 238` (a plain non-mobile
    // beacon) + `_team_peer[238]` (a later team beacon from the same id — the §18/I9 collision, or a live is_mobile /
    // team_id config change) => a GLOBAL `send 55` aired `RTS src=93 next=238 dst=55 addr_len=1` with inner origin 17.
    // ★ §hybrid-rts S2 — the three marks now come from the ONE producer `rts_wire_marks` (node_mac.cpp, below this
    // function). The expression it holds is the §team-parity T8 predicate VERBATIM; the second consumer is the
    // sender-side terminal-CTS echo comparison in `handle_cts`, which must compare the plane this RTS DECLARED.
    const RtsWireMarks marks = rts_wire_marks(pt);
    const bool team_next = marks.team_src;
    rin.addr_len   = marks.addr_len;
    // §6.4: mark the src a LOCAL id when it is one — a registered mobile (pt.mobile_src) OR a team-plane send (team_next; an
    // off-grid team member's node_id IS its team local id). Team DMs previously carried mobile_src=0 (only addr_len=1), so the
    // mobile_src-keyed guards (learn/anti-spam node_mac_rx :40/:47, the receiver's mobile_from, the ACK's mobile_to) MISSED
    // them -> a team local id leaked into the static _rt/ledger. This closes it uniformly. Non-team/static flight -> 0 -> identical wire.
    rin.mobile_src = marks.mobile_src;
    if (team_next) rin.src = team_local_id();   // §6.4: team-plane RTS src = OUR team local id, NOT _node_id (a static node_id may collide across teammates; off-grid team_local_id==node_id -> no-op)
    // e2e-ack backstop exemption (2026-07-02): mark the RTS so the 1st-hop backstop skips its DROP for this ack (an ack
    // must never be throttled — a throttled ack -> re-send -> more traffic). Verified at DATA-time (anti-spoof). Duty still binds.
    if (pt.type == DATA_TYPE_E2E_ACK) rin.rts_flags |= RTS_FLAG_E2E_ACK;
    rin.payload_len = static_cast<uint8_t>(pt.inner_len + data_mac_len(pt.flags)); rin.m_payload_id_lo16 = 0;  // +8 under CRYPTED (nonce-seed)
    // ★★★ §hybrid-rts S1 — THE ONE PLACE A UNICAST RTS IDENTITY IS PRODUCED, because this is the ONE unicast
    // RTS producer (S0 proved it: every origin, relay, last-mile, requeue and cross-layer reinject path reaches
    // the wire through here, via `issue_send`). RECOMPUTED from the flight's own canonical DATA fields on every
    // attempt rather than cached in a carrier — that is design §3's "prefer recomputing over copying a
    // redundant tag through every carrier", and it makes retry stability true BY CONSTRUCTION: the inputs
    // (`origin`/`ctr`/`dst`/`nonce_seed`) are exactly the fields `txitem_from_pending` already preserves across
    // a requeue, so a retried or requeued flight reproduces identical bytes with nothing to forget.
    // ⚠ NO CARRIER CHANGE WAS NEEDED and none was made: all four inputs are already members of BOTH TxItem and
    //   PendingTx and are already copied by the single conversion (U2).
    // ★★★★ §hybrid-rts S2 (2026-08-08) — **THE PLAINTEXT IDENTITY'S `origin` IS THE BYTE THE DATA WILL EXPOSE,
    // NOT `pt.origin`, AND THIS CORRECTION WAS FORCED BY MEASUREMENT.** S1 fed `pt.origin` here. The receiver can
    // only recompute from what the frame carries — `parse_unicast_inner(inner, flags)->origin`. Typed-answer frames
    // used to build a RAW inner with no `[origin]` prefix, so the originator's carrier said
    // `_node_id` while the frame's first inner byte was `target_layer`. B161 now wraps H_ANSWER /
    // AUTHORITATIVE_H_ANSWER / MOBILE_H_ANSWER / MOBILE_H_ANSWER_PUBKEY in this same canonical envelope;
    // AUTHORITATIVE_H_ANSWER_PUBKEY already used it. Keeping the read frame-derived proves the RTS identity against the
    // bytes DATA will actually air, while native controls require it to equal `pt.origin`.
    // ⛔ AND THE FALLBACK IS `0`, DELIBERATELY, NOT the RTS `src`: `handle_data`'s `origin` local falls back to
    //    `from`, which PREFERS `meta.src_hint` — the simulator's PHY oracle, which carries a homed teammate's STATIC
    //    id rather than the `team_local_id` the frame aired. Binding the identity to that would be a [[B156]]-class
    //    sim/metal divergence. A frame whose inner exposes no origin (an empty typed inner) therefore identifies as
    //    `(0, ctr)` on both sides — still bound to the full 16-bit ctr and to the cache's (sender, dst, plane) key.
    // ⓘ A relay was unaffected by the historical defect: it already copied the DATA-exposed origin into its own
    //    carrier (`_post_ack.origin` -> `TxItem::origin`), so only the originator of a pre-B161 typed answer diverged.
    rin.id = flight_identity(pt);   // ⇐ the ONE producer (below) — never inline this derivation again
    uint8_t buf[11];                                     // §hybrid-rts S1: 10 B plaintext / 11 B crypted
    const size_t l = pack_rts(rin, std::span<uint8_t>(buf, sizeof(buf)));
    if (l == 0) { _hal.log("RTS pack failed"); return; }
    MR_EMIT("rts_tx", EF_I("dst", pt.dst), EF_I("next", pt.next), EF_I("ctr", pt.ctr));   // emit at the call site (before the LBT defer, dv-faithful)
    // R4.5: the actual TX + start_rts_timeout go through the LBT wrapper (defer if the channel is busy). RX stays
    // on routing_sf. lbt_enabled=false (every gate) -> straight TX + timeout, byte-identical.
    tx_initiating(buf, l, static_cast<int16_t>(_cfg.routing_sf), LbtKind::rts, pt.flight_gen);
}

// ★★★ §hybrid-rts S2 (2026-08-08) — THE ONE PRODUCER OF A UNICAST RTS's WIRE ADDRESSING MARKS.
// Extracted VERBATIM from `tx_rts_retry` above (the `team_next` / `addr_len` / `mobile_src` triple, whose long
// §team-parity T8 argument stays there beside the pack). It exists because S2 added a SECOND consumer:
// `handle_cts`'s terminal-CTS echo must compare the PLANE THIS SENDER DECLARED ON THE WIRE, and that plane is
// `rts_wire_team_plane(marks.addr_len, marks.mobile_src)` — not `is_team_peer(next)`, not the flight's `Plane`
// enum, and not anything receiver-relative. Re-deriving `team_next` at that site would have forked the T8
// predicate into two copies that can drift (U1); this keeps ONE.
// ⚠ It reads LIVE node state (`is_team_peer`, `flight_is_team_plane`), so a role/peer change between the RTS and
//   its CTS re-derives the CURRENT answer — which is exactly what a retry of the same flight would air anyway.
// ★★★★★ §hybrid-rts S2 (2026-08-08) — THE ONE PLACE A PENDING FLIGHT'S IDENTITY IS DERIVED, and it exists
// because the FIRST draft of S2 did NOT have it and the corpus caught the consequence within one run.
// ⛔ THE DEFECT THIS CLOSES, recorded because it is the arc's own recurring shape: `tx_rts_retry` derived the
//    plaintext origin from the flight's INNER (see below) while `handle_cts`'s terminal-echo comparison derived
//    it from `pt.origin`. Those two disagree for exactly the frames [[B161]] is about — and the corpus showed it
//    as **40 `cts_terminal_mismatch` refusals** across `s15`/`s15_metal`/`s27`, a retry deadlock in which the
//    receiver kept answering terminally and the sender kept refusing its OWN flight's echo. Two derivations of
//    one identity is exactly the U1 failure the design's "one producer, one comparator" rule names.
// ★ THE RULE: the plaintext identity's `origin` is **the byte the DATA will EXPOSE** — `parse_unicast_inner`'s
//   `origin` over this flight's own inner, which is byte-for-byte what the receiver parses (`do_data_tx` airs
//   `pt.inner` verbatim). B161 makes every production plaintext-unicast producer expose the carrier's stamped
//   origin through that canonical byte; the frame-derived comparator remains the stronger authority.
// ⛔ The fallback is `0` and NOT the aired `src` — see the argument at `tx_rts_retry`'s call site ([[B156]]).
RtsFlightIdentity Node::flight_identity(const PendingTx& pt) const {
    const auto ui = parse_unicast_inner(std::span<const uint8_t>(pt.inner, pt.inner_len), pt.flags);
    return rts_flight_identity((pt.flags & DATA_FLAG_CRYPTED) != 0,
                               ui ? ui->origin : 0, pt.ctr, pt.dst, pt.nonce_seed);
}

Node::RtsWireMarks Node::rts_wire_marks(const PendingTx& pt) const {
    RtsWireMarks m{};
    m.team_src   = (pt.addr_len == 0 && is_team_peer(pt.next)
                    && flight_is_team_plane(pt.plane, pt.dst));   // §6.4/§T8 — see tx_rts_retry for the full argument
    m.addr_len   = m.team_src ? 1 : pt.addr_len;
    m.mobile_src = pt.mobile_src || m.team_src;
    return m;
}

// R4.5 LBT: hand an INITIATING frame to the radio, but if the channel is busy (and lbt_enabled) defer the real
// TX past busy_until + rand(0,lbt_backoff+1) — the ONE LBT draw, ONLY when busy (dv:3693-3706).
// ⛔⛔ CORRECTED IN PLACE 2026-08-07 (§MH-S1, V1 — this line MISLED A SLICE PLAN). It used to read
// *"lbt_enabled=false (every gate) -> straight to lbt_complete -> byte-identical, NO draw."* **THAT IS FALSE AND
// HAS BEEN SINCE THE 2026-07-24b LBT-ENERGY RE-ANCHOR**, which gave the simulator a default `lbt_model:"energy"`
// carrier sense. MEASURED on the current corpus, by counting the `tx_lbt_defer{kind:"initiating"}` that
// immediately follows a `mobile_discover_tx` from the same node: **s28 defers 18 of its 70 DISCOVERs, s29 2 of
// 15, s07 1 of 56** (longest 1732 ms). ⇒ the deferred branch is HOT in the gate, it DOES draw, and any change to
// what happens on it moves those scenarios. §MH-S1's "byte-identical" premise was written on the strength of this
// sentence and did not survive contact with the measurement — see `simulation/BASELINE.md`.
// ★★★ §id-hash S1c + §tx-admission TX1 (2026-08-01): it RETURNS. `false` = the frame was DROPPED — not sent, not
// scheduled, and NOTHING will retry it. TWO things produce that, one per branch, and they were found one review
// apart:
//   · the busy branch — `schedule_lbt_defer` refusing a full 4-slot ring (*"ring full -> drop loudly"*), whose
//     `bool` this function used to discard (S1c);
//   · the clear-channel branch — `lbt_complete` -> `tx_with_retry` -> `DeviceHal::tx` answering `busy` on a full
//     8-entry outbound ring (it bumps `txq_drops` and does NOT retain the frame) or `too_long` (TX1).
// Either way `emit_hash_query` used to report `sent`, `CmdResult` carried acceptance, and BLE emitted
// `reqpubkey_sent`.
// ★ OWNER RULING ON THE SEMANTICS (2026-08-01): the event means **"the TX path ACCEPTED the frame — nothing rejected
//   it"**, NOT a claim of airtime. That is the only thing answerable synchronously: a deferred frame reaches the
//   radio when a timer fires, long after on_command returned. ⇒ a SUCCESSFUL defer is `true` here. What can still
//   go wrong AFTER that — the deferred timer meeting a full HAL queue — is reported LATE, by on_timer's defer arm.
// ⓘ `lbt_complete`'s two RTS-only early-outs are excluded on inspection, not by omission: a stale-flight CANCEL
//   abandons a flight that is already gone, and the duty defer re-arms kRtsDutyDeferTimerId — neither is a loss.
//   Unreachable from the one reader regardless: `emit_hash_query` always passes `LbtKind::flood`.
// ⓘ U3: `tx_flood` in this same file has returned `bool` on exactly this "did the frame survive the gates" question
//   since R4.5, so this is the sibling shape, not a new convention.
// §MH-S1: `out` (optional) splits the two `false` outcomes apart — see the TxAdmission comment in node.h.
// It is written on EVERY path, so a caller that passes it never reads a stale/default value.
bool Node::tx_initiating(const uint8_t* bytes, size_t len, int16_t sf, LbtKind kind, uint32_t completion_gen,
                         TxAdmission* out) {
    const uint64_t now = _hal.now();
    uint64_t busy_until = 0;
    if (_cfg.lbt_enabled) { const uint64_t b = _hal.channel_busy_until(); if (b > busy_until) busy_until = b; }  // physical carrier sense (LBT)
    if (_cfg.nav_enabled && _nav_until_ms > busy_until) busy_until = _nav_until_ms;                              // virtual carrier sense (NAV)
    if (busy_until > now) {
        const uint32_t wait  = static_cast<uint32_t>(busy_until - now);
        const uint32_t delay = wait + static_cast<uint32_t>(_hal.rand_range(0, static_cast<int>(_lbt_backoff_ms) + 1));   // shared backoff jitter -> NAV-released TX de-syncs
        MR_EMIT("tx_lbt_defer", EF_S("kind", "initiating"), EF_I("defer_ms", delay),
                EF_I("busy_until_ms", busy_until));
        const bool queued = schedule_lbt_defer(bytes, len, sf, kind, completion_gen, delay);   // false ⇒ ring full ⇒ DROPPED
        if (out) *out = queued ? TxAdmission::deferred : TxAdmission::defer_full;
        return queued;
    }
    const bool handed = lbt_complete(bytes, len, sf, kind, completion_gen);   // §tx-admission TX1: false ⇒ the HAL REJECTED it
    if (out) *out = handed ? TxAdmission::admitted : TxAdmission::tx_rejected;
    return handed;
}

// NAV (virtual carrier sense) duration helpers — pure, native-testable. Conservative: an overheard RTS
// reserves CTS+DATA+ACK (DATA size known exactly from payload_len, SF taken as our max = longest), a CTS
// reserves DATA+ACK (SF exact from chosen_data_sf, size from byte 3's 4-B-quantized hint, or max if absent).
// Per-leg turnaround gaps included.
// §rts-cr-overhear (2026-07-27): `data_cr` is a PARAMETER, not active_cr(). The DATA being reserved for is
// the peer's transmission, so the peer's coding rate sizes it. An RTS carries that datum (cr_adv), so the
// two nav_duration_rts callers and the flood-yield caller pass rts_cr_decode(r.cr_adv); §cts-len6-cr2 put it
// on the CTS too, so the two overheard-CTS callers now pass the peer's CR as well (byte 3's cr2 half) and
// fall back to active_cr() ONLY when the CTS carried no byte 3 at all. No caller guesses any more.
uint32_t Node::nav_duration_rts(uint8_t data_sf, uint8_t payload_len, uint8_t data_cr) const {
    // M6: payload_len is an UNAUTHENTICATED wire byte (0..255). At max SF a forged 255 arms NAV for seconds; NAV
    // is on by default -> a cheap overheard RTS with payload_len=255 could indefinitely silence a victim's TX.
    // Clamp to the real hard cap (a DATA body can never exceed max_payload_bytes_hard_cap) BEFORE the airtime calc.
    // Centralised here so every caller (the NAV arm AND the reserve-yield estimate) is covered by one guard.
    if (payload_len > protocol::max_payload_bytes_hard_cap) payload_len = protocol::max_payload_bytes_hard_cap;
    // The CTS/ACK terms stay on airtime_routing_ms (our own CR): they are the *receiver's* frames and no
    // wire field carries that node's CR either — but they are 3 B on the routing SF, i.e. tens of ms against
    // a DATA term measured in hundreds, so the residual is noise. Only the DATA term is worth threading.
    const uint32_t cts_air  = static_cast<uint32_t>(airtime_routing_ms(3));   // CTS = 3 B on the routing SF
    const uint32_t data_air = static_cast<uint32_t>(airtime_ms(data_sf, active_bw_hz(), data_cr,
                                  protocol::preamble_sym, static_cast<uint16_t>(payload_len + 13)));   // +13 = DATA header (handle_rts:57)
    const uint32_t ack_air  = static_cast<uint32_t>(airtime_routing_ms(3));   // ACK = 3 B
    return cts_air + data_air + ack_air + 3u * static_cast<uint32_t>(protocol::cts_to_data_gap_ms);   // 3 turnarounds
}
// ✔✔ §cts-len6-cr2 (2026-07-27) — THE SITE THE §rts-cr-overhear BLOCK CALLED UNFIXABLE IS NOW CLOSED. Kept
// as the full record so nobody redoes the analysis, and so the retired premise is visible rather than deleted.
//   WHAT WAS WRONG: two of the three callers overhear a *CTS* and must size the DATA that CTS is clearing — a
//   third party's frame at that third party's CR — and passed active_cr(), OUR CR, as the stand-in.
//   DIRECTION OF THE ERROR — the DANGEROUS one, not the safe one:
//     peer CR > ours  -> the real DATA outlasts our reservation, we UNDER-reserve and release NAV early.
//                        We may then transmit ON TOP of the DATA we were protecting. This is precisely the
//                        hidden-terminal collision NAV exists to prevent, so the mechanism failed in the one
//                        case it is there for. Worst case cr8-vs-cr5 = 1.6x the payload symbol term.
//     peer CR < ours  -> we OVER-reserve: silent longer than needed. Wasted airtime only, fail-safe.
//   MEASURED (cr5 overhearer, cr8 peer, BW250k, routing SF8) — computed vs truly needed, PRE-slice:
//     SF10 pl=38  389 -> 525 ms  (-136)   SF11 pl=38  690 ->  935 ms (-245)   SF12 pl=38 1412 -> 1953 (-541)
//     SF11 pl=120 1304 -> 1918 ms (-614)  SF12 pl=120 2723 -> 4050 ms (-1327)
//   ⇒ at the s32/s33 shape the hole was ~245 ms, the same order as the 246 ms DATA-wait shortfall §rts-cr
//   existed to close — not a rounding residual, the same bug at the same magnitude.
//   ⚠ THE RETIRED PREMISE, recorded because it was wrong in an instructive way: "the CTS cannot carry CR, it
//   has ZERO free bits", and the only ways costed were a 5th conditional byte (a flag day + a tax on every CTS
//   in every mesh) or reclaiming the load-bearing already_received. Both were rejected — correctly. The move
//   that was missed: byte 3 did not need to stay an exact 8-bit length. Quantizing it to 4-B units frees two
//   bits for the CR, and `payload_len` counts inner+MAC ONLY, so the consumer's flat +13 was already
//   over-reserving by 4-5 B (the true header is DATA_HDR_MAX_LEN = 9). Quantization spends exactly that
//   existing fudge: worst case 0-3 B (quantization, rounded UP) + 0-1 B (header) = 0-4 B over, vs 4-5 B before.
//   SAME MARGIN, ZERO BYTES ADDED, and the CR becomes exact. Encoding + the sweep invariant: frame_codec.h
//   §cts-len6-cr2. Spec: docs/superpowers/specs/2026-07-27-cts-len6-cr2-design.md.
//   ⚠ STILL MISSING, DELIBERATELY (noise-level, and each would need a WIDER CTS — byte 3 is now full):
//     (a) the CTS and ACK terms of BOTH helpers stay on airtime_routing_ms (our own CR) — they are the
//         RECEIVER's 3-B frames on the routing SF, tens of ms against a DATA term of hundreds;
//     (b) the anti-spam ledger's CTS term (node_mac_rx.cpp handle_cts) — byte 3's cr2 is the WRONG NODE's CR
//         there (c.rx_id's, not the CTS sender c.tx_id's), so this hint cannot help it;
//     (c) nav_duration_rts below still adds a flat +13, i.e. it over-reserves by 4-5 B. SAFE direction, an
//         exact 8-bit RTS payload_len needs no quantization, and narrowing it would move every NAV-bearing
//         stream — a separate slice, not folded in here (rule C1).
uint32_t Node::nav_duration_cts(uint8_t data_sf, uint8_t payload_len, uint8_t data_cr) const {
    // The frame length. payload_len = the inner+MAC count: from a CTS it is byte 3's hint, already quantized UP
    // to a multiple of CTS_LEN_QUANTUM by parse_cts (so this is an over- never under-estimate); from the two
    // flood/yield callers it is the ½-max reserve_est_payload_bytes guess. + DATA_HDR_MAX_LEN = the widest
    // cleartext header (we cannot see the frame's APP bit, so assume the TYPE byte is there). 0 => no hint at
    // all => the max-frame fallback.
    //   M6 (unauthenticated wire byte) IS STILL BOUNDED, by a better bound than the old 241-B clamp: the 6-bit
    //   len6 field cannot express more than 63*4 + 9 = 261 B, and the min() pins that to lora_max_frame_bytes —
    //   EXACTLY the no-hint fallback's reservation. So the worst case a forged hint can buy is identical to the
    //   worst case an absent hint already buys: no new DoS surface, provably. The old clamp-to-241 was also
    //   UNSAFE at the top end (payload_len is inner+MAC, so it legally reaches 241+8 = 249 under CRYPTED, and
    //   clamping to 241 then under-reserved a real 255-B frame) — the min() on the BYTE COUNT fixes that too.
    const unsigned hinted = static_cast<unsigned>(payload_len) + DATA_HDR_MAX_LEN;
    const uint16_t data_bytes = (payload_len == 0 || hinted > protocol::lora_max_frame_bytes)
        ? protocol::lora_max_frame_bytes
        : static_cast<uint16_t>(hinted);
    const uint32_t data_air = static_cast<uint32_t>(airtime_ms(data_sf, active_bw_hz(), data_cr,
                                  protocol::preamble_sym, data_bytes));
    const uint32_t ack_air  = static_cast<uint32_t>(airtime_routing_ms(3));
    return data_air + ack_air + 2u * static_cast<uint32_t>(protocol::cts_to_data_gap_ms);
}
void Node::nav_arm(uint32_t duration_ms) {
    const uint64_t until = _hal.now() + duration_ms;
    if (until > _nav_until_ms) _nav_until_ms = until;   // extend; never shorten
}

// spec 2026-06-28: mid-handshake (awaiting_cts/awaiting_ack), we overheard our NEXT-HOP get reserved for `reserve_ms`
// -> our CTS/ACK can't come until it clears. PUSH our pending timeout past the reserve (extend-only) WITHOUT burning a
// retry (a yield is not an attempt) so the retry fires on a FREE medium, not blind during the reserve. SAFETY: bounded
// by the flight's total-lifetime giveup horizon (enqueue_time_ms + cascade_requeue_total_max_ms) -> a saturated cell
// can't make us yield forever; past the horizon we DON'T yield and the normal timeout->retry->cascade->giveup runs.
bool Node::reserve_yield(uint32_t reserve_ms) {
    if (!_active->_pending_tx) return false;
    PendingTx& pt = *_active->_pending_tx;
    const uint32_t timer_id = pt.awaiting_cts ? kRtsTimeoutTimerId
                            : (pt.awaiting_ack ? kAckTimeoutTimerId : 0u);
    if (timer_id == 0u) return false;                                          // not mid-handshake
    const uint64_t now     = _hal.now();
    const uint64_t horizon = pt.enqueue_time_ms + protocol::cascade_requeue_total_max_ms;   // the flight's giveup ceiling
    if (now >= horizon) return false;                                          // past lifetime -> let it cascade/giveup (no infinite yield)
    uint64_t deadline = now + reserve_ms;
    if (deadline < pt.timeout_deadline_ms) deadline = pt.timeout_deadline_ms;  // EXTEND-ONLY (never shorten an already-later timeout)
    if (deadline > horizon)               deadline = horizon;                  // clamp to the giveup ceiling (bounded politeness)
    (void)_hal.after(static_cast<uint32_t>(deadline - now), timer_id);         // re-arm the SAME timeout, later — retries_left / retry_attempt UNTOUCHED
    pt.timeout_deadline_ms = deadline;
    MR_EMIT("reserve_yield", EF_I("reserve_ms", reserve_ms), EF_I("awaiting", pt.awaiting_cts ? 1 : 2));
    return true;
}

// Stash a busy-channel deferred TX in a free ring slot + arm its own timer (kLbtDeferTimerId + slot), so
// concurrent defers each fire independently (Lua per-closure semantics). false = ring full (rare; >4 defers).
bool Node::schedule_lbt_defer(const uint8_t* bytes, size_t len, int16_t sf, LbtKind kind,
                              uint32_t completion_gen, uint32_t delay,
                              const uint32_t* digest_ids, uint8_t digest_n) {
    for (uint8_t s = 0; s < kLbtSlots; ++s) {
        if (_deferred_lbt[s].pending) continue;
        DeferredLbt& d = _deferred_lbt[s];
        d.pending = true; d.kind = static_cast<uint8_t>(kind); d.sf = sf; d.completion_gen = completion_gen;
        // §TX3: carry the advertised digest ids (beacon only). ALWAYS rewritten — a recycled slot must not inherit a
        // previous beacon's ids and commit them for an unrelated frame.
        for (uint8_t k = 0; k < kDeferDigestIds; ++k)
            d.digest_ids[k] = (digest_ids && k < digest_n) ? digest_ids[k] : 0u;
        d.len = static_cast<uint8_t>(len < sizeof(d.buf) ? len : sizeof(d.buf));
        for (uint8_t i = 0; i < d.len; ++i) d.buf[i] = bytes[i];
        (void)_hal.after(delay, kLbtDeferTimerId + s);
        return true;
    }
    MR_EMIT("tx_lbt_defer_dropped", EF_I("kind", static_cast<uint8_t>(kind)));                         // ring full -> drop loudly
    return false;
}

// The actual TX (immediate clear-channel path OR the kLbtDeferTimerId re-fire). RTS: the flight-gen staleness check
// (cancel a stale deferred RTS, dv:3708/3712) + the #A duty pre-check (defer over-budget) + start_rts_timeout (the
// after_tx). NACK/flood: just TX.
bool Node::lbt_complete(const uint8_t* bytes, size_t len, int16_t sf, LbtKind kind, uint32_t completion_gen) {
    if (kind == LbtKind::rts) {
        if (!_active->_pending_tx || _active->_pending_tx->flight_gen != completion_gen) {  // flight changed while we waited (flight_gen = object-identity, not the 4-bit ctr_lo)
            MR_EMIT("rts_tx_cancelled_stale", EF_S("reason", "pending_tx_changed"));
            return true;                                              // §TX1: a deliberate CANCEL of a dead flight — nothing was rejected, nothing to report
        }
        // ★★ [[B159]]: THE ADMISSION BOUND. This is the immediate AND the LBT-deferred RTS path, so a frame that
        // waited out a busy channel is re-judged before it is handed to the HAL. ⚠ NOT the air start: `Hal::tx()`
        // only ENQUEUES on a device — `DeviceHal::pump_tx`'s deadline check is the terminal authority.
        if (rts_handoff_deadline_cancel(completion_gen))
            return true;                                              // §TX1: a deliberate CANCEL — given up loudly, nothing rejected

        // Cleanup #A (redo): duty pre-check the RTS (the #2 slot<0 residual). Over budget -> defer in the DEDICATED
        // _rts_duty_defer slot (NOT the shared LBT ring — that reuse was net-worse, review wgvbtirmu) + arm the
        // re-check timer + return (NOT handed; start_rts_timeout armed on the eventual send by rts_duty_defer_fire).
        // The ~1h wait is SAFE now: flight_gen staleness is exact. Draw-free; gate-inert (healthy duty never defers).
        uint32_t wait = 0;
        if (duty_over_budget(len, sf, &wait)) {
            MR_EMIT("duty_cycle_blocked", EF_S("label", "RTS"), EF_I("wait_ms", wait), EF_S("source", "lbt_complete"));
            RtsDutyDefer& d = _rts_duty_defer;
            d.pending = true; d.sf = sf; d.flight_gen = completion_gen;
            d.len = static_cast<uint16_t>(len < sizeof(d.buf) ? len : sizeof(d.buf));
            for (uint16_t i = 0; i < d.len; ++i) d.buf[i] = bytes[i];
            (void)_hal.after(wait, kRtsDutyDeferTimerId);
            return true;                                              // §TX1: deferred, kRtsDutyDeferTimerId will re-run it — not a loss
        }
    }
#if MR_FEAT_MOBILE
    // ★★★ [[B142]] 2026-08-07 — THE STALE-ATTACHMENT CANCEL, AND IT IS THE RTS DISCIPLINE ABOVE, WEARING TWO
    // MORE KINDS (U1). Everything below this line — the TX itself, the collect-OFFERs arm, the adopt — used to
    // be reached by a deferred completion correlated by `LbtKind` ALONE. `_mobile_claim_pending` is ONE GLOBAL
    // BOOLEAN with no attempt identity, so an ABA was possible and it destroyed the NEWER transaction:
    //     CLAIM A enters defer slot A -> the operator runs `mobile register` again -> DISCOVER B picks another
    //     host and CLAIM B is staged in the same `_mobile_offers[0]` behind the same bool -> slot A fires first
    //     -> ACCEPTED: A's bytes go on the air and candidate **B** is adopted (a home that was sent nothing);
    //        REJECTED: node.cpp's deferred-loss arm clears **B's** stage and arms a retry for an attempt that no
    //        longer exists, so slot B can never complete correctly.
    // ★★ THE REJECTED PATH IS AS DESTRUCTIVE AS THE ACCEPTED ONE — that is the whole shape of the defect — so
    //    the cancel is placed HERE, BEFORE `tx_with_retry`, and a stale completion does ALL FIVE nothings:
    //    it does not transmit, does not arm the guard, does not adopt, does not clear any current state, and
    //    does not schedule a retry. Returning TRUE is what buys the last two: `false` would send node.cpp's
    //    defer arm into `mobile_admission_rejected`, i.e. straight back into the defect (see the TX1 contract
    //    in node.h — this is the third early-out that answers true, for the same "the owner is already gone"
    //    reason as the RTS one directly above).
    // ⓘ Draw-free and clear-channel-inert BY CONSTRUCTION: on the immediate path `lbt_complete` is entered
    //   synchronously from `tx_initiating` with the token just read from `_mobile_attach_gen`, so the test can
    //   only ever compare a value against itself. Only a DEFER can put a bump in between.
    // ⛔ NOT `mobile_offer`: that is the HOST side, whose single staging slot is [[B137]]/S2's to give an
    //   identity to. Its `completion_gen` is 0 and it is never tested here.
    // §B186a: `mobile_reclaim` is named here TOO — it used to arrive as `mobile_claim` and the cancel applied to it,
    // so omitting it would REMOVE a live guard from re-CLAIMs. The emitted `kind` now comes from the op table, so a
    // stale re-CLAIM reports "reclaim" instead of the pre-slice "claim" (0 occurrences corpus-wide, measured).
    if ((kind == LbtKind::mobile_discover || kind == LbtKind::mobile_claim || kind == LbtKind::mobile_reclaim)
        && completion_gen != _mobile_attach_gen) {
        MR_EMIT("mobile_tx_cancelled_stale", EF_S("kind", mobile_tx_op_name(mobile_op_of_kind(kind))),
                EF_I("gen", static_cast<int64_t>(completion_gen)),
                EF_I("current_gen", static_cast<int64_t>(_mobile_attach_gen)));
        return true;   // a superseded transaction's frame — CANCELLED, not lost: nothing happens, nothing is reported
    }
#endif
    const FrameTag tag = (kind == LbtKind::rts)  ? FrameTag::rts
                       : (kind == LbtKind::nack) ? FrameTag::nack : FrameTag::beacon;
    // §B186a: the mobile operation is DERIVED FROM THE KIND THE SENDING SITE PASSED — i.e. from the fact
    // established by the act, before this hand-off — and rides `TxParams::tag`'s high byte from here on. Non-mobile
    // kinds give `none`, so the tag they carry is bit-for-bit the pre-slice value.
    const TxHandOff r = tx_with_retry(bytes, len, sf, tag, mobile_op_of_kind(kind));   // R4.5b: stash (NACK) + tag the frame
    if (kind == LbtKind::rts) start_rts_timeout();                     // after_tx: CTS-wait starts when the RTS is on air
#if MR_FEAT_MOBILE
    // ★★ §MH-S1 §6.1 — THE ADMISSION BOUNDARY FOR THE COLLECT-OFFERs WINDOW, and it is the RTS line above
    // wearing a different kind (U1). `mobile_discover_fire` no longer arms kMobileClaimGuardTimerId; the
    // window opens HERE, where the DISCOVER actually crosses the accepted LBT/HAL handoff — which is also
    // why the "successfully LBT-deferred DISCOVER starts the guard when the defer fires" requirement is
    // satisfied for free: node.cpp's defer arm re-enters this same function with the stored kind.
    // ⛔ NO DRAW, and the ORDERING IS PRESERVED: the old code armed the guard immediately after
    // `tx_initiating` returned, i.e. immediately after this very `tx_with_retry` — so on a clear channel
    // the sequence of hal calls is unchanged and the corpus is byte-identical by construction.
    // ★★★ §MH-S3 §5.4 — AND THE "NO DRAW" ABOVE IS NOW SUPERSEDED, DELIBERATELY, BY THE ARC'S ONE PLANNED
    // RNG RE-ANCHOR. `mobile_offer_window_ms` is a MINIMUM COLLECTION INTERVAL, not a deadline: mobiles that
    // opened their windows in the same millisecond used to close them — and CLAIM — in the same millisecond,
    // which is the collision §5.4 exists to remove. The guard is therefore armed at the minimum PLUS a
    // bounded per-mobile jitter, drawn ONCE here, at the same point in the Hal-call sequence the fixed
    // `after` occupied. The ordering argument above still holds; only the VALUE is now drawn.
    // ★★ THE SELECTION RULE IS UNTOUCHED — jitter moves the DEADLINE, it must not change WHICH OFFER wins.
    //    `mobile_claim_guard_fire` still picks the strongest `_mobile_offers[]` entry collected before the
    //    fire, which is exactly §5.4's "the strongest received before that mobile's individual deadline".
    //    A late-arriving stronger OFFER inside the extra jitter is therefore eligible, by design.
    // ⛔ MOBILE-PLANE ONLY: `LbtKind::mobile_discover` is emitted by `mobile_discover_fire`, which hard-guards
    //    on `_cfg.is_mobile`. A static/gateway node never reaches this line ⇒ the static corpus (and s18)
    //    is inert by construction, which is the property that makes this slice's re-anchor attributable.
    if (kind == LbtKind::mobile_discover && r != TxHandOff::rejected)
        (void)_hal.after(protocol::mobile_offer_window_ms
                             + static_cast<uint32_t>(_hal.rand_range(0, static_cast<int>(protocol::mobile_claim_jitter_ms) + 1)),
                         kMobileClaimGuardTimerId);   // collect for AT LEAST the window, then decide
    // ★★ §MH-S1b §6.3 — AND THE CLAIM ADOPTS HERE, FOR THE SAME REASON AND ON THE SAME LINE. QA round 2:
    // arming the DISCOVER window at the handoff while leaving the CLAIM adopting at the REQUEST fixed one of
    // three siblings. `tx_initiating` answers `true` for a frame merely accepted into the LBT defer ring, so
    // `mobile_claim_guard_fire` was still declaring the mobile REGISTERED — `set_identity`, `_joined`, the
    // app-facing `mobile_reg{registered:true}` push — for a CLAIM the HAL had not seen and might yet refuse
    // (node.cpp's deferred-loss arm). ⇒ the adopt is now anchored to the SAME accepted handoff.
    // ⛔ ORDER-PRESERVING ON A CLEAR CHANNEL: `lbt_complete` is entered synchronously from `tx_initiating`,
    //    and the adopt used to run on the statement immediately after that call returned — with nothing in
    //    between but the two `kind`-gated lines above. So the Hal-call sequence of a non-deferred CLAIM is
    //    unchanged, which is what keeps the non-deferring corpus rows byte-identical.
    // §B186a: BOTH claim kinds, so the pre-slice call is preserved EXACTLY for a re-CLAIM. It is a deliberate no-op
    // for one (`mobile_claim_adopt` early-returns on `!_mobile_claim_pending`, which is exactly a re-CLAIM's state —
    // see its note at node_mobile.cpp), and leaving it out would make that invariant load-bearing HERE instead of
    // where it is documented.
    if ((kind == LbtKind::mobile_claim || kind == LbtKind::mobile_reclaim) && r != TxHandOff::rejected) mobile_claim_adopt();
#endif
    // ★ §MH-S1b §6.2/§10 — `mobile_offer_tx` NOW MEANS TRANSMITTED. It used to be emitted at DISCOVER time,
    // beside the stash, i.e. it meant only "copied into a stash" — the very thing §10 forbids by name, and
    // the arc's fourth "success that isn't". The staging emit is renamed `mobile_offer_scheduled` (its honest
    // meaning) in node_join.cpp and THIS is the transmitted one, raised where the frame actually crosses the
    // accepted handoff — immediate or LBT-deferred alike. Together with `mobile_offer_dropped` that is §10's
    // required triple of scheduled / transmitter-admitted / (S4) confirmed.
    // ⓘ The fields are READ BACK OUT OF THE FRAME rather than passed down, deliberately: the event then
    //   reports what is on the wire instead of what the caller believed it staged, and the OFFER slot is a
    //   single 13-byte buffer that a re-arm can have overwritten between staging and firing. NOT
    //   `#if MR_FEAT_MOBILE` — a HOME IS A STATIC NODE (twin of `mobile_offer_admission_rejected`).
    // ⚠ WRAPPED IN `MR_TELEMETRY`, NOT JUST `MR_EMIT`: the parse exists ONLY to fill the event, so on a
    //   `MESHROUTE_NO_TELEMETRY` board build the read-back must vanish with it — otherwise metal pays for a
    //   `parse_j` per OFFER and `j` is a set-but-unused variable (MEASURED: it was, and it broke the
    //   warning census on all three OLED envs at 179 vs the pinned 178). This block is pure telemetry, so
    //   it is exactly what MR_TELEMETRY's contract says may be wrapped — no state, no return, no TX.
    // ⓘ RESIDUAL, stated rather than hidden: §10 also asks the DEVICE log to distinguish the three states.
    //   The refusal half does that (`mobile_offer_admission_rejected` logs). The SUCCESS half deliberately
    //   does not — one console line per OFFER on a busy home is noise, and §10's own answer is the pair of
    //   COUNTERS it asks for beside S2's ring. Owed there, not faked here.
    MR_TELEMETRY( if (kind == LbtKind::mobile_offer && r != TxHandOff::rejected) {
                      const auto j = parse_j(std::span<const uint8_t>(bytes, len));
                      MR_EMIT("mobile_offer_tx", EF_I("to_key", j ? static_cast<int64_t>(j->target_key_hash32) : 0),
                              EF_I("local_id", j ? j->proposed_mobile_id : 0));
                  } );
    return r != TxHandOff::rejected;                                  // §tx-admission TX1: the HAL's answer, propagated
}

// Cleanup #A redo: the RTS duty-defer timer fired. Drop if the flight is gone/replaced (flight_gen = the Lua
// __pending_tx_ref object-identity, dv:3712); re-defer if still over budget; else hand the RTS + DRIFT: arm
// start_rts_timeout (a CTS-wait) — the Lua's duty-defer DROPS after_tx and stalls (asymmetric vs its own LBT-defer
// which keeps it); the C++ is more robust. Deliberate documented divergence ([[feedback_port_wire_divergence]] #0).
void Node::rts_duty_defer_fire() {
    RtsDutyDefer& d = _rts_duty_defer;
    if (!d.pending) return;
    if (!_active->_pending_tx || _active->_pending_tx->flight_gen != d.flight_gen) {       // the flight this RTS belonged to is gone
        d.pending = false;
        MR_EMIT("rts_tx_cancelled_stale", EF_S("reason", "pending_tx_changed"));
        return;
    }
    uint32_t wait = 0;
    if (duty_over_budget(d.len, d.sf, &wait)) {                          // still over budget -> re-defer (re-check later)
        (void)_hal.after(wait, kRtsDutyDeferTimerId);
        return;
    }
    // ★★ [[B159]]: THE HANDOFF BOUND ON THE DUTY-DEFERRED PATH — the one the previous cut missed entirely. The
    // wait above is priced at "~1h" by this function's own design note, so without this test an RTS accepted at
    // age 149 s could air arbitrarily late. Checked AFTER the re-defer arm, so a still-blocked frame is re-armed
    // rather than cancelled, and only a frame about to REACH the HAL is judged.
    if (rts_handoff_deadline_cancel(d.flight_gen)) { d.pending = false; return; }
    d.pending = false;
    // §T1: identity = `RtsDutyDefer::flight_gen` — the value STORED IN THIS CARRIER at defer time, which is also
    // what the staleness guard eleven lines above compared. ⛔ Not `_pending_tx->flight_gen`: they are equal here
    // only because that guard just proved it, and depending on that equality is how a derived identity sneaks in.
    TxParams p = tx_params_of(static_cast<uint16_t>(FrameTag::rts), d.sf, d.flight_gen, rts_air_deadline_ms());
    const TxResult tr = _hal.tx(d.buf, d.len, p);
    if (tr != TxResult::ok)
        MR_EMIT("tx_hal_rejected", EF_S("label", "RTS"), EF_I("result", static_cast<uint8_t>(tr)),
                EF_I("len", static_cast<int64_t>(d.len)));
    start_rts_timeout();                                                 // the DRIFT — arm the CTS-wait the Lua drops
}

// R4.5 FLOOD TX (beacon, dv:3765-3814). Duty pre-check (skip if it would breach budget), then LBT: drop the page
// if the channel is busy longer than flood_lbt_max_defer_ms, else defer past busy_until + a backoff, else TX now.
bool Node::tx_flood(const uint8_t* bytes, size_t len, int16_t sf,
                    const uint32_t* digest_ids, uint8_t digest_n) {
    if (_duty_cycle_budget_ms > 0) {                                   // duty pre-check (dv:7781) — only when enabled
        const uint64_t airtime = airtime_routing_ms(static_cast<int>(len));
        const uint64_t used    = _hal.airtime_used_ms(_cfg.duty_cycle_window_ms);
        if (used + airtime > _duty_cycle_budget_ms) {
            MR_EMIT("duty_cycle_blocked", EF_I("airtime_ms", airtime), EF_S("source", "tx_flood"));
            return false;
        }
    }
    {
        const uint64_t now = _hal.now();
        uint64_t busy_until = 0;
        if (_cfg.lbt_enabled) { const uint64_t b = _hal.channel_busy_until(); if (b > busy_until) busy_until = b; }  // physical carrier sense (LBT)
        if (_cfg.nav_enabled && _nav_until_ms > busy_until) busy_until = _nav_until_ms;                              // virtual carrier sense (NAV)
        const int64_t  wait = static_cast<int64_t>(busy_until) - static_cast<int64_t>(now);
        if (wait > static_cast<int64_t>(_flood_lbt_max_defer_ms)) {    // busy too long -> drop the page (dv:3796)
            MR_EMIT("tx_flood_skipped", EF_I("busy_for_ms", wait));
            return false;
        }
        if (wait > 0) {
            const uint32_t delay = static_cast<uint32_t>(wait) +
                                   static_cast<uint32_t>(_hal.rand_range(0, static_cast<int>(_lbt_backoff_ms) + 1));
            MR_EMIT("tx_lbt_defer", EF_S("kind", "flood"), EF_I("defer_ms", delay),
                    EF_I("busy_until_ms", busy_until));
            // ★★★ §tx-admission TX2 (2026-08-01): the ring-full DROP was DISCARDED here and this answered `true`.
            // ⚠ THIS IS NOT TELEMETRY — `emit_beacon:517` takes this boolean as `sent` and `:525` calls
            // `commit_channel_digest_advertised` under the comment *"burn an ad_count … ONLY for advertisements that
            // ACTUALLY AIRED … the air-honesty fix"* (that wording is now the TRANSMITTER-ADMITTED boundary, owner-ruled
            // 2026-08-02). That commit does `++e.bcn_ad_count` and, on horizon, sets
            // `e.dirty = false`. ⇒ a beacon the ring dropped consumed the advertisement horizon and could RETIRE a
            // digest nothing ever received. The air-honesty mechanism was defeated by a discarded return.
            // §TX3: ACCEPTED into the ring ⇒ NO commit yet. The ids ride the slot and node.cpp's defer arm commits
            // them iff DeviceHal later answers ok. Ring full ⇒ false ⇒ the entry stays dirty.
            return schedule_lbt_defer(bytes, len, sf, LbtKind::flood, 0, delay, digest_ids, digest_n);
        }
    }
    // tag the immediate beacon too (the deferred path tags via lbt_complete) — else a blocked clear-channel beacon
    // reaches on_radio_busy mislabelled tag=0(rts).
    // §T1: identity = **0**, passed deliberately — a beacon belongs to no flight, and there is nothing to borrow.
    TxParams p = tx_params_of(static_cast<uint16_t>(FrameTag::beacon), sf, /*flight_seq=*/0u);
    // ★★★ §tx-admission TX2: the second discarded result, same consequence. `DeviceHal::tx` answers `busy` on a full
    // 8-entry ring (bumps `txq_drops`, does NOT retain) and a beacon is `slot < 0` — no stash, no retry. It has its
    // OWN emit because tx_flood bypasses `tx_with_retry` entirely: that was the sweep-scope error which hid this
    // site for three rounds (the dispatch enumerated `tx_with_retry`'s callers; `tx_flood` is not one of them).
    const TxResult tr = _hal.tx(bytes, len, p);
    if (tr != TxResult::ok) {
        MR_EMIT("tx_hal_rejected", EF_S("label", "BCN"), EF_I("result", static_cast<uint8_t>(tr)),
                EF_I("len", static_cast<int64_t>(len)));
        return false;                                                  // dropped ⇒ the digest MUST stay dirty
    }
    // §TX3: the IMMEDIATE path's admission point — DeviceHal took it, so commit here (the owner's boundary).
    if (digest_ids && digest_n) commit_channel_digest_advertised(digest_ids, digest_n);
    return true;
}

// R4.5b: FrameTag -> the human label for telemetry/TxParams.
// §w4-switchenum: `beacon` is an EXPLICIT case (it used to be served by `default: return "BCN"`, so a 7th FrameTag
// would have silently printed "BCN"). No `default:` -> -Wswitch now fails the build on a new tag. The trailing
// return keeps the pre-existing out-of-range behaviour verbatim: on_radio_busy casts a HAL-supplied uint16
// (node.cpp:1177) into FrameTag, so a value outside 0..5 is representable and must still label as "BCN".
const char* Node::label_of_frame(FrameTag t) {
    switch (t) { case FrameTag::rts: return "RTS"; case FrameTag::cts: return "CTS";
                 case FrameTag::data: return "DATA"; case FrameTag::ack: return "ACK";
                 case FrameTag::nack: return "NACK"; case FrameTag::beacon: return "BCN"; }
    return "BCN";
}
// ★★★ §T1 2026-08-14 — THE ONE `TxParams` BUILDER. All four `_hal.tx()` hand-offs in `lib/core` build their params
// here, so the params can no longer be assembled field-by-field at a site that forgets one (U2, the S1/L9 shape).
// ⛔⛔ IT DERIVES NOTHING FROM LIVE STATE, AND `static` IS WHAT ENFORCES THAT — it cannot reach `_pending_tx` even
//    by accident. `flight_seq` is supplied BY THE CALLER, at the act:
//      · `tx_with_retry`         DATA  -> the CURRENT `PendingTx::flight_gen` (this IS the flight being handed)
//      · `retry_stashed`         DATA  -> ★ `TxStashSlot::flight_gen`, NEVER the current one: this function has no
//                                         pre-transmit flight guard, so its bytes may belong to a SUPERSEDED flight
//      · `rts_duty_defer_fire`   RTS   -> `RtsDutyDefer::flight_gen`, the identity STORED in that carrier
//      · `tx_flood` / CTS/ACK/NACK     -> **0**, passed deliberately: they belong to no flight
// ⛔ A builder that read the current flight instead would label a stale retry as the NEW flight — a reconstructed
//    fact, i.e. a false confirmation, which is the exact defect class the identity exists to prevent.
// ⓘ §T2: DeviceHal is the production reader of `TxParams::seq`, carrying it with the frame through queue,
//    in-flight record and outcome; native TestHal reads it solely for regression evidence. `label` remains derived
//    from the tag through `label_of_frame` — the same pointer the three tag-driven sites already used and, for
//    `rts_duty_defer_fire`/`tx_flood`, the same "RTS"/"BCN" text their literals carried. The identity is internal
//    metadata only and never changes the bytes handed to the radio.
TxParams Node::tx_params_of(uint16_t tag, int16_t sf, uint32_t flight_seq, uint64_t deadline_ms) {
    TxParams p;
    p.sf    = sf;
    p.label = label_of_frame(frame_tag_of(tag));
    p.tag   = tag;
    p.seq   = flight_seq;
    p.deadline_ms = deadline_ms;   // [[B159]]: 0 = no deadline (every frame but a gateway-bound RTS)
    return p;
}
// ★★★ §B186a — THE FOUR MOBILE TX IDENTITIES, encoded into `TxParams::tag`'s HIGH byte. See the contract at the
// `MobileTxOp` declaration in node.h. These five functions are the whole mechanism; every one is pure.
// ⛔ `frame_tag_of` is what keeps the slice byte-inert for every non-mobile frame AND for the mobile frames'
//    handling: the low byte is exactly what `on_radio_busy` used to cast, so `retry_slot_of` / `label_of_frame` /
//    the giveup arm see unchanged values. (An unknown low byte still falls through to their trailing returns, as
//    it did before — see label_of_frame's note on the HAL-supplied uint16.)
// THE ONE ENCODER (U1) — everything else that needs a tag goes through it, so the format cannot be written two ways.
uint16_t Node::tx_tag_of(FrameTag t, MobileTxOp op) {
    return static_cast<uint16_t>((static_cast<uint16_t>(op) << 8) | static_cast<uint16_t>(t));
}
// A mobile J frame is ALWAYS `FrameTag::beacon` (lbt_complete's tag table maps all four kinds there), so the public
// form a host/test needs takes only the operation.
uint16_t Node::mobile_tx_tag(MobileTxOp op) { return tx_tag_of(FrameTag::beacon, op); }
// ⛔⛔ REPAIRED 2026-08-13 — THE FIRST VERSION OF THIS FUNCTION CARRIED A COMMENT ASSERTING A PROTECTION THE CODE
// DID NOT HAVE, WHICH IS THE DEFECT CLASS THIS ARC HAS PAID FOR ELEVEN-PLUS TIMES. It claimed *"no `default:` —
// -Wswitch must fail the build when a fifth operation is added"* and was wrong TWO ways:
//   (a) a `default: break;` sat FOUR LINES BELOW that very comment; and
//   (b) worse, and the reason (a) hardly mattered: it switched on `hi`, a **`uint8_t`**, and **-Wswitch gives no
//       exhaustiveness checking at all when the condition is an integer** — so the guard could never have fired
//       even with the `default:` removed. A comment is not a gate.
// ★ THE GUARD IS NOW REAL, and it is the pattern `mobile_op_of_kind` (three lines below) already used: switch on
//   the ENUM TYPE, list every enumerator, and have NO `default:`. Adding a fifth `MobileTxOp` now fails the build
//   HERE under `-Werror=switch` (proved by mutation, not asserted).
// ⓘ The trailing return is NOT a `default:` in disguise and is load-bearing for a different reason: `tag` is a
//   HAL-supplied uint16, so its high byte can hold a value no enumerator names (a newer build's operation
//   arriving at an older one). That case must report NOTHING rather than guess an op — the same
//   representable-but-unnamed argument `label_of_frame` / `retry_slot_of` document for `FrameTag`.
Node::MobileTxOp Node::mobile_op_of_tag(uint16_t tag) {
    const MobileTxOp op = static_cast<MobileTxOp>(static_cast<uint8_t>(tag >> 8));
    switch (op) {   // no `default:` — and the condition is the ENUM, which is what makes -Wswitch bite
    case MobileTxOp::discover: case MobileTxOp::offer:
    case MobileTxOp::claim:    case MobileTxOp::reclaim: return op;
    case MobileTxOp::none:                               return MobileTxOp::none;
    }
    return MobileTxOp::none;   // an out-of-range cast (see above): report NOTHING rather than guess an op
}
Node::FrameTag Node::frame_tag_of(uint16_t tag) { return static_cast<FrameTag>(tag & 0xFFu); }
Node::MobileTxOp Node::mobile_op_of_kind(LbtKind kind) {
    switch (kind) { case LbtKind::mobile_discover: return MobileTxOp::discover;
                    case LbtKind::mobile_offer:    return MobileTxOp::offer;
                    case LbtKind::mobile_claim:    return MobileTxOp::claim;
                    case LbtKind::mobile_reclaim:  return MobileTxOp::reclaim;
                    case LbtKind::rts: case LbtKind::nack: case LbtKind::flood: return MobileTxOp::none; }
    return MobileTxOp::none;   // no `default:` above -> -Wswitch catches a new LbtKind that forgets its op
}
const char* Node::mobile_tx_op_name(MobileTxOp op) {
    switch (op) { case MobileTxOp::discover: return "discover"; case MobileTxOp::offer: return "offer";
                  case MobileTxOp::claim:    return "claim";    case MobileTxOp::reclaim: return "reclaim";
                  case MobileTxOp::none:     return "none"; }
    return "none";
}
// Telemetry-only: the BusyReason a refusal carried, by name. The numeric `reason` is emitted beside it (the
// pre-existing `radio_busy` convention) — the name exists so an evidence fixture can match on the CONDITION
// instead of on an enum ordinal that a future insertion could renumber.
const char* Node::busy_reason_name(BusyReason r) {
    switch (r) { case BusyReason::channel_busy:        return "channel_busy";
                 case BusyReason::self_tx_in_flight:   return "self_tx_in_flight";
                 case BusyReason::oversized:           return "oversized";
                 case BusyReason::duty_cycle_exceeded: return "duty_cycle_exceeded";
                 case BusyReason::none:                return "none"; }
    return "unknown";
}
int Node::retry_slot_of(FrameTag tag) {
    // PORT DIVERGENCE (deliberate, non-goal): Lua keys its stash by string label and has SEPARATE retry-eligible
    // labels "CTS" vs "CTS-dup" (and "K-dup", "Q") — dv:3073-3081. We collapse the dup variants into the base slot
    // (CTS-dup -> cts slot 0), so a fresh CTS and a dup-CTS share one slot (a 2nd overwrites the 1st's retry budget).
    // Benign: these CTS variants target the same flight + a lost CTS retry is recovered by the peer's rts_timeout
    // re-RTS; and it is gate-inert (on_radio_busy never fires at lbt_enabled=false). A byte-faithful CTS-dup/K-dup/Q
    // split is a documented R-future non-goal ([[r4.5b spec §7]]).
    // §w4-switchenum: the rts/beacon exclusion is now IN THE CODE, not only in the comment (was `default: return -1`),
    // so -Wswitch fails the build on a new FrameTag instead of silently making it non-retry-eligible. The trailing
    // return keeps the out-of-range behaviour verbatim (see label_of_frame: the tag is a cast HAL uint16).
    switch (tag) { case FrameTag::cts: return 0; case FrameTag::data: return 1;
                   case FrameTag::ack: return 2; case FrameTag::nack: return 3;
                   case FrameTag::rts: case FrameTag::beacon: return -1; }   // rts/beacon NOT retry-eligible
    return -1;
}

// Duty-cycle consumption readout (console `duty` + companion). Pure: surfaces the SAME budget/used/recovery
// duty_over_budget uses, without a hypothetical frame ("where am I NOW", not the pre-TX check). 100% = silent.
Node::DutyStatus Node::duty_status() const {
    if (_duty_cycle_budget_ms == 0) return DutyStatus{0, 0, false};   // duty_cycle <= 0 -> no limit (unlimited)
    const uint64_t used = _hal.airtime_used_ms(_cfg.duty_cycle_window_ms);
    const uint8_t  pct  = (used >= _duty_cycle_budget_ms) ? 100
                          : static_cast<uint8_t>(used * 100 / _duty_cycle_budget_ms);
    uint32_t avail = 0;
    if (pct >= 100) {                                                 // over budget -> when the oldest TX ages out of the window
        const uint64_t oldest = _hal.oldest_tx_end_ms();
        const uint64_t now    = _hal.now();
        avail = (oldest > 0 && oldest + _cfg.duty_cycle_window_ms > now)
                ? static_cast<uint32_t>(oldest + _cfg.duty_cycle_window_ms - now)
                : static_cast<uint32_t>(_cfg.duty_cycle_window_ms);
    }
    return DutyStatus{pct, avail, true};
}

// Anti-spam v2 (2026-07-02): the `limits` companion query snapshot. Live-computed, const, no state change — composes
// the earlier-slice getters (channel_duty_budget_ms/channel_cap_origin/rt_count/max_data_sf/duty_status) + the self-gate
// state (_channel_buffer own count / _last_channel_origin_ms / _last_dm_origin_ms). ch_ceiling reuses channel_capacity_C()
// so the shown C is byte-identical to the enforced cap's C (MF8). *_next_ms = max(burst-floor remaining, duty recovery).
Node::LimitsSnapshot Node::limits_snapshot() const {
    LimitsSnapshot s{};
    s.win_ms       = protocol::originator_window_ms;
    s.n            = rt_count();
    s.ch_sf        = max_data_sf();
    s.ch_cap       = channel_cap_origin();
    s.ch_min_ms    = _cfg.channel_min_interval_ms;
    s.dm_min_ms    = _cfg.dm_min_interval_ms;
    s.duty_ms      = channel_duty_budget_ms();                            // 5-min D basis (0 = duty disabled), MF1
    s.duty_used_ms = static_cast<uint32_t>(_hal.airtime_used_ms(protocol::originator_window_ms));
    // C (channel ceiling): the SAME helper channel_cap_origin() uses (0 when duty disabled -> legacy-flat-cap regime).
    s.ch_ceiling   = channel_capacity_C();

    // window_left: originator_window_ms is a rolling counter (airtime_used_ms), so there is no single reset instant —
    // report the full window as "left" (the app reads it as the reset horizon; the cap is a sliding count, not a hard reset).
    s.win_left_ms  = protocol::originator_window_ms;

    const uint64_t now = _hal.now();
    const DutyStatus ds = duty_status();

    // ch_used = this node's OWN distinct floods currently held — the exact inline loop the do_send_channel self-gate uses.
    uint16_t used = 0;
    for (uint16_t i = 0; i < _active->_channel_buffer_n; ++i)
        if (_active->_channel_buffer[i].origin == _node_id) ++used;
    s.ch_used = used;

    // ch_next_ms: the 10s channel burst-floor remaining (mirrors the self-gate's _last_channel_origin_ms check),
    // then let duty recovery dominate when it is larger. On a fresh node both are 0 -> ready now.
    uint32_t ch_next = 0;
    if (_last_channel_origin_ms != 0 && now - _last_channel_origin_ms < _cfg.channel_min_interval_ms)
        ch_next = static_cast<uint32_t>(_cfg.channel_min_interval_ms - (now - _last_channel_origin_ms));
    if (ds.avail_ms > ch_next) ch_next = ds.avail_ms;                    // duty recovery dominates when silent
    s.ch_next_ms = ch_next;

    // dm_next_ms: the 3s DM burst-floor remaining (mirrors the node_mac DM self-throttle's _last_dm_origin_ms check),
    // then duty recovery. Fresh node -> 0.
    uint32_t dm_next = 0;
    if (_last_dm_origin_ms != 0 && now - _last_dm_origin_ms < _cfg.dm_min_interval_ms)
        dm_next = static_cast<uint32_t>(_cfg.dm_min_interval_ms - (now - _last_dm_origin_ms));
    if (ds.avail_ms > dm_next) dm_next = ds.avail_ms;
    s.dm_next_ms = dm_next;
    return s;
}

// check_duty_cycle (Lua dv:3573-3593): true if a `len`-byte TX at `sf` would breach the duty budget; *wait_ms = the
// earliest moment a fresh TX could fit (oldest in-window entry ages out), floored to 1. Disabled (budget 0) -> false.
// Pure airtime/timestamp arithmetic — NO rand. Used by tx_with_retry (#2 duty pre-check, retry-eligible frames only).
bool Node::duty_over_budget(size_t len, int16_t sf, uint32_t* wait_ms) {
    if (_duty_cycle_budget_ms == 0) return false;
    const uint64_t airtime = airtime_ms(sf, active_bw_hz(), active_cr(), protocol::preamble_sym,
                                        static_cast<uint16_t>(len));
    const uint64_t used = _hal.airtime_used_ms(_cfg.duty_cycle_window_ms);
    if (used + airtime <= _duty_cycle_budget_ms) return false;
    const uint64_t oldest = _hal.oldest_tx_end_ms();
    const uint64_t now    = _hal.now();
    uint32_t w = (oldest > 0 && oldest + _cfg.duty_cycle_window_ms > now)
                 ? static_cast<uint32_t>(oldest + _cfg.duty_cycle_window_ms - now)
                 : static_cast<uint32_t>(_cfg.duty_cycle_window_ms);
    if (w < 1) w = 1;                                                  // guarantee forward progress (dv:3590)
    if (wait_ms) *wait_ms = w;
    return true;
}

// R4.5b central TX (Lua tx_with_retry dv:3599-3639): STASH the retry-eligible frame so on_radio_busy can re-issue
// it on a busy channel, then hand to the radio tagged with the frame type (the sim echoes the tag back). RTS and
// beacon are not retry-eligible (slot -1).
// ★ §tx-admission TX1 — THE INERTNESS ARGUMENT FOR EVERY NON-reqpubkey CALLER, pinned rather than argued: the three
// readers below branch on `!= deferred_retry_armed`, and BOTH other enumerators satisfy that, so their behaviour is
// bit-for-bit the pre-TX1 `handed == true`. A fourth enumerator added on the wrong side of this line would change
// DATA post-TX arming silently; these asserts make that a build failure instead.
Node::TxHandOff Node::tx_with_retry(const uint8_t* bytes, size_t len, int16_t sf, FrameTag tag, MobileTxOp op) {
    static_assert(TxHandOff::handed   != TxHandOff::deferred_retry_armed, "TX1: `handed` must satisfy the readers' predicate");
    static_assert(TxHandOff::rejected != TxHandOff::deferred_retry_armed, "TX1: a HAL rejection must still arm the MAC timeout that recovers a retry-eligible frame");
    const int slot = retry_slot_of(tag);
    if (slot >= 0) {
        TxStashSlot& s = _tx_stash[slot];
        s.valid = true; s.sf = sf; s.retries_left = protocol::tx_defer_max_retries;
        s.reissue_pending = false;   // a fresh attempt: only the duty-defer / on_radio_busy paths below arm a re-issue
        s.flight_gen = _active->_pending_tx ? _active->_pending_tx->flight_gen : 0;   // L9: the EXACT flight this DATA belongs to (the retry_stashed re-arm guard). Was the 4-bit ctr_lo (1/16 aliasing let a re-arm fire against a since-replaced flight); flight_gen is monotonic per-flight = exact. CTS/ACK/NACK slots never consult it.
        s.len = static_cast<uint16_t>(len < sizeof(s.buf) ? len : sizeof(s.buf));
        for (uint16_t i = 0; i < s.len; ++i) s.buf[i] = bytes[i];
    }
    // SHARED-BUG FIX (#2): duty pre-check (Lua dv:3615-3635). Over budget -> emit duty_cycle_blocked + DEFER via a
    // timer (re-run tx_with_retry from the stash) instead of handing to the radio — else the sim's duty hard-block
    // bounces it via on_radio_busy, consuming a stash retry + an LBT draw per bounce (the Lua re-defers with fresh
    // retries). DRAW-FREE; gate-inert at healthy duty (the check passes -> _hal.tx, byte-identical). Scoped to the
    // retry-eligible frames (slot>=0): only they have a stash to re-run from, and only they hit the stash-retry
    // accounting the bug is about. slot<0 (RTS/beacon) keep their own recovery (rts_timeout / tx_flood's own duty
    // pre-check dv:7781), so they are NOT deferred here.
    uint32_t wait = 0;
    if (slot >= 0 && duty_over_budget(len, sf, &wait)) {
        MR_EMIT("duty_cycle_blocked", EF_S("label", label_of_frame(tag)), EF_I("wait_ms", wait), EF_S("source", "tx_with_retry"));
        _tx_stash[slot].reissue_pending = true;                        // a duty re-issue timer is now armed (gates the gateway layer swap)
        (void)_hal.after(wait, kDutyDeferTimerId + static_cast<uint32_t>(slot));
        return TxHandOff::deferred_retry_armed;                        // NOT handed to the radio (caller must not arm post-tx state)
    }
    // §B186a: the tag carries the frame type in its LOW byte (verbatim) and the mobile operation in its HIGH byte.
    // ⛔ `p.label` is DELIBERATELY LEFT AT "BCN" for a mobile J frame: the label is what the simulator prints in its
    //    `tx` / `tx_deferred` records, so renaming it would move every mobile stream line AND break the [[B183]]
    //    correlator, which binds a lost J frame to a same-millisecond **BCN** refusal. The identity belongs in the
    //    tag (which the sim does not serialize) — that is why the corpus movement here is only the new emit's.
    // §T1: identity = the CURRENT `PendingTx::flight_gen` for a DATA — this function IS the hand-off of the live
    // flight, so the fact is established at the act, not reconstructed later. ⛔ **0** for every other tag
    // (CTS/ACK/NACK responses and the mobile J frames): they belong to no flight of ours, and stamping the live
    // flight onto them would attribute an unrelated frame's completion to it. ⓘ Same read as the stash write at
    // the top of this function (`s.flight_gen`), deliberately — one flight, one identity.
    const uint32_t flight_seq = (tag == FrameTag::data && _active->_pending_tx) ? _active->_pending_tx->flight_gen : 0u;
    // [[B159]]: an RTS carries the air deadline to the physical start; every other tag gets the 0 sentinel.
    TxParams p = tx_params_of(tx_tag_of(tag, op), sf, flight_seq,
                              tag == FrameTag::rts ? rts_air_deadline_ms() : 0u);   // op == none ⇒ the pre-slice tag value, bit for bit
    // ★★★ §tx-admission TX1 (2026-08-01): the TxResult was DISCARDED here and this returned `true // handed`
    // unconditionally. `DeviceHal::tx` answers `busy` when its 8-entry outbound ring is full — it bumps `txq_drops`
    // and **does not retain the frame** — and `too_long` past the SX1262 length register. For a `slot < 0` frame
    // (RTS / beacon-flood) there is no stash and no MAC timeout, so that is a DEFINITIVE drop that was reported
    // upward as a send. Now it is answered honestly. See Node::TxHandOff for why this is three-way and not a bool.
    // ⓘ Telemetry only (MR_EMIT is device-stripped): the metal-side diagnostic is DeviceHal's own `txq_drops`
    // counter, which already existed. A per-frame device log would fire on every rejection on a saturated radio —
    // noise, and out of scope for this slice.
    const TxResult tr = _hal.tx(bytes, len, p);
    if (tr != TxResult::ok) {
        MR_EMIT("tx_hal_rejected", EF_S("label", label_of_frame(tag)), EF_I("result", static_cast<uint8_t>(tr)),
                EF_I("len", static_cast<int64_t>(len)));
        return TxHandOff::rejected;
    }
    // ★★★★★ §hybrid-rts S4d (2026-08-10) — ⛔⛔ **THE ONE CROSSING POINT FOR `data_ever_admitted`. THE WRITE LIVES
    // HERE, NOT AT THE CALLERS, AND THAT IS THE WHOLE POINT OF THE FIX.**
    // ⛔ WHAT WAS WRONG: the only writer sat in `do_data_tx`'s `disp == TxHandOff::handed` arm — the INITIAL send
    //    path. But `duty_defer_fire` re-enters THIS function from the stash when the duty wait expires
    //    (`tx_with_retry(s.buf, s.len, s.sf, tag) != deferred_retry_armed`), so a DATA that was duty-deferred and
    //    LATER admitted got no write at all. ⇒ `true` was honest ("an admission was observed") but **`false` was
    //    NOT**, while the consumer maps `false` **CATEGORICALLY** to `basis=alternate_path`, which the spec defines
    //    as *"no DATA has been admitted locally"* (design §5.2 item 2). A best-effort flag cannot carry a
    //    categorical label.
    // ★★ WHY THIS PLACEMENT MAKES IT EXACT RATHER THAN BEST-EFFORT: **every** DM-DATA admission — initial AND
    //    duty-deferred-retry — necessarily crosses this `_hal.tx()`. Establishing the fact at the crossing rather
    //    than at an exit makes it true by construction, **and makes a future call path unable to bypass it.**
    // ★★ THE STRUCTURAL LESSON, and it is [[B162]]'s refusal-banner lesson in a second shape: **A GUARANTEE MADE AT
    //    ONE OF SEVERAL EXITS IS NOT MADE AT ALL.** ⛔ Therefore do NOT "fix" a future gap by adding a per-path
    //    assignment: that is this defect in a new shape, and it is exactly what [[B164]] warned against for the
    //    retry sites.
    // ★ WHY `retry_stashed()` NEEDS NO WRITER — stated here so nobody adds a third copy. `retry_stashed` calls
    //   `_hal.tx` DIRECTLY (bypassing this function), so it looks like a second crossing. It is not a NEW one:
    //   · it is reached ONLY from the `kRadioBusyRetryTimerId + slot` timer (`node.cpp`'s `on_timer` dispatch),
    //     armed ONLY inside the refusal arm of `Node::on_tx_complete` (§T1 moved that body out of `on_radio_busy`,
    //     which is now the adapter) after `retry_slot_of(tag) >= 0 && s.valid`;
    //   · that arm REPORTS a frame the HAL had already taken — for the DATA slot its `info.tag` can only be
    //     `FrameTag::data`, and the ONLY `_hal.tx` in `lib/core` that ever carries that tag is the one above
    //     (the other three are the RTS at `rts_duty_defer_fire`, the BCN at `tx_flood`, and `retry_stashed` itself,
    //     which only ever re-sends bytes THIS site already admitted). ⇒ reaching `retry_stashed` for the DATA slot
    //     REQUIRES a prior successful admission here, so the flag is ALREADY true for that flight;
    //   · and it re-sends `s.buf` — the stashed bytes of the very frame that was admitted — so it can never air a
    //     DIFFERENT flight's DATA. If the flight has since been replaced, the NEW flight's `false` is CORRECT:
    //     nothing of the new flight was ever admitted.
    //   ⚠ Checked in BOTH directions (the METHOD rule this arc keeps relearning): it cannot air a DATA whose flight
    //   has no write (above), and it cannot cause a write for a flight that aired nothing (it takes no write).
    // ⛔ THE GUARD IS `!m_broadcast`, LOAD-BEARING: `do_data_tx`'s M-broadcast arm reaches this function with
    //    `FrameTag::data` (`node_mac.cpp:1788`) but airs an **M frame (cmd 0xA)**, not a DATA frame, and
    //    `handle_rts`'s credit refuses an `m_broadcast` flight outright — so booking it would be a lie about a
    //    frame type the consumer never labels. The same guard covers the duty-deferred re-run of that M frame.
    // ⓘ WHAT THIS DOES **NOT** FIX, unchanged and still [[B164]]: the flag is still not proof of AIRING. Both
    //   post-admission drop mechanisms remain — `on_tx_complete`'s refused arm for `FrameTag::data` (reached
    //   through the `on_radio_busy` adapter since §T1) and `pump_tx()`'s failed arm (`device_hal.cpp:38-46`) —
    //   and neither can unset it. ⛔ Option (b), a
    //   flight-correlated TX-completion signal, stays **DEFERRED, NOT DISMISSED** (no consumer needs "aired").
    //   ⇒ what S4d closes is the FALSE-NEGATIVE direction **for admission**, exactly, and nothing more.
    if (tag == FrameTag::data && _active->_pending_tx && !_active->_pending_tx->m_broadcast)
        _active->_pending_tx->data_ever_admitted = true;
    return TxHandOff::handed;
}

// SHARED-BUG FIX (#2): the duty-defer timer (kDutyDeferTimerId+slot) fired — re-run tx_with_retry from the stashed
// frame (re-checks duty + re-stashes fresh retries, faithful to the Lua `self:after(wait, tx_with_retry)` re-run).
void Node::duty_defer_fire(uint8_t slot) {
    if (slot >= kRetrySlots) return;
    TxStashSlot& s = _tx_stash[slot];
    if (!s.valid) return;
    static const FrameTag kSlotTag[kRetrySlots] = { FrameTag::cts, FrameTag::data, FrameTag::ack, FrameTag::nack };
    const FrameTag tag = kSlotTag[slot];
    // DATA staleness guard (review #6): if the flight moved on during the duty wait (ACK/NACK/implicit-ack replaced
    // _active->_pending_tx), do NOT re-transmit the stale DATA / re-stash with a mismatched ctr_lo. Follows the Lua
    // m_broadcast retry guard (dv:12172). CTS/ACK/NACK are idempotent responses -> no flight guard.
    // ⛔⛔ CORRECTED 2026-08-14 (§T1, V1): this comment used to say the guard *"Mirrors retry_stashed"*. IT DOES NOT,
    //    AND THE DIFFERENCE IS LOAD-BEARING. `retry_stashed` has NO pre-transmit flight guard at all — it calls
    //    `_hal.tx()` unconditionally, and its ONLY `flight_gen` test guards the POST-tx ACK re-arm. ⇒ this function
    //    cannot re-transmit a superseded DATA; `retry_stashed` CAN, and routinely may. Anything that reasons about
    //    the two paths as equivalent (identity, "aired" attribution, a completion report) is reasoning from a
    //    symmetry that is not there — which is exactly how §T1's identity hazard stayed invisible.
    if (tag == FrameTag::data && (!_active->_pending_tx || _active->_pending_tx->flight_gen != s.flight_gen)) return;   // L9: exact flight match (was the 4-bit ctr_lo, 1/16 alias)
    // §tx-admission TX1: `!= deferred_retry_armed` is EXACTLY this site's previous `handed == true` — a HAL
    // rejection must still arm the ACK wait, because for a retry-eligible frame that timeout IS the recovery.
    const bool handed = tx_with_retry(s.buf, s.len, s.sf, tag) != TxHandOff::deferred_retry_armed;   // re-runs the duty pre-check (re-defers if still over budget)
    // DATA re-hand: re-arm the ACK wait do_data_tx skipped at defer-time (the DATA now hit the air). Anchored to the
    // actual send time, matching the Lua deferred re-run replaying on_handed (dv:3633 -> 3637 -> 10274-10278).
    if (handed && tag == FrameTag::data && _active->_pending_tx && _active->_pending_tx->flight_gen == s.flight_gen) {   // L9: exact flight match
        _active->_pending_tx->awaiting_ack = true;
        start_ack_timeout();
    }
}

// R4.5b: re-issue a stashed frame (kRadioBusyRetryTimerId+slot fire). Re-uses the SAME tag so a repeat block
// lands back on the same stash slot (retries_left already decremented in on_radio_busy).
void Node::retry_stashed(uint8_t slot) {
    if (slot >= kRetrySlots) return;
    TxStashSlot& s = _tx_stash[slot];
    if (!s.valid) return;
    static const FrameTag kSlotTag[kRetrySlots] = { FrameTag::cts, FrameTag::data, FrameTag::ack, FrameTag::nack };
    const FrameTag tag = kSlotTag[slot];
    // ★★ §T1: identity = `TxStashSlot::flight_gen` — ⛔ NEVER `_active->_pending_tx->flight_gen`. THIS FUNCTION HAS
    // NO PRE-TRANSMIT FLIGHT GUARD (unlike `duty_defer_fire`): it re-sends `s.buf` unconditionally, so the bytes may
    // belong to a flight that has already been REPLACED — and the exact-match test six lines below exists precisely
    // because that happens. Reading the current flight here would report the stale frame's completion against the
    // NEW flight and falsely confirm it. `s.flight_gen` is the identity the stash captured at hand-off time.
    // ⓘ **0** for CTS/ACK/NACK: those slots never consult `s.flight_gen` (it holds whatever flight was live when
    //    an unrelated response was stashed), so passing it would be a borrowed identity, not this frame's.
    const uint32_t flight_seq = (tag == FrameTag::data) ? s.flight_gen : 0u;
    TxParams p = tx_params_of(static_cast<uint16_t>(tag), s.sf, flight_seq);
    const TxResult tr = _hal.tx(s.buf, s.len, p);
    if (tr != TxResult::ok)
        MR_EMIT("tx_hal_rejected", EF_S("label", label_of_frame(tag)),
                EF_I("result", static_cast<uint8_t>(tr)), EF_I("len", static_cast<int64_t>(s.len)));
    s.reissue_pending = false;   // the armed busy re-issue has now been handed to the radio. UNLIKE the duty path
                                 // (duty_defer_fire -> tx_with_retry, which clears it), THIS path calls _hal.tx
                                 // directly, so clear it HERE — else a gateway's busy-retried ACK leaves the stash
                                 // reissue_pending forever and layer_swap_blocked() deadlocks the leaf swap. If the
                                 // re-TX busies AGAIN, on_radio_busy re-arms + re-sets it.
    // DATA re-issue: re-arm the ACK wait the on_radio_busy block cleared, exactly as the Lua DATA on_handed does
    // (dv:10270-10278) — fires on the initial tx AND on the stash retry. Without this the re-sent DATA flies but the
    // sender stays !awaiting_ack with no ack-timeout, so the returning ACK is dropped + the flight never recovers.
    // Guarded on the pending flight (flight_gen, exact) so a retry against a since-replaced flight does NOT re-arm.
    if (tag == FrameTag::data && _active->_pending_tx && _active->_pending_tx->flight_gen == s.flight_gen) {   // L9: exact flight match
        _active->_pending_tx->awaiting_ack = true;
        start_ack_timeout();
    }
}

void Node::do_data_tx() {
    if (!_active->_pending_tx || _active->_pending_tx->awaiting_ack || _active->_pending_tx->chosen_data_sf == 0) return;
    PendingTx& pt = *_active->_pending_tx;
    // Channel M-broadcast: send the lean M frame (cmd 0xA) on the data SF, NOT a DATA frame. No DM header /
    // hop-budget / visited / MAC — pt.inner = [channel_msg_id 4 BE][channel_id][flavor][body]. Fire-and-forget
    // (no ACK): clear the flight after the M-frame airtime (kMBcastClearTimerId).
    if (pt.m_broadcast) {
        if (pt.inner_len < 6) { _hal.log("M-frame inner_len < 6 — refusing tx"); _active->_pending_tx.reset(); become_free(); return; }   // fail loud: would underflow inner_len-6 -> OOB body span
        const uint32_t id = m_inner_id(pt.inner);
        m_in min{};
        min.leaf_id = _cfg.leaf_id; min.channel_id = pt.inner[4]; min.flavor = pt.inner[5];
        min.channel_msg_id = id;
        if (min.flavor & protocol::channel_flavor_team) {
            // §mobile 6.3: a team frame carries team_id (pack_m appends it) — stamped from _cfg.team_id because the
            // frame itself carries no scope (TxItem/PendingTx have no team_id field, by design: adding one would grow
            // every carrier for a value that is derivable).
            // ★ THE REAL INVARIANT (§clean-team-channel, 2026-07-27): every team-scoped M payload reaching this line was
            // minted or admitted under the team that is live RIGHT NOW — guaranteed by purge_team_channel_state()
            // (node_channel.cpp), which drops the OLD team's buffer rows, flood states, queued TxItems AND the in-flight
            // flight at the moment _cfg.team_id changes (Node::set_team_id is the only live writer). The previous claim
            // here — "we only EMIT our own team's messages (originated, or relayed after the ingest team-match), so
            // _cfg.team_id is always the right one" — was FALSE for exactly one case, a TEAM SWITCH: the ingest match
            // held when the payload arrived, not when it was re-emitted, so an old team's message was re-stamped into
            // the new team. That case is now purged at the source rather than papered over here.
            // C2 backstop for the one shape that must NEVER reach the air: team-flavored with NO team. pack_m would
            // write team_id 0, and a 0 team_id parses as a PLAIN LEAF message (same_team(0) is false everywhere), so it
            // would be ingested by every static node on the leaf — a containment breach, not just a mis-stamp. The purge
            // makes this unreachable; if it ever fires, the purge has a hole. Same refuse shape as the inner_len guard.
            if (_cfg.team_id == 0) { _hal.log("team M-frame with no team_id — refusing tx"); _active->_pending_tx.reset(); become_free(); return; }
            min.team_id = _cfg.team_id;
        }
        min.body = std::span<const uint8_t>(pt.inner + 6, static_cast<size_t>(pt.inner_len - 6));
        uint8_t mbuf[protocol::lora_max_frame_bytes];
        const size_t mlen = pack_m(min, std::span<uint8_t>(mbuf, sizeof(mbuf)));
        if (mlen == 0) { _hal.log("M-frame pack failed"); return; }
        const bool handed = tx_with_retry(mbuf, mlen, static_cast<int16_t>(pt.chosen_data_sf), FrameTag::data) != TxHandOff::deferred_retry_armed;   // §tx-admission TX1: verbatim the old `handed`
        MR_EMIT("data_tx", EF_I("dst", pt.dst), EF_I("next", pt.next), EF_I("ctr", pt.ctr),
                EF_I("sf", pt.chosen_data_sf), EF_B("m_broadcast", true));
        if (handed) {
            const uint32_t data_air = airtime_ms(pt.chosen_data_sf, active_bw_hz(), active_cr(),
                                                 protocol::preamble_sym, static_cast<uint16_t>(mlen));
            (void)_hal.after(data_air + 5, kMBcastClearTimerId);
        }
        return;
    }
    // Hop budget (§7.6). An ORIGINATOR derives the initial budget from its route:
    // remaining = min(31, rt_hops + slack); a FORWARDER carries the already-decremented
    // values (threaded from handle_data). prev_fwd_rt_hops is ALWAYS re-stamped to
    // self's own rt[dst].hops (never inherited). Pure arithmetic — no rand.
    RtEntry* rte = rt_find(pt.dst, pt.plane);   // Wave 2: this flight's plane (a GLOBAL flight reads _rt, never _rt_team for a colliding id)
    const bool have_rt = (rte != nullptr && rte->n > 0);
    uint8_t hb_remaining, hb_committed, hb_prev_fwd;
    if (pt.has_previous_hop) {                            // forwarder: inherit, re-stamp prev (fallback 0)
        hb_remaining = pt.fwd_remaining;
        hb_committed = pt.fwd_committed;
        hb_prev_fwd  = have_rt ? rte->candidates[0].hops : 0;
    } else {                                              // originator: budget from rt (fallback rt_hops=1)
        const uint8_t rt_hops = have_rt ? rte->candidates[0].hops : 1;
        const int rem = static_cast<int>(rt_hops) + protocol::hop_budget_slack;
        hb_remaining = static_cast<uint8_t>(rem > protocol::hop_budget_max_initial
                                            ? protocol::hop_budget_max_initial : rem);
        hb_committed = 0;
        hb_prev_fwd  = rt_hops;
    }
    const uint8_t mac[4] = { 0, 0, 0, 0 };
    data_in din{};
    // §mobile 3b: the last-mile DATA carries the mobile mark (addr_len=1) so the mobile accepts it + a colliding static rejects
    // it; §6.4: also when `next` is a team peer (team-plane local-id). 0 on every normal flight -> identical wire.
    // ★ §team-parity T8: the DATA's addr_len MUST use the SAME predicate as the RTS's `team_next` (build_rts, :867) —
    // they are one addressing decision on two frames of one flight, and a disagreement makes the receiver's mark-accept
    // reject the DATA it already CTS'd. Narrowed together, with the reasoning at that site.
    din.addr_len = (pt.addr_len == 0 && is_team_peer(pt.next)
                    && flight_is_team_plane(pt.plane, pt.dst)) ? 1 : pt.addr_len; din.flags = pt.flags; din.type = pt.type; din.next = pt.next; din.dst = pt.dst;
    din.hops_remaining = hb_remaining; din.committed_hops = hb_committed;
    din.prev_fwd_rt_hops = hb_prev_fwd; din.ctr = pt.ctr;
    din.inner = std::span<const uint8_t>(pt.inner, pt.inner_len);
    din.mac   = (pt.flags & DATA_FLAG_CRYPTED) ? std::span<const uint8_t>(pt.nonce_seed, 8)   // CRYPTED: 8-B nonce-seed trailer
                                               : std::span<const uint8_t>(mac, 4);             // else the 4-B(-zero) MAC
    uint8_t buf[protocol::lora_max_frame_bytes];
    const size_t dlen = pack_data(din, std::span<uint8_t>(buf, sizeof(buf)));
    if (dlen == 0) {
        // ★★ §B20 (2026-08-28) — **THIS BAIL USED TO LOG AND LEAVE.** No push, no teardown: the flight stayed
        // `_pending_tx` with `awaiting_ack` false and nothing armed to re-fire it, while the RTS this flight had
        // ALREADY aired had burned real airtime. That was the visible half of register [[B20]] — a send that
        // "disappeared" and took the node's MAC with it.
        // ⛔⛔ [[B297]] — **THE CLAIM THAT USED TO STAND HERE WAS ONLY HALF TRUE, AND IT IS CORRECTED IN PLACE
        //   RATHER THAN QUIETLY REWRITTEN.** It read, verbatim:
        //       *"IT IS NOW UNREACHABLE FROM AN ORIGINATION: enqueue_data sizes the seal against `data_inner_cap`,
        //        the packer's own bound, so no same-layer DM can be built too long for its own frame any more."*
        //   True of the SEALED arm only. The PLAINTEXT arm discarded `pack_unicast_inner`'s return, so a body that
        //   overflowed its own inner was queued with `inner_len = 0`, aired its RTS, and arrived HERE — the exact
        //   path [[B296]] shape 3 reproduced (registered mobile, wrapper body 237..239).
        // ✅ AFTER Slice 0h THE CLAIM IS TRUE AS WRITTEN, and for a stated reason rather than by assertion: BOTH
        //   arms of `enqueue_data` now check their packer (the seal against `data_inner_cap`, the plaintext arm
        //   against `pack_unicast_inner`'s own answer — :440), and neither admits a zero-length inner. Native proof
        //   that no origination reaches this line: `test_node_r3.cpp` §B20/B21 asserts `pack_failed == false` for
        //   EVERY carrier shape across the whole body-length band.
        //   It stays as the C2 backstop for every other producer (forwarders, the XL builders) and matches its two
        //   siblings in this function: report, tear the flight down, become free.
        // ⛔ NO `push_send_failed` HERE, DELIBERATELY, and this is the one candidate the slice reports rather
        //   than invents: pack_data has FOUR refusals (addr_len > 1 · CRYPTED without DST_HASH · a wrong-sized
        //   trailer · the length) and only the last is `too_large`, so pushing `too_large` would re-commit
        //   exactly B21's defect — a confident, wrong condition — for the other three. No existing
        //   `SendFailReason` is true for "the frame could not be built"; the honest surface until one is ruled is
        //   the loud telemetry + operator log below. There is no app-facing silence left on the B20 path itself,
        //   because the send is now refused `too_large` before anything airs.
        _hal.log("DATA pack failed");
        MR_EMIT("data_pack_failed", EF_I("dst", pt.dst), EF_I("ctr", pt.ctr),
                EF_I("inner_len", pt.inner_len), EF_I("flags", pt.flags), EF_I("type", pt.type));
        // ★★★ [[B268]] blocker-1, THE **SEVENTH** POST-ADMISSION CARRIER DEATH: this one is deliberately silent
        //     for everybody — the note above records the standing ruling that no honest `SendFailReason` exists
        //     for "the frame could not be built", so ⛔ `generic_owed = false` keeps that silence EXACTLY. Routing
        //     it through the shared helper anyway is the point of "EVERY site": the grant's panel must not freeze
        //     on `GRANT QUEUED` merely because this path has no generic story to tell.
        terminal_carrier_outcome(pt.type, !pt.has_previous_hop, /*generic_owed=*/false,
                                 SendFailReason::none, pt.dst, pt.ctr);
        _active->_pending_tx.reset(); become_free();
        return;
    }
    // ★★★ §hybrid-rts S4b (2026-08-09) — the three-way disposition is kept in `disp` and the legacy two-way
    // `handed` derived from it, so the two questions ("was it admitted?" vs "was it not deferred?") stay distinct.
    // ⓘ §hybrid-rts S4d (2026-08-10) — **THE ORIGINAL WORDING HERE IS CORRECTED, NOT DELETED.** It read *"THE
    //   DISPOSITION IS KEPT, NOT COLLAPSED, BECAUSE TWO DIFFERENT DECISIONS READ IT"*. That was true while the
    //   `data_ever_admitted` writer lived below; S4d moved that writer to the ONE crossing point inside
    //   `tx_with_retry`, so **only ONE decision reads the disposition here now** — `handed`, which gates
    //   `start_ack_timeout()`. ⛔ `disp` is deliberately NOT collapsed into the `!=` expression: the three-way
    //   answer is the honest one at the call site (§tx-admission TX1) and inlining it would re-hide the asymmetry
    //   TX1 exists to surface. ⚠ A comment that survives the code it described is a false claim; this one is fixed
    //   in place because a reader who saw the old sentence must be able to see it withdrawn.
    const TxHandOff disp = tx_with_retry(buf, dlen, static_cast<int16_t>(pt.chosen_data_sf), FrameTag::data);   // R4.5b stash; #2 may duty-defer
    const bool handed = disp != TxHandOff::deferred_retry_armed;   // §tx-admission TX1: verbatim the old `handed` — see TxHandOff for why a HAL rejection must NOT suppress start_ack_timeout()
    MR_EMIT("data_tx", EF_I("dst", pt.dst), EF_I("next", pt.next), EF_I("ctr", pt.ctr),
            EF_I("sf", pt.chosen_data_sf), EF_B("m_broadcast", false));   // emitted before tx_with_retry (dv:10251); m_broadcast handled above (early return)
    // Arm the ACK wait ONLY if the DATA was NOT duty-deferred — mirrors the Lua DATA on_handed (dv:10270-10279) + the
    // not-handed clear (dv:10281-10283). #2's duty defer returns handed=false: arming a short ack-timeout on a stashed
    // DATA would fire before the (long) duty wait, draw a rand + tear the flight down.
    // ⛔ §hybrid-rts S4c (2026-08-10): this comment read *"ONLY if the DATA actually hit the air … fires only on real
    //    self:tx"*. **WITHDRAWN — IT WAS WRONG TWICE.** (i) `handed` here is `disp != deferred_retry_armed`, so a HAL
    //    `rejected` frame ALSO arms the wait — deliberately, per §tx-admission TX1, because the ack-timeout is a
    //    rejection's ONLY recovery; (ii) even `TxHandOff::handed` is an ADMISSION, not an on-air fact (see below).
    //    ⓘ The BEHAVIOUR is correct and untouched; only the sentence describing it was false.
    if (handed) {
        pt.awaiting_ack = true; start_ack_timeout();
        // ★★★★★ §hybrid-rts S4c (2026-08-10) — ⛔⛔ **THE HAL-**ADMISSION** BOUNDARY. IT IS *NOT* A TRANSMISSION
        // BOUNDARY, AND S4's HEADING HERE — *"THE ACTUAL DATA TRANSMISSION BOUNDARY, AND THE ONLY WRITER OF THIS
        // FACT"* — IS WITHDRAWN AT ITS OWN SITE.** Only the "only writer" clause was ever true.
        // ⛔⛔ §hybrid-rts S4d (2026-08-10) — **AND NOW THE "ONLY WRITER" CLAUSE IS WITHDRAWN TOO, BECAUSE IT WAS
        //    TRUE ONLY BY BEING INCOMPLETE.** The writer no longer lives at this exit at all: it lives at the ONE
        //    crossing point inside `tx_with_retry`, immediately after `_hal.tx()` answers `ok`. Everything below
        //    that discusses the flag is kept — the claims were asserted HERE and a reader who saw them must be able
        //    to see them withdrawn HERE — but each is amended to the S4d truth in place.
        // ★ WHAT `TxHandOff::handed` ACTUALLY PROVES: `IHal::tx` returned `ok`. On metal that is an **ENQUEUE** —
        //   `lib/hal/device_hal.cpp:10-12` says so outright (*"tx() ENQUEUES … Returns ok when queued"*), with the
        //   on-air send deferred to `pump_tx()`. ⇒ the flag can be wrong in **BOTH** directions:
        //   · **FALSE POSITIVE (admitted, never aired)** — `Node::on_tx_complete`'s refused arm for
        //     `FrameTag::data` (§T1 moved that body out of `on_radio_busy`, which is now its adapter)
        //     is the medium refusing a frame this flag has ALREADY booked; it clears `awaiting_ack` but **cannot
        //     unset this flag**. ⚠ The path is LIVE, not hypothetical: **652 `data_tx_blocked` events across 15 of
        //     the 36 corpus scenarios.** Second mechanism, metal-only: `pump_tx()`'s failed arm (`device_hal.cpp:
        //     38-46`) DROPS the queued frame with no retry.
        //   · **FALSE NEGATIVE (aired, never recorded)** = [[B164]], see the note below.
        // ⇒ ★★ **SO THE FLAG AND THE `basis` LABEL ARE NAMED FOR ADMISSION (`data_ever_admitted` /
        //   `basis=local_admitted`) AND ARE BEST-EFFORT DIAGNOSTIC TELEMETRY.** The alternative — a
        //   flight-correlated completion signal that establishes "aired" — now exists (§T2) and reports telemetry.
        //   It deliberately does NOT rewrite this admission flag or change either implicit-credit action: neither
        //   basis becomes airing or delivery evidence. The app/UI consumer is the separate T3 slice, so this flag
        //   keeps its exact admission meaning and its single writer.
        // ⛔ §hybrid-rts S4d (2026-08-10) — **"BEST-EFFORT" IS NOW TOO WEAK IN ONE DIRECTION AND MUST BE SPLIT.**
        //    For **ADMISSION** the flag is now **EXACT**: every admission crosses the one write point, so `true`
        //    means an admission was observed AND `false` means none was — which is what makes the consumer's
        //    CATEGORICAL `basis=alternate_path` label ("no DATA has been admitted locally") legitimate. ⛔ For
        //    **AIRING** it is still not evidence at all (the two post-admission drops above). §T2 now reports the
        //    separate completion outcome without mutating this field. ⇒ the honest phrasing remains *"exact about
        //    admission, silent about airing"*.
        // ⛔ THE PLACEMENT IS STILL LOAD-BEARING and must NOT move above the `_hal.tx()` call: a duty-deferred or
        //    HAL-rejected DATA was never even ADMITTED, so booking it before the call would make the flag wrong
        //    about its own, weaker proposition too. The S4 gate mutates exactly that placement and requires a RED.
        //    ⓘ S4d MOVED the write into `tx_with_retry` (still strictly after `_hal.tx()` returns `ok`), so the
        //    invariant is unchanged in substance and is now enforced for EVERY caller instead of this one.
        // ⓘ The M-broadcast arm above returns EARLY, and the crossing point additionally guards `!m_broadcast`:
        //    it airs an M frame (cmd 0xA), not a DATA frame, and `handle_rts`'s credit refuses an `m_broadcast`
        //    flight outright. ⚠ The guard is NOT redundant once the write moved — the M arm reaches
        //    `tx_with_retry` with `FrameTag::data` (`node_mac.cpp:1788`), so without it that path would book a lie.
        //
        // ★★★★★ §hybrid-rts S4b (2026-08-09) — ⛔⛔ **CORRECTED: THE CONDITION IS `disp == handed`, NOT `handed`,
        // AND THE TWO ARE DELIBERATELY DIFFERENT HERE WHILE BEING DELIBERATELY THE SAME ONE LINE ABOVE.**
        // S4 wrote *"the same condition that arms `awaiting_ack`"* and treated that symmetry as the point. It is
        // not: `handed` is `disp != deferred_retry_armed`, so **`TxHandOff::rejected` satisfies it** — the HAL
        // REFUSED the frame (`DeviceHal::tx` on a full ring: `busy`, `txq_drops`, nothing retained) and S4 still
        // recorded the flag, i.e. **a rejection was booked as an admission**.
        // ⚠ WHY THE ASYMMETRY IS RIGHT, stated because it is the part that is easy to get wrong twice:
        //   · `start_ack_timeout()` must fire for BOTH `handed` and `rejected` — §tx-admission TX1's whole finding
        //     (see `TxHandOff` in node.h): a rejection arms NOTHING, so the MAC ack-timeout IS its only recovery,
        //     and suppressing it would leave the flight with none. ⛔ That behaviour is UNCHANGED here.
        //   · `data_ever_admitted` must be true for `handed` ONLY. A DEFERRED frame is legitimately in flight
        //     (`tx_initiating`/`tx_with_retry` answer TRUE-ish for it) and a REJECTED one is not in flight at all —
        //     so the two dispositions are **not symmetric for this flag even though they are for the timeout**.
        //     ⓘ §hybrid-rts S4d: that asymmetry is now STRUCTURAL rather than restated at a caller — the write sits
        //     on the `tr == ok` side of `tx_with_retry`'s own rejection return, so no caller can get it wrong.
        // ★★ AND THIS IS THE SIXTH SITE OF ONE RULE IN THIS ARC — **A FACT IS ESTABLISHED BY THE PHYSICAL ACT,
        //    NEVER BY THE REQUEST**: [[B84]]'s `_tries`, [[B139]]'s `_presence_miss`, [[B145]]/[[B146]]'s OFFER
        //    counters, the re-CLAIM budget, §HYBRID-RTS-S2b's accounting split, and now this flag.
        //    ⚠⚠ **AND S4b APPLIED THAT RULE ONLY ONE STEP: `handed` is the ADMISSION act, not the PHYSICAL one.**
        //    §HYBRID-RTS-S4c's answer is to NAME the flag after the act it really witnesses rather than to chase the
        //    physical act no reader needs — the rule is satisfied by honest naming, not only by moving the write.
        // ⓘ SCOPE FENCE (C1): the `_dm_payload_mean` EWMA below still rolls on `handed`, i.e. it also folds in a
        //    REJECTED frame's length. That is PRE-EXISTING and left alone — it is an airtime-estimator average,
        //    not a claim about a transmission, and moving it would be a behaviour change this slice did not agree.
        // ⚠⚠ [[B164]] — **OPEN, REGISTERED, NOT FIXED HERE, AND IT IS THE *OTHER* DIRECTION OF THE SAME ERROR.**
        //    This is the ONLY WRITER of the flag, but NOT the only boundary at which a DM DATA reaches the radio:
        //    `duty_defer_fire` (this file, the `handed && tag == FrameTag::data` re-hand) and `retry_stashed` (its
        //    direct `_hal.tx`) both fly a DATA for this same flight and NEITHER writes it ⇒ **FALSE NEGATIVE.**
        // ⛔⛔ §hybrid-rts S4d (2026-08-10) — **[[B164]]'s ADMISSION HALF IS NOW CLOSED, AND THE SENTENCE ABOVE IS
        //    HALF-RETIRED IN PLACE.** `duty_defer_fire` re-enters `tx_with_retry`, so it now DOES record the fact —
        //    at the shared crossing point, not with a copy of its own. `retry_stashed` still writes nothing and
        //    still needs nothing: reaching it REQUIRES a prior successful admission at that crossing point, and it
        //    only ever re-sends the stashed bytes of the frame that was admitted (the full structural argument, in
        //    both directions, is at the crossing point). ⇒ §T2 now OBSERVES the separate `aired` / `failed` /
        //    `unknown` attempt outcomes without changing this admission fact. What remains outside this slice is the
        //    app/UI use of `aired` (T3); neither attempt failures nor an unknown completion are terminal send
        //    outcomes.
        // ⛔⛔ §hybrid-rts S4c (2026-08-10) — **A RETIRED CLAIM OF S4b's, CORRECTED IN PLACE.** ⛔ WHAT STOOD HERE:
        //    *"★ THE DIRECTION IS THE SAFE ONE … whereas the defect fixed above was an OVER-claim"*. ★ **THAT IS
        //    FALSE, AND IT WAS AN ASYMMETRY ASSERTED WITHOUT CHECKING THE OTHER DIRECTION.** The over-claim was NOT
        //    fully fixed above: `handed` only proves the HAL **ADMITTED** the frame, and `on_radio_busy` /
        //    `pump_tx()`'s failed arm can still reject it AFTER that ⇒ the flag can also read TRUE for a flight
        //    whose DATA never aired. **IT IS WRONG IN BOTH DIRECTIONS**, which is why S4c renames it instead.
        // ⛔ AND [[B164]]'s FIX IS **NOT** "add the assignment at the two retry sites": that repairs the false
        //    negatives and PRESERVES the late-busy false positive. §T2 instead landed the durable, separate,
        //    flight-correlated completion signal while leaving this flag ADMISSION-named and exact about admission.
        //    See the register entry and `BASELINE.md` §HYBRID-RTS-S4c.
        // ⓘ §hybrid-rts S4d HONOURED THAT PROHIBITION EXACTLY: it added **no** per-path assignment. It moved the
        //    single write to the one point every admission crosses, which closes the admission-side false negative
        //    WITHOUT touching the airing question and without a second copy anyone could forget. See
        //    `BASELINE.md` §HYBRID-RTS-S4c (S4d is recorded in place there).
        // ⛔⛔ §hybrid-rts S4d (2026-08-10) — **THE WRITER THAT STOOD HERE IS GONE, MOVED INTO `tx_with_retry`
        //    IMMEDIATELY AFTER `_hal.tx()` RETURNS `ok`.** What stood here was
        //    `if (disp == TxHandOff::handed) pt.data_ever_admitted = true;` — correct for THIS path and for no
        //    other. ★ THE BLOCKER IT LEFT: a duty-deferred DATA that `duty_defer_fire` LATER admits (the
        //    `tx_with_retry(...) != deferred_retry_armed` re-run in this file) never reached this line, so `false`
        //    did not mean *"no DATA was admitted locally"* — which is precisely what the consumer's
        //    `basis=alternate_path` label asserts CATEGORICALLY (`node_mac_rx.cpp`, design §5.2 item 2).
        // ★★ ⇒ THE FACT IS NOW ESTABLISHED AT THE **ONE CROSSING POINT** EVERY ADMISSION MUST PASS, WHICH MAKES IT
        //    EXACT INSTEAD OF BEST-EFFORT (for admission — NOT for airing; see [[B164]]). ⛔ Do NOT re-add a copy
        //    here or at any other caller: a guarantee made at one of several exits is not made at all.
        //    Full reasoning, including why `retry_stashed` needs no writer, is at the crossing point itself.
        // §3e: roll the DATA-payload mean (EWMA alpha 5/16) over every DATA we pass — feeds exchange_airtime_ms.
        _dm_payload_mean = _dm_payload_mean ? static_cast<uint16_t>((_dm_payload_mean * 11u + pt.inner_len * 5u) / 16u)
                                            : pt.inner_len;
    }
    else        { pt.awaiting_ack = false; }
}

void Node::start_rts_timeout() {
    // M-broadcast (fire-and-forget): there is no CTS to wait for. start_rts_timeout is called at the RTS
    // hand-off in EVERY path (lbt_complete:327 + rts_duty_defer_fire:351) = the Lua's on_handed (dv:7032),
    // so anchor the RTS->DATA gap to the ACTUAL TX here. The DATA then fires cts_to_data_gap_ms AFTER the
    // RTS clears the air, which is exactly when overhearers have received the RTS + retuned to the data SF.
    if (_active->_pending_tx && _active->_pending_tx->m_broadcast) {
        // The gap must outlast the RTS-M's OWN airtime so the M frame fires after the RTS clears the air (and
        // overhearers have decoded it + retuned). The RTS-M is 43 B for a FLOOD (id + 32-B bitmap) vs 9 B for a
        // legacy M_BROADCAST (7 base + id_lo16) — size the gap to the actual RTS, else a flood's M frame fires
        // mid-RTS and overhearers (whose retune window is anchored to the full 43-B RTS) miss it.
        const uint8_t rts_len = _active->_pending_tx->flood ? 43 : 9;
        const uint32_t gap = airtime_routing_ms(rts_len) + protocol::cts_to_data_gap_ms;
        (void)_hal.after(gap, kCtsToDataGapTimerId);                       // RTS->DATA gap fires do_data_tx (no CTS)
        return;
    }
    // ★★★ §hybrid-rts S1 item 8 / [[B158]] — THE CTS-WAIT NOW PRICES THE FRAMES THAT ACTUALLY FLY.
    // ⛔ WHAT WAS HERE: `airtime_routing_ms(8) + airtime_routing_ms(4)` with the comment "Lua RTS_LEN=8 +
    //    CTS_LEN=4". That priced a **phantom 8-byte RTS** for a live 7-byte wire — one byte of unearned margin,
    //    not zero as the design supposed — and a 4-byte CTS. §hybrid-rts S1 makes the unicast RTS 10/11 B, which
    //    overruns that at most PHYs, so leaving it would create an intermediate UNDER-TIMED protocol: the wait
    //    could expire while the request was still on the air.
    // ★ WHAT IT PRICES NOW: the ACTIVE request (10 B plaintext / 11 B crypted) plus the LONGEST possible
    //   response (the 6/7-B terminal CTS), because the sender cannot know whether the receiver's completed-flight
    //   cache will hit. An ordinary 3/4-B CTS is shorter and cancels the timer the moment it arrives
    //   (`handle_cts` -> `_hal.cancel(kRtsTimeoutTimerId)`), so a SUCCESSFUL exchange pays nothing for this —
    //   only the NO-RESPONSE/retry boundary moves.
    // ⓘ PER-PHY, measured (§HYBRID-RTS-S0's 128-cell grid): +20 ms on s18's SF8/BW125k/CR5, +41 ms on s06's
    //   SF8/BW62.5k/CR5, **+0 ms** at BW62.5k/CR5/SF10, and **+1049 ms** at the BW62.5k/CR8/SF12 worst case.
    //   "The extra bytes fall in the same symbol bucket" is TRUE at some PHYs and FALSE at others, and the sign
    //   is not monotone in SF — never quote one figure for the cost of three bytes.
    // ⓘ The domain is read from the flight, so a plaintext flight is priced at 10+6 and only a CRYPTED one pays
    //   11+7. Guarded like the `attempt` term below: no pending flight (a torn-down flight's late re-arm) prices
    //   the CRYPTED worst case, which over-waits and therefore fails safe.
    // ⛔ M_BROADCAST/FLOOD returned above and are UNTOUCHED; the Lua-parity RTS_LEN/CTS_LEN constants elsewhere
    //   mean different things and are NOT folded into these helpers (design §6). S5 audits the remaining sites.
    const bool crypted_flight = _active->_pending_tx
                                ? (_active->_pending_tx->flags & DATA_FLAG_CRYPTED) != 0 : true;
    const uint32_t base = airtime_routing_ms(static_cast<uint16_t>(unicast_rts_wire_len(crypted_flight)))
                        + airtime_routing_ms(static_cast<uint16_t>(terminal_cts_wire_len(crypted_flight)));
    const uint8_t  attempt = static_cast<uint8_t>(protocol::rts_max_retries -
                              (_active->_pending_tx ? _active->_pending_tx->retries_left : 0));
    // x2 backoff, cap x4
    // §CTS-wait metal slop (2026-07-05): base covers ON-AIR time only; the CTS round-trip ALSO crosses TWO radio
    // turnarounds (sender TX->RX + gateway RX->TX) — the real-metal margin airtime_ms can't see. rx_window_slop_ms is
    // ZERO on the sim (HAL default) => delay UNCHANGED on native/sim (s18 byte-identical); ~53ms/turnaround on metal.
    // Was the ONLY handshake-wait omitting it -> a 62.5kHz gateway CTS landed ~204ms past the ~135ms window -> the
    // awaiting_cts was cleared -> the arriving CTS ignored (node_mac_rx.cpp:337) -> endless RTS<->CTS. Mirrors start_ack_timeout.
    const uint32_t slop  = _hal.rx_window_slop_ms(_cfg.routing_sf);
    const uint32_t delay = cts_wait_delay_ms(base, attempt, slop);
    (void)_hal.after(delay, kRtsTimeoutTimerId);
    if (_active->_pending_tx) _active->_pending_tx->timeout_deadline_ms = _hal.now() + delay;   // for reserve_yield's extend-only push
}
void Node::start_ack_timeout() {
    const uint8_t  sf  = _active->_pending_tx ? _active->_pending_tx->chosen_data_sf : max_data_sf();  // pending always set here
    const uint16_t len = static_cast<uint16_t>(18 + (_active->_pending_tx ? _active->_pending_tx->inner_len : 0));
    // base = DATA airtime + the ACK's routing airtime. PLUS the REAL hardware turnaround airtime_ms can't see
    // (rx_window_slop_ms, ZERO on the sim): the ACK round-trip crosses TWO SPI SF-reconfigs — the receiver
    // retunes data->routing to SEND the ACK, and WE restore RX data->routing to HEAR it. Without them the
    // ack-timeout landed ~70 ms BEFORE the ACK on metal -> it cleared awaiting_ack, so the real ACK was then
    // ignored (handle_ack needs awaiting_ack) and a redundant re-RTS fired on a DELIVERED flight. Mirrors
    // start_pending_rx_expiry, which already carries the slop for the symmetric DATA wait. (Bench: SF9 DATA.)
    // ⚠ §rts-cr — DELIBERATELY NOT CONVERTED, and here is the analysis so nobody has to redo it. The DATA term
    // below is OUR OWN transmission, so active_cr() is exactly right. Only the airtime_routing_ms(3) ACK term is
    // the PEER's transmission and therefore uses the wrong CR — worth tens of ms against the 229 ms DATA
    // shortfall that motivated the RX-window fix, and in the gateway-high-CR shape (a cr5 node awaiting a cr8
    // gateway's ACK) it OVER-waits, which fails safe. Fixing it needs a peer-CR channel the CTS does not have:
    // pack_cts is FULL (frame_codec.cpp:341-353 — the low nibble is (sf-5)<<1 | already_received, and
    // tx_id/rx_id/payload_len are whole bytes), so it would cost a wire growth or a wire_version bump. NOT DONE.
    const uint32_t data_air = airtime_ms(sf, active_bw_hz(), active_cr(), protocol::preamble_sym, len);
    const uint32_t ack_air = airtime_routing_ms(3);
    const uint32_t slop_data = _hal.rx_window_slop_ms(sf);
    const uint32_t slop_routing = _hal.rx_window_slop_ms(_cfg.routing_sf);
    const uint32_t delay = ack_wait_delay_ms(data_air, ack_air, slop_data, slop_routing);
    (void)_hal.after(delay, kAckTimeoutTimerId);
    if (_active->_pending_tx) _active->_pending_tx->timeout_deadline_ms = _hal.now() + delay;   // for reserve_yield's extend-only push
}
void Node::start_pending_rx_expiry(uint8_t payload_len) {
    // M6: payload_len can be the RTS wire byte (node_mac_rx.cpp:302, r.payload_len) — clamp it like nav_duration_rts
    // so a forged 255 can't inflate the pending-RX expiry (and its BUSY_RX NACK busy_for) at max SF.
    if (payload_len > protocol::max_payload_bytes_hard_cap) payload_len = protocol::max_payload_bytes_hard_cap;
    const uint8_t  sf  = _active->_pending_rx ? _active->_pending_rx->chosen_data_sf : max_data_sf();  // pending always set here
    // §rts-cr (2026-07-27): size for the SENDER's coding rate, carried in the RTS (frame_codec.h cr_adv) and
    // stashed on the PendingRx by handle_rts — NOT our own active_cr(). With our own, a leaf at cr5 armed
    // ~746 ms for a cr8 gateway's ~975 ms SF11/BW250k DATA and abandoned a frame still on air (s32 gw_4 -> the
    // layer-5 leaves, and symmetrically gw_5 -> the layer-4 leaves). CR is auto-detected by the PHY from the
    // explicit header, so the frame demodulates fine — only OUR clock was wrong.
    const uint8_t  cr  = _active->_pending_rx ? _active->_pending_rx->sender_cr : active_cr();          // pending always set here
    const uint16_t len = static_cast<uint16_t>(14 + payload_len);
    // +2: the original ideal-timing margin — this is ALL the sim uses, so s18 contention is unchanged.
    // On top, _hal.rx_window_slop_ms(sf) is the REAL hardware slop airtime_ms can't see, bench-measured
    // across SF5..SF12 as ~30 ms SPI reconfig/mode-switch (SF-flat) + ~1 symbol RX_DONE demod lag
    // (scales with SF; airtime verified vs the chip via [txair]: SF12 model 2564 == measured 2571). It's
    // a HAL hook so it's ZERO on the idealized sim (a fat shared margin inflated BUSY_RX busy_for +
    // over-held pending_rx on lost DATA -> 96%->69% s18 collapse) and metal-real on the device (else the
    // receiver hops back to routing before the slow DATA's RX_DONE and aborts it).
    const uint32_t t = airtime_routing_ms(4) /*CTS_LEN=4*/ + protocol::cts_to_data_gap_ms +
                       airtime_ms(sf, active_bw_hz(), cr, protocol::preamble_sym, len)
                       + 2 + _hal.rx_window_slop_ms(sf);
    if (_active->_pending_rx) _active->_pending_rx->expiry_ms = _hal.now() + t;   // for the BUSY_RX NACK busy_for calc
    (void)_hal.after(t, kPendingRxExpiryTimerId);
}

}  // namespace meshroute
