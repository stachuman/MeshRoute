// MeshRoute — src/fw_context.h
// Author: Stanislaw Kozicki <cgpsmapper@gmail.com>
//
// The shared FIRMWARE CONTEXT: extern declarations of fw_main.cpp's device-stack + runtime/config/admin
// globals (cleanup 2026-07-14, codebase-review triage "split firmware by responsibility"). This is the
// FOUNDATION step — a pure static→extern seam with NO code moved — so the subsequent cluster extractions
// (firmware_remote / firmware_config / firmware_commands / transports) become straight moves onto a vetted base.
//
// The 1:1 rule (auditable): every mutable file-scope global that fw_main.cpp used to declare `static` is now
//   (a) `extern`-declared here, and (b) DEFINED once (non-static) in fw_main.cpp, guards matched.
// Excluded on purpose: the `static constexpr` compile-time constants (MESHROUTE_SYNC_WORD,
// kChannelCtrLeaseMargin) stay in fw_main.cpp — they are constants, not shared state, and
// each moves WITH its cluster when that cluster is extracted.
//
// DEVICE-ONLY header (pulls RadioLib etc.) — included by fw_main.cpp and future device cluster TUs, never by
// the native unit suite.
#pragma once
#include <Arduino.h>
#include <RadioLib.h>
#include "helpers/radiolib/CustomSX1262.h"   // vendored — Module lives in RadioLib; CustomSX1262 here
#include <cstdint>
#include "protocol_constants.h"   // meshroute::protocol::max_payload_bytes_hard_cap (g_rxbuf bound)
#include "iclock.h"               // meshroute::ArduinoClock
#include "device_radio.h"         // meshroute::Sx1262Radio
#include "fw_context_pure.h"      // §B105: DeviceHal + Node, AND the `g_hal` / `g_node` externs — the ONE declaration
#include "identity.h"             // meshroute::Identity
#include "device_inbox_fs_nrf52.h"  // [[B260]] mrinboxnrf::Nrf52SegmentStore/InternalFsMetaStore (=> MRINBOX_QSPI_READY)
#include "device_inbox_fs_esp32.h"  // [[B134]] mrinboxfs::Esp32SegmentStore/Esp32NvsMetaStore (=> MRINBOX_ESP32_LITTLEFS)
#include "segmented_inbox_store.h"  // meshroute::SegmentedInboxStore — the REUSED ring logic BOTH device seams host
#include "fixed_inbox_store.h"    // meshroute::FixedInboxStore (the RAM-ring fallback for a board with NEITHER backend)
#include "fault_log.h"            // mrfault::FaultLog / FaultRecord
#include "sched_send.h"           // mrsched::Schedule

// ---- persistent fault log + halt/scheduled-send (fw_main.cpp block @61-75) ----
extern mrfault::FaultLog    g_fault_log;
extern mrfault::FaultRecord g_last_reset;
extern bool                 g_last_reset_valid;
extern bool                 g_halted;              // `prep-restart`: loop stays DORMANT (WDT-fed) but serves the console
extern mrsched::Schedule    g_sched;               // firmware scheduled-send (testsend/testch) workload

// ---- the device stack (defined in fw_main.cpp; ctor args live with the definition) ----
extern Module                  g_mod;
extern CustomSX1262            g_radio;
extern meshroute::ArduinoClock g_clock;
extern meshroute::Sx1262Radio  g_iradio;
// ⓘ `g_hal` and `g_node` are declared in `fw_context_pure.h` (included above) — §B105. They are NOT missing from the
//   1:1 rule and they are NOT declared twice: that header IS their declaration, so a feature TU can reach them
//   without `<RadioLib.h>`. Their definitions still live in fw_main.cpp beside the rest of this block.

// Inbox stores — guard MUST match the fw_main.cpp definitions. THREE arms, in order of durability:
//   1. MRINBOX_QSPI_READY      (nRF52 + QSPIFLASH=1) -> meshroute::SegmentedInboxStore over the QSPI/InternalFS seam
//   2. MRINBOX_ESP32_LITTLEFS  (ESP32, [[B134]])     -> meshroute::SegmentedInboxStore over the LittleFS/NVS seam
//   3. neither                                       -> meshroute::FixedInboxStore, a VOLATILE RAM ring
// ★★ [[B260]] 2026-08-29 — ARMS 1 AND 2 ARE NOW **THE SAME CLASS**, and that is the whole slice. Arm 1 used to
//   declare `mrinbox::DeviceInboxStore`, a hand-maintained TWIN of the lib/core ring logic that had drifted into
//   five durable-ack defects while the shared copy was being hardened. The twin is DELETED; only the two
//   INJECTED backends differ between the arms now, so the two durable platforms cannot diverge again.
// ★ `MRINBOX_DURABLE` is derived ONCE, here, and is what every boot-semantics consumer keys on (the per-boot
//   random epoch, the banner). Before [[B134]] those consumers keyed on MRINBOX_QSPI_READY directly, which
//   silently meant "nRF52" as well as "durable" — two facts one macro could not keep separate once a second
//   durable platform existed.
// Both seam headers' member defs are `inline`, so they are safe to include across firmware TUs via here.
#ifndef MR_RAM_INBOX_SLOTS
#define MR_RAM_INBOX_SLOTS 32           // RAM inbox depth per store (~8.5 KB/store at 272-B slots) — arm 3 only
#endif
#if defined(MRINBOX_QSPI_READY) || defined(MRINBOX_ESP32_LITTLEFS)
#define MRINBOX_DURABLE 1
#endif
#if defined(MRINBOX_QSPI_READY) || defined(MRINBOX_ESP32_LITTLEFS)
// ⓘ ONE declaration for BOTH durable arms since [[B260]] — the platform difference is in the backends the
//   definitions inject (fw_main.cpp), not in the store's type.
extern meshroute::SegmentedInboxStore g_inbox_dm;
extern meshroute::SegmentedInboxStore g_inbox_ch;
#else
extern meshroute::FixedInboxStore<MR_RAM_INBOX_SLOTS> g_inbox_dm;
extern meshroute::FixedInboxStore<MR_RAM_INBOX_SLOTS> g_inbox_ch;
#endif

extern meshroute::Identity g_identity;   // seed -> Ed25519/X25519 + key_hash32

// ---- runtime / diagnostic / live-config state (fw_main.cpp block @142-171) ----
extern uint8_t  g_rxbuf[meshroute::protocol::max_payload_bytes_hard_cap + 32];
extern bool     g_radio_ok;
extern uint32_t g_rx_count;
extern uint32_t g_sleep_count;
// §B200 light-sleep wake/arm diagnostics (status). ESP32 only — same guard as their definitions in fw_main.cpp and as
// the `board_sleep_until()` branch that is the only thing that writes them.
#if defined(ARDUINO_ARCH_ESP32) || defined(ESP32) || defined(BOARD_HELTEC_V3)
extern uint32_t g_wake_gpio, g_wake_ext1, g_wake_timer;
extern uint32_t g_wake_arm_busy, g_wake_arm_fail, g_wake_disarm_fail, g_wake_sleep_fail;
#endif
extern bool     g_host_present;
extern bool     g_force_sleep;
extern double   g_freq_mhz;
extern int8_t   g_tx_power;
extern uint8_t  g_ble_mode;
extern uint8_t  g_ble_period_min;
extern uint32_t g_ble_pin;
extern uint32_t g_remote_action_activation_ms;
extern int32_t  g_lat_e7;
extern int32_t  g_lon_e7;
extern uint8_t  g_persist_id, g_persist_epoch, g_persist_join;   // last DAD lease state written to NV (change-detect)
extern uint8_t  g_persist_team_local_id;                         // §mobile 6.4 team-DAD id
extern uint16_t g_ctr_lease;                                     // persisted channel-ctr lease (InternalFS self-heal Part 3)
extern bool     g_fs_reformatted;                               // mount_or_repair() reformatted a corrupt InternalFS this boot

// ---- inbox NDJSON scratch (shared: pull_inbox records AND live loop() push lines; single-threaded) ----
extern char s_inbox_jb[1700];

// ---- mesh loop task handle (nRF52 FreeRTOS only) ----
#if defined(NRF52_SERIES) || defined(ARDUINO_ARCH_NRF52) || defined(BOARD_XIAO_WIO_SX1262)
extern TaskHandle_t g_mesh_task;
#endif

// ---- shared fw_main helpers (defined in fw_main.cpp; referenced across a cluster boundary) ----
uint32_t loop_stack_free_bytes();   // nRF52 loop-task min free stack bytes (0 elsewhere) — used by dump_status

// ---- firmware_commands seam wrappers (single-TU board glue): the moved firmware_commands (dispatch etc.) reaches the
//      STAY-set board-glue through these. do_reboot/do_ota/dump_faults/handle_crashtest can't live in a 2nd TU
//      (device_fault.h ISR-vector + MRFAULT_HW/MRFAULT_ESP32 MACRO trap — both #defined inside device_fault.h);
//      handle_prep_restart is loop-coupled (writes the loop's g_halted latch). Defined in fw_main.cpp.
void fw_reboot();                              // -> do_reboot()   (`reboot` verb + moved handle_factory_reset's terminal reset)
void fw_ota();                                 // -> do_ota()      (`ota` verb)
void fw_faults_dump(Print& out);               // -> dump_faults() (`faults` verb; MRFAULT_HW macro trap)
void fw_crashtest(const char* args, Print& out); // -> handle_crashtest() (`crashtest` verb; MRFAULT_ESP32 macro trap + do_reboot)
void fw_prep_restart(Print& out);              // -> handle_prep_restart() (`prep-restart` verb; loop g_halted)
