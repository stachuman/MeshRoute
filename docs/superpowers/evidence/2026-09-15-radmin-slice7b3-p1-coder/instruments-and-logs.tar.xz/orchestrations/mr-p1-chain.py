from pathlib import Path
import subprocess,json,hashlib,shutil,os,time,sys
q=Path('/tmp/mr-codex-s7b3p1-active').read_text().strip();q=Path(q);r=q/'gate';shared=Path('/home/staszek/MeshRoute');mode=sys.argv[1]
if mode=='prepare':
 subprocess.run(['git','clone','--shared','--no-hardlinks',str(shared),str(r)],check=True)
 paths=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z'],cwd=shared).decode().split('\0')
 for rel in set(paths)-{''}:
  src=shared/rel;dst=r/rel;dst.parent.mkdir(parents=True,exist_ok=True)
  if src.is_symlink():
   target=src.resolve();dst.unlink(missing_ok=True);dst.symlink_to(r/target.relative_to(shared) if target.is_relative_to(shared) else target)
  else:shutil.copy2(src,dst)
 measured=r/'.pio-measure/verified-base/gateway';measured.mkdir(parents=True)
 for name in ['firmware.elf','manifest.json']:shutil.copy2(q/'base/.pio-measure/p1-base/gateway'/name,measured/name)
 raise SystemExit(0)
env=dict(os.environ,MR_LUS_SRC='/home/staszek/lora-universal-simulator')
if mode in ('chain','chain-remaining'):
 cmds=[('native-build',['pio','test','-e','native']),('native',['./.pio/build/native/program']),('abi',['python3','tools/probe_board_abi.py']),('abi-b278',['python3','tools/probe_b278_row_abi.py'])]
 for p in ['console_sink','inbox_verbs','firmware_ui','custody_usb','ble_line','features']:
  cmds += [(p,['bash','tools/probe_'+p+'/run.sh']),(p+'-no-neg',['bash','tools/probe_'+p+'/run.sh','--no-neg'])]
 cmds += [('inbox-client',['env','MR_PROBE_ARM=client','bash','tools/probe_inbox_verbs/run.sh']),('tools',['python3','-m','unittest','discover','-s','tools','-p','test_*.py']),('inventory-write',['python3','tools/gen_command_inventory.py','--write']),('inventory-bare',['python3','tools/gen_command_inventory.py']),('inventory-check',['python3','tools/gen_command_inventory.py','--check']),('authority',['python3','tools/check_command_authority.py']),('authority-controls',['python3','tools/check_command_authority.py','--selftest']),('a0',['python3','tools/check_a0_matrix.py']),('literals',['python3','tools/check_data_type_literals.py']),('census',['bash','tools/warning_census.sh'])]
else:
 build=q/'sim-final';cmds=[('configure',['cmake','-S','/home/staszek/lora-universal-simulator','-B',str(build),'-G','Ninja','-DMESHROUTE_DIR='+str(r),'-DCMAKE_BUILD_TYPE=Release']),('build',['cmake','--build',str(build),'--target','lus','--parallel','3','--verbose']),('corpus',['python3','tools/run_corpus.py','--out',str(q/'corpus-final'),'--lus',str(build/'orchestrator/lus'),'--jobs','3','--require-anchors']),('validate',['python3','tools/run_corpus.py','--validate',str(q/'corpus-final')])]
if mode=='chain-remaining':cmds=cmds[5:]
results=[]
for name,cmd in cmds:
 print('START',mode,name,flush=True);start=time.monotonic();log=q/'logs'/(mode+'-'+name+'.log')
 with log.open('wb') as f:code=subprocess.run(cmd,cwd=r,env=env,stdout=f,stderr=subprocess.STDOUT).returncode
 results.append(dict(name=name,cmd=cmd,cwd=str(r),exit=code,seconds=time.monotonic()-start,log=str(log),sha256=hashlib.sha256(log.read_bytes()).hexdigest()));(q/(mode+'-results.json')).write_text(json.dumps(results,indent=2)+'\n');print('END',mode,name,code,flush=True)
 if code and mode!='chain-remaining':raise SystemExit(code)
