from pathlib import Path
import importlib.util,json,subprocess,shlex
q=Path('/tmp/mr-codex-s7b3p1-active').read_text().strip();q=Path(q);r=q/'base';out=q/'stack';out.mkdir(exist_ok=True)
spec=importlib.util.spec_from_file_location('abi',r/'tools/probe_board_abi.py');abi=importlib.util.module_from_spec(spec);spec.loader.exec_module(abi)
results=[]
for env in ['native','gateway','heltec_mobile']:
 print('STACK',env,flush=True);data=abi.idedata(env);(out/(env+'-idedata.json')).write_text(json.dumps(data,indent=2)+'\n')
 source=out/'types.cpp';source.write_text('#include "firmware_action_effects.h"\n'+''.join('char mr_size_'+n+'[sizeof(mrfw::'+n+')];\n' for n in ['ActionPlan','ActionAdmission','ActionSupport','ActionObserver']))
 obj=out/(env+'-types.o');cmd=abi.compile_command(data,source,obj)
 p=subprocess.run(cmd,cwd=r,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(out/(env+'-types.log')).write_bytes(p.stdout);assert p.returncode==0,(env,p.stdout[-2000:])
 nm=subprocess.check_output([abi.binutil(data['cxx_path'],'nm'),'-S','--size-sort',str(obj)]).decode();(out/(env+'-types.nm')).write_text(nm);print(nm,flush=True)
 if env=='native':continue
 for state in ['base','final']:
  for file in ['fw_main.cpp','firmware_commands.cpp','device_ota.cpp']:
   source=(q/'original/src' if state=='base' else r/'src')/file;obj=out/(env+'-'+state+'-'+file+'.o');cmd=abi.compile_command(data,source,obj)+['-fstack-usage']
   log=out/(obj.stem+'.log');p=subprocess.run(cmd,cwd=r,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);log.write_bytes(p.stdout)
   results.append(dict(env=env,state=state,file=file,cmd=cmd,exit=p.returncode));(out/'results.json').write_text(json.dumps(results,indent=2)+'\n');print(env,state,file,p.returncode,flush=True)
   if p.returncode:print(p.stdout.decode()[-3000:]);raise SystemExit(p.returncode)
