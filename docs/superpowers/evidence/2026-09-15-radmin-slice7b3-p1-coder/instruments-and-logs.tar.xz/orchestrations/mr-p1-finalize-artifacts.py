from pathlib import Path
import json,hashlib,shutil,tarfile,subprocess,stat
root=Path('/home/staszek/MeshRoute');q=Path('/tmp/mr-codex-s7b3p1-active').read_text().strip();q=Path(q);out=root/'docs/superpowers/evidence/2026-09-15-radmin-slice7b3-p1-coder'
for p in q.glob('*.json'):shutil.copy2(p,out/p.name)
# Build/probe logs, generated control sources, pristine baseline source, exact orchestrations.
with tarfile.open(out/'instruments-and-logs.tar.xz','w:xz',preset=3) as t:
 for rel in ['logs','original']:
  t.add(q/rel,arcname=rel)
 for p in sorted(q.glob('probe-*')):
  if p.is_dir():t.add(p,arcname=p.name)
 for p in sorted(Path('/tmp').glob('mr-p1-*.py')):t.add(p,arcname='orchestrations/'+p.name)
 for name in ['corrupted-literal.cpp','corrupted-reference-array.cpp']:
  if (q/name).exists():t.add(q/name,arcname='reference-controls/'+name)
(root/'docs/superpowers/evidence/2026-09-15-radmin-slice7b3-p1-coder/source-state.patch').write_bytes(subprocess.check_output(['git','diff','--binary','HEAD'],cwd=root))
untracked=subprocess.check_output(['git','ls-files','--others','--exclude-standard','-z'],cwd=root).decode().split('\0');untracked=[p for p in untracked if p and not p.startswith(str(out.relative_to(root))+'/')]
with tarfile.open(out/'source-overlay.tar.xz','w:xz',preset=3) as t:
 for rel in untracked:t.add(root/rel,arcname=rel)
(root/'docs/superpowers/evidence/2026-09-15-radmin-slice7b3-p1-coder/untracked-overlay-inputs.json').write_text(json.dumps({p:{'sha256':hashlib.sha256((root/p).read_bytes()).hexdigest(),'mode':stat.S_IMODE((root/p).stat().st_mode)} for p in untracked},indent=2)+'\n')
# Verify all simulator bytes using the original preflight inventory implementation.
import importlib.util,sys
p=root/'docs/superpowers/evidence/2026-09-15-radmin-slice7b3-p1-preflight/inventory.py';print(p.read_text()[:1200])
print('artifact package created',flush=True)
