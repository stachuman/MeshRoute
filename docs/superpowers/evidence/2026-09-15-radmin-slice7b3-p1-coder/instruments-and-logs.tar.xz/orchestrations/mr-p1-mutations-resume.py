from pathlib import Path
import json,subprocess,time
q=Path('/tmp/mr-codex-s7b3p1-active').read_text().strip();q=Path(q);dest=q/'mutations';results=json.loads((q/'mutation-results.json').read_text());assert results[-1]['target']=='sliceBmac' and results[-1]['exit']==1
s=(q/'logs/mutation-sliceBmac.log').read_text();assert 'mutations: 3 RED / 1 unusable' in s and 'FAIL M04' in s and 'match count 0' not in s
results[-1]['known_exception']='B342 M04: compiles but test remains green; 3 RED + 1 unusable'
done={r['target'] for r in results};targets=json.loads((q/'mutation-selectors.json').read_text())['union']
for target in [t for t in targets if t not in done]:
 cmd=['python3','tools/probe_ui_model_mutations.py','--target='+target,'--workers=3'];print('START',target,flush=True);start=time.monotonic()
 with (q/'logs'/('mutation-'+target+'.log')).open('w') as f:rc=subprocess.run(cmd,cwd=dest,stdout=f,stderr=subprocess.STDOUT).returncode
 results.append({'target':target,'command':cmd,'exit':rc,'seconds':time.monotonic()-start});(q/'mutation-results.json').write_text(json.dumps(results,indent=2)+'\n');print('END',target,rc,flush=True)
 if rc:raise SystemExit(rc)
print('ALL 53 BATTERIES EXECUTED',flush=True)
