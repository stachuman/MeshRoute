from pathlib import Path
p=Path('tools/probe_deferred_actions/probe.cpp');s=p.read_text();s=s.replace('static void action_delay(uint32_t ms)', 'static void action_flush(Print& out) { out.flush(); actions.push_back("flush"); }\nstatic void action_delay(uint32_t ms)')
s=s.replace('static void observe_action(', '''extern "C" void __real__ZN9meshroute4Node19clear_learned_stateEv(meshroute::Node*);
extern "C" void __wrap__ZN9meshroute4Node19clear_learned_stateEv(meshroute::Node* node) {
    actions.push_back("clear-learned");
    __real__ZN9meshroute4Node19clear_learned_stateEv(node);
}
static void observe_action(''')
s=s.replace('int main() {\n','int main() {\n    setvbuf(stdout,nullptr,_IONBF,0);\n')
s=s.replace('CHECK_ACTION(!prep_print_before_halt); transcript(', 'CHECK_ACTION(!prep_print_before_halt); CHECK_ACTION(actions.front()=="clear-learned"); transcript(')
s=s.replace('std::vector<std::string>{"delay:100"}', 'std::vector<std::string>{"flush","delay:100"}')
s=s.replace('expected{"delay:100","mark-reset","reset"}', 'expected{"flush","delay:100","mark-reset","reset"}')
s=s.replace('expected);\n#endif\n        }', 'expected);\n#endif\n        }')
# crashtest reboot has its own flush before the shared reset flush.
s=s.replace('if(!strcmp(line,"reboot")||!strcmp(line,"crashtest reboot")) {','if(!strcmp(line,"crashtest reboot")) { CHECK_ACTION(!actions.empty() && actions.front()=="flush"); actions.erase(actions.begin()); }\n        if(!strcmp(line,"reboot")||!strcmp(line,"crashtest reboot")) {')
s=s.replace('std::strstr(Serial.out,"start FAILED")', 'std::strstr(Serial.out,"> OTA: start FAILED\\r\\n")')
p.write_text(s)
p=Path('tools/probe_deferred_actions/run.py');s=p.read_text();s=s.replace("return block+'''", "fw=fw.replace('out.flush();','action_flush(out);').replace('mrcon.flush();','action_flush(mrcon);')\n    return block+'''")
s=s.replace("commands=['build_support || exit 2']", "commands=['LDWRAP+=(-Wl,--wrap=_ZN9meshroute4Node19clear_learned_stateEv)', 'build_support || exit 2']")
s=s.replace("commands += [cmd+f' || {{ cat \"$OUT/build.log\"; exit 2; }}',", "commands += [cmd+f' || {{ cat \"$OUT/build.log\"; exit 2; }}',f'cp \"$OUT/build.log\" {shlex.quote(str(output/(name+\"-compile.log\")))}',")
s=s.replace("f'\"$OUT/{name}\" > {shlex.quote(str(log))} 2>&1;", "f'cp \"$OUT/build.log\" {shlex.quote(str(directory/\"compile.log\"))}',\n                         f'\"$OUT/{name}\" > {shlex.quote(str(log))} 2>&1;")
p.write_text(s)
p=Path('tools/probe_deferred_actions/controls.py');s=p.read_text();s=s.replace('\n]\n', '''
 ('C17 NV erase moved before inbox warning','src/firmware_commands.cpp',
  'if (!dm_ok || !ch_ok) out.println(F("> factory_reset WARN: inbox erase incomplete (messages may remain on flash)"));\\n    const bool nv_ok = mrnv::factory_erase();',
  'const bool nv_ok = mrnv::factory_erase();\\n    if (!dm_ok || !ch_ok) out.println(F("> factory_reset WARN: inbox erase incomplete (messages may remain on flash)"));',2,1),
 ('C18 crash flush removed','src/fw_main.cpp',
  'out.println(F("> crashtest reboot — NVIC_SystemReset (SREQ)")); out.flush();',
  'out.println(F("> crashtest reboot — NVIC_SystemReset (SREQ)"));',2,1),
 ('C19 learned-state clear omitted','src/fw_main.cpp',
  '    g_node.clear_learned_state();', '    /* learned-state clear omitted */',2,1),
]
''');p.write_text(s)
