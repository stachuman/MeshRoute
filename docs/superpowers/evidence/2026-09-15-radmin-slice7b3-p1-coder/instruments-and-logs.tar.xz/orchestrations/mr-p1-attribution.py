from pathlib import Path
import hashlib,json,struct,collections,subprocess
q=Path('/tmp/mr-codex-s7b3p1-active').read_text().strip();q=Path(q)
old=(q/'prior-coder/attribute.py').read_text();start=old.index('def elf(');end=old.index('\nsummary =',start);exec(old[start:end])
summary={}
for env in ['gateway','heltec_mobile']:
 paths=[q/'base/.pio-measure'/state/env for state in ['p1-base','p1-iteration1']];sections=[];coverage=[];symbols=[];manifests=[]
 for p in paths:
  sec,cov=elf(p/'firmware.elf');sections.append(sec);coverage.append(cov);m=json.loads((p/'manifest.json').read_text());manifests.append(m)
  symbols.append(collections.Counter(line for line in (p/'symbols.txt').read_text().splitlines() if line.split('\t')[1] not in ['FILE','NOTYPE']))
 removed=list((symbols[0]-symbols[1]).elements());added=list((symbols[1]-symbols[0]).elements())
 allocated=[]
 for name in sorted(sections[0].keys()|sections[1].keys()):
  b=sections[0].get(name,{});a=sections[1].get(name,{})
  if (b or a)['flags']&2: allocated.append({'name':name,'base_bytes':b.get('size',0),'final_bytes':a.get('size',0),'delta':a.get('size',0)-b.get('size',0),'base_sha256':b.get('sha256'),'final_sha256':a.get('sha256')})
 changed_objects=[]
 # Same actual env's flags, -fstack-usage only; retain fresh base/final owning-TU objects.
 for name in ['fw_main.cpp','firmware_commands.cpp','device_ota.cpp']:
  result=[]
  cmd=manifests[1]['toolchain']['commands']['cxx']['executable_realpath'];size=cmd.replace('g++','size')
  for state in ['base','final']:
   p=q/'stack'/(env+'-'+state+'-'+name+'.o');line=subprocess.check_output([size,str(p)]).decode();result.append(line);(q/'stack'/(p.stem+'.size')).write_text(line)
  changed_objects.append(dict(tu=name,base=result[0],final=result[1]))
 result=dict(allocated_sections=allocated,text_coverage=coverage,removed_symbols=removed,added_symbols=added,objects=changed_objects,measurements=[m['measurements'] for m in manifests],fixed_identity_equal=manifests[0]['fixed_identity']==manifests[1]['fixed_identity'])
 summary[env]=result;print(env, 'allocated deltas',[(r['name'],r['delta']) for r in allocated if r['delta']]);print('coverage',coverage)
 for state,rows in [('removed',removed),('added',added)]:
  print(state)
  for line in sorted(rows,key=lambda s:-int(s.split('\t')[-1]))[:28]:print(line)
 print('object sizes',changed_objects)
(q/'elf-attribution.json').write_text(json.dumps(summary,indent=2)+'\n')
