from pathlib import Path
import subprocess,json,os,time
q=Path('/tmp/mr-codex-s7b3p1-active').read_text().strip();q=Path(q);r=q/'base';original=Path('/home/staszek/MeshRoute')
for p in (r/'spec').iterdir():
 if p.is_symlink():
  target=p.resolve()
  if target.is_relative_to(original):p.unlink();p.symlink_to(r/target.relative_to(original))
env=dict(os.environ,MESHROUTE_GIT_REV_OVERRIDE='c591721',MR_LUS_SRC='/home/staszek/lora-universal-simulator')
cmds=[('base-native-build',['pio','test','-e','native']),('base-native',['./.pio/build/native/program']),('base-sim-configure',['cmake','-S','/home/staszek/lora-universal-simulator','-B',str(q/'sim-build'),'-G','Ninja','-DMESHROUTE_DIR='+str(r),'-DCMAKE_BUILD_TYPE=Release']),('base-sim-build',['cmake','--build',str(q/'sim-build'),'--target','lus','--parallel','3','--verbose']),('base-corpus',['python3','tools/run_corpus.py','--out',str(q/'corpus-base'),'--lus',str(q/'sim-build/orchestrator/lus'),'--jobs','3','--require-anchors']),('base-corpus-validate',['python3','tools/run_corpus.py','--validate',str(q/'corpus-base')]),('base-boards',['python3','tools/measure_board.py','pair','--output','.pio-measure/p1-base','--jobs','1'])]
results=[]
for name,cmd in cmds:
 print('START',name,flush=True);start=time.monotonic()
 with (q/'logs'/(name+'.log')).open('w') as f:code=subprocess.run(cmd,cwd=r,env=env,stdout=f,stderr=subprocess.STDOUT).returncode
 results.append({'name':name,'cmd':cmd,'cwd':str(r),'exit':code,'seconds':time.monotonic()-start});(q/'base-results.json').write_text(json.dumps(results,indent=2)+'\n');print('END',name,code,flush=True)
 if code:raise SystemExit(code)
print('BASE GATE READY',flush=True)
