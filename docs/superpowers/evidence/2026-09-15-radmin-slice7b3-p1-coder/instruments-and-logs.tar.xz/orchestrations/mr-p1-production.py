from pathlib import Path
r=Path('/home/staszek/MeshRoute')
def replace_fn(s,name,replacement):
 a=s.index('static void '+name+'(');b=s.index('\n}',a)+2
 # Skip forward declarations: require opening brace before first semicolon.
 if ';' in s[a:s.index('{',a)]:
  a=s.index('static void '+name+'(',a+1);b=s.index('\n}',a)+2
 return s[:a]+replacement+s[b:]
p=r/'src/firmware_action_effects.h';s=p.read_text().replace('ActionOutcome action_reboot_apply(ActionBackend, Print&, ActionObserver = {});','ActionOutcome action_reboot_apply(ActionBackend, Print&, ActionObserver = {},\n                                 ActionOutcome reset_outcome = ActionOutcome::started);');p.write_text(s)
p=r/'src/firmware_commands.cpp';s=p.read_text();s=s.replace('#include "firmware_commands.h"','#include "firmware_commands.h"\n#include "firmware_action_effects.h"',1)
a=s.index('static void handle_factory_reset(');b=s.index('\n}',a)+2;old=s[a:b];start=old.index('        out.println(F("> factory reset');end=old.index('\n    } else {');effects=old[start:end]
effects=effects.replace('        if (!mrnv::factory_erase()) out.println','        const bool nv_ok = mrnv::factory_erase();\n        if (!nv_ok) out.println').replace('        fw_reboot();','''        const auto reset_outcome = !dm_ok || !ch_ok
            ? (nv_ok ? ActionOutcome::inbox_partial : ActionOutcome::inbox_nv_partial)
            : (nv_ok ? ActionOutcome::started : ActionOutcome::nv_partial);
        return action_reboot_apply(backend, reboot_out, observer, reset_outcome);''')
effects='\n'.join(line[4:] if line.startswith('    ') else line for line in effects.splitlines())
replacement='''ActionOutcome action_factory_reset_apply(ActionBackend backend, Print& out, Print& reboot_out,
                                         ActionObserver observer) {
'''+effects+'''
}

static void handle_factory_reset(const char* arg, size_t n, Print& out) {
    const auto admission = action_factory_reset_admit(arg, n, action_build_support());
    // Build-level support is for a later remote consumer; preserve the local erase even without reset HW.
    if (admission.status != ActionAdmissionStatus::confirmation) {
        action_factory_reset_apply(admission.plan.backend, out, mrcon);
'''+old[end:]+'''
'''
s=s[:a]+replacement.rstrip()+s[b:]
a=s.index('static void handle_sleep(');b=s.index('\n}',a)+2;old=s[a:b]
new='''ActionOutcome action_sleep_apply(ActionKind kind, Print& out, ActionObserver observer) {
    if (kind == ActionKind::sleep_off) {
        g_force_sleep = false;
        out.println(F("> sleep off — staying awake while a host is connected"));
    } else if (kind == ActionKind::sleep_on) {
        g_force_sleep = true;
        out.println(F("> sleep on — light-sleeping when idle; reconnect to wake the console (still wakes on RX)"));
    } else {
        return action_report(observer, ActionOutcome::backend_failed);
    }
    return action_report(observer, ActionOutcome::completed);
}

static void handle_sleep(const char* arg, size_t n, Print& out) {
    const auto admission = action_sleep_admit(arg, n, action_build_support());
    // MR_NO_POWERSAVE still sets the local flag and prints; it only removes the sleep policy.
    action_sleep_apply(admission.plan.kind, out);
}'''
s=s[:a]+new+s[b:];p.write_text(s)
p=r/'src/fw_main.cpp';s=p.read_text();a='#include "fw_context.h"';assert s.count(a)==1;s=s.replace(a,a+'\n#include "firmware_action_effects.h"',1)
new='''mrfw::ActionSupport mrfw::action_build_support() {
    ActionSupport support{};
#if defined(NRF52_SERIES) || defined(ARDUINO_ARCH_NRF52) || defined(BOARD_XIAO_WIO_SX1262)
    support.reboot = ActionBackend::nrf_reset;
    support.ota = ActionBackend::nrf_dfu;
#elif defined(ARDUINO_ARCH_ESP32) || defined(ESP32) || defined(BOARD_HELTEC_V3)
    support.reboot = ActionBackend::esp_reset;
    support.ota = ActionBackend::wifi_ota;
#endif
#if defined(NRF52_PLATFORM)
    support.fault = ActionBackend::nrf_fault;
#elif defined(MRFAULT_ESP32)
    support.fault = ActionBackend::esp_fault;
#endif
#if !defined(MR_NO_POWERSAVE)
    support.power_save = true;
#endif
    return support;
}

mrfw::ActionOutcome mrfw::action_reboot_apply(ActionBackend backend, Print& out, ActionObserver observer,
                                            ActionOutcome reset_outcome) {
    out.println(F("> rebooting")); out.flush(); delay(100);
#if defined(MRFAULT_HW)
    mrfault::mark_expected_reset();   // v2 fault log: classify the upcoming reset as REBOOT, not UNEXPECTED
#endif
    action_report(observer, reset_outcome);
#if defined(NRF52_SERIES) || defined(ARDUINO_ARCH_NRF52) || defined(BOARD_XIAO_WIO_SX1262)
    if (backend != ActionBackend::nrf_reset) return action_report(observer, ActionOutcome::backend_failed);
    NVIC_SystemReset();
#elif defined(ARDUINO_ARCH_ESP32) || defined(ESP32) || defined(BOARD_HELTEC_V3)
    if (backend != ActionBackend::esp_reset) return action_report(observer, ActionOutcome::backend_failed);
    ESP.restart();
#else
    (void)backend;
    return action_report(observer, ActionOutcome::backend_failed);
#endif
    return action_report(observer, ActionOutcome::unexpected_return);
}

static void do_reboot() {
    const auto admission = mrfw::action_reboot_admit(mrfw::action_build_support());
    mrfw::action_reboot_apply(admission.plan.backend, mrcon);
}'''
s=replace_fn(s,'do_reboot',new)
a=s.index('static void do_ota() {');b=s.index('\n}',a)+2;old=s[a:b]
new='''mrfw::ActionOutcome mrfw::action_ota_apply(ActionBackend backend, Print& out, ActionObserver observer) {
#if defined(NRF52_SERIES) || defined(ARDUINO_ARCH_NRF52) || defined(BOARD_XIAO_WIO_SX1262)
    if (backend != ActionBackend::nrf_dfu) return action_report(observer, ActionOutcome::backend_failed);
    out.println(F("> OTA: rebooting into BLE DFU now — this USB console will drop here."));
    out.println(F(">      Push firmware.zip via the Nordic DFU app (enable its auto-reboot). Double-tap RESET to abort."));
    out.flush(); delay(500);
    mrfault::mark_expected_reset();   // v2 fault log: the OTA reset is a REBOOT, not UNEXPECTED
    NRF_POWER->GPREGRET = 0xA8;   // DFU_MAGIC_OTA_RESET
    action_report(observer, ActionOutcome::started);
    NVIC_SystemReset();
    return action_report(observer, ActionOutcome::unexpected_return);
#elif defined(ARDUINO_ARCH_ESP32) || defined(ESP32) || defined(BOARD_HELTEC_V3)
    if (backend != ActionBackend::wifi_ota) return action_report(observer, ActionOutcome::backend_failed);
    if (mrota::ota_start(out)) {
        mrota::set_pre_reboot_hook([] { mrfault::mark_expected_reset(); });
        out.println(F("> OTA: browse to the IP above, upload firmware.bin — node reboots on success"));
        return action_report(observer, ActionOutcome::completed);
    }
    out.println(F("> OTA: start FAILED"));
    return action_report(observer, ActionOutcome::backend_failed);
#else
    (void)backend; (void)out;
    return action_report(observer, ActionOutcome::backend_failed);
#endif
}

static void do_ota() {
#if defined(ARDUINO_ARCH_ESP32) || defined(ESP32) || defined(BOARD_HELTEC_V3)
    if (mrota::ota_active()) {
        mrota::ota_stop();
        mrcon.println(F("> OTA: stopped"));
        return;
    }
#endif
    const auto admission = mrfw::action_ota_admit(mrfw::action_build_support());
    mrfw::action_ota_apply(admission.plan.backend, mrcon);
}'''
s=s[:a]+new+s[b:]
a=s.index('static void handle_crashtest(const char* args, Print& out) {');b=s.index('\n}',a)+2;old=s[a:b]
new='''mrfw::ActionOutcome mrfw::action_crash_apply(ActionPlan plan, Print& out, Print& reboot_out,
                                           ActionObserver observer) {
    if (plan.kind == ActionKind::crash_hang) {
        out.println(F("> crashtest hang — spinning; the watchdog should reset in ~8 s")); out.flush();
        action_report(observer, ActionOutcome::started);
        for (;;) { /* no WDT feed -> DOG reset (nRF52); on a no-WDT build this hangs until power-cycle) */ }
    } else if (plan.kind == ActionKind::crash_fault) {
        out.println(F("> crashtest fault — forcing a crash")); out.flush();
#if defined(NRF52_PLATFORM)
        if (plan.backend != ActionBackend::nrf_fault) return action_report(observer, ActionOutcome::backend_failed);
        action_report(observer, ActionOutcome::started);
        volatile uint32_t* p = reinterpret_cast<volatile uint32_t*>(0xFFFFFFF0u); (void)*p;
        __asm volatile("udf #0");
#elif defined(MRFAULT_ESP32)
        if (plan.backend != ActionBackend::esp_fault) return action_report(observer, ActionOutcome::backend_failed);
        action_report(observer, ActionOutcome::started);
        abort();
#else
        out.println(F("> (no HW fault path on this build)"));
        return action_report(observer, ActionOutcome::backend_failed);
#endif
        return action_report(observer, ActionOutcome::unexpected_return);
    } else if (plan.kind == ActionKind::crash_reboot) {
        out.println(F("> crashtest reboot — NVIC_SystemReset (SREQ)")); out.flush();
        return action_reboot_apply(plan.backend, reboot_out, observer);
    }
    return action_report(observer, ActionOutcome::backend_failed);
}

static void handle_crashtest(const char* args, Print& out) {
    const auto admission = mrfw::action_crash_admit(args, strlen(args), meshroute::g_mr_trace_on,
                                                 mrfw::action_build_support());
    if (admission.status == mrfw::ActionAdmissionStatus::debug_disabled) {
        out.println(F("> crashtest err (enable `debug on` first — gated to avoid an accidental crash)"));
    } else if (admission.status == mrfw::ActionAdmissionStatus::usage) {
        out.println(F("> crashtest err usage: crashtest <hang|fault|reboot>"));
    } else {
        // Unsupported local fault still prints its original two lines; typed support stays explicit.
        mrfw::action_crash_apply(admission.plan, out, mrcon);
    }
}'''
s=s[:a]+new+s[b:]
a=s.index('static void handle_prep_restart(Print& out) {');b=s.index('\n}',a)+2;old=s[a:b]
new=old.replace('static void handle_prep_restart(Print& out) {','mrfw::ActionOutcome mrfw::action_prep_restart_apply(Print& out, ActionObserver observer) {')
new=new[:-2]+'''    return action_report(observer, inbox_dm_ok && inbox_ch_ok ? ActionOutcome::completed
                                                            : ActionOutcome::inbox_partial);
}

static void handle_prep_restart(Print& out) {
    const auto admission = mrfw::action_prep_restart_admit();
    (void)admission; // no arguments or build-dependent backend; the local effect remains immediate
    mrfw::action_prep_restart_apply(out);
}'''
s=s[:a]+new+s[b:];p.write_text(s)
p=r/'src/device_ota.h';s=p.read_text().replace('namespace mrota {','class Print;\n\nnamespace mrota {').replace('bool ota_start();','bool ota_start(Print& out); // same idempotent entry with an explicit startup-output sink\nbool ota_start();',1);p.write_text(s)
p=r/'src/device_ota.cpp';s=p.read_text();a=s.index('bool ota_start() {');b=s.index('\n}',a)+2;old=s[a:b];new=old.replace('bool ota_start() {','bool ota_start(Print& out) {').replace('mrcon','out');new+='\n\nbool ota_start() { return ota_start(mrcon); }';s=s[:a]+new+s[b:];p.write_text(s)
