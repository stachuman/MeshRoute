from pathlib import Path
p=Path('tools/gen_command_inventory.py');s=p.read_text()
s=s.replace('Surface("src/firmware_commands.cpp", "handle_sleep", "sub", "serial,ble", parent="sleep",\n            reached_from=(("src/firmware_commands.cpp", "dispatch", "handle_sleep"),)),','''Surface("src/firmware_action_effects.h", "action_sleep_admit", "sub", "serial,ble", parent="sleep",
            reached_from=(("src/firmware_commands.cpp", "dispatch", "handle_sleep"),
                          ("src/firmware_commands.cpp", "handle_sleep", "action_sleep_admit"))),''')
s=s.replace('Surface("src/firmware_commands.cpp", "handle_factory_reset", "sub", "serial,ble", parent="factory_reset",\n            reached_from=(("src/firmware_commands.cpp", "dispatch", "handle_factory_reset"),)),','''Surface("src/firmware_config_parse.h", "parse_confirm_token", "sub", "serial,ble", parent="factory_reset",
            reached_from=(("src/firmware_commands.cpp", "dispatch", "handle_factory_reset"),
                          ("src/firmware_commands.cpp", "handle_factory_reset", "action_factory_reset_admit"),
                          ("src/firmware_action_effects.h", "action_factory_reset_admit", "parse_confirm_token"))),''')
s=s.replace('Surface("src/fw_main.cpp", "handle_crashtest", "sub", "serial,ble", parent="crashtest",\n            reached_from=(("src/firmware_commands.cpp", "dispatch", "fw_crashtest"),\n                          ("src/fw_main.cpp", "fw_crashtest", "handle_crashtest"))),','''Surface("src/firmware_action_effects.h", "action_crash_admit", "sub", "serial,ble", parent="crashtest",
            reached_from=(("src/firmware_commands.cpp", "dispatch", "fw_crashtest"),
                          ("src/fw_main.cpp", "fw_crashtest", "handle_crashtest"),
                          ("src/fw_main.cpp", "handle_crashtest", "action_crash_admit"))),''')
s=s.replace('SCAN_FILES = (\n    "src/firmware_commands.cpp",','SCAN_FILES = (\n    "src/firmware_commands.cpp",\n    "src/firmware_action_effects.h",\n    "src/firmware_config_parse.h",')
pos=s.index('\n# ★ THE REAL PRODUCT PROFILE MATRIX')
s=s[:pos]+'''
# P1 reuses this existing library predicate for factory confirmation. The rest of
# the library parses configuration VALUES, outside the command scanner's scope.
# All prior command files and the new action header retain full-file coverage.
# Keep the actual predicate's file/line and verify every caller hop above.
PREDICATE_ONLY = {"src/firmware_config_parse.h": ("parse_confirm_token",)}

'''+s[pos:]
needle='''    lines = text.split("\\n")
    blank_lines = _blank_comments_and_literals(text).split("\\n")

    sites = []'''
replacement='''    lines = text.split("\\n")
    blank_lines = _blank_comments_and_literals(text).split("\\n")
    if rel in PREDICATE_ONLY:
        spans = _function_spans(root, rel)
        keep = set()
        for name in PREDICATE_ONLY[rel]:
            definitions = [i for i, (raw, blank) in enumerate(zip(lines, blank_lines), 1)
                           if (m := FUNC_DEF_RE.match(raw)) and m.group(1) == name
                           and "{" in blank and not blank.rstrip().endswith(";")]
            if len(definitions) != 1 or name not in spans:
                raise GeneratorError("predicate %s::%s must resolve to exactly one definition" % (rel, name))
            lo, hi = spans[name]
            keep.update(range(lo, hi + 1))
        # Blank, never delete: emitted source line numbers stay the real ones.
        lines = [line if i in keep else "" for i, line in enumerate(lines, 1)]
        blank_lines = [line if i in keep else "" for i, line in enumerate(blank_lines, 1)]

    sites = []'''
assert s.count(needle)==1;s=s.replace(needle,replacement);p.write_text(s)
