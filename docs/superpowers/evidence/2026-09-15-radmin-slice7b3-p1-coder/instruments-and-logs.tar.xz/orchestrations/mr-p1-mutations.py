from pathlib import Path
import ast,subprocess,shutil,json,hashlib,os,time
root=Path('/home/staszek/MeshRoute');q=Path('/tmp/mr-codex-s7b3p1-gaz2dlhn');dest=q/'mutations';dest.mkdir(exist_ok=False)
subprocess.run(['git','clone','--shared',str(root),str(dest)],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
paths=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z'],cwd=root).decode().split('\0')
for rel in sorted(set(paths)-{''}):
 src=root/rel;d=dest/rel;d.parent.mkdir(parents=True,exist_ok=True)
 if src.is_symlink():
  if d.exists() or d.is_symlink():d.unlink()
  target=src.resolve();d.symlink_to(dest/target.relative_to(root) if target.is_relative_to(root) else target)
 else:shutil.copy2(src,d)
values={};tables={}
for node in ast.parse((dest/'tools/probe_ui_model_mutations.py').read_text()).body:
 if isinstance(node,ast.Assign):
  for t in node.targets:
   if isinstance(t,ast.Name):
    try:values[t.id]=ast.literal_eval(node.value)
    except (ValueError,TypeError):
     if t.id=='MUTS_BY_TARGET':tables={ast.literal_eval(k):v.id for k,v in zip(node.value.keys,node.value.values)}
floor=json.loads((dest/'docs/superpowers/evidence/2026-09-13-radmin-slice7b3-precheck/historical-mutation-floor.json').read_text())['union']
changed=subprocess.check_output(['git','diff','--name-only'],cwd=root).decode().splitlines()+subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=root).decode().splitlines()
sel=sorted(t for t,p in values['TARGET_SRC'].items() if p in changed);union=sorted(set(sel)|set(floor));rows=[]
for t in union:
 text=(dest/values['TARGET_SRC'][t]).read_text();mut=values[tables[t]]
 assert all(text.count(a)==1 for _,a,_ in mut),t
 rows.append({'target':t,'path':values['TARGET_SRC'][t],'count':len(mut),'sha256':hashlib.sha256(text.encode()).hexdigest()})
audit={'S':sel,'H':floor,'union':union,'configured':sum(x['count'] for x in rows),'rows':rows}
(q/'mutation-selectors.json').write_text(json.dumps(audit,indent=2)+'\n');assert len(union)==53 and audit['configured']==827
# Native compiles test/ and all lib sources; retain its entire build-input set plus all src headers.
frozen={}
for rel in paths:
 p=dest/rel
 if rel and p.is_file() and (rel.startswith(('test/','lib/')) or rel.startswith('src/') and p.suffix=='.h' or rel in ['platformio.ini','tools/probe_ui_model_mutations.py']):frozen[rel]=hashlib.sha256(p.read_bytes()).hexdigest()
(q/'mutation-native-inputs.json').write_text(json.dumps(frozen,indent=2)+'\n')
results=[]
for target in ['actionadmit']+[t for t in union if t!='actionadmit']:
 cmd=['python3','tools/probe_ui_model_mutations.py','--target='+target,'--workers=3'];print('START',target,flush=True);start=time.monotonic()
 with (q/'logs'/('mutation-'+target+'.log')).open('w') as f:rc=subprocess.run(cmd,cwd=dest,stdout=f,stderr=subprocess.STDOUT).returncode
 results.append({'target':target,'command':cmd,'exit':rc,'seconds':time.monotonic()-start});(q/'mutation-results.json').write_text(json.dumps(results,indent=2)+'\n');print('END',target,rc,flush=True)
 if rc:raise SystemExit(rc)
print('ALL 53 BATTERIES EXECUTED',flush=True)
