from pathlib import Path
import subprocess,shutil,os,json,time,hashlib
q=Path('/tmp/mr-codex-s7b3p1-active').read_text().strip();q=Path(q);r=q/'readers-final';source=Path('/home/staszek/MeshRoute')
subprocess.run(['git','clone','--shared','--no-hardlinks',str(source),str(r)],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
paths=set(subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z'],cwd=source).decode().split('\0'))-{''}
manifest={}
for rel in sorted(paths):
 src=source/rel;dest=r/rel;dest.parent.mkdir(parents=True,exist_ok=True)
 if src.is_symlink():
  target=src.resolve();dest.unlink(missing_ok=True);dest.symlink_to(r/target.relative_to(source) if target.is_relative_to(source) else target);manifest[rel]={'symlink':str(src.readlink())}
 else:shutil.copy2(src,dest);manifest[rel]={'sha256':hashlib.sha256(src.read_bytes()).hexdigest()}
(q/'reader-final-inputs.json').write_text(json.dumps(manifest,indent=2)+'\n')
measured=r/'.pio-measure/verified-base/gateway';measured.mkdir(parents=True)
for name in ['firmware.elf','manifest.json']:shutil.copy2(q/'base/.pio-measure/p1-base/gateway'/name,measured/name)
cmds=[('console',['bash','tools/probe_console_sink/run.sh']),('console-no-neg',['bash','tools/probe_console_sink/run.sh','--no-neg']),('inventory-write',['python3','tools/gen_command_inventory.py','--write']),('inventory-bare',['python3','tools/gen_command_inventory.py']),('inventory-check',['python3','tools/gen_command_inventory.py','--check']),('authority',['python3','tools/check_command_authority.py']),('authority-controls',['python3','tools/check_command_authority.py','--selftest']),('tools',['python3','-m','unittest','discover','-s','tools','-p','test_*.py'])]
results=[]
for name,cmd in cmds:
 print('START readers',name,flush=True);start=time.monotonic();log=q/'logs'/('readers-'+name+'.log')
 with log.open('wb') as f:p=subprocess.run(cmd,cwd=r,env=dict(os.environ,MR_LUS_SRC='/home/staszek/lora-universal-simulator'),stdout=f,stderr=subprocess.STDOUT)
 results.append(dict(name=name,cmd=cmd,cwd=str(r),exit=p.returncode,seconds=time.monotonic()-start,sha256=hashlib.sha256(log.read_bytes()).hexdigest()));(q/'reader-results.json').write_text(json.dumps(results,indent=2)+'\n');print('END readers',name,p.returncode,flush=True)
 if p.returncode:raise SystemExit(p.returncode)
