from pathlib import Path
import subprocess,tempfile,json,hashlib,shutil,stat
r=Path('/home/staszek/MeshRoute');q=Path(tempfile.mkdtemp(prefix='mr-codex-s7b3p1-'));Path('/tmp/mr-codex-s7b3p1-active').write_text(str(q)+'\n')
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r).decode().strip();assert head=='c591721c2e09bb4e7583f49e458da9e5155cf822'
assert subprocess.check_output(['git','diff','ac5f9a5','--','lib','src','test','tools','simulation','platformio.ini'],cwd=r)==b''
p=r/'docs/superpowers/plans/2026-09-15-radmin-slice7b3-p1-simple-action-preparation.md';s=p.read_text();s=s.replace('**Revision 1 — READY FOR CODER SOURCE-VALIDATION;', '**Revision 2 — SOURCE-VALIDATION RESUMED AT THE RECONCILED BASE;')
s=s.replace('Base **`ac5f9a592065d08e7cc8c06ef395e79891d41b34`**, the owner\'s QA-passed codec commit; simulator','Base **`c591721c2e09bb4e7583f49e458da9e5155cf822`** plus the permitted preparation inventory in the P1\ncoder receipt §5. This documentation-only successor preserves every production input from QA-passed codec\n`ac5f9a592065d08e7cc8c06ef395e79891d41b34`; simulator')
s=s.replace('Both inbox wipes are attempted independently, warnings precede factory_erase/reboot, and partial failure does not skip later effects.','Both inbox wipes are attempted independently; their conditional warning precedes NV factory_erase. The conditional NV-failure warning follows that call; reboot follows both checks. Partial failure does not skip later effects.')
s=s.replace('| Source at ac5f9a5 |','| Source unchanged from ac5f9a5 at the reconciled base |')
s=s.replace('its own implementation report, complete independent gate and owner commit. QA then refreshes the behavior\nbrief\'s base/anchors against that commit.','its own implementation report and complete independent gate. QA then refreshes the behavior\nbrief\'s base/anchors against that frozen input set; commits are not gates.')
s=s.replace('B394 closes only when these shared seams are implemented and gated;\nQA then refreshes 7b-3 to that commit.','B394 closes only when these shared seams are implemented and gated;\nQA then refreshes 7b-3 to that frozen input set (last commit plus SHA-256 inventory).')
s=s.replace('Owner commits after independent PASS.','The owner commits when they choose; no step waits for a commit.')
a='## 2. Resulting interface and local behavior\n';s=s.replace(a,a+'\n**Owner fold-in (2026-09-15):** typed admission explicitly reports build-level support, including power-saving\ncompiled out, absent fault backend and absent OTA backend. Local handlers still run their existing grammar,\noutput and effects on those builds; an unsupported typed result is not permission to change local behavior.\nNo resident state is added. The later remote consumer uses this support result before promising.\n')
p.write_text(s)
# Complete base snapshot, including all permitted dirty documentation and untracked preflight evidence.
paths=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z'],cwd=r).decode().split('\0');inputs={}
for rel in sorted(set(paths)-{''}):
 p=r/rel
 if p.is_symlink():data=str(p.readlink()).encode();rec={'symlink':str(p.readlink()),'mode':stat.S_IMODE(p.lstat().st_mode)}
 else:data=p.read_bytes();rec={'mode':stat.S_IMODE(p.stat().st_mode)}
 rec['sha256']=hashlib.sha256(data).hexdigest();inputs[rel]=rec
(q/'inputs-base.json').write_text(json.dumps(inputs,indent=2)+'\n')
subprocess.run(['git','clone','--shared','--no-hardlinks',str(r),str(q/'base')],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
for rel,rec in inputs.items():
 src=r/rel;dst=q/'base'/rel;dst.parent.mkdir(parents=True,exist_ok=True)
 if 'symlink' in rec:
  if dst.is_symlink() or dst.exists():dst.unlink()
  dst.symlink_to(src.resolve()) # bind to the exact original resource; documentation directory links are read-only inputs
 else:shutil.copy2(src,dst)
(q/'logs').mkdir();(q/'base-identity.json').write_text(json.dumps({'head':head,'source_attribution':'ac5f9a592065d08e7cc8c06ef395e79891d41b34','input_count':len(inputs),'manifest_sha256':hashlib.sha256((q/'inputs-base.json').read_bytes()).hexdigest(),'brief_sha256':inputs[str(p.relative_to(r))]['sha256'] if False else hashlib.sha256((r/'docs/superpowers/plans/2026-09-15-radmin-slice7b3-p1-simple-action-preparation.md').read_bytes()).hexdigest(),'path':str(q)},indent=2)+'\n')
print(q)
