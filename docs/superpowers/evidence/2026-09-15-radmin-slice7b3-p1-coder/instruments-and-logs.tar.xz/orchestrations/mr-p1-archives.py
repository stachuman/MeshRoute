from pathlib import Path
import tarfile,hashlib,json,time
q=Path('/tmp/mr-codex-s7b3p1-active').read_text().strip();q=Path(q);out=Path('/home/staszek/MeshRoute/docs/superpowers/evidence/2026-09-15-radmin-slice7b3-p1-coder');out.mkdir(exist_ok=True)
for name,items in [('measurements',[('base/.pio-measure/p1-base','board-base'),('base/.pio-measure/p1-iteration1','board-final'),('stack','stack'),('elf-attribution.json','elf-attribution.json')]),('corpus',[('corpus-base','base'),('corpus-final','final'),('corpus-byte-comparison.json','byte-comparison.json')])]:
 start=time.monotonic();p=out/(name+'.tar.xz');print('ARCHIVE',name,flush=True)
 with tarfile.open(p,'w:xz',preset=3) as t:
  for src,dest in items:t.add(q/src,arcname=dest)
 print(name,p.stat().st_size,hashlib.sha256(p.read_bytes()).hexdigest(),round(time.monotonic()-start,1),flush=True)
