#include "firmware_action_effects.h"
char mr_size_ActionPlan[sizeof(mrfw::ActionPlan)];
char mr_size_ActionAdmission[sizeof(mrfw::ActionAdmission)];
char mr_size_ActionSupport[sizeof(mrfw::ActionSupport)];
char mr_size_ActionObserver[sizeof(mrfw::ActionObserver)];
