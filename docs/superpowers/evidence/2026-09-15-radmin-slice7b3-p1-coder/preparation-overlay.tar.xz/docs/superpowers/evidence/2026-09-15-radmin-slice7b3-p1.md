<!-- Coder source-validation: OpenAI Codex, assigned by owner 2026-09-15 -->
# Slice 7b-3-P1 — coder receipt — 2026-09-15

## 1. Source-validation disposition: STOP-1, before implementation

The owner assigned this session the P1 coder task, authorized the existing uncommitted QA preparation,
required typed build-support reporting without local changes, and removed commits as progress gates.
Independent QA still follows a complete implementation freeze; the behavior brief then refreshes at that
QA-passed frozen base. R-RA-40 is recorded and binding for later behavior, with zero resident state in P1.
No further allocation permission is requested here.

Two preflight discrepancies were reported before any repository edit:

1. **Base identity:** the brief and dispatch name `ac5f9a592065d08e7cc8c06ef395e79891d41b34`; actual HEAD is
   **`c591721c2e09bb4e7583f49e458da9e5155cf822`**. Its sole intervening commit changes 60 documentation paths;
   production/test/tool/profile/source inputs remain identical to ac5f9a5. The seven uncommitted files below
   are accepted as permitted preparation, not treated as unexplained dirty work. Nevertheless the specified
   commit pin differs. Owner instruction §5 and the roles document's September-15 override expressly retain
   mismatch→STOP. No reset, checkout repair or silent re-pin was performed. QA can reconcile the brief to the
   observed hash plus this complete inventory without requiring another commit.
2. **B399 — factory-reset anchor wording:** brief §1 says “warnings precede factory_erase/reboot”. At
   `src/firmware_commands.cpp:1083–1086`, the exact order is both inbox wipes → conditional inbox warning →
   NV factory_erase → conditional NV warning → reboot. The NV warning follows the operation it reports.
   Proposed comment-only fold-in: “Both inbox wipes run independently; their conditional warning precedes
   NV factory_erase. The conditional NV-failure warning follows that call. Reboot follows both checks.”
   Existing behavior must stay unchanged; no production correction or owner policy decision is proposed.

Implementation/full-gate dispatch remains stopped pending that base/brief reconciliation. These findings
are source-validation issues, not a requirement to wait for an owner commit. The current report is not a
P1 freeze, P1 PASS or authority for 7b-3 behavior implementation.

## 2. Exact preparation inputs and preservation boundary

Consumed P1 revision-1 brief SHA-256:
`1443c6821dea395b5db1ab46fe7ef127eaaefd997b71d0098b64a6ffba58d3bf`.
All **1,459** original tracked paths are inventoried, including directory symlinks (1,456 regular/resolved-file
paths plus three directory-link paths); there were no untracked or staged inputs at preflight start.
The complete initial manifest SHA-256 is
`12b6c7f126682bd948821bed0e086107f3d12e885459d3f3ede955b9f53515c8`.

| Permitted uncommitted preparation | SHA-256 at source-validation start |
| --- | --- |
| MEMORY.md | 1e8bb349c766a69fe30180c804c6936a3ac28e2d52b8f29037c2a7eb39f32be4 |
| docs/2026-07-30-open-bug-register.md | ea28f021a372154e40fa9d9477897552316f7b3ee65e52e57fdcce3024ec438f |
| docs/2026-09-02-agent-roles.md | fd60c3ccf3179ddbf9ba0d0a2a2bd4064e7541796fe322b665feba1867184dc7 |
| docs/superpowers/plans/2026-09-03-remote-admin-v2-rulings.md | cbce67054db4caa0c2207dd2c21416481398969279875b7dc3b67d1f563f877e |
| docs/superpowers/plans/2026-09-13-radmin-slice7b3-deferred-actions.md | 4a7af9b19e723598470fa5b9b054403c63f7e88d44ffaffd7bb7aa717c31b397 |
| docs/superpowers/plans/2026-09-15-radmin-slice7b3-p1-simple-action-preparation.md | 1443c6821dea395b5db1ab46fe7ef127eaaefd997b71d0098b64a6ffba58d3bf |
| docs/superpowers/specs/2026-08-23-remote-admin-independent-rpc-design.md | 309d576a7e485afcc9d8189a85202993687ff53309f41e60ada02303ab9daf9f |

Simulator HEAD **06746a97de5764415d6fcef10b97bca90569b9c7**, clean; all **285** paths inventoried. Original
preparation diff and manifests are retained in the [artifact directory](2026-09-15-radmin-slice7b3-p1-preflight/README.md).
This landing adds the receipt/artifacts and M1's B399/current-dispatch bookkeeping only. It preserves the
briefs, owner rulings and source; final hashes distinguish those new reporting documents from the input set.

## 3. Source anchors and the owner's build-support fold-in

| Current source (unchanged from ac5f9a5) | Verified consequence |
| --- | --- |
| firmware_commands.cpp:1071–1089 | Exact seven-byte confirm after leading spaces; no effect-only helper. B399 records precise warning/erase/reboot order. |
| firmware_config_parse.h:562–566 | Existing parse_confirm_token matches the stated whitespace/token predicate; adds explicit null rejection. Reuse only with local behavior preserved. |
| firmware_commands.cpp:1096–1105; fw_main.cpp:1827–1852 | Sleep off-prefix/otherwise-on grammar and flag/output always execute locally; MR_NO_POWERSAVE removes the sleep policy. Future typed admission reports unsupported in that build without skipping/changing the local handler. |
| fw_main.cpp:395–416 | Debug gate precedes prefix grammar. Fault uses NRF52_PLATFORM or MRFAULT_ESP32; absent backend still prints the existing fault text and unsupported line locally. Typed support must say unsupported without changing those local bytes/effects. |
| fw_main.cpp:293–298, :320–354, :423–445 | Local wrappers retain their global/caller sink choices, reset marks/delays, two prep wipes and halt/output order. No complete typed sink/outcome contract exists. |
| device_ota.cpp:92–105; fw_main.cpp:335–354 | ota_start is idempotent; local ESP OTA toggles stop/start. The absent outer OTA backend has no effect/output in do_ota. Typed admission must expose absent backend while preserving the local no-op. |
| firmware_remote_executor.h:41–43/:87–90; firmware_commands.cpp:1666–1673 | Shared disruptive predicate is enforced in both executor and common command seam. Both remain refusing throughout P1. |

The three support cases are explicit owner instructions, not new refusals on local USB/BLE. P1's future
remote consumer needs the typed support result; P1 itself grants no remote execution. Device-fault macro/ISR
ownership remains single-TU. The 36 R-RA-39 refusal rows remain outside this preparation implementation.

## 4. Fresh focused proof and what has not run

I extracted the actual factory-reset function (source SHA-256
`a91d78f79b931a35e83692d7390dd999bc457ae428e112753912f832629ab57e`) and compiled it with Print/inbox/NV/reset
fakes. **Eight erase-result combinations PASS**, comparing complete output bytes and operation order.
A private reorder control compiles and fails an executed assertion: `ORDER/BYTES assertion failed, case 0`.
Commands/generated TUs/hashes/logs are retained. This runs an extracted production function, not the whole
firmware_commands TU/router and not real flash or reboot. It proves the narrow B399 wording correction only.

No native suite, corpus, board/ABI gate, probes/tools sweep, census or mutation union ran this turn. No
implementation has been written, so prior QA totals are not a P1 result. No PIN re-sync is claimed:

`PIN re-synced? NO — preflight STOP-1; no implementation or full P1 gate.`

The required YES line belongs in the later completed full-gate freeze and must contain independently derived
counts. After the brief/base is reconciled, P1 source-validation resumes; then implementation/full gate,
independent QA, and behavior reissue at the frozen QA-passed input set. Commits may occur at the owner's
chosen time and are not a prerequisite.
