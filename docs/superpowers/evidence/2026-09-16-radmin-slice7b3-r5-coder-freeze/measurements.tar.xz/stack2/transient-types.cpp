#include "firmware_remote_actions.cpp"
char mr_size_EffectSink[sizeof(mrfw::EffectSink)];
char mr_align_EffectSink[alignof(mrfw::EffectSink)];
char mr_size_ActivationReport[sizeof(mrfw::ActivationReport)];
char mr_align_ActivationReport[alignof(mrfw::ActivationReport)];
