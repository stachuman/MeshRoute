// MeshRoute — lib/core/node_mac_rx.cpp  (R3/R4 MAC data plane — RX frame handlers)
// Author: Stanislaw Kozicki <cgpsmapper@gmail.com>
//
// The receive side of the RTS-CTS-DATA-ACK-NACK handshake: what we do when each
// frame type arrives. Includes the R4 anti-spam originator drop + budget-aware
// NACK (handle_rts), the §7.6 hop-budget enforcement + origin dedup + budget-hint
// ACK (handle_data), the post-ACK deliver/forward, and the sender's NACK reactions
// (LOOP_DUP cascade / BUSY_RX wait-or-requeue / HOP_BUDGET rt-bump / BUDGET blind).
// The TX/send path is in node_mac.cpp; the duty/anti-spam metric helpers are in
// node_budget.cpp. Behaviour mirrors dv_dual_sf.lua. Part of the Node class (node.h).
#include "node.h"
#include "monocypher.h"  // wipe the per-frame sealed-body scratch on every return

#include "frame_codec.h"
#include "airtime.h"
#include "identity.h"  // §P2-6: key_hash32_of (LE(ed_pub[:4]) derivation)

#include <span>

namespace MESHROUTE_NS {

// 2-bit ACK SNR bucket (dv_dual_sf.lua:842; centers -16/-8/+4) — NOT the 4-bit one.
static uint8_t bucket_of_snr_2b(int snr_q4) {
    if (snr_q4 < -192) return 0;        // < -12 dB
    if (snr_q4 <  -64) return 1;        // < -4 dB
    return 2;
}

// B161: H_ANSWER / AUTHORITATIVE_H_ANSWER / MOBILE_H_ANSWER / MOBILE_H_ANSWER_PUBKEY are internal answers
// with fixed, type-owned BODY shapes inside the
// standard plaintext-unicast envelope. Merely parsing `[origin][body]` is not enough to
// distinguish a legacy raw body: its first type byte can be consumed as a plausible origin.
// Require the exact production body shape before any cache/store/drain side effect.
// AUTHORITATIVE_H_ANSWER_PUBKEY remains outside this classifier because its existing standard-DM body and optional DST_HASH
// prefix are unchanged by B161.
static bool canonical_typed_answer_body_valid(uint8_t type, std::span<const uint8_t> body) {
    switch (type) {
        case DATA_TYPE_H_ANSWER:
        case DATA_TYPE_AUTHORITATIVE_H_ANSWER:
            return body.size() == 6;
        case DATA_TYPE_MOBILE_H_ANSWER:
            return body.size() == 7;
        case DATA_TYPE_MOBILE_H_ANSWER_PUBKEY: {
            if (body.size() < 40) return false;                 // hash-bind 7 + ed_pub 32 + name_len
            const uint8_t name_len = body[39];
            return name_len <= 32 && body.size() == static_cast<size_t>(40 + name_len);
        }
        default:
            return true;
    }
}

// B251/U2: the one PostAck -> forwarded TxItem conversion. The ordinary post-ACK relay and the hosted-mobile
// counter-boundary prequeue both use it; the latter changes only ctr/ctr_lo and the explicit GLOBAL plane on the
// accepted PostAck before calling here. Keeping one conversion prevents a later carrier field from being preserved
// on normal relays but silently dropped on translated ones.
static TxItem forward_item_from_post_ack(const PostAck& pa, uint64_t now_ms) {
    TxItem it{};
    it.origin = pa.origin; it.dst = pa.dst; it.ctr = pa.ctr; it.ctr_lo = pa.ctr_lo;
    it.flags = pa.flags; it.type = pa.type; it.is_forward = true; it.previous_hop = pa.previous_hop;
    it.inner_len = pa.inner_len;
    for (uint8_t i = 0; i < pa.inner_len; ++i) it.inner[i] = pa.inner[i];
    for (int i = 0; i < 8; ++i) it.nonce_seed[i] = pa.nonce_seed[i];
    it.fwd_remaining = pa.fwd_remaining; it.fwd_committed = pa.fwd_committed;
    it.enqueue_time_ms = now_ms;
    return it;
}

void Node::handle_rts(const uint8_t* bytes, size_t len, const RxMeta& meta) {
    auto pr = parse_rts(std::span<const uint8_t>(bytes, len));
    if (!pr) return;
    const rts_out& r = *pr;
    // §mobile 6.4: a TEAM RTS addressed to our team_local_id (addr_len=1) rides the leaf-AGNOSTIC team plane — a MIXED team
    // spans leaves (an off-grid member on leaf 0 + a registered member on its home's adopted leaf) yet shares the PHY +
    // team_id. Do NOT drop it on leaf mismatch; the rest of the exchange (CTS/DATA/ACK) matches on pending state, not leaf.
    // A non-team frame, or a member whose team_local_id differs, hits the normal leaf gate -> s18/static byte-identical.
#if MR_FEAT_TEAM
    const bool team_rts_for_us = team_addr_for_us(r.next, r.addr_len);   // §P2-3
    // §P2-1 (mixed-leaf team channel): a TEAM channel-flood RTS-M (m_broadcast + mobile_src) is leaf-EXEMPT for a team member,
    // so a teammate homed on another nibble still retunes to catch the DATA-M. The RTS-M carries no team_id (only the DATA-M
    // does) so we exempt ANY team flood — the DATA-M's team_id gate (ingest_channel_m) does the actual team filtering (the same
    // "accepted residual" already documented below for the same-nibble different-team case). A static (team_id==0) is unchanged.
    const bool team_flood_rts  = r.m_broadcast && r.mobile_src && _cfg.team_id != 0;
#else
    const bool team_rts_for_us = false;   // §featuresplit: no team plane -> the normal leaf gate applies
    const bool team_flood_rts  = false;
#endif
    if (r.leaf_id != _cfg.leaf_id && !team_rts_for_us && !team_flood_rts) return;
    // §mobile: any RTS FROM our HOME (it relays our DMs onward + originates its own) proves the home is alive -> refresh
    // the home-lost clock (see handle_cts). is_mobile+active gated -> s18/static byte-identical (compiled out on a static build).
#if MR_FEAT_MOBILE
    if (_cfg.is_mobile && _my_mobile_reg.active && r.src == _my_mobile_reg.home_id)
        _my_mobile_reg.last_heard_home_ms = _hal.now();
#endif
    // R4.4 anti-spam: track this RTS in the sender's window even when it's NOT addressed to us (we
    // overhear routing-SF broadcasts) so all 1st-hop neighbours accumulate evidence. Gateway cross-layer
    // relays (RTS_FLAG_RELAY) are exempt — not a 1st-hop origination (dv:9709-9712). Keyed on the decoded
    // RTS src (frame-derived, metal-correct), NOT meta.src_hint (the sim PHY oracle, -1 on hardware).
    // M_BROADCAST RTS (a channel-gossip re-broadcast) is exempt too — a holder relaying a channel msg
    // is not a DM originator; counting it would DM-throttle honest gossipers (Lua dv:9709 `elseif
    // r.m_broadcast`). The become_free self-cap already exempts M_BROADCAST (Inc 4); this is the
    // RTS-observation half. Draw-free + inert until M_BROADCAST RTS flows (Phase 2 channel responder).
    // ✔ §rts-cr-overhear (2026-07-27) — CONVERTED, and this site was MISSED by the audit that scoped the
    // slice: it bills at the sender's CR via airtime_routing_ms(), which calls active_cr() INSIDE (node_mac.cpp),
    // so a grep for "active_cr()" does not list it. It is the RTS half of the SAME anti-spam ledger whose DATA
    // half is converted at handle_data below — one ledger, one quantity ("airtime this sender imposed on us"),
    // so billing the two halves at different coding rates would be incoherent. Expanded inline rather than
    // through airtime_routing_ms because only the CR differs (SF/BW are ours: we received it on our routing SF).
    if (!(r.rts_flags & RTS_FLAG_RELAY) && !r.m_broadcast && !r.mobile_src)   // §mobile 3b A1: a mobile_src RTS's src is a LOCAL id, not a global identity -> skip the src-keyed track (accountability rides origin=home_id)
        track_originator_observation(r.src, /*kind=rts*/0, r.ctr_lo,
                                     static_cast<uint32_t>(airtime_ms(_cfg.routing_sf, active_bw_hz(),
                                         rts_cr_decode(r.cr_adv), protocol::preamble_sym,
                                         static_cast<uint16_t>(len))));
    // Learn the RTS sender as a 1-hop neighbour — any RTS, overheard or addressed (Lua learn_rx_source).
    // §mobile 3b A1 (the load-bearing collision fix): NEVER learn a mobile's LOCAL id as a global neighbour — it can
    // collide a global id, and then rt_find(that id) would resolve to the mobile so a mobile's E2E-ACK to the colliding
    // GLOBAL id would loop back. The mobile reaches the mesh via its home_node; its src never enters the global rt.
    // §team-parity T0: the learn PLANE is now written out at the call site instead of riding learn_direct_neighbor's
    // default argument, so T2's diff is a one-token flip that a reviewer can see. Static reduction: the explicit
    // `false` IS the previous default ⇒ identical call, on every build profile (the parameter is not MR_FEAT_TEAM-gated).
    // ✔ §team-parity T2 (spec §3/T2 row 1) — DONE below as a THIRD arm. This guard is UNCHANGED (invariant I2: a
    // mobile/team local id never enters the static _rt); T2 only gives the excluded traffic a TEAM destination.
    if (!r.mobile_src && learn_direct_neighbor(r.src, protocol::db_to_q4(meta.snr_db), false, /*team_plane=*/false)) schedule_triggered_beacon();
    // §6.4 team reverse-learn: a team RTS ADDRESSED to OUR team-local id (mobile_src + addr_len=1 + next==our team id) ->
    // its src is a reachable same-team peer. Mark it a team peer (the _team_peer bitmap that is_team_peer/route-selection
    // read) AND learn a 1-hop TEAM route (_rt_team) so we can REPLY — mirrors the beacon path (node_beacon.cpp:685-686).
    // Team routes are otherwise beacon-only, and an off-grid team's 15-min periodic beacons + join-order can miss a peer
    // entirely. Gated on r.next==_team_local_id (NOT our MOBILE local id) -> never a home last-mile; mobile_src+addr_len=1
    // keeps it off the static _rt (s18/mobile-DM sims have no such frame -> byte-identical). A NEW peer also triggers our
    // beacon (Fix a) so the peer learns us back.
#if MR_FEAT_TEAM
    else if (r.mobile_src && team_addr_for_us(r.next, r.addr_len)   // §P2-3
             && r.src != 0 && r.src != 0xFF) {
        _active->_team_peer[r.src >> 3] |= static_cast<uint8_t>(1u << (r.src & 7));   // known same-team peer (is_team_peer reads this)
        if (learn_direct_neighbor(r.src, protocol::db_to_q4(meta.snr_db), false, /*team_plane=*/true)) schedule_triggered_beacon();
    }
    // ✔ §team-parity T2 (spec §3/T2 row 1) — an OVERHEARD team RTS (mobile_src, NOT addressed to our team id) proves its
    // src is a 1-hop neighbour RIGHT NOW. Today the team plane learns a direct neighbour from exactly two events (a
    // same-team beacon, 15-min periodic; the arm above), while the static plane learns from seven — this is one of the
    // five T2 closes.
    // ★★ NARROWED vs the spec, DELIBERATELY, and this is the one T2 judgement a reviewer must check. The spec says
    // "+ team learn when the src is a same-team local id". THE RTS CARRIES NO TEAM ID — verified at frame_codec.h:289
    // (rts_in has leaf_id/src/next/ctr_lo/dst/sf_index/rts_flags/payload_len/addr_len/mobile_src/cr_adv and nothing
    // else), and the sibling `team_flood_rts` at :42 says so in as many words ("we exempt ANY team flood — the DATA-M's
    // team_id gate does the actual team filtering"). So "is this src a teammate?" is NOT DECIDABLE from an overheard
    // RTS: it could equally be a FOREIGN team's member or a plain mobile's home last-mile. Admitting such a src would
    // set _team_peer for a non-teammate, which makes rt_find(x, AUTO) shadow the static _rt for that id — the mirror of
    // the I2 leak, and s35's A2 ("_rt_team contains zero static node ids"). ⇒ the arm is restricted to a src ALREADY
    // known to be a teammate, so it REFRESHES/SHORTENS a route and NEVER ADMITS a new id. _team_peer is set only from a
    // same-team BEACON (node_beacon.cpp:765, team_id-verified) or the addressed-RTS arm above — the same trust basis.
    // MISSING (needs a wire bit or T4's team-scoped Q, NOT reachable here): admitting an UNKNOWN teammate from an
    // overheard RTS. There is no sound way to do it with today's RTS.
    else if (r.mobile_src && is_team_peer(r.src)                                       // §T2 row 1 — refresh a KNOWN teammate
             && learn_direct_neighbor(r.src, protocol::db_to_q4(meta.snr_db), false, /*team_plane=*/true)) schedule_triggered_beacon();
#endif
    // §mobile 3b/6.4: addressed iff the frame targets EITHER of my plane ids. for_static = next==_node_id AND the mark
    // matches my kind (a mobile accepts addr_len=1, a static addr_len=0). for_team = next==_team_local_id AND addr_len=1
    // (a team member's team-plane id; off-grid it's the only id). A non-team node has _team_local_id==0 -> for_team false
    // -> this is byte-identical to the old `next != _node_id || (addr_len==1)!=is_mobile`.
    // ★★★★★ §hybrid-rts S4b (2026-08-09) — **HOISTED FROM ITS POST-M_BROADCAST POSITION TO HERE, so the implicit-
    // forward credit below can ask "is this frame addressed BACK to me?" from the CANONICAL predicates.** ⛔ NOT a
    // second derivation: `for_static_rts`, `team_addr_for_us` and `rts_wire_team_plane` are the same three producers
    // the addressing decision at `if (!addressed_for_us)` below uses, moved rather than copied — a SECOND identity
    // derivation cost §hybrid-rts S2 forty false refusals and there is still only one here.
    // ★ THE MOVE IS VALUE-IDENTICAL, and the argument is STRUCTURAL rather than "nothing looked relevant": for any
    //   frame that reaches the `!addressed_for_us` branch, the ONLY code now executing between this point and that
    //   branch is the credit gate (which RETURNS when it fires), the `allowed_sf_bitmap` refusal (which RETURNS)
    //   and the whole `r.m_broadcast` block (which RETURNS on every path, at both its own `return`s). ⇒ nothing
    //   between the two positions can run AND fall through, so nothing can mutate `_node_id`, `_team_local_id`,
    //   `_cfg.is_mobile` or `_cfg.team_id` in between. The three predicates are `const`-read and side-effect-free.
    const bool for_static_rts = r.next == _node_id && ((r.addr_len == 1) == _cfg.is_mobile);
#if MR_FEAT_TEAM
    const bool for_team_rts   = team_addr_for_us(r.next, r.addr_len);   // §P2-3
#else
    const bool for_team_rts   = false;   // §featuresplit
#endif
    const bool wire_team        = rts_wire_team_plane(r);
    const bool addressed_for_us = wire_team ? for_team_rts : for_static_rts;
    // ⛔⛔ ② THE IMPLICIT-ACK FROM AN OVERHEARD FORWARD-RTS (Lua dv:9863-9893) WAS **DELETED** by §B153/[[B157]]
    // on 2026-08-08 and is **RESTORED HERE, KEYED ON THE S1 FLIGHT IDENTITY**, by §hybrid-rts S4 (2026-08-09).
    // ⓘ THE DELETION WAS RIGHT ABOUT THE FRAME IT WAS WRITTEN ABOUT, and the argument is kept because the
    // restoration only survives review if the reader can see exactly which premise changed:
    //   ⛔ The old match was `next/dst/ctr_lo` + `payload_len`, and its own comment credited `payload_len` with
    //      *"disambiguates a 4-bit ctr_lo wrap"* — ★ **IT NEVER DID: `payload_len` IS A LENGTH, NOT AN IDENTITY,
    //      AND THAT CLAIM IS WITHDRAWN, NOT SOFTENED** (design §2.4; the same fence stands at frame_codec.h's
    //      `payload_len IS NOT PART OF IDENTITY` note). It is a frame-consistency / NAV field and nothing else.
    //      ⛔ It is therefore ABSENT from the comparison below, deliberately — do not add it "for extra safety":
    //      the comparison is the full identity or nothing.
    //   ⛔ MEASURED, NOT ARGUED — this is what forced the deletion. With the RTS-time gate removed, `s27` STAYED
    //      RED, and the cause was here: at t=362768 gateway G1 has both hosted mobiles' replies queued to home 101
    //      (origins 114 and 111, both `ctr` 2, both `payload_len` 57); the origin-114 flight completes, the
    //      origin-111 flight airs its RTS and gets no CTS (103 is busy relaying the first), and at t=363718 G1
    //      overhears 103 forwarding the **114** message to 102 and credits it to the **111** flight — which had
    //      never transmitted a DATA at all. `re-m3` was lost in silence.
    // ★★★★ WHAT CHANGED IS THE FRAME, NOT THE REASONING. A unicast RTS is no longer 7 bytes: it is 10 B
    //   (plaintext `origin|ctr_hi|ctr_lo`) or 11 B (crypted `BLAKE2b-512(0xE1|seed8|ctr_hi|ctr_lo|dst)[:4]`) and
    //   CARRIES the canonical flight identity (§hybrid-rts S1). ⇒ in the `s27` case above, origin 114's forward and
    //   origin 111's pending flight now differ in the identity tail, so the credit REFUSES — that exact frame is a
    //   required regression of this slice, not a hope.
    // ★★★ AND THE CREDIT IS NOT A DELIVERY VERDICT, WHICH IS THE OTHER HALF OF WHY IT IS SAFE TO HAVE BACK.
    //   Owner ruling 2026-08-09 (ledger §1.10), verbatim: *"A mismatch may be billed as physical airtime, but must
    //   not refresh liveness or alter timers, routing, pending state, or application outcomes."*
    //   ⇒ ⛔ NO `send_acked`, NO `send_e2e_acked`, NO delivered, NO `send_failed` is synthesized on EITHER basis,
    //     and any independently armed end-to-end ACK wait (`_pending_e2e_acks`) is LEFT RUNNING — it is keyed on the
    //     app's own ctr and is the only thing that can report a real end-to-end outcome. The app was told `queued`;
    //     an ordinary non-`-a` send gets no new terminal outcome, which is the historical behaviour verbatim.
    //   ⇒ A MISMATCH does nothing at all: it falls through to ordinary RTS handling with every timer, deadline,
    //     pending copy and route/liveness datum untouched. (The anti-spam observation and the neighbour learn a few
    //     lines above already happened for EVERY RTS — that is the pre-existing per-frame accounting/learning of a
    //     frame that really aired, not an effect of this arm, and it is the same accounting-vs-trust split S2c
    //     wrote down for the terminal CTS.)
    // ★★ THE TWO BASES STAY NAMED SEPARATELY (design §5.2) — ⛔⛔ BUT §hybrid-rts S4c (2026-08-10) DOWNGRADED WHAT
    //   THE FIRST ONE CLAIMS, AND ITS NAME WITH IT. **NEITHER IS A PROOF THAT ANY DATA OF OURS AIRED.**
    //   · `local_admitted` — `pt.data_ever_admitted` (was `local_data` / `data_ever_transmitted`): this node
    //                        **ADMITTED** a DATA for this flight to its own radio — `IHal::tx` returned `ok`, which
    //                        on metal is an ENQUEUE (`device_hal.cpp:10-12`). ⛔ It is **NOT** evidence the DATA
    //                        aired: `on_radio_busy(FrameTag::data)` can refuse it AFTER admission (652
    //                        `data_tx_blocked` corpus-wide) and `pump_tx()`'s failed arm can drop it. §T2 now
    //                        reports the separate attempt outcome, but does not mutate this admission flag.
    //                        Nothing in this implicit-credit arm consumes airing as delivery evidence.
    //     ⛔⛔ **§hybrid-rts S4d (2026-08-10) — "WRONG BOTH WAYS" IS NOW WRONG ONE WAY, AND THAT IS THE WHOLE POINT
    //     OF S4d.** The FALSE side of this test is the one that carries a CATEGORICAL claim — `alternate_path` says
    //     *"we admitted NO DATA"* — and it could not support it while the only writer sat on the initial send path:
    //     a duty-deferred DATA that `duty_defer_fire` later admitted read `false`. S4d moves the write to the ONE
    //     crossing point (`tx_with_retry`, right after `_hal.tx()` returns `ok`), which **every** DM-DATA admission
    //     must pass ⇒ ★ **`false` NOW MEANS "no DATA of ours was admitted", EXACTLY, and this label is legitimate.**
    //     ⛔ The over-claim direction is UNCHANGED and still real: `true` is ADMISSION, never AIRING, because
    //     `on_radio_busy` and `pump_tx()`'s failed arm can drop the frame afterwards and nothing can unset the flag.
    //     §T2's flight-correlated completion signal now reports the separate outcome without rewriting this field;
    //     its app/UI consumer remains T3. ⚠ So neither basis became delivery evidence — see the ruling two lines
    //     down.
    //   · `alternate_path` — we admitted NO DATA for it (typically still `awaiting_cts`). ★★ ITS JUSTIFICATION IS
    //                        **"the flight is progressing and this local copy is redundant"** — ⛔ it is **NOT**
    //                        *"our DATA crossed the hop"*, because no DATA of ours exists. The next hop obtained the
    //                        same flight through ANOTHER branch/path; keeping our copy would only add a duplicate
    //                        DATA behind a hop that is already forwarding it. ⚠ Stated here in as many words
    //                        because a later reader who skips this line will re-derive a false success claim from it
    //                        — and it matters MORE, not less, now that it is the RARER branch (see below).
    // ⛔⛔ §hybrid-rts S4b (2026-08-09) — **A RETIRED CLAIM, CORRECTED IN PLACE RATHER THAN DELETED, because it was
    //   asserted at this exact line and a reader who saw it once must be able to see it withdrawn.** ⛔ WHAT STOOD
    //   HERE: *"`alternate_path` is the MAJORITY case, not a corner (46 of the 61 historical firings)"*.
    //   ★ IT IS FALSE, AND IT WAS UNKNOWABLE WHEN WRITTEN. Unknowable because the field that DECIDES the basis,
    //   `data_ever_admitted` (S4 named it `data_ever_transmitted`), is introduced by S4 — the historical census had
    //   only the pending state and INFERRED "DATA never transmitted" from `awaiting_cts`. ★★ THAT INFERENCE IS THE
    //   BUG IN THE CLAIM: **`awaiting_cts` IS NOT A MONOTONE PHASE.** A flight that admits a DATA, loses the ACK,
    //   times out and re-RTSes is back in `awaiting_cts` with a DATA already admitted. ⇒ MEASURED on the S4 wire, 36
    //   scenarios, from this emit's own fields: **49 credits — 36 / 13**, i.e. `alternate_path` is the **MINORITY at
    //   ~27 %**; by state 45 `awaiting_cts` / 3 `awaiting_ack` / 1 neither, and **32 of the 45 `awaiting_cts` credits
    //   carry the local basis** — which is the false inference shown as a number. ⓘ Those 36 were emitted under the
    //   label `local_data`; §hybrid-rts S4c renamed it `local_admitted` with the counts unmoved, so the two figures
    //   are ONE continuous series (the S4/S4b tables in `BASELINE.md` keep the old label as measured).
    //   ⓘ `alternate_path`'s JUSTIFICATION above is UNCHANGED by this correction and still load-bearing: it is
    //   *"the flight is progressing and this local copy is redundant"*, never *"our DATA crossed the hop"*. Only
    //   the frequency claim was wrong. ★★ §hybrid-rts S4c STRENGTHENS it to the ONLY justification either basis has:
    //   with the local basis downgraded to admission telemetry, redundancy-of-this-copy is all that ever carried the
    //   clear, on BOTH branches. Figures: `BASELINE.md` §HYBRID-RTS-S4 (3), §HYBRID-RTS-S4b, §HYBRID-RTS-S4c.
    // ★ ONE DERIVATION, ALWAYS: the identity comes from `Node::flight_identity` (the ONE producer `tx_rts_retry`
    //   also uses) and the comparison from `rts_flight_identity_equal` (the ONE comparator — full width + domain,
    //   never a prefix). A SECOND derivation of this identity cost S2 forty false refusals; there is not one here.
    // ★ THE PLANE IS DECODED FROM THE WIRE ON BOTH SIDES: `rts_wire_team_plane(r)` for the overheard frame (the only
    //   plane evidence an overhearer HAS) against `rts_wire_team_plane(rts_wire_marks(pt))` — the marks we ourselves
    //   AIRED for this flight. ⛔ NOT `team_addr_for_us` (receiver-relative address admission; it never consults
    //   `mobile_src`, and this frame is not addressed to us at all), ⛔ NOT layer membership, ⛔ NOT
    //   `is_team_peer(src)` (our own state, not the frame's declaration). Design §4.3 / §5.2 item 4.
    // ⛔ AN `m_broadcast` FLIGHT IS EXCLUDED — new vs the historical arm, and deliberately. A channel M flight is
    //   fire-and-forget (`awaiting_cts == awaiting_ack == false`, cleared by kMBcastClearTimerId) and airs an M
    //   frame, not DATA: there is no CTS/ACK wait to short-circuit, clearing it would race that timer, and it has
    //   no `data_ever_admitted` writer so its basis label would be a lie. Its identity cannot match anyway
    //   (an M/FLOOD RTS carries NO identity tail, and `rts_flight_identity_equal` treats absent-vs-absent as NOT a
    //   match), so this guard is belt-and-braces made explicit rather than left to be re-derived.
    // ★★★★★ §hybrid-rts S4b (2026-08-09) — ⛔⛔ **`!addressed_for_us` IS A LOAD-BEARING TERM OF THIS GATE, AND ITS
    //   ABSENCE WAS A REAL DEFECT: A LOOPED RTS READ AS DOWNSTREAM PROGRESS.**
    // ★ THE PRINCIPLE, because it generalises past this gate: **AN EXACT IDENTITY MATCH PROVES *WHICH FLIGHT*,
    //   NEVER *WHICH DIRECTION*. Direction is a separate fact and needs its own evidence.** Every other term here
    //   (identity, plane, `r.src == pt.next`, `r.dst == pt.dst`) answers "which flight?"; not one of them answers
    //   "did it move AWAY from me?".
    // ⛔ THE FRAME, and it is reachable rather than hypothetical: in a route loop our own next hop B can forward the
    //   EXACT flight straight BACK to us (`r.next == our id`). Every S4 term then matched — the identity is right,
    //   because it IS our flight — so we cancelled our timers, `reset()` our `_pending_tx`, `become_free()` and
    //   RETURNED. ⇒ we DISCARDED THE ONLY VIABLE COPY of a message on evidence that showed the opposite of
    //   progress, and we returned BEFORE the normal addressed-RTS handling that frame was owed.
    // ★★ AND THE FIX IS NOT "NO CREDIT" — IT IS "NO CREDIT **AND STILL HANDLED**". A frame addressed to us FALLS
    //   THROUGH from here into the ordinary path below (`rts_rx`, the completed-flight terminal CTS, the re-CTS
    //   branch, the BUSY_RX NACK / `rts_drop_pending_tx`), with the pending flight INTACT. A guard that merely
    //   skipped the credit and swallowed the frame would trade a lost message for a lost response.
    // ⓘ COVERAGE, stated honestly: **corpus-DARK on the 36-scenario corpus** (the credit census is 49 before and
    //   after this term, all 36 streams byte-identical), so its ONLY detectors are native — the negative loop case,
    //   the positive genuine-forward control beside it, and the mutation that removes this term.
    if (_active->_pending_tx && !_active->_pending_tx->m_broadcast
        && !addressed_for_us                                   // ★ direction: an RTS aimed BACK at us is not progress
        && r.src == _active->_pending_tx->next
        && r.dst == _active->_pending_tx->dst) {
        const PendingTx&        pt   = *_active->_pending_tx;
        const RtsFlightIdentity mine = flight_identity(pt);                       // the ONE producer
        const RtsWireMarks      mk   = rts_wire_marks(pt);                        // the ONE producer of OUR marks
        if (rts_flight_identity_equal(r.id, mine)
            && rts_wire_team_plane(r) == rts_wire_team_plane(mk.addr_len, mk.mobile_src)) {
            // [[maybe_unused]] is LOAD-BEARING — **QA-RECOMMENDED** form, 2026-08-10 ([[B169]]); ⛔ NOT an owner
            // ruling, and the distinction is recorded because this arc has now mis-attributed provenance five times.
            // This value's ONLY consumer is the
            // MR_EMIT below, and the board envs define MESHROUTE_NO_TELEMETRY, which expands MR_TELEMETRY to
            // `do {} while (0)` and DELETES that body -> `-Wunused-variable` on all ten board envs. ⛔ Do NOT "fix"
            // it by moving the read inside MR_EMIT (**QA-recommended constraint**, not an owner ruling): the
            // declaration is what documents that the credit's basis is read BEFORE any timer is cancelled, and
            // warnings are gate-blocking.
            // ★★ WHY NO AUTOMATED GATE SAW IT FOR FOUR SLICES: native and the simulator build with telemetry ON, so
            // the variable is genuinely USED there. The defect is invisible to `pio test -e native` and to all 36
            // corpus streams BY CONSTRUCTION — only a board build can see it. It entered at §hybrid-rts S4.
            [[maybe_unused]] const bool local_admitted = pt.data_ever_admitted;
            _hal.cancel(kRtsTimeoutTimerId);
            _hal.cancel(kAckTimeoutTimerId);
            _hal.cancel(kRetryBackoffTimerId);                 // parity with handle_ack: drop a stale retry armed by a just-fired timeout
            // The emit keeps its HISTORICAL NAME so the telemetry series is continuous — ⛔ but the name is a
            // historical label ONLY and never an app ACK (design §5.2). `basis` says which observation this credit
            // rests on; `awaiting_cts`/`awaiting_ack` are carried so the census can be split by pending state
            // without a second instrument.
            // ⛔⛔ §hybrid-rts S4c (2026-08-10) — **THE `basis` VALUE `local_data` IS RENAMED `local_admitted` AND
            //   THAT IS THE ONE THING IN THIS SLICE THAT MOVES A STREAM BYTE.** Deliberate: `local_data` reads as
            //   *"our DATA"*, i.e. as proof of airing, which the flag cannot support in EITHER direction (see
            //   `do_data_tx` and [[B164]]). ★ The movement is exactly this token — proven by substituting it back
            //   and reproducing all 36 pre-rename streams byte-for-byte (`BASELINE.md` §HYBRID-RTS-S4c). ⛔ The
            //   COUNTS are unmoved (49 · 36/13 · 45/3/1), so the census is one continuous series across the rename.
            MR_EMIT("implicit_ack_from_forward", EF_I("from", r.src), EF_I("dst", pt.dst), EF_I("ctr", pt.ctr),
                    EF_I("forward_next", r.next), EF_S("basis", local_admitted ? "local_admitted" : "alternate_path"),
                    EF_B("awaiting_cts", pt.awaiting_cts), EF_B("awaiting_ack", pt.awaiting_ack));
            _active->_pending_tx.reset();
            become_free();
            return;
        }
    }
    // No data SF configured (empty sf_list) -> this node is data-incapable: it can't pick a DATA SF, so it does
    // NOT CTS / retune / arm NAV (no silent fallback). The sender's DM just fails — fail loud. Control plane
    // (neighbour-learn above, beacons, routing) still runs; only data participation is refused.
    if (_cfg.allowed_sf_bitmap == 0) return;
    // ROADMAP §3: an M_BROADCAST RTS is a fire-and-forget channel re-broadcast (no CTS). ANY node that hears
    // it and LACKS the msg (by the id low-16) retunes RX to the advertised SF to catch the DATA-M — not just
    // the addressed puller. The retune-back timer restores routing_sf. Holders + gateways skip. (dv:2081/9940.)
    if (r.m_broadcast) {
        // Mid-DATA-reception: don't abandon the in-flight RX to chase a channel overhear. SF-gating keeps us off
        // the control SF while _active->_pending_rx (so normally unreachable), but guard defensively — retuning here would
        // clobber the awaited DATA, and a fresh flood-state created without a resolving retune would leak the slot.
        // The flood/M-broadcast is best-effort + repair-backstopped, so skipping it while busy is safe.
        if (_active->_pending_rx) return;
        if (r.flood) {                                       // FLOOD RTS-M (§4.2): dedup/merge/create state, then catch the DATA-M
            // COUPLE create->resolve (§8 note): only a participant ALLOCS a flood-state — else the state is
            // created but the retune that resolves it is skipped and nothing ever frees it (the gateway-leak
            // bug). Gate the whole flood handling on the SAME condition as the retune. §7 CONSUMER half: a
            // gateway+owner participates (catches the DATA-M for its owner); a pure bridge (gateway_only) +
            // a data-incapable node (no data SF) stay out.
            // §mobile 6.3: a static / non-team node does NOT participate in a TEAM channel flood (mobile_src) — no flood-state,
            // no re-flood, no retune. Keeps team traffic off the static plane. s18 has no mobile_src floods -> byte-identical.
            // §mobile ACCEPTED RESIDUAL (separation): a DIFFERENT-team member (team_id!=0) can't tell WHOSE team a mobile_src
            // RTS-M is (the RTS carries no team_id — only the DATA-M does) so it DOES alloc a flood-state + may fast-pull. But
            // ingest_channel_m team-gates the DATA-M (node_channel.cpp:191: a foreign team_id DROPS it + FREES the flood-state)
            // -> NO cross-team delivery/re-flood; the only residual is a transient foreign CHANNEL_PULL (airtime). A full fix
            // needs team_id on the RTS-M (a wire change) — deferred; the delivery-level separation already holds.
            if (!(_cfg.is_gateway && _cfg.gateway_only) && _cfg.n_layers != 2 && _cfg.allowed_sf_bitmap != 0
                && !(r.mobile_src && _cfg.team_id == 0)
                && !(_cfg.is_mobile && !r.mobile_src && !mobile_registered())) {   // §S7 T-B: an OFF-GRID mobile does NOT catch/ingest a LEAF/static flood (mobile_src==0). A REGISTERED mobile (a leaf citizen) DOES (it ingests, never re-floods — flood_forward_decision). A team flood (mobile_src==1) is gated above.
                auto fbm = rts_flood_bitmap(std::span<const uint8_t>(bytes, len), r);
                if (fbm.size() == 32) {
                    const int16_t snr_q4 = protocol::db_to_q4(meta.snr_db);
                    const bool fresh = handle_flood_rts(r, fbm.data(), snr_q4);
                    if (fresh) {                              // §4.2 step 3: retune to catch the DATA-M for a FRESH state
                        const uint8_t data_sf = select_data_sf(r.sf_index, snr_q4);
                        _hal.set_rx_sf(data_sf);
                        // The data-SF frame is the lean M frame: payload_len carries its BODY length, +M_FRAME_HDR_LEN
                        // (7) = the full on-air M frame (was +13 = the old DATA-M header). Sizing it short retunes
                        // back before the M frame's RX_DONE -> drop_sf_mismatch. +30 ideal margin + the metal slop.
                        // §mobile 6.3: a TEAM M-frame (mobile_src is the exact proxy — set IFF the frame is team-scoped)
                        // is +4 B (the team_id tail, M_FRAME_TEAM_HDR_LEN=11) -> size the window for it or the frame is
                        // dropped at data SF>=10 (the +4 B airtime exceeds the 30 ms margin).
                        const uint16_t m_hdr = r.mobile_src ? M_FRAME_TEAM_HDR_LEN : M_FRAME_HDR_LEN;
                        // ✔ §rts-cr-overhear (2026-07-27) — CONVERTED. This is an OVERHEARER's retune window for
                        // the SENDER's M frame, so the CR that sizes it is the sender's, not ours: rts_cr_decode
                        // (r.cr_adv), the same datum start_pending_rx_expiry consumes off PendingRx. With
                        // active_cr() an overhearer at cr5 retuned back BEFORE a cr8 sender's M frame finished
                        // (up to 1.6x on the payload term) and lost it to drop_sf_mismatch — the same defect that
                        // cost s32 26 data_rx_timeouts, just on the channel plane instead of the DM plane.
                        // ★ MEASURED in s33_mixed_cr_channel_overhear (cr8 gateway leaves 119/120 flood to cr5
                        // leaves): channel_msg_received 26 -> 35, channel_msg_overheard 17 -> 26, and because
                        // the overhearers now CATCH those 9 frames, channel_pull_sent 10 -> 1 — nine repair
                        // pulls that no longer have to happen, plus the contention they cost (tx_lbt_defer
                        // 17 -> 7, collision 8 -> 4). Reverting THIS ONE LINE to active_cr() puts every one of
                        // those counters back, so the win is attributable here and nowhere else. Before s33
                        // existed the site was unvalidatable, which is why §rts-cr deferred it. Twin below.
                        const uint32_t back = protocol::cts_to_data_gap_ms
                            + airtime_ms(data_sf, active_bw_hz(), rts_cr_decode(r.cr_adv), protocol::preamble_sym,
                                         static_cast<uint16_t>(r.payload_len + m_hdr)) + 30 + _hal.rx_window_slop_ms(data_sf);
                        (void)_hal.after(back, kOverhearRetuneTimerId);
                        MR_EMIT("channel_overhear_armed", EF_I("sender", r.src), EF_I("chosen_data_sf", data_sf), EF_B("flood", true));
                        // Part B YIELD (spec 2026-06-28): we retuned to grab a NEW flood while awaiting our CTS -> our
                        // next-hop likely retuned for it too, so the CTS won't arrive until the flood clears. Push our
                        // CTS-timeout past it (no retry burned) -> catch the channel msg AND keep the DM retry, instead
                        // of today's "miss the CTS on the wrong SF -> timeout -> burn a retry" with the flood caught anyway.
                        // §rts-cr-overhear: nav_duration_cts is used here only as a DATA+ACK duration estimator
                        // and the frame being estimated is THIS FLOOD's M frame, whose sender advertised its CR
                        // in the RTS we are holding. So — unlike the two genuine overheard-CTS callers — this
                        // one CAN state the peer's CR, and does. (This caller is why the CR is a parameter of
                        // nav_duration_cts rather than a hardcoded active_cr() inside it.)
                        // ⚠ CURRENTLY UNREACHABLE, and that is the honest coverage statement: the guard's first
                        // term is the compile-time constant protocol::flood_yield_grab_enable == 0 (Part B was
                        // shipped OFF — "UNTESTED, twin has no floods"). A poison probe here moves 0/30 and the
                        // corpus emits ZERO reserve_yield events. So this conversion is correct-by-inspection
                        // and inert today; it becomes live the day Part B is enabled. Nothing tests it.
                        if (protocol::flood_yield_grab_enable && _active->_pending_tx && _active->_pending_tx->awaiting_cts)
                            reserve_yield(nav_duration_cts(data_sf, static_cast<uint8_t>(protocol::reserve_est_payload_bytes),
                                                           rts_cr_decode(r.cr_adv)));
                    }
                }
            }
            return;                                          // FLOOD RTS never CTSes
        }
        if (!(_cfg.is_gateway && _cfg.gateway_only) && _cfg.n_layers != 2 && !channel_have_id_lo16(r.m_payload_id_lo16)
            && !(r.mobile_src && _cfg.team_id == 0)
            && !(_cfg.is_mobile && !r.mobile_src && !mobile_registered())) {   // §S7 T-B: an OFF-GRID mobile does not overhear a LEAF pull-response either (not a leaf member); §mobile 6.3: a static / non-team node does not overhear a TEAM pull-response (mobile_src) — §7 consumer / Principle 11: a dual-layer gateway never overhears a channel pull-response

            const uint8_t data_sf = select_data_sf(r.sf_index, protocol::db_to_q4(meta.snr_db));
            _hal.set_rx_sf(data_sf);
            // Stay on the data SF until the M frame lands: gap (RTS->DATA) + the FULL M-frame airtime
            // (r.payload_len carries the BODY length; +M_FRAME_HDR_LEN (7) covers the M header) + margin.
            // Sizing it short retunes back ~one header's airtime too early -> the M frame is dropped
            // (drop_sf_mismatch). The +30 is the sim's ideal margin; rx_window_slop_ms adds the REAL metal
            // RX_DONE/SPI turnaround (ZERO on the sim; the same slop start_pending_rx_expiry carries).
            const uint16_t m_hdr = r.mobile_src ? M_FRAME_TEAM_HDR_LEN : M_FRAME_HDR_LEN;   // §mobile 6.3: a team M-frame is +4 B (team_id tail) — size for it or it drops at data SF>=10
            // ✔ §rts-cr-overhear — the twin of the FLOOD retune above, converted with it: the M frame is the
            // SENDER's, so it is sized at the sender's advertised CR. ⚠ COVERAGE IS WEAKER HERE THAN AT THE
            // TWIN, and measured 2026-07-27 rather than assumed. This line EXECUTES ~676x corpus-wide (s15,
            // s15_metal, s17, sim_9node_base) — a poison probe here moves 5/30 scenarios — but EVERY one of
            // those senders is cr5, so the conversion is value-inert: reverting this site alone to active_cr()
            // moves NOTHING. Even s33, the mixed-CR channel scenario, reaches the FLOOD twin 28x and this site
            // exactly ONCE, from a cr5 sender. ⇒ the ONLY regression detector for the mixed-CR behaviour is
            // the native test "§rts-cr-overhear: the M_BROADCAST retune window is sized for the SENDER's CR".
            // OWED: a scenario in which a cr8 node answers a CHANNEL_PULL (an M_BROADCAST RTS-M, not a flood).
            const uint32_t back = protocol::cts_to_data_gap_ms
                + airtime_ms(data_sf, active_bw_hz(), rts_cr_decode(r.cr_adv), protocol::preamble_sym,
                             static_cast<uint16_t>(r.payload_len + m_hdr)) + 30 + _hal.rx_window_slop_ms(data_sf);
            (void)_hal.after(back, kOverhearRetuneTimerId);
            MR_EMIT("channel_overhear_armed", EF_I("id_lo16", r.m_payload_id_lo16), EF_I("sender", r.src), EF_I("target", r.next),
                    EF_I("chosen_data_sf", data_sf),        // chosen_data_sf = the advertised SF we retuned to (t69)
                    EF_I("guard_ms", static_cast<int64_t>(back)),
                    EF_B("addressed", (r.next == _node_id && ((r.addr_len == 1) == _cfg.is_mobile))));   // §mobile 3b: mark-aware addressed
        }
        return;                                          // M_BROADCAST RTS never CTSes
    }
    // ★★★★ §hybrid-rts S2 (2026-08-08) — THE WIRE DECLARATION SELECTS WHICH RECEIVER-RELATIVE TARGET MUST HOLD.
    // `rts_wire_team_plane(r)` = `(addr_len == 1 && mobile_src)` is what the SENDER said this flight's plane is
    // (frame_codec.h). The two predicates above are receiver-relative ADDRESS admission and say nothing about the
    // plane. Design §4.3: wire TEAM ⇒ `team_addr_for_us` must be true; wire STATIC/GLOBAL ⇒ `for_static_rts` must
    // be true. Anything else is not addressed to us and takes the ordinary OVERHEAR path below (NAV-armed, no CTS,
    // no PendingRx) — ⛔ NOT a malformed-frame drop: "an overheard frame is not malformed merely because
    // `team_addr_for_us` is false; the receiver is not its addressee."
    // ★★ THE CASE THIS EXISTS FOR, and it is a REAL frame, not a hypothetical: a host's `(1, 0)` last-mile to a
    // hosted mobile satisfies BOTH targets at a team-member mobile whose hosted local id equals its
    // `_team_local_id` (the §18 one-numeric-space collision). The pre-S2 OR-admission then let the TEAM reading
    // win the CTS's `tx_id` and would have let it into the stored plane. The wire says STATIC, and the wire is the
    // only party that knows: `team_addr_for_us` never consults `mobile_src`.
    // ⇒ STATIC REDUCTION, so the immovability is checkable rather than asserted: with `team_id == 0` (every static
    //   node) and on the three `MR_FEAT_TEAM 0` gateway envs, `for_team_rts` is CONSTANT FALSE, so
    //   `addressed_for_us == (wire_team ? false : for_static_rts)`. A `wire_team` frame was therefore never
    //   admitted on those builds either (`for_static_rts` needs `(addr_len==1) == is_mobile`, and a static node is
    //   not mobile), so this predicate is byte-identical there.
    if (!addressed_for_us) {   // else overheard
        // NAV (virtual carrier sense): an overheard UNICAST RTS reserves the medium for the rest of the
        // exchange (CTS+DATA+ACK) — M_BROADCAST already returned above, so this is unicast. Defer own
        // unsolicited TX until then (tx_initiating/tx_flood) so we don't step on the CTS in the silent gap.
        if (_cfg.nav_enabled) {
            const uint8_t nav_sf = (r.sf_index <= 2)
                ? select_data_sf(r.sf_index, protocol::db_to_q4(meta.snr_db))   // pinned singleton -> the exact data SF
                : max_data_sf();                                                // ANY(3) -> conservative (the receiver picks)
            // §rts-cr-overhear: the reserved DATA is the RTS SENDER's, so size it at the CR it advertised.
            // Coverage: HEAVILY executed (a poison probe here moves 14/30 scenarios) but VALUE-inert on the
            // corpus — every unicast RTS a scenario overhears comes from a cr5 sender, so reverting this to
            // active_cr() moves nothing. The mixed-CR behaviour rests on the native test
            // "§rts-cr-overhear: the NAV reservation from an overheard RTS uses the SENDER's CR".
            nav_arm(nav_duration_rts(nav_sf, r.payload_len, rts_cr_decode(r.cr_adv)));
        }
        // Part A YIELD (spec 2026-06-28): the overheard RTS TARGETS our next-hop -> it's about to be occupied -> our
        // CTS/ACK can't come. Push our pending timeout past the reserve (max-SF est, LBT-backstopped), no retry burned.
        if (protocol::reserve_yield_enable && _active->_pending_tx
            && (_active->_pending_tx->awaiting_cts || _active->_pending_tx->awaiting_ack)
            && r.next == _active->_pending_tx->next)
            // §rts-cr-overhear: same exchange, same sender -> the same advertised CR sizes the estimate.
            // ⚠ UNREACHABLE TODAY, same as the flood-yield twin: reserve_yield_enable is the compile-time
            // constant 0 (Part A shipped off). Poison probe moves 0/30; zero reserve_yield events corpus-wide.
            reserve_yield(nav_duration_rts(max_data_sf(), static_cast<uint8_t>(protocol::reserve_est_payload_bytes),
                                           rts_cr_decode(r.cr_adv)));
        return;
    }
    // NAV: virtually busy under someone else's reservation -> (optionally) ignore this (new) addressed RTS;
    // the requester is a hidden node that didn't hear the reservation and will time out + retry. Tunable
    // (nav_ignore_rts): dropping it protects the reservation but causes the requester to cascade/give up.
    if (_cfg.nav_enabled && _cfg.nav_ignore_rts && _hal.now() < _nav_until_ms) return;
    MR_EMIT("rts_rx", EF_I("from", r.src), EF_I("dst", r.dst));

    // ★★★★ §B153 (2026-08-08) — THE RTS-TIME `already_received` SHORT-CIRCUIT IS GONE, AND IT IS NOT COMING BACK.
    // What stood here looked up `_last_acked_from` and, on a hit inside a 10 s TTL, answered
    // `CTS already_received = 1`. `handle_cts` treats that as DELIVERED: `_pending_tx.reset(); become_free();
    // return;` — no DATA, no emit, no `send_failed`. So a wrong answer here DISCARDS A MESSAGE IN SILENCE.
    //
    // ★★★ WHY NO KEY CAN FIX IT — THE ARGUMENT IS INFORMATION-THEORETIC, NOT A TUNING MATTER.
    // **A 7-byte RTS cannot distinguish (a) a RETRY of message A from (b) the FIRST ATTEMPT of message B that
    // shares the same `(hop src, dst, ctr_lo, payload_len)`. Those two frames are BYTE-IDENTICAL.** ⇒ no amount
    // of receiver state and no cleverer matching can return a safe TERMINAL verdict from that frame, because the
    // information simply is not in it. ⛔ The first fix attempt widened the RTS with a 4-B `flight_id` tail; that
    // "works" only by changing the frame — and the frame never needed to carry it, because the DATA already does.
    // ★★ **THE PRINCIPLE, STATED HERE BECAUSE IT IS THE DURABLE LESSON: RTS AUTHORIZES RECEPTION; ONLY DATA
    // PROVES MESSAGE IDENTITY.** It is the sharp form of this arc's recurring error — [[B142]], [[B133]],
    // [[B147]], [[B153]] — *a terminal decision made from evidence that could not support it*.
    // ⇒ A FREE RECEIVER NOW ALWAYS: creates `PendingRx`, returns a normal CTS, and waits for the DATA.
    //
    // WHERE THE AUTHORITY LIVES INSTEAD (and it was already there, doing the real work): `handle_data`'s
    // `_seen_origins` dedup, keyed on the CANONICAL identity — the full `(origin, dst, ctr)` with all 16 bits of
    // `ctr`, or the whole 8-B cleartext nonce-seed for a CRYPTED flight. Fresh DATA -> ACK + deliver/forward +
    // record. Same message, SAME prev-hop (the real lost-ACK case) -> ACK only, and it RETURNS BEFORE
    // `_post_ack` is set, so there is no second delivery and no second forward. Same message, DIFFERENT
    // prev-hop -> the existing LOOP_DUP NACK. ⓘ Its TTL is `seen_origin_ttl_ms`, so the replacement is strictly
    // MORE durable than the 10 s window this gate had.
    // ⚠ THIS LINE READ "= 30 s, THREE TIMES the 10 s window" until [[B159]] (2026-08-28), and the arithmetic was
    // right while the CONCLUSION was wrong: 30 s beat the retired 10 s gate but sat FAR BELOW the retry horizons
    // that actually reach this dedup (cascade 80 s, gateway doorstep 150 s), so a retry arriving in between
    // delivered to the app a SECOND time. The TTL is now DERIVED from the longest of those horizons — see
    // `seen_origin_ttl_ms` in protocol_constants.h, declared beside `completed_flight_cache_ttl_ms` because both
    // answer the same retry question. ⛔ Never re-spell it as a literal.
    // ⓘ COST, so nobody re-adds the bit as an "optimization": successful traffic is UNCHANGED
    // (RTS -> CTS -> DATA -> ACK, 7-B RTS). Only lost-ACK recovery pays, and it pays ONE redundant DATA —
    // after an ACK was actually lost — instead of every hop of every message risking a wrong terminal answer.
    //
    // ⚠⚠ SUPERSEDED IN PART BY §hybrid-rts S2 (2026-08-08), AND THE ARGUMENT ABOVE IS STILL EXACTLY RIGHT ABOUT
    // THE FRAME IT WAS WRITTEN ABOUT. What changed is the PREMISE, not the reasoning: the unicast RTS is no longer
    // 7 bytes. It is 10 B (plaintext `origin|ctr_hi|ctr_lo`) or 11 B (crypted `BLAKE2b-512(...)[:4]`) and CARRIES
    // the canonical flight identity, so "a retry of A" and "a first attempt of B" are no longer byte-identical
    // frames. The gate restored immediately below is therefore keyed on evidence the old frame did not contain.
    // ⛔ WHAT IS **NOT** RESTORED, ever: a terminal answer derived from `(src, dst, ctr_lo, payload_len)`. The
    //    cache key is the FULL identity + domain + the wire plane + the immediate sender + dst, and `payload_len`
    //    is deliberately absent from it (it is a NAV/consistency field — design §2.4).
    // ★ AND THE TERMINAL ANSWER IS NOW BINDABLE AT THE SENDER: it echoes the complete identity + plane (6 B
    //   plaintext / 7 B crypted), and `handle_cts` refuses to act on one whose echo does not match its CURRENT
    //   flight — so a delayed/stashed terminal CTS for flight A can no longer clear a newer flight B (design §2.3).
    if (const CompletedFlight* cf = completed_flight_find(r.src, r.dst, wire_team, r.id, _hal.now())) {
        cts_in cin{};
        cin.already_received = true;              // TERMINAL: no DATA follows, no PendingRx is allocated
        cin.id               = cf->id;            // the COMPLETE echo — the sender binds on this, not on endpoints
        cin.team_plane       = cf->team_plane;    // the WIRE plane we stored, echoed back
        cin.tx_id            = wire_team ? team_local_id() : _node_id;
        cin.rx_id            = r.src;
        cin.payload_len      = 0;                 // pack_cts REFUSES a NAV hint on this shape (nothing follows)
        cin.chosen_data_sf   = 0;                 // no SF exists on the terminal shape (parse_cts returns 0)
        uint8_t cbuf[7]; const size_t cl = pack_cts(cin, std::span<uint8_t>(cbuf, sizeof cbuf));
        if (cl != 0) {
            tx_with_retry(cbuf, cl, static_cast<int16_t>(_cfg.routing_sf), FrameTag::cts);
            MR_EMIT("cts_tx", EF_I("to", r.src), EF_B("already_received", true),
                    EF_I("id_width", cf->id.width), EF_B("team_plane", cf->team_plane));
            return;
        }
        // pack refused -> fall through to ordinary admission rather than answer nothing (fail loud, not silent).
        MR_EMIT("cts_terminal_pack_failed", EF_I("to", r.src), EF_I("id_width", cf->id.width));
    }
    // A retried RTS for the SAME flight while we still await its DATA -> re-CTS + restart
    // the expiry (dv_dual_sf.lua:218 CTS-dup) so the sender's retry gets a fresh CTS.
    // ★ §B153 — THIS BRANCH IS DELIBERATELY KEPT, AND WHAT MAKES THAT LEGITIMATE IS THAT IT IS **NOT TERMINAL**.
    // It only reissues a CTS (`already_received = false`) and restarts the DATA-wait: the sender must still send
    // the DATA, and the DATA-level dedup still adjudicates identity. So the worst case of a WRONG match here is a
    // re-CTS carrying the other flight's `chosen_data_sf` plus a restarted expiry — costing a retry, never a
    // message — whereas the block deleted above could destroy one. That asymmetry is the whole distinction.
    // ⇒ `payload_len` IS INCLUDED in the match: it is the end-to-end inner+MAC length, forwarded unchanged, so it
    // cheaply separates most colliding `ctr_lo` values. ⛔ It is NOT an identity check and must never be
    // described as one — it cannot be (see the argument above); it is a cheap filter on a non-terminal fast path.
    // ✖ THE CONSERVATIVE ALTERNATIVE WAS CONSIDERED AND REJECTED, not overlooked: drop the branch and let the
    // "busy with a DIFFERENT flight" BUSY_RX NACK below answer every retried RTS. Strictly worse here — a NORMAL
    // lost-CTS retry (exactly the case this branch exists for) would be answered with a CONGESTION verdict,
    // pushing the sender into backoff/cascade against a receiver that is in fact holding its own reception for
    // it. Keeping a non-terminal fast path costs nothing that can lose data.
    // ★★★★ §hybrid-rts S2 — THE MATCH IS UNCHANGED AND THE STORED IDENTITY IS **REFRESHED FROM THIS RTS**, and
    // that refresh is LOAD-BEARING, not tidiness. Without it S2 would convert this branch's documented worst case
    // ("costing a retry, never a message") into a LOST MESSAGE, which is the exact class this arc exists to remove:
    // a sender is single-slot stop-and-wait, so it can only RTS for flight B after flight A's own attempt died at
    // its end. If B's RTS lands here (same `from`/`dst`/`ctr_lo`/`payload_len`, DIFFERENT identity) we restart the
    // DATA-wait for B — so the identity we then VALIDATE B's DATA against must be B's. Keeping A's would drop B at
    // `handle_data`, un-ACKed, for as long as A's stale reservation lived.
    // ⇒ THE INVARIANT THIS PRESERVES: the reservation always awaits the identity most recently advertised on it.
    // ⚠ RESIDUAL, STATED NOT HIDDEN: `chosen_data_sf`, `payload_len`, `mobile_from` and `sender_cr` are still NOT
    //   refreshed here. That is PRE-EXISTING (the branch has always answered with the first flight's chosen SF) and
    //   is left alone under C1 — it costs a retry, never a message, which is the property this branch is allowed to
    //   have. The identity is different: it is the one field a stale value turns into a DROP.
    if (_active->_pending_rx && _active->_pending_rx->from == r.src && _active->_pending_rx->dst == r.dst &&
        _active->_pending_rx->ctr_lo == r.ctr_lo && _active->_pending_rx->payload_len == r.payload_len) {
        _active->_pending_rx->id              = r.id;        // await the identity THIS RTS advertised (see above)
        _active->_pending_rx->wire_team_plane = wire_team;   // ... and the plane it declared, or DATA validation would contradict it
        cts_in cin{}; cin.chosen_data_sf = _active->_pending_rx->chosen_data_sf;
        cin.already_received = false; cin.tx_id = wire_team ? team_local_id() : _node_id; cin.rx_id = r.src;
        cin.payload_len = _cfg.nav_enabled ? r.payload_len : 0;   // NAV: size the overhearer's DATA reservation
        cin.cr_adv      = r.cr_adv;   // §cts-len6-cr2: forward the RTS sender's advertised CR into byte 3's cr2 half
        uint8_t cbuf[4]; const size_t cl = pack_cts(cin, std::span<uint8_t>(cbuf, sizeof cbuf));
        tx_with_retry(cbuf, cl, static_cast<int16_t>(_cfg.routing_sf), FrameTag::cts);   // R4.5b
        MR_EMIT("cts_tx", EF_I("to", r.src), EF_B("dup", true));
        start_pending_rx_expiry(_active->_pending_rx->payload_len);
        return;
    }
    // Busy with a DIFFERENT flight. If we hold a pending_rx (receiving someone else's
    // DATA), NACK the sender with how-long-busy so it waits/requeues instead of
    // grinding rts_timeout (dv:9934). If we hold a pending_tx (sending our own), STAY
    // SILENT (dv:9962 — the busy_for estimate lied for ACK-loss-stuck nodes).
    if (_active->_pending_rx) {
        const uint64_t now = _hal.now();
        uint64_t busy_for = (_active->_pending_rx->expiry_ms > now) ? (_active->_pending_rx->expiry_ms - now) : 0;
        if (busy_for > 65535) busy_for = 65535;
        const uint32_t q = (static_cast<uint32_t>(busy_for) + protocol::nack_busy_quantum_ms - 1)
                           / protocol::nack_busy_quantum_ms;                    // ceil
        nack_in nin{}; nin.reason = protocol::nack_reason_busy_rx; nin.ctr_lo = r.ctr_lo;
        nin.payload = static_cast<uint8_t>(q > 255 ? 255 : q); nin.to = r.src; nin.mobile_to = r.mobile_src;   // §mobile: a mobile/team RTS's src is a LOCAL id -> mark the NACK
        uint8_t nbuf[4]; const size_t nl = pack_nack(nin, std::span<uint8_t>(nbuf, 4));
        MR_EMIT("nack_tx", EF_I("to", r.src), EF_I("reason", protocol::nack_reason_busy_rx),
                EF_I("busy_ms", static_cast<int64_t>(busy_for)));
        tx_initiating(nbuf, nl, static_cast<int16_t>(_cfg.routing_sf), LbtKind::nack, 0);   // R4.5 LBT (handle_rts NACK, dv:9953)
        return;
    }
    if (_active->_pending_tx) {                                   // sending our own -> silent (no NACK)
        MR_EMIT("rts_drop_pending_tx", EF_I("from", r.src));
        return;
    }

    // R4.4 anti-spam DROP (Inc 1+2): if this sender's overheard airtime over the window exceeds
    // originator_airtime_share of our duty budget, silently drop the RTS — no CTS, no NACK. Relay
    // forwards are exempt. Keyed on the decoded RTS src (frame-derived, metal-correct — NOT src_hint,
    // which is -1 on hardware). The airtime BACKSTOP is gated on a real budget: with duty disabled
    // (budget 0) there is no SHARE to enforce, so skip it (matches compute_budget_tier / check_duty_cycle).
    // R-C apparent-origination COUNT clause REMOVED (Inc 1): a missed CTS makes a forwarder look like an
    // originator -> 168 false-drops on s18; the airtime backstop is the robust half (honesty- and
    // CTS-loss-independent). app_orig/rts/cts kept as info-only emit fields.
    // e2e-ack backstop exemption (2026-07-02): an RTS marked RTS_FLAG_E2E_ACK (its pending DATA is a DATA_TYPE_E2E_ACK)
    // skips the DROP — an ack must never be throttled (a throttled ack -> the sender never learns delivery -> re-send ->
    // MORE traffic). It is still OBSERVED at :40 (honest airtime metric, no bypass). Anti-spoof: a sender caught faking
    // the bit (DATA-time verify below) is flagged (e2e_ack_spoofer_flagged) and its exemption revoked for a whole window.
    // The hard duty-cycle limit still binds the sender's own ack originations (the un-spoofable ceiling).
    const bool e2e_ack_exempt = (r.rts_flags & RTS_FLAG_E2E_ACK) && !e2e_ack_spoofer_flagged(r.src);
    if (!(r.rts_flags & RTS_FLAG_RELAY) && !e2e_ack_exempt) {
        int app_orig; uint32_t total_air; uint8_t rts_n, cts_n;
        compute_originator_metric(r.src, app_orig, total_air, rts_n, cts_n);
        const uint32_t airtime_cap = static_cast<uint32_t>(
            static_cast<double>(protocol::originator_airtime_share) * _duty_cycle_budget_ms);   // floor
        const bool over_airtime = (_duty_cycle_budget_ms > 0) && (total_air > airtime_cap);
        // WARN band (Inc 2): airtime in [warn_fraction x cap, cap) -> flag, don't drop. Inc 3 carries this
        // to the sender in the ACK warn bit so an honest node backs off before the hard cap. Emitted here
        // for calibration (how close legit traffic comes to the cap).
        const uint32_t airtime_warn = static_cast<uint32_t>(
            static_cast<double>(protocol::originator_airtime_warn_fraction) * airtime_cap);
        if (_duty_cycle_budget_ms > 0 && !over_airtime && total_air > airtime_warn) {
            MR_EMIT("rts_originator_airtime_warn", EF_I("from", r.src), EF_I("ctr_lo", r.ctr_lo),
                    EF_I("airtime_ms", static_cast<int64_t>(total_air)), EF_I("warn_airtime_ms", static_cast<int64_t>(airtime_warn)),
                    EF_I("threshold_airtime_ms", static_cast<int64_t>(airtime_cap)), EF_I("window_ms", protocol::originator_window_ms));
        }
        if (over_airtime) {
            MR_EMIT("rts_drop_originator_throttle", EF_I("from", r.src), EF_I("ctr_lo", r.ctr_lo), EF_I("apparent_origination", app_orig),
                    EF_I("airtime_ms", static_cast<int64_t>(total_air)), EF_I("rts_count", rts_n), EF_I("cts_count", cts_n),
                    EF_I("threshold_count", _cfg.originator_max_per_window),
                    EF_I("threshold_airtime_ms", static_cast<int64_t>(airtime_cap)), EF_I("window_ms", protocol::originator_window_ms));
            return;                                       // silent drop (no CTS, no NACK)
        }
    }
    // R4.1 budget-aware NACK (Lua dv:10016-10044): if OUR duty budget is >=CRITICAL we likely
    // can't carry this flight to completion (CTS+DATA-RX are free but the ACK + any forward cost
    // budget), so refuse early with a BUDGET NACK -> the sender reroutes via the blind machinery
    // instead of a full RTS-CTS-DATA-ACK that stalls mid-cycle. We still pay the small NACK
    // airtime but save the CTS+ACK round-trip. STRAINED still CTSes.
    const BudgetTier my_tier = compute_budget_tier();
    if (my_tier >= BudgetTier::critical) {
        nack_in nin{}; nin.reason = protocol::nack_reason_budget; nin.ctr_lo = r.ctr_lo;
        nin.payload = static_cast<uint8_t>((static_cast<uint8_t>(my_tier) & 0x0f) << 4);   // tier HIGH nibble
        nin.to = r.src; nin.mobile_to = r.mobile_src;   // §mobile: a mobile/team RTS's src is a LOCAL id -> mark the NACK
        uint8_t nbuf[4]; const size_t nl = pack_nack(nin, std::span<uint8_t>(nbuf, 4));
        MR_EMIT("nack_tx", EF_I("to", r.src), EF_I("reason", protocol::nack_reason_budget), EF_I("tier", static_cast<uint8_t>(my_tier)));
        tx_initiating(nbuf, nl, static_cast<int16_t>(_cfg.routing_sf), LbtKind::nack, 0);   // R4.5 LBT (handle_rts NACK, dv:10043)
        return;                                          // NO CTS, NO pending_rx
    }

    const uint8_t sf = select_data_sf(r.sf_index, protocol::db_to_q4(meta.snr_db));
    PendingRx prx{}; prx.from = r.src; prx.dst = r.dst; prx.ctr_lo = r.ctr_lo;
    prx.chosen_data_sf = sf; prx.payload_len = r.payload_len; prx.set_at_ms = _hal.now();
    prx.claimed_e2e_ack = (r.rts_flags & RTS_FLAG_E2E_ACK) != 0;   // carried to DATA-time for the anti-spoof verify
    prx.mobile_from = r.mobile_src;                               // §mobile: carry the mobile-src mark -> DATA-time learn skips a mobile local id (mirror the RTS learn guard :47)
    prx.sender_cr = rts_cr_decode(r.cr_adv);                      // §rts-cr: the SENDER's CR -> start_pending_rx_expiry sizes the DATA wait for the frame actually coming, not for our own CR
    // ★★★ §hybrid-rts S2 — the reservation records WHAT IT IS WAITING FOR. `r.id` is mandatory on an admitted
    // unicast RTS (parse_rts cannot produce one without it) and `wire_team` is the plane the SENDER declared, NOT
    // whichever of `for_static_rts`/`for_team_rts` matched — see the discriminator's note above.
    prx.id = r.id; prx.wire_team_plane = wire_team;
    _active->_pending_rx = prx;
    start_pending_rx_expiry(r.payload_len);
    cts_in cin{}; cin.chosen_data_sf = sf; cin.already_received = false; cin.tx_id = wire_team ? team_local_id() : _node_id; cin.rx_id = r.src;
    cin.payload_len = _cfg.nav_enabled ? r.payload_len : 0;   // NAV: size the overhearer's DATA reservation
    // ✔ §cts-len6-cr2 — PURE FORWARDING of a datum already in hand: §rts-cr put the sender's CR in the RTS and
    // we are holding that parsed RTS, so the CTS can hand it to overhearers who never heard the RTS at all.
    // r.payload_len here is the DM quantity (inner+MAC, node_mac.cpp tx_rts) — the M_BROADCAST/FLOOD quantity
    // (inner_len-6) can NEVER reach a CTS: every path through `if (r.m_broadcast)` above returns.
    cin.cr_adv      = r.cr_adv;
    uint8_t cbuf[4]; const size_t cl = pack_cts(cin, std::span<uint8_t>(cbuf, sizeof cbuf));
    tx_with_retry(cbuf, cl, static_cast<int16_t>(_cfg.routing_sf), FrameTag::cts);   // R4.5b: stash + tag the CTS
    MR_EMIT("cts_tx", EF_I("to", r.src), EF_I("sf", sf));
    _hal.set_rx_sf(sf);                                  // NOW retune RX to hear the DATA on the data SF
}

void Node::handle_cts(const uint8_t* bytes, size_t len, const RxMeta& meta) {
    auto pc = parse_cts(std::span<const uint8_t>(bytes, len));
    if (!pc) return;
    const cts_out& c = *pc;
    // ★ §hybrid-rts S2b (2026-08-09) — THE LEDGER BILLS THE CTS **FRAME ITSELF**, so its length must be the shape
    // that was actually aired. `id.width` IS the frame's own length discriminator (`parse_cts` sets width = n - 3),
    // so this is ONE derivation off the parsed frame — NOT a second guess at the domain (the S2 second-derivation
    // defect). ⚠ THE ORDINARY ARM DELIBERATELY STAYS the Lua CTS_LEN=4 timing constant, unchanged: it is a
    // parity constant, the 4th byte is optional and a 4-B frame with b3==0 is indistinguishable from a 3-B one,
    // and re-pricing it would move every CTS-bearing stream for a reason unrelated to this slice (C1).
    const uint16_t cts_air_len = c.already_received ? static_cast<uint16_t>(3u + c.id.width) : 4u;
    // ★★ §hybrid-rts S2c/S2d — THE PLANE GUARD ON THE METER, **HOISTED SO THERE IS ONE DERIVATION OF IT** and read
    // by ALL THREE billing sites (the pure-overhear terminal arm ①, the invalid-terminal arm at ③, and the ordinary
    // meter further down). WHAT IT ANSWERS, and the only thing it answers: **is `c.tx_id` a LOCAL id?** The ledger is
    // keyed by GLOBAL id, so billing a local id charges an unrelated global node — and the metric feeds
    // originator-drop, so mis-attribution can drop an innocent peer's traffic. Not a trust decision (see the ⚖ note
    // in the gate below); purely "is this id in the ledger's namespace".
    //
    // ★★★ §hybrid-rts S2d (2026-08-09) — **THE TWO ARMS DIFFER BECAUSE THE TWO FRAME SHAPES DIFFER: ONE STATES ITS
    // PLANE ON THE WIRE, THE OTHER DOES NOT.** ⛔ Do not collapse them.
    //   • TERMINAL (`already_received`): the frame CARRIES its plane — `CTS_TERM_PLANE_BIT`, byte-0 bit 3, set by
    //     `pack_cts` from `cin.team_plane` and recovered by `parse_cts` into `c.team_plane`. At the producer
    //     (handle_rts, the `completed_flight_find` branch above) `cin.tx_id = wire_team ? team_local_id() : _node_id`
    //     while `cin.team_plane = cf->team_plane`, and `completed_flight_find` matched on `wire_team` ⇒
    //     `cf->team_plane == wire_team`. So on this shape `c.team_plane == 1` **IFF** `c.tx_id` is a team-local id:
    //     the bit IS the answer to this question, exactly, stated by the node that chose the id. ⇒ READ IT.
    //   • ORDINARY: those same three bits are (sf-5). There is NO plane bit on that shape (frames.md, CTS-by-context)
    //     ⇒ local pending state is the only evidence in existence, so it must be inferred. Retained verbatim.
    //
    // ⚠⚠ WHY THIS IS THE FIX AND NOT A TIDY-UP — S2c used the pending-state inference for BOTH shapes and was wrong
    // three ways on the terminal one: it billed a team-local id as a global peer whenever **no flight was pending**
    // (the REACHABLE case — both corpus-billed terminal frames have no pending flight); it SKIPPED billing a static
    // terminal CTS merely because an unrelated TEAM flight happened to be pending; and its comment claimed the frame
    // carries no plane mark, which is false for this shape and is corrected here and at ① below.
    // ★★★ THE LINEAGE, because this is the arc's signature error and the reusable part: **inferring from local state
    // what the wire already declares** — [[B142]] (`LbtKind` alone), [[B147]] (hash alone), [[B153]]/[[B157]] (a
    // terminal verdict from ambiguous bytes), S2's own "store the WIRE plane, never whichever predicate matched",
    // and now the meter. When a frame states a fact, READ THE FRAME.
    //
    // ⓘ HOIST SAFETY (unchanged from S2c): pure reads of state nothing between here and the meter mutates — the
    // terminal gate writes nothing, and the §mobile refresh touches `_my_mobile_reg`, not `_pending_tx` ⇒
    // value-identical to computing it at each site.
    const bool cts_tx_id_is_local = c.already_received
        ? c.team_plane                                            // the WIRE says so — one bit, one meaning
        : (for_me_dst(c.rx_id) && _active->_pending_tx
           && next_is_local_id(_active->_pending_tx->addr_len, _active->_pending_tx->next));
    // ★★★★★ §hybrid-rts S2b (2026-08-09) — **THE TERMINAL SHAPE IS GATED HERE, BEFORE EVERY SIDE EFFECT.**
    // S2 landed the identity check but left it BELOW the home-liveness refresh and the anti-spam meter, so a
    // terminal CTS that FAILED its identity check had already refreshed home liveness and metered the ledger.
    // ⚠⚠ THAT IS THIS ARC'S SIGNATURE ERROR FOR THE THIRD TIME — [[B147]], [[B153]], and now here: **a terminal
    // decision acting before the evidence that licenses it.** The ordering below is the fix and it is the point of
    // this block: ① is it about us · ② is there a flight this could possibly answer (pending + awaiting + the
    // next hop we RTS'd) · ③ does the identity and plane BIND · ④ only then may anything be refreshed,
    // learned, cancelled or cleared — which is the untouched tail further down that a validated frame falls into.
    // ⛔ DO NOT "simplify" this by moving any of ①②③ back below the refresh/learn.
    // ⚠⚠ §hybrid-rts S2c (2026-08-09) NARROWS S2b's own instruction: "hoist the bind above EVERY side effect" was
    // TOO BROAD. **The anti-spam AIRTIME METER is not a side effect of believing the frame** — see the ⚖ note at
    // ②③ below, which is where that distinction is stated and where an invalid terminal CTS is charged once.
    if (c.already_received) {
        // ① ★★ AN OVERHEARD TERMINAL CTS MUST NOT ARM NAV. A terminal CTS means **NO DATA FOLLOWS** — it is the
        //    receiver saying "I already have that flight". S2 let it take the ordinary overhear path, which armed
        //    NAV for a DATA+ACK exchange that will never exist. Worse than a small over-reserve: `parse_cts`
        //    zeroes the shape (`chosen_data_sf = 0`, `payload_len = 0`), and `payload_len == 0` is
        //    `nav_duration_cts`'s NO-HINT MAX-FRAME fallback ⇒ it asked for a full `lora_max_frame_bytes`
        //    reservation. (In practice `data_sf = 0` makes `airtime.cpp`'s `den` zero, which zeroes the payload
        //    term and floors the preamble to 0, so the false reservation that actually landed was
        //    `airtime_routing_ms(3) + 2*cts_to_data_gap_ms` — small, but reserved against nothing at all.)
        //    ⇒ no `nav_arm`, and no `reserve_yield` either: the CTS sender is NOT about to receive anyone's DATA.
        // ⓘ STILL METERED (design §2.3; §hybrid-rts S2c makes this the RULE for every terminal CTS, not an
        //    exception): it really did consume airtime, and an overhearer can never validate it — the frame is
        //    not addressed to us, so there is no flight of ours to bind it to. Metering is a THROTTLE, never a
        //    route/deliver decision. See the ⚖ note at ②③ for why accounting and trust part company here.
        // ★★ §hybrid-rts S2d (2026-08-09) — **AND IT IS BILLED PER THE PLANE THE FRAME DECLARES.** S2c's comment
        //    here recorded this as an unclosable residual on the grounds that "the CTS carries no mark" — TRUE of
        //    the ordinary shape, **FALSE of this one**: the terminal shape spends byte-0 bit 3 on exactly that mark.
        //    So an overhearer CAN tell, without any flight of its own, whether `c.tx_id` is a team-local id, and
        //    `cts_tx_id_is_local` (hoisted above) reads it. Unbindable ≠ unattributable: we still refuse to BELIEVE
        //    the frame, we merely decline to bill a local id into a global-keyed ledger.
        if (!for_me_dst(c.rx_id)) {
            if (!cts_tx_id_is_local)
                track_originator_observation(c.tx_id, /*kind=cts*/1, /*dedup_key=*/c.rx_id,
                                             static_cast<uint32_t>(airtime_routing_ms(cts_air_len)));
            return;
        }
        // ② A terminal answer with no flight to answer, or from a node that is not the next hop we RTS'd, is
        //    unbindable — and ③ THE BIND ITSELF is full-width and total, exactly as S2 built it (that part was
        //    sound): the identity's DOMAIN, its WIDTH, EVERY identity byte (`rts_flight_identity_equal` — the ONE
        //    comparator) and the wire-declared PLANE. The identity is RECOMPUTED from the pending flight's own
        //    canonical fields by `Node::flight_identity`, the ONE producer that `tx_rts_retry` also uses — no
        //    cached tag, and ⛔ never a second derivation (that defect cost 40 false refusals in S2).
        // ★ WHY AN ENDPOINT MATCH IS NOT ENOUGH (the whole reason the terminal shape carries 3-4 extra bytes):
        //   a CTS is retry/duty-stash eligible and that stash has NO flight-generation guard, so a delayed
        //   terminal answer to flight A can arrive while flight B — same next hop, same endpoints — is awaiting
        //   its CTS. With only `tx_id`/`rx_id`/`awaiting_cts` (all of which B satisfies) it would TERMINALLY
        //   clear B, with no DATA, no emit and no `send_failed`: [[B153]]'s silent loss from the other side.
        // ⓘ ② and ③ share ONE exit (`bound == false`) because they need the SAME treatment: no trust, one charge.
        bool bound = false;
        if (_active->_pending_tx && _active->_pending_tx->awaiting_cts
            && c.tx_id == _active->_pending_tx->next) {
            const PendingTx&        pt   = *_active->_pending_tx;
            const RtsFlightIdentity mine = flight_identity(pt);   // the ONE producer — identical to the RTS's
            const RtsWireMarks      mk   = rts_wire_marks(pt);    // the ONE producer of the marks we AIRED
            const bool my_team = rts_wire_team_plane(mk.addr_len, mk.mobile_src);
            bound = rts_flight_identity_equal(c.id, mine) && (c.team_plane == my_team);
            if (!bound)                                          // only reportable when there WAS a flight to name
                MR_EMIT("cts_terminal_mismatch", EF_I("from", c.tx_id), EF_I("ctr", pt.ctr),
                        EF_I("echo_width", c.id.width), EF_I("my_width", mine.width),
                        EF_B("echo_team", c.team_plane), EF_B("my_team", my_team));
        }
        // ⚖⚖⚖ THE TWO CLASSES OF SIDE EFFECT — §hybrid-rts S2c (2026-08-09), QA-required. This is the ONE place
        //   the distinction is written down, and it exists so a later reader does not "clean up" the charge below.
        //     ⛔ A TRUST decision must wait for the evidence that licenses it: home-liveness refresh, pending-state
        //        change, timer cancel/re-arm, route/link learning, any application-facing outcome. An unbindable
        //        terminal claim gets NONE of those — that is what the `return` here protects.
        //     ✅ ACCOUNTING IS NOT A TRUST DECISION. It is a MEASUREMENT OF PHYSICAL AIRTIME THAT DID OCCUR: the
        //        frame hit the channel and cost it, whether or not we believe a single byte of the frame. So an
        //        invalid terminal CTS IS charged — EXACTLY ONCE, at its true 6/7-B `cts_air_len`.
        //   ★ WITHOUT THIS CHARGE THE TERMINAL BIT IS AN ACCOUNTING ESCAPE HATCH: set `already_received`, echo a
        //     bogus identity, and every frame you air is invisible to the anti-spam ledger. S2b briefly had that
        //     hole (it hoisted the bind above the meter along with everything else); this narrows the hoist to the
        //     trust class only. ⛔ Do NOT re-remove the charge on the grounds that the frame was rejected.
        //   ⓘ EXACTLY ONCE, structurally: this arm RETURNS, so it can never also reach the ordinary meter below;
        //     and the BOUND arm ④ does NOT charge here — it falls through and is charged there once, at the same
        //     `cts_air_len`. Mutually exclusive by the `return`, not by a flag.
        //   ⓘ `cts_tx_id_is_local` gates it for the SAME reason as the ordinary meter, off the SAME hoisted
        //     derivation: a team-local `c.tx_id` is not in the ledger's global namespace, so charging it bills an
        //     UNRELATED global node — and the metric feeds originator-drop, so mis-attribution can drop an innocent
        //     peer's traffic. The terminal bit opens no NEW escape there: the ordinary shape is not billed on that
        //     path either, so this is PARITY, not a second policy.
        //   ★★ §hybrid-rts S2d (2026-08-09) — **S2c's "RESIDUAL" HERE WAS NOT A RESIDUAL, IT WAS THE BUG, and it was
        //     the REACHABLE case.** S2c wrote that with NO pending flight the guard is "structurally false" so a
        //     team-plane terminal CTS is billed under its local id, and filed that as unclosable because "the CTS
        //     carries no plane mark". ⛔ WRONG for this shape — the terminal CTS carries `CTS_TERM_PLANE_BIT`, and it
        //     is precisely the no-pending-flight case that dominates in the corpus. `cts_tx_id_is_local` now reads
        //     the bit, so no pending flight is needed to attribute the frame correctly, and (the mirror error) an
        //     unrelated TEAM flight being pending no longer suppresses the charge for a STATIC terminal CTS.
        //     Closing it needed the bit we already spend, not a wider CTS.
        if (!bound) {
            if (!cts_tx_id_is_local)
                track_originator_observation(c.tx_id, /*kind=cts*/1, /*dedup_key=*/c.rx_id,
                                             static_cast<uint32_t>(airtime_routing_ms(cts_air_len)));
            return;
        }
        // ④ BOUND. Fall through into the ONE accept tail below (refresh, meter, learn, confirm, cancel, clear).
        //   ⓘ It re-tests ② on the way through; that is a cheap re-read of state nothing in between mutates,
        //   and it keeps the ordinary path's source byte-for-byte unchanged rather than forking a parallel
        //   accept path (U1).
    }
    // §mobile: a CTS from our HOME clearing OUR flight (c.tx_id=home, c.rx_id=us) proves the home is alive -> refresh the
    // home-lost clock. The mobile routes all its DMs via the home, so this fires FAR more often than the home's (possibly
    // 15-min) beacon — the beacon-only refresh (node_beacon.cpp:551) is what let a live-but-slow-beaconing home be
    // declared "lost". is_mobile+active gated -> s18/static byte-identical.
#if MR_FEAT_MOBILE
    if (_cfg.is_mobile && _my_mobile_reg.active && c.rx_id == _node_id && c.tx_id == _my_mobile_reg.home_id)
        _my_mobile_reg.last_heard_home_ms = _hal.now();
#endif
    // R4.4 anti-spam: track this CTS in the CTS sender's (c.tx_id) window (overheard, addressed to us or
    // not). CTS is the forwarder fingerprint — a legit forwarder emits ~1 CTS per inbound flight (dv:10149).
    // Unconditional now: tx_id is on the wire (no PHY-sender god-view). Dedup key is rx_id (the cleared
    // requester), not the dropped ctr_lo. ★ §hybrid-rts S2b: timing is now `cts_air_len` — the Lua CTS_LEN=4
    // parity constant for the ORDINARY shape (unchanged), but the TERMINAL shape's ACTUAL 6/7 B (it is not a 4-B
    // frame and must not be billed as one). See the derivation at the top of this function.
    // §mobile: skip the track when `c.tx_id` is a LOCAL id (the home or teammate we are sending to) rather than a
    // global one the ledger can key. ★ §hybrid-rts S2d: WHICH EVIDENCE ANSWERS THAT depends on the SHAPE, and the
    // hoisted `cts_tx_id_is_local` is where the two arms and their justification live — ORDINARY (which is all that
    // reaches this line except a BOUND terminal falling through ④) has no plane bit on the wire, so it infers from
    // pending state; a TERMINAL one reads the bit it actually carries.
    // ⚠ RESIDUAL, ORDINARY-SHAPE ONLY (the terminal shape's version of it is CLOSED by S2d): a PURE-OVERHEAR
    // mobile/team ORDINARY CTS (c.rx_id != us) still meters a local id here — that shape carries no mark (its 3 flag
    // bits are (sf-5), frames.md CTS-by-context) so an overhearer genuinely cannot tell. THROTTLE-ONLY (a stale
    // window entry), never a route/deliver decision -> no misroute/misdeliver; closing THAT needs a wider ordinary
    // CTS (a flag-day, not worth it for a throttle). cts_tx_id_is_local is false on s18 -> byte-identical.
    // ⚠ §rts-cr-overhear STILL MISSING HERE, and §cts-len6-cr2 does NOT close it — the reason CHANGED, so read
    // this and don't "finish the job" by grabbing c.cr_adv. The ledger's third term bills the CTS FRAME ITSELF,
    // whose sender is c.tx_id. Byte 3's cr2 is the CR of c.rx_id (the cleared node's upcoming DATA) — the WRONG
    // NODE. Using it would swap one wrong CR for another. The CTS sender's own CR is on no wire, and byte 3 is
    // now full, so closing this needs a WIDER CTS. Bounded and unchanged: a fixed 4-B frame on the routing SF
    // (single-digit ms) against a DATA term of hundreds, erring the same way (under-billing heavier peers).
    // The RTS and DATA halves of this ledger ARE billed at the sender's advertised CR.
    // ★ §hybrid-rts S2c: `cts_tx_id_is_local` is DERIVED ONCE at the top of this function (value-identical —
    // nothing between there and here mutates `_pending_tx`) so all three charge sites cannot drift apart.
    // ⛔ Do not re-declare it here, and ⛔ do not "simplify" its terminal arm away (§hybrid-rts S2d).
    // ⓘ REACHED BY: every ordinary CTS, and a BOUND terminal CTS (④) — which is charged HERE, exactly once, and
    //   never also inside the gate (that arm returns).
    if (!cts_tx_id_is_local)
        track_originator_observation(c.tx_id, /*kind=cts*/1, /*dedup_key=*/c.rx_id,
                                     static_cast<uint32_t>(airtime_routing_ms(cts_air_len)));
    if (!for_me_dst(c.rx_id)) {                           // overheard CTS (not clearing EITHER of our plane ids: node_id or team_local_id)
        // ★★ §hybrid-rts S2b: **ORDINARY-ONLY BY CONSTRUCTION.** An overheard TERMINAL CTS returned at ① in the
        // gate at the top of this function, so `c.already_received` is provably false here — which is what makes
        // arming NAV legitimate: an ordinary CTS is the one shape that really does authorize a DATA+ACK.
        // NAV: reserve the medium for the DATA+ACK this CTS just authorized (covers the hidden node near the
        // receiver that didn't hear the RTS). chosen_data_sf is exact; the length is byte 3's 4-B-quantized hint.
        // ✔ §cts-len6-cr2 (2026-07-27) — CLOSED. This was the ONE wrong-CR site that failed in the DANGEROUS
        // direction: the DATA is the CLEARED node's (c.rx_id) at ITS CR, and a cr5 overhearer sizing a cr8
        // peer's DATA released NAV mid-frame (-245 ms at the s32 shape, -1327 ms at SF12/120 B) and could then
        // transmit straight into the frame NAV existed to protect. Byte 3 now carries that CR (+ the length in
        // 4-B units), so both terms are the peer's. NO HINT (a 3-B CTS = the CTSer has NAV off) keeps the
        // unchanged fallback: a full 255-B frame at OUR CR — the only guess available, and over-reserving.
        const uint8_t peer_cr = c.payload_len ? rts_cr_decode(c.cr_adv) : active_cr();
        if (_cfg.nav_enabled) nav_arm(nav_duration_cts(c.chosen_data_sf, c.payload_len, peer_cr));
        // Part A YIELD (spec 2026-06-28): the CTS sender is OUR next-hop -> it just cleared someone else and is about
        // to receive their DATA -> busy, our CTS/ACK can't come. Push our pending timeout past the reserve (½-max est,
        // LBT-backstopped) instead of timing out blind + burning a retry during it.
        if (protocol::reserve_yield_enable && _active->_pending_tx
            && (_active->_pending_tx->awaiting_cts || _active->_pending_tx->awaiting_ack)
            && c.tx_id == _active->_pending_tx->next)
            // ✔ §cts-len6-cr2 — converted with the nav_arm above (same peer_cr). The LENGTH stays the ½-max
            // estimate, not byte 3's hint: this yield is about the CTSer being busy with SOMEONE ELSE's flight
            // whose size we deliberately guess (reserve_est_payload_bytes), LBT-backstopped.
            // ⚠ UNREACHABLE TODAY: reserve_yield_enable is the compile-time constant 0 (Part A shipped off), so
            // a poison probe here moves 0/30 and the corpus emits zero reserve_yield events. Correct by
            // inspection + inert; it goes live the day Part A is enabled.
            reserve_yield(nav_duration_cts(c.chosen_data_sf, static_cast<uint8_t>(protocol::reserve_est_payload_bytes),
                                           peer_cr));
        return;
    }
    if (!_active->_pending_tx || !_active->_pending_tx->awaiting_cts) return;   // ctr_lo flight-match dropped: rx_id==me + tx_id==next (below) pin the flight
    // Cascade disambiguation: the CTS now carries its sender (tx_id), so accept only the CTS from the
    // next-hop we RTS'd. Wire-backed (no PHY-sender god-view) — this is what distinguishes the primary
    // next-hop's CTS from an alt's when both answer the same RTS (cascade-to-alt). dv:10195.
    if (c.tx_id != _active->_pending_tx->next) return;
    // ★★★★ §hybrid-rts S2b (2026-08-09) — **THE TERMINAL BIND USED TO LIVE HERE AND HAS MOVED UP**, to the gate at
    // the top of this function. S2 put it here, which was ALREADY below the §mobile home-liveness refresh and the
    // anti-spam meter ⇒ a terminal CTS that failed its identity check had refreshed home liveness and metered the
    // ledger before being rejected. Reaching this line with `already_received` set therefore PROVES the echo
    // matched (endpoints, plane, domain, width and every identity byte) — the check is simply earlier now, and a
    // mismatch returned before touching any TRUST state: no liveness refresh, no timer, no learn, no emit but the
    // refusal itself. ⚠ §hybrid-rts S2c: it IS still charged to the anti-spam ledger up there (accounting is a
    // measurement of airtime that occurred, not a trust decision — see the ⚖ note in the gate), which is why the
    // ordinary meter below can be reached by a BOUND terminal CTS only: exactly one charge either way.
    // ⛔ DO NOT re-add a bind here: a second evaluation is a second derivation waiting to happen (S2's 40 false
    //    refusals came from exactly that), and it would restore the wrong ordering by making this the real gate.
    // Learn the CTS sender (= our next-hop) as a 1-hop neighbour (Lua learn_rx_source / cts_frame).
    // §mobile: our next-hop on a mobile last-mile (addr_len=1) or a team DM (is_team_peer) is a LOCAL id, not a global
    // identity -> keep it OUT of the static _rt (mirror the ACK-learn guard below). Inert on s18/static (both false).
    // §team-parity T0: plane made explicit (was learn_direct_neighbor's default). Static reduction: `false` IS the
    // old default ⇒ identical call.
    // ✔ §team-parity T2 (§3/T2 row 3) — the LEARN half is DONE by the else-arm below; the guard is UNCHANGED (I2).
    if (!(next_is_local_id(_active->_pending_tx->addr_len, _active->_pending_tx->next))
        && learn_direct_neighbor(c.tx_id, protocol::db_to_q4(meta.snr_db), false, /*team_plane=*/false)) schedule_triggered_beacon();
#if MR_FEAT_TEAM
    // ✔ §team-parity T2 (§3/T2 row 3): a CTS from OUR next-hop on a TEAM flight proves that teammate hears us and is
    // 1 hop away. c.tx_id == _pending_tx->next (pinned at the `c.tx_id != next` return just above), so this learns the
    // next-hop itself. Safe by construction: is_team_peer(next) is our OWN state, so no new id is admitted.
    // ⚠ ELSE-ARM ALGEBRA (the reason the static path cannot move): next_is_local_id == (addr_len==1 || is_team_peer(next)),
    // so `!next_is_local_id` FALSE is the ONLY way to reach this arm with is_team_peer(next) true — i.e. the arm fires
    // exactly on the traffic the guard above excludes, and is unreachable whenever the guard admitted the frame.
    // team_id==0 ⇒ _team_peer is all-zero ⇒ is_team_peer false ⇒ inert (s18/static byte-identical).
    else if (is_team_peer(_active->_pending_tx->next)
             && learn_direct_neighbor(c.tx_id, protocol::db_to_q4(meta.snr_db), false, /*team_plane=*/true)) schedule_triggered_beacon();
#endif
    if (!(next_is_local_id(_active->_pending_tx->addr_len, _active->_pending_tx->next)))   // §mobile: a mobile/team next is a LOCAL id -> keep it OUT of the static bidi/liveness + route-rerank planes (mirror the CTS-learn guard above)
        note_link_confirmed(c.tx_id);                    // bidi plane: a real CTS proves our next-hop hears us -> confirmed (clears any one_way + emits link_recover)
#if MR_FEAT_TEAM
    // ★★★ ✔ §team-parity T5 (spec §3/T2 row 3 SECOND HALF — the ✖ T2 left here, now CLOSED). T2's reason for deferring
    // was exact and is now spent: "there is nothing to write it to". T5 adds team_bidi_state/team_bidi_confirmed_s to the
    // _team_liveness slot (node.h's PeerLiveness note), so a team confirm writes TEAM state and never touches the
    // node_id-indexed _link_bidi. The GUARD ABOVE IS UNTOUCHED — this is a team destination for the traffic it excludes.
    // ⚠ ELSE-ARM ALGEBRA (identical to the T2 learn arms 3 lines up, restated because it is what makes the static path
    // provably immovable): next_is_local_id == (addr_len==1 || is_team_peer(next)), so `!next_is_local_id` FALSE is the
    // ONLY way in — the arm fires exactly on the traffic the static guard rejects and is unreachable whenever the guard
    // admitted the frame. team_id==0 ⇒ _team_peer all-zero ⇒ inert (s18 / every static scenario byte-identical).
    // `c.tx_id` (not `->next`) mirrors the static arm verbatim; the two are pinned equal by the `c.tx_id != next` return
    // earlier in this function, which is the same pinning T2's learn arm documents at :496.
    else if (is_team_peer(_active->_pending_tx->next))
        note_link_confirmed(c.tx_id, /*team_plane=*/true);
#endif
    _hal.cancel(kRtsTimeoutTimerId);                     // else it fires same-tick and burns a retry
    _hal.cancel(kRetryBackoffTimerId);                   // drop a stale retry armed by a just-fired rts_timeout
    _active->_pending_tx->awaiting_cts = false;
    _active->_pending_tx->chosen_data_sf = c.chosen_data_sf;
    MR_EMIT("cts_rx", EF_I("from", _active->_pending_tx->next), EF_I("sf", c.chosen_data_sf));  // CTS is from our next-hop (src_hint=-1 on metal)
    // ✔ §hybrid-rts S2 (2026-08-08), ordering corrected by S2b (2026-08-09) — the ✖ MISSING marker S1 left here is
    // CLOSED: reaching this line with `already_received` set PROVES the echo matched (endpoints, plane, domain,
    // width and every identity byte), because the comparison is the GATE AT THE TOP of this function and a mismatch
    // returned there without touching a timer, a learn, `awaiting_cts`, any emit — and, since S2b, without touching
    // the §mobile home-liveness refresh either (S2c keeps the anti-spam CHARGE, which is accounting, not trust).
    // So the terminal credit below is bound to THIS flight, which is what makes it legitimate at all.
    // ⓘ It deliberately clears the flight WITHOUT synthesizing an app outcome: `_pending_tx.reset()` + `become_free()`
    //   is the historical behaviour and no `send_acked`/`send_e2e_acked`/`send_failed` is invented (design §5.2's
    //   rule for the sibling optimisation applies here too — a hop's "I already have it" is progress evidence, not
    //   an end-to-end delivery receipt; any independently armed E2E-ack wait is left running).
    if (c.already_received) { _active->_pending_tx.reset(); become_free(); return; }   // already delivered downstream (echo-verified above)
    (void)_hal.after(protocol::cts_to_data_gap_ms, kCtsToDataGapTimerId);     // fixed 5ms gap (NOT rand)
}

// 2026-06-09: a channel message is now the lean M frame (cmd 0xA), NOT a DATA+PAYLOAD_TYPE_M. The data SF
// frame that follows a FLOOD/M_BROADCAST RTS-M is this M frame; every node that retuned (the overhear ARM)
// ingests it promiscuously — but the STANDARD byte-0 leaf gate runs first, so a stray that punched into an
// adjacent leaf dies before buffering (the cross-leaf leak fix). No CTS/ACK/forward; the retune-back timer
// restores routing_sf. `from` keeps the DATA-M's src_hint-or-0xFF derivation (metal carries no PHY sender).
void Node::handle_channel_data(const uint8_t* bytes, size_t len, const RxMeta& meta) {
    auto pm = parse_m(std::span<const uint8_t>(bytes, len));
    if (!pm) return;
    if (pm->leaf_id != _cfg.leaf_id && !same_team(pm->team_id)) return;   // the leak gate — a foreign-leaf M frame dies here. §P2-1: EXEMPT a same-team M-frame (a mixed-leaf team channel crosses nibbles); ingest_channel_m still team_id-gates. Static/foreign-team -> unchanged.
    const uint8_t from = (meta.src_hint >= 0) ? static_cast<uint8_t>(meta.src_hint) : 0xFF;
    ingest_channel_m(*pm, from);
}

// Record this flight's (origin,dst,ctr) key -> expiry + prev-hop for the loop/retransmit dedup. Prune the
// expired entries first; then if still at the cap (all live) and the key is NEW, ROLL — evict the OLDEST
// (min-expiry = earliest recorded, least remaining loop-window) to make room, rather than refusing the new
// key. Re-recording an existing key just refreshes it (no eviction). Bounded by cap_seen_origins; no growth.
void Node::record_seen_origin(uint64_t sokey, uint8_t from, uint64_t now_ms) {
    for (auto it = _active->_seen_origins.begin(); it != _active->_seen_origins.end(); )
        { if (it->second <= now_ms) { _active->_seen_origin_from.erase(it->first); it = _active->_seen_origins.erase(it); } else ++it; }
    if (_active->_seen_origins.size() >= protocol::cap_seen_origins
        && _active->_seen_origins.find(sokey) == _active->_seen_origins.end()) {              // full of LIVE entries + a NEW key -> roll
        auto oldest = _active->_seen_origins.begin();
        for (auto it = _active->_seen_origins.begin(); it != _active->_seen_origins.end(); ++it)
            if (it->second < oldest->second) oldest = it;                   // min expiry = the earliest recorded
        _active->_seen_origin_from.erase(oldest->first);
        _active->_seen_origins.erase(oldest);
    }
    _active->_seen_origins[sokey]     = now_ms + protocol::seen_origin_ttl_ms;
    _active->_seen_origin_from[sokey] = from;
}

// ★★★ §hybrid-rts S2 (2026-08-08) — THE COMPLETED-FLIGHT CACHE (design §4.3). A FIXED per-layer array, so there
// is no heap, no per-peer dynamic structure and no way for it to grow: `cap_completed_flights` slots, an empty
// slot is `expiry_ms == 0`. Eviction policy is `record_seen_origin`'s VERBATIM (U1): prune expired, refresh an
// existing key in place, and only when every slot is LIVE evict the min-expiry one.
// ⛔ THE MATCH IS THE COMPLETE TUPLE AND NOTHING MAY BE DROPPED FROM IT: immediate sender | dst | wire plane |
//    identity domain | full identity. The domain is compared by `rts_flight_identity_equal`, which also refuses
//    "absent == absent" — so a width-0 identity can never match anything, and an M/flood frame (which has none)
//    cannot reach a hit even if some future caller passed one in.
const CompletedFlight* Node::completed_flight_find(uint8_t from, uint8_t dst, bool team_plane,
                                                   const RtsFlightIdentity& id, uint64_t now_ms) const {
    for (const CompletedFlight& e : _active->_completed_flights) {
        if (e.expiry_ms <= now_ms) continue;                       // empty (0) or expired
        if (e.from != from || e.dst != dst || e.team_plane != team_plane) continue;
        if (!rts_flight_identity_equal(e.id, id)) continue;        // THE one comparator: full width + domain
        return &e;
    }
    return nullptr;
}
void Node::completed_flight_store(uint8_t from, uint8_t dst, bool team_plane,
                                  const RtsFlightIdentity& id, uint64_t now_ms) {
    if (!rts_flight_identity_valid(id)) return;                    // a flight with no identity is not storable
    const uint64_t expiry = now_ms + protocol::completed_flight_cache_ttl_ms;   // DERIVED from gateway_send_giveup_ms
    CompletedFlight* victim = nullptr;
    for (CompletedFlight& e : _active->_completed_flights) {
        if (e.expiry_ms != 0 && e.expiry_ms <= now_ms) e = CompletedFlight{};   // prune expired -> free slot
        if (e.expiry_ms != 0 && e.from == from && e.dst == dst && e.team_plane == team_plane
            && rts_flight_identity_equal(e.id, id)) { e.expiry_ms = expiry; return; }   // refresh in place
        if (e.expiry_ms == 0 && victim == nullptr) victim = &e;                 // first free slot
    }
    if (victim == nullptr) {                                       // every slot LIVE -> evict the min-expiry one
        victim = &_active->_completed_flights[0];
        for (CompletedFlight& e : _active->_completed_flights) if (e.expiry_ms < victim->expiry_ms) victim = &e;
    }
    victim->expiry_ms = expiry; victim->id = id;
    victim->from = from; victim->dst = dst; victim->team_plane = team_plane;
}
size_t Node::completed_flight_live_count(uint64_t now_ms) const {
    size_t n = 0;
    for (const CompletedFlight& e : _active->_completed_flights) if (e.expiry_ms > now_ms) ++n;
    return n;
}

void Node::handle_data(const uint8_t* bytes, size_t len, const RxMeta& meta) {
    auto pd = parse_data(std::span<const uint8_t>(bytes, len));
    if (!pd) return;
    
    const data_out& d = *pd;
    // §mobile 3b/6.4: mark-aware DATA accept — addressed to EITHER plane id (for_team on a team member's team-plane id).
    // Non-team node: _team_local_id==0 -> for_team_data false -> byte-identical to the old `next != _node_id || (addr_len==1)!=is_mobile`.
    const bool for_static_data = d.next == _node_id && ((d.addr_len == 1) == _cfg.is_mobile);
#if MR_FEAT_TEAM
    const bool for_team_data   = team_addr_for_us(d.next, d.addr_len);   // §P2-3
#else
    const bool for_team_data   = false;   // §featuresplit
#endif
    if (!for_static_data && !for_team_data) return;
    if (!_active->_pending_rx || _active->_pending_rx->ctr_lo != d.ctr_lo4) return;
    // ★★★★★ §hybrid-rts S2 (2026-08-08) — **DATA VALIDATION AGAINST THE RESERVATION. MANDATORY, FAIL-LOUD, AND
    // FIRST.** The RTS only AUTHORIZED a reception; this is where the message's identity is actually proved. It is
    // placed here — above the anti-spoof flag, the anti-spam ledger, every neighbour/route learn, the ACK and the
    // dedup — so that a frame which is not the one we cleared teaches this node NOTHING.
    // ⓘ The three reads below are PURE (`data_inner`/`parse_unicast_inner`/`data_nonce_seed` only look at `bytes`)
    //   and were HOISTED from further down verbatim; no MR_EMIT moved, so a stream can only change if a mismatch
    //   actually fires.
    // The DATA's link sender = whoever we CTS'd (_active->_pending_rx->from, set in handle_rts).
    // src_hint is the SIM oracle (real LoRa carries no PHY source; the device sets -1), so use it only when
    // present, else fall back to our pending-RX contract — else from=0xFF on metal -> the ACK + HOP_BUDGET/LOOP_DUP
    // NACKs target node 255 and the dedup/loop keys are corrupt, so the DM never completes.
    const uint8_t from = (meta.src_hint >= 0) ? static_cast<uint8_t>(meta.src_hint)
                                              : _active->_pending_rx->from;
    // Parse the inner up-front so data_rx carries the (origin, ctr) message key — telemetry parity with the Lua
    // data_rx (dv:10911), which the analysis tools key delivery on. origin is also needed below (BEFORE the ACK)
    // so HOP_BUDGET/LOOP_DUP can NACK instead of re-ACKing.
    auto inner = data_inner(std::span<const uint8_t>(bytes, len), d);
    auto ui = parse_unicast_inner(inner, d.flags);
    const uint8_t origin = ui ? ui->origin : from;
    // §1b: the CRYPTED flight's 8-B cleartext nonce seed (an EMPTY span on a plaintext frame -> stays zero).
    uint8_t nseed[8] = {0};
    if (d.crypted) { auto sd = data_nonce_seed(std::span<const uint8_t>(bytes, len), d);
                     for (uint8_t i = 0; i < 8 && i < sd.size(); ++i) nseed[i] = sd[i]; }
    {
        // PLANE first (design §4.3): DATA carries no `mobile_src`, so its plane cannot be re-read off the wire —
        // it is validated against the plane the RTS DECLARED and we stored. Stored TEAM requires `for_team_data`;
        // stored STATIC/GLOBAL requires `for_static_data`. A contradiction is the same fail-loud path as an
        // identity mismatch, because "the RTS said team and the DATA is addressed to my static id" is not a frame
        // whose plane we may pick.
        const bool plane_ok = _active->_pending_rx->wire_team_plane ? for_team_data : for_static_data;
        // IDENTITY: recomputed from CANONICAL DATA fields through the ONE producer, then compared with the ONE
        // comparator (full width + domain — never a prefix). Plaintext uses `origin | ctr`; crypted uses the
        // clear `nonce_seed | ctr | dst`, which is exactly what the sender bound and is preserved verbatim across
        // forwards. ⛔ `payload_len` is NOT part of this and never may be.
        // ⛔⛔ NOTE WHICH ORIGIN THIS IS, because it is NOT the `origin` local three lines up: the identity uses
        //    `ui ? ui->origin : 0`, i.e. STRICTLY what the frame exposes. The `origin` local falls back to `from`,
        //    which prefers `meta.src_hint` (the simulator's PHY oracle, -1 on hardware) — feeding that into an
        //    identity would make the comparison sim/metal-divergent, which is [[B156]]'s defect class. The sender
        //    computes the same `ui ? ui->origin : 0` from its own carrier (see `tx_rts_retry`), so the two agree
        //    for every production frame shape. B161 removed the typed-answer raw-inner exception.
        const RtsFlightIdentity did = rts_flight_identity(d.crypted, ui ? ui->origin : 0, d.ctr, d.dst, nseed);
        if (!plane_ok || !rts_flight_identity_equal(did, _active->_pending_rx->id)) {
            // ⛔ ALL FOUR PROHIBITIONS, and they are enforced by RETURNING HERE rather than by four separate
            // guards further down: no delivery, no ACK, no completed-flight cache seed/refresh, no route-success
            // credit. The reservation is CLEARED (mirroring `pending_rx_expiry_fire`) so the receiver is free for
            // the next flight, and the sender falls back on its EXISTING bounded timeout/retry — there is
            // deliberately NO fallback that accepts a mismatch.
            MR_EMIT("rts_flight_id_mismatch", EF_I("from", _active->_pending_rx->from), EF_I("dst", d.dst),
                    EF_I("ctr", d.ctr), EF_I("origin", origin), EF_B("crypted", d.crypted),
                    EF_B("plane_ok", plane_ok), EF_B("stored_team", _active->_pending_rx->wire_team_plane),
                    EF_I("rts_width", _active->_pending_rx->id.width), EF_I("data_width", did.width));
            _hal.cancel(kPendingRxExpiryTimerId);
            _hal.set_rx_sf(_cfg.routing_sf);
            _active->_pending_rx.reset();
            become_free();
            return;
        }
    }
    // B251: bind a static-plane mobile ingress to the LIVE DIRECT hosted row while PendingRx still carries the
    // immediate sender. `mobile_from` alone is not a plane discriminator (team traffic sets it too), so the stored
    // wire plane and the DATA admission plane are both load-bearing. A SOURCE_HASH, when present, must name this
    // exact row; a mismatch gets no translation authority and follows the pre-B251 path.
    uint32_t hosted_mobile_hash = 0;
    bool hosted_mobile_direct = false;
    if (!d.crypted && _active->_pending_rx->mobile_from && !_active->_pending_rx->wire_team_plane
        && for_static_data && ui) {
        for (uint8_t i = 0; i < _active->_mobile_reg_n; ++i) {
            const auto& row = _active->_mobile_reg[i];
            if (row.mobile_local_id != _active->_pending_rx->from || !host_row_live_direct(i)) continue;
            if (ui->has_source_hash && ui->source_hash != row.key_hash32) {
                MR_EMIT("mobile_transit_source_mismatch", EF_I("local", row.mobile_local_id),
                        EF_I("expected", static_cast<int64_t>(row.key_hash32)),
                        EF_I("got", static_cast<int64_t>(ui->source_hash)));
                break;
            }
            hosted_mobile_hash = row.key_hash32;
            hosted_mobile_direct = true;
            break;
        }
    }
    // e2e-ack backstop exemption ANTI-SPOOF verify (2026-07-02): the RTS claimed RTS_FLAG_E2E_ACK (so its DROP was
    // exempted at handle_rts), but the DATA that arrived is NOT a DATA_TYPE_E2E_ACK -> the sender lied to bypass the
    // backstop. Flag it: while flagged, its RTS_FLAG_E2E_ACK is ignored (the backstop re-applies). Keyed on the PHYSICAL
    // SENDER = _pending_rx->from (the cleartext RTS src, metal-correct), NOT the sealed inner origin. One free pass, revoked.
    if (_active->_pending_rx->claimed_e2e_ack && d.type != DATA_TYPE_E2E_ACK) {
        const uint8_t spoofer = _active->_pending_rx->from;
        MR_EMIT("e2e_ack_spoof", EF_I("from", spoofer), EF_I("type", d.type));
        if (PeerLiveness* s = peer_liveness_slot(spoofer, /*create=*/true))
            s->e2e_ack_spoof_until_ms = _hal.now() + protocol::e2e_ack_spoof_penalty_ms;
    }
    // Inc 2 anti-spam: record this inbound DATA's airtime in the sender's window — the dominant
    // airtime a sender imposes on us (RTS-only never approached the cap). Keyed on _active->_pending_rx->from
    // (== this hop's RTS src, so RTS+DATA accumulate in one entry; frame-derived, metal-correct) and
    // costed at the chosen data SF over the whole frame.
    // ✔ §rts-cr-overhear (2026-07-27) — CONVERTED, and this one is an ACCOUNTABILITY fix, not a timing fix.
    // The quantity is "airtime THIS SENDER imposed on us", so it must be costed at the CR the sender actually
    // transmitted at (PendingRx.sender_cr, stashed from the RTS by handle_rts) — not active_cr(), OUR CR.
    // Billing a peer's frame at our own rate mis-meters the duty/abuse cap: a cr8 sender was under-billed by
    // up to 8/5 of its payload term against originator_airtime_share, so it could impose ~1.6x the airtime we
    // charged it before the throttle bit. The error is signed and self-serving in the wrong direction — the
    // heavier (costlier) the peer's CR, the more we under-charge it.
    if (!_active->_pending_rx->mobile_from)   // §mobile: a mobile/team DATA's src is a LOCAL id -> keep it OUT of the anti-spam ledger (mirror the RTS-anti-spam guard :40); accountability rides origin=home_id
        track_originator_observation(_active->_pending_rx->from, /*kind=data*/2, d.ctr_lo4,
            airtime_ms(_active->_pending_rx->chosen_data_sf, active_bw_hz(), _active->_pending_rx->sender_cr,
                       protocol::preamble_sym, static_cast<uint16_t>(len)));
    int oa_app_; uint32_t orig_air; uint8_t oa_rts_, oa_cts_;   // sender's windowed airtime AFTER this DATA (calibration)
    compute_originator_metric(_active->_pending_rx->from, oa_app_, orig_air, oa_rts_, oa_cts_);
    (void)oa_app_; (void)oa_rts_; (void)oa_cts_;
    // ⓘ §hybrid-rts S2: `from`, `inner`, `ui` and `origin` are computed at the TOP of this function now — the
    // DATA-identity validation needs them before anything else may happen. Their derivations moved verbatim.
    MR_EMIT("data_rx", EF_I("origin", origin), EF_I("ctr", d.ctr), EF_I("ctr_lo", d.ctr_lo4), EF_I("from", from), EF_I("dst", d.dst),
            EF_I("orig_airtime_ms", static_cast<int64_t>(orig_air)));
    // Learn the DATA prev-hop as a 1-hop neighbour (Lua learn_rx_source / data_frame).
    // §mobile: a mobile_src DATA's prev-hop `from` is a home-assigned LOCAL id -> keep it OUT of the static _rt
    // (mirror the RTS/Q guards). mobile_from==false for every static frame -> unchanged (s18 byte-identical).
    // §team-parity T0: plane made explicit (was the default). Static reduction: `false` IS the old default.
    // ✔ §team-parity T2 (§3/T2 row 4) — DONE by the else-arm below; this guard is UNCHANGED (I2).
    if (!_active->_pending_rx->mobile_from && learn_direct_neighbor(from, protocol::db_to_q4(meta.snr_db), false, /*team_plane=*/false)) schedule_triggered_beacon();
#if MR_FEAT_TEAM
    // ✔ §team-parity T2 (§3/T2 row 4): a TEAM DATA's prev-hop is a 1-hop teammate. for_team_data (:564) proves the LINK
    // is team-plane (d.next == our _team_local_id && addr_len==1) — the same acceptance edge the shipped RTS reverse-learn
    // uses — and is_team_peer pins the prev-hop as an already-known teammate, so no new id is admitted (see the row-1 note
    // on why an unknown one is not decidable from these frames).
    // ★ USE _pending_rx->from, NOT `from`. `from` prefers meta.src_hint, which is the SIM ORACLE carrying the sender's
    // STATIC protocol node_id (SimController.cpp: protocolId()); for a HOMED teammate that is NOT its team_local_id, so
    // learning `from` would install a static id in _rt_team. _pending_rx->from is the RTS's own `src`, which
    // node_mac.cpp:855 sets to the sender's team_local_id() on a team flight — frame-derived and metal-correct.
    // Static reduction: for_team_data is `false` whenever team_id==0 (team_addr_for_us, node.h:174) ⇒ inert.
    else if (for_team_data && is_team_peer(_active->_pending_rx->from)
             && learn_direct_neighbor(_active->_pending_rx->from, protocol::db_to_q4(meta.snr_db), false, /*team_plane=*/true)) schedule_triggered_beacon();
    // ✔ §team-parity T2 — DATA-ORIGIN LEARNING. The spec's §3/T2 REJECTED this on two grounds and the QA review (§10.1)
    // overruled BOTH; the owner ruled it IN. Re-verified at source here: the structs are data_in/data_out (not d_in/d_out)
    // and frame_codec.h:595 does carry `committed_hops`, a FROM-ORIGIN hop count incremented at every forward (:626 below).
    // So a real metric IS available and a REAL route installs — which sets the _team_peer bit ALONGSIDE an _rt_team entry
    // and therefore PRESERVES the node_beacon.cpp:73 invariant rather than decoupling it. U1: reuse learn_route_via, the
    // same installer the F/RREP reverse-path uses (node_route_discovery.cpp:281) — do not fork a second multi-hop install.
    //
    // METRIC. hops = committed_hops + 1, EXACT for every legal team path: an originator airs committed_hops=0 and the
    // receiver is 1 hop away, each forward adds 1. ★ THE BRIEF'S SATURATION CAVEAT DOES NOT BITE: :626 saturates the
    // value a FORWARDER airs at 7, so a receiver 8 hops out (R4's team ceiling) still reads exactly 7 → hops 8. The
    // understatement starts at 9 hops, which team_hop_cap=8 makes unreachable by discovery or DV. No cap guard is needed
    // either: committed_hops is a 3-bit wire field (frame_codec.h:483) so +1 can neither wrap nor exceed 8 — unlike the
    // F path, whose 8-bit f.hops needed the M4 guard at node_route_discovery.cpp:272.
    //
    // ★★★ ✔ §team-parity T7 (2026-07-28) — THE `is_team_peer(origin)` FENCE IS GONE, AND THIS IS THE ✖ MISSING HALF OF
    // T2's NOTE CLOSED. T2 fenced this learn because a HOMED member stamped origin = its HOME's STATIC node id
    // (stamp_origin had no team-plane exception), so "is this origin a team-plane id?" was undecidable and _rt_team[101]
    // would have put a static id in the team plane (I2's mirror, s35's A2) AND shadowed that node's own static route home.
    // ★ T6 (`9c7b40a`) REMOVED THE PREMISE, and the proof is the same two scenarios T2 cited: T2 measured origin=101 on
    // s28 node 3 (team_local_id 233) and s29 node 3 (team_local_id 196); T6's re-anchor moved exactly that inner byte,
    // origin 101 → 233/196. stamp_origin (node.h:858) now stamps team_local_id() for every flight_is_team_plane() flight.
    // RE-MEASURED HERE, not inherited: instrumenting every gate entry over all 35 scenarios yields 51 team DATA
    // receptions and **not one** plain-DM origin outside the team id space. The one surviving refusal was s35a's
    // origin=213 / prev=235 / committed_hops=2 — a member 174 dropping a route to a teammate it had never heard, i.e.
    // spec §0's bench failure itself. That is what this slice installs: `_rt_team[213] = {next 235, hops 3}`.
    //
    // ★★ WHAT NOW CARRIES THE SOUNDNESS, STATED EXACTLY — because this admits a NEW id into _rt_team/_team_peer from a
    // received DATA, which none of T2's six refresh arms do. The basis is `for_team_data` = team_addr_for_us(d.next,
    // d.addr_len) (node.h:174) = "team_id != 0 && _team_local_id != 0 && d.next == _team_local_id && addr_len == 1", i.e.
    // BOTH the RTS we CTS'd and the DATA were addressed to OUR team-plane id on the team-plane link marking. It does NOT
    // prove the SENDER is a teammate: neither RTS nor plain DATA carries a team_id (frame_codec.h:289 / :591), so a §18
    // numeric collision — a FOREIGN team's member, or a home last-miling to a hosted mobile whose local id equals our
    // _team_local_id — satisfies it too. ⇒ THE RESIDUAL IS NOT NEW: it is the identical predicate the already-shipped
    // addressed-RTS arm at :91 admits `r.src` on (its own note at :107 names the same two cases), so T7 extends an
    // accepted 1-hop admission to the multi-hop origin rather than opening a new trust basis. And in that collision the
    // frame is already CTS'd, ACKed and relayed by us (:568 accepts it on the same test) — a strictly larger containment
    // exposure than one route row, pre-existing and reported, not created here.
    // ✖ TWO NARROWER GATES WERE BUILT AND REFUSED AS DECORATION, measured not judged: `is_team_peer(_pending_rx->from)`
    // and `_pending_rx->mobile_from` are BOTH true in 51/51 corpus gate entries — the :91 arm sets the _team_peer bit for
    // exactly the src that gets us here, so the first cannot fire; and every hole either would close is already closed by
    // learn_route_via's own `via == 0 / 0xFF` sentinel guard (node_beacon.cpp:65). A guard that reads as safety and is
    // provably inert is worse than none.
    // ★ T6's FALLBACK ARM, checked independently as the one reachable static-origin path: stamp_origin takes the team
    // branch only when team_local_id() != 0, so a member whose team-DAD is still pending stamps a static/home id. `send
    // -t` is refused there (node.cpp:1141) but an AUTO send to a team peer is NOT, and _team_peer bits DO get set before
    // our own DAD completes (node_beacon.cpp:776 does not require our id) ⇒ the state IS reachable. It cannot install
    // here: that sender's RTS airs src = team_local_id() = 0 (node_mac.cpp:855), so _pending_rx->from == 0 and
    // learn_route_via returns on `via == 0` before any merge. Pinned by a native test, not by inspection.
    // ⚠ !d.app is LOAD-BEARING, not caution: parse_unicast_inner's layout applies only to a plain DM. A typed DATA builds
    // its own inner, so ui->origin is a payload byte — measured over all 35 scenarios as 14 gate entries with app=1, of
    // which s28's four read origin=4 (a hash-bind payload byte that WOULD now install, since nothing else refuses it) and
    // ten read origin=0. !d.app ⟺ type==0 (pack_data emits the TYPE byte iff type != 0). !d.crypted: §1c seals the origin,
    // so parse_unicast_inner leaves it 0 for a relay by design (frame_codec.cpp:925) — an encrypted team DM teaches
    // nothing here, deliberately (2 such entries in s22).
    // ⚠ `origin != from` is NOT load-bearing, and the brief that asked me to confirm it was overstated — MEASURED: dropping
    // it moves 0 of 36 scenarios. It keeps the 1-hop case with the else-arm above (which owns the SNR re-score and the
    // triggered beacon); without it a 1-hop team DATA re-merges an IDENTICAL candidate (same dest==via, same hops 1, same
    // score from the same meta.snr_db) microseconds after that arm installed it, so rt_merge returns MergeAction::none and
    // learn_route_via emits nothing. ⇒ it eliminates a redundant merge, it does not prevent a wrong route. Kept for that
    // reason and for clarity of intent, not as a safety gate. `!d.crypted` is likewise corpus-invisible (0 of 36) but for a
    // different reason worth distinguishing: its 2 entries carry origin 0, which learn_route_via's dest==0 sentinel already
    // refuses — so relying on that would be accidental, whereas this conjunct states the intent. Only `!d.app` is a real
    // barrier (1 of 36: dropping it installs _rt_team[4] on four s28 nodes from a hash-bind payload byte).
    if (for_team_data && !d.app && !d.crypted && ui
        && origin != _active->_pending_rx->from)          // 1 hop is the else-arm above's job (it also fires the triggered beacon)
        learn_route_via(origin, _active->_pending_rx->from, static_cast<uint8_t>(d.committed_hops + 1),
                        protocol::db_to_q4(meta.snr_db), /*team_plane=*/true);
#endif
    // ★★★ §hybrid-rts S2 — capture the VALIDATED flight's cache key BEFORE the reservation is dropped. The store
    // itself happens only after an ACK has been STAGED for it (⚠ NOT "emitted" — see the corrected invariant at the
    // store site; `tx_with_retry` can defer or reject), and every early return between here and there (HOP_BUDGET,
    // LOOP_DUP) leaves the cache untouched — correctly, because neither of those ACKs.
    const RtsFlightIdentity done_id   = _active->_pending_rx->id;
    const uint8_t           done_from = _active->_pending_rx->from;         // ON-AIR immediate sender, never src_hint
    const bool              done_team = _active->_pending_rx->wire_team_plane;
    const bool              done_mobile = _active->_pending_rx->mobile_from;
    _hal.cancel(kPendingRxExpiryTimerId);
    _hal.set_rx_sf(_cfg.routing_sf);                     // receiver retunes back
    _active->_pending_rx.reset();
    // §B153: the per-hop last-acked CACHE THAT WAS WRITTEN HERE IS GONE, along with the RTS-time gate it fed and
    // the two locals (`rx_sf`, `pl`) that existed only to feed it. `_seen_origins` below is now the ONLY dedup —
    // and it is the one holding the evidence (see the argument at handle_rts).
    // ⚠ §hybrid-rts S2 (2026-08-08): "Nothing replaces this write" is no longer true, and the difference is the
    // KEY, not the mechanism. A completed-flight record IS written again — but AFTER the ACK, not here, and keyed
    // by the full wire identity instead of `(src, dst, ctr_lo, len)`. `_seen_origins` remains the sole DELIVERY
    // dedup; the new cache only answers a repeat RTS, and it can only be consulted with evidence the old 7-B frame
    // never carried. See `completed_flight_store` below the ACK.
    const uint64_t nowm = _hal.now();
    // §1b sealed-sender dedup key — TYPE-NAMESPACED into one 64-bit space so PLAINTEXT and CRYPTED can NEVER alias.
    // PLAINTEXT = (origin<<24|dst<<16|ctr), naturally in [0,2^32) — same VALUE as before, just widened (s18 invariant).
    // CRYPTED = the FULL 8-B cleartext nonce-seed loaded LE, top bit forced => [2^63,2^64). The seed is globally unique
    // per message (a crypto invariant), preserved VERBATIM across forwards (so a loop via a different prev-hop still
    // matches), and — once §1c seals `origin` — the ONLY flight-id a relay can read. Forcing bit 63 costs one seed bit
    // (63 left => ~2^-47 birthday at the 256 cap) and makes the plaintext/CRYPTED disjointness a HARD invariant, not a
    // probability. Extract the seed HERE, before the sokey: PLAINTEXT data_nonce_seed() returns an EMPTY span
    // (frame_codec:717), so nseed stays zero and is never read on that path. origin is still read BEFORE the ACK so
    // HOP_BUDGET/LOOP_DUP can NACK instead of re-ACKing.
    // ⓘ §hybrid-rts S2: `nseed` is extracted at the TOP of this function now (the crypted identity is derived from
    // it), so only the LE load remains here. Same bytes, same span, same guard — the extraction moved verbatim.
    uint64_t seed_u64 = 0; for (int i = 0; i < 8; ++i) seed_u64 |= uint64_t(nseed[i]) << (8 * i);   // LE load (zero for plaintext)
    const uint64_t sokey = d.crypted
        ? (seed_u64 | (uint64_t(1) << 63))                                                          // CRYPTED namespace: >= 2^63
        // PLAINTEXT namespace: < 2^32 for a STATIC (global-id) origin. §mobile: a mobile/team DATA (mobile_from) has a
        // LOCAL-id origin that can §18-collide a static global id -> OR in bit 62 to move it to a DISJOINT plaintext range
        // [2^62, 2^62+2^32) so a team/mobile origin X can never alias a static origin X (a false LOOP_DUP would DROP a real
        // message). mobile_from=0 on s18 -> identical.
        // ★★ §team-parity T6/B (spec §3/T6 Part B): + bit 61 for a TEAM-plane flight, and the reason is a CORRECTION to
        // this slice's own brief AND to the LayerRuntime "§P2-7 AUDIT" note, both of which say this key "has NO plane bit".
        // IT ALREADY HAD ONE — bit 62 above — but bit 62 is `mobile_from`, which is NOT the plane: it is set for a
        // REGISTERED MOBILE's ordinary STATIC-plane DM (whose origin is its home's GLOBAL id) *and* for a team-plane DM
        // (node_mac.cpp:817 ORs it with team_next). So the residual alias was team-vs-mobile-static INSIDE the 2^62 range,
        // not team-vs-static. `for_team_data` (computed at the top of this function, :564 — "this DATA is addressed to OUR
        // team-plane id") is the exact plane discriminator and is stable across every hop of a team flight, since each
        // team hop is addressed addr_len=1 to the next hop's team id. B251 adds bit 60 for a VERIFIED hosted-mobile
        // first hop and replaces its redundant home-origin byte with the hosted row's full key hash. That is what keeps
        // two mobiles at the same ctrM/dst from being mistaken for a loop. FIVE disjoint ranges now: static <2^32 ·
        // generic mobile-static at bit62 · hosted-mobile first-hop at bit62+bit60 · TEAM at bit62+bit61 · CRYPTED >=2^63.
        // Static reduction: for_team_data is false for every static node and every non-team frame (team_addr_for_us
        // requires team_id!=0 && _team_local_id!=0, and stubs to false on the three MR_FEAT_TEAM 0 gateway_* envs).
        // Ordinary static and generic mobile-static key values stay unchanged. Team-plane flights move together, and
        // only a verified live-direct hosted-mobile first hop enters the B251 hash-qualified range.
        : hosted_mobile_direct
          ? ((uint64_t(1) << 62) | (uint64_t(1) << 60)
             | (uint64_t(hosted_mobile_hash) << 24) | (uint64_t(d.dst) << 16) | d.ctr)
          : (((uint64_t(origin) << 24) | (uint64_t(d.dst) << 16) | d.ctr)
             | (done_mobile  ? (uint64_t(1) << 62) : uint64_t(0))
             | (for_team_data ? (uint64_t(1) << 61) : uint64_t(0)));
    // HOP_BUDGET enforcement FIRST (dv:10918-10964), BEFORE the dedup AND the ACK so the
    // NACK fires IN LIEU OF the ACK. A FORWARDER (d.dst != self) decrements the TTL; if the
    // decremented value went negative (the frame arrived with hops_remaining==0 at a
    // non-destination), the budget is exhausted -> NACK the sender (terminal) instead of
    // forwarding. The destination is exempt. Lua runs this check ABOVE the loop-dup dedup,
    // so a budget-exhausted frame ALWAYS HOP_BUDGET-NACKs (terminal + rt-bump self-heal)
    // regardless of dup status.
    const int     hb_new_remaining = static_cast<int>(d.hops_remaining) - 1;
    const uint8_t hb_new_committed = (d.committed_hops >= 7) ? 7
                                     : static_cast<uint8_t>(d.committed_hops + 1);
    if (!for_me_dst(d.dst) && hb_new_remaining < 0) {   // §6.4: the destination (static OR team-plane id) is exempt from the hop-budget NACK
        MR_EMIT("hop_budget_exceeded", EF_I("origin", origin), EF_I("dst", d.dst), EF_I("ctr", d.ctr));
        // Record (origin,dst,ctr) so a LATER non-exhausted arrival of the SAME flight via
        // a DIFFERENT prev-hop is caught as LOOP_DUP (not accepted+forwarded) — dv:10933-10940.
        record_seen_origin(sokey, from, nowm);   // prune + roll-evict-oldest-if-full + insert (see the def)
        nack_in nin{}; nin.reason = protocol::nack_reason_hop_budget; nin.ctr_lo = d.ctr_lo4;
        nin.payload = static_cast<uint8_t>((hb_new_committed & 0x0f) << 4);   // committed in the HIGH nibble
        nin.to = from; nin.mobile_to = done_mobile;   // §mobile: use the receive-flight discriminator captured before PendingRx was retired
        uint8_t nbuf[4]; const size_t nl = pack_nack(nin, std::span<uint8_t>(nbuf, 4));
        tx_with_retry(nbuf, nl, static_cast<int16_t>(_cfg.routing_sf), FrameTag::nack);   // R4.5b (HOP_BUDGET NACK)
        MR_EMIT("nack_tx", EF_I("to", from), EF_I("reason", protocol::nack_reason_hop_budget), EF_I("ctr", d.ctr));
        become_free();
        return;
    }
    // Origin-level dedup (dv:10966+), AFTER HOP_BUDGET. A same-prev-hop dup is normal
    // lost-ACK recovery (ACK-only below); a DIFFERENT prev-hop means a mesh loop -> NACK.
    auto so = _active->_seen_origins.find(sokey);
    const bool live_dup = (so != _active->_seen_origins.end() && so->second > nowm);
    if (live_dup) {
        auto sof = _active->_seen_origin_from.find(sokey);
        if (sof != _active->_seen_origin_from.end() && sof->second != from) {
            // LOOP_DUP: the SAME flight arrived via a DIFFERENT prev-hop (a mesh loop,
            // dv:10971). NACK the sender so it cascades to an alt, and do NOT ACK (the
            // ACK would clear its pending_tx early). prior_from = the first prev-hop.
            nack_in nin{}; nin.reason = protocol::nack_reason_loop_dup; nin.ctr_lo = d.ctr_lo4;
            nin.payload = sof->second; nin.to = from;
            uint8_t nbuf[4]; const size_t nl = pack_nack(nin, std::span<uint8_t>(nbuf, 4));
            tx_with_retry(nbuf, nl, static_cast<int16_t>(_cfg.routing_sf), FrameTag::nack);   // R4.5b (LOOP_DUP NACK)
            MR_EMIT("nack_tx", EF_I("to", from), EF_I("reason", protocol::nack_reason_loop_dup), EF_I("ctr", d.ctr));
            MR_EMIT("dup_drop", EF_I("origin", origin), EF_I("dst", d.dst), EF_I("ctr", d.ctr));
            become_free();
            return;
        }
    }
    // B251 admission boundary. A qualifying hosted-mobile transit must own a real queue row before we acknowledge
    // ctrM; an E2E-requesting one must also own reverse-correlation capacity. The same reservation protects the
    // existing MOBILE_SEND delegation path, whose re-origination may be immediate or parked. A retryable BUSY_RX NACK
    // is preferable to silence: the sender already has a bounded same-hop wait/retry path and eventually reports its
    // ordinary send_failed if pressure persists.
    const bool translate_mobile_transit = hosted_mobile_direct && !for_me_dst(d.dst)
        && !(_cfg.is_gateway && !_cfg.intra_layer_relay);
    const bool wants_reverse_map = (d.flags & DATA_FLAG_E2E_ACK_REQ) != 0
                                && d.type != DATA_TYPE_E2E_ACK;
    uint32_t map_mobile_hash = 0;
    DelegAckPeer map_target_kind = DelegAckPeer::node_id;
    uint32_t map_target = 0;
    // ★★★ §B278 S1b §5 PHASE 1 — the PROVISIONAL custody verdict, decided from facts already parsed BEFORE the
    //     mobile hop ACK and from nothing else. ⛔ NO SECOND BODY PARSER AND NO WRAPPER-BYTE PEEK: `candidate`
    //     means "not yet disproven", and activation owns the final type and dispatch-arm facts (§4.3).
    DelegAckCustody map_custody = DelegAckCustody::none;
    if (!live_dup && translate_mobile_transit && wants_reverse_map) {
        map_mobile_hash = hosted_mobile_hash;
        map_target = d.dst;
        // §5 for a DIRECT HOSTED-MOBILE TRANSIT, term by term, and SEVEN of the eight are STRUCTURAL at this site:
        //   (1) verified direct hosted transit  -> `hosted_mobile_direct` (a live DIRECT row whose local id is the
        //       immediate sender, and whose SOURCE_HASH, when present, names that exact row);
        //   (2) E2E-ACK requested               -> `wants_reverse_map`, the same gate that decides reservation;
        //   (3) plaintext outer DATA            -> `!d.crypted`, required by `hosted_mobile_direct`;
        //   (4) static/global, same layer       -> `!wire_team_plane && for_static_data`, likewise;
        //   (5) normal DATA, not channel M/FLOOD-> structural: a channel message is an M frame and never reaches
        //       `handle_data` at all;
        //   (6) not XL/team/gateway re-inject/last-mile -> a direct transit is same-layer by construction, and
        //       `translate_mobile_transit` already excludes the gateway re-inject and `for_me_dst` (the last mile);
        //   (8) nonzero target with a complete identity -> `d.dst`, and `deleg_ack_reserve` refuses a 0 target.
        // ⇒ (7) is the ONE term left to state, and `d.type` IS knowable here — so this arm is type-complete.
        map_custody = deleg_custody_reserve_verdict(/*carrier_prospectively_eligible=*/true,
                                                    /*outward_type_known=*/true, d.type);
    } else if (!live_dup && !d.crypted && !done_team && for_me_dst(d.dst) && wants_reverse_map
               && d.type == DATA_TYPE_MOBILE_SEND && ui && ui->has_source_hash && ui->has_dst_hash) {
        // Existing wrapper path: reserve by the stable requested target hash. do_post_ack/send_by_hash later
        // finalizes this same row with the return discriminator exposed by the chosen same/XL route.
        for (uint8_t i = 0; i < _active->_mobile_reg_n; ++i)
            if (_active->_mobile_reg[i].key_hash32 == ui->source_hash && host_row_live_direct(i)) {
                map_mobile_hash = ui->source_hash;
                map_target_kind = DelegAckPeer::key_hash;
                map_target = ui->dst_key_hash32;
                // §5 for a MOBILE_SEND WRAPPER: terms (1)-(5) and (8) are structural in this arm's own condition
                // (a live direct hosted row owns `source_hash`; E2E requested; plaintext; static/same-layer;
                // the DATA path; a nonzero `dst_key_hash32`). ★ Of term (6), the CROSS-LAYER half IS knowable
                // here — `ui->has_cross_layer` is already parsed — so the wrapper XL branch is excluded at
                // RESERVATION and not merely at activation. ⛔ The LAST-MILE half of (6) is NOT knowable (it is
                // decided inside `send_by_hash`'s direct-host arm) and neither is term (7) (the enclosed type is
                // `etype`, read only in `do_post_ack`) ⇒ `outward_type_known = false`, which is precisely WHY
                // this row is only provisional.
                map_custody = deleg_custody_reserve_verdict(
                    /*carrier_prospectively_eligible=*/!ui->has_cross_layer,
                    /*outward_type_known=*/false, /*outward_type=*/0);
                break;
            }
    }
    uint8_t correlation_slot = kDelegAckNoSlot;
    uint16_t admitted_ctr_h = 0;                                // B251 E2E path: predicted without allocating
    uint32_t admission_retry_ms = protocol::nack_busy_quantum_ms;
    uint8_t admission_refusal = 0;                              // 1=TX queue, 2=correlation ring
    if (!live_dup && translate_mobile_transit && _active->_tx_queue_n >= kTxQueueCap) {
        admission_refusal = 1;
    } else if (map_mobile_hash != 0
               && !deleg_ack_reserve(map_mobile_hash, d.ctr, map_target_kind, map_target,
                                      active_layer_id(), map_custody,
                                      correlation_slot, admission_retry_ms)) {
        admission_refusal = 2;
    }
    if (admission_refusal == 0 && correlation_slot != kDelegAckNoSlot && translate_mobile_transit) {
        admitted_ctr_h = peek_next_ctr(d.dst);
        if (!deleg_ack_activation_available(correlation_slot, admitted_ctr_h, DelegAckPeer::node_id,
                                            d.dst, active_layer_id(), admission_retry_ms)) {
            // ★ §B278 S1b: this is the LOUD half of the cross-mobile refusal. It runs BEFORE the mobile hop ACK,
            //   so the mobile learns immediately through BUSY_RX reason 2 and retries — no DM has flown yet.
            deleg_ack_release(map_mobile_hash, d.ctr, map_target_kind, map_target, active_layer_id(),
                              DelegAckReleaseCause::activation_conflict);
            correlation_slot = kDelegAckNoSlot;
            admission_refusal = 2;
        }
    }
    if (admission_refusal != 0) {
        ++_mobile_ctr_admission_refused_n;
        MR_EMIT("mobile_ctr_admission_refused", EF_I("reason", admission_refusal),
                EF_I("mobile_hash", static_cast<int64_t>(map_mobile_hash ? map_mobile_hash : hosted_mobile_hash)),
                EF_I("dst", d.dst), EF_I("ctr_m", d.ctr), EF_I("retry_ms", admission_retry_ms));
        uint32_t q = (admission_retry_ms + protocol::nack_busy_quantum_ms - 1)
                   / protocol::nack_busy_quantum_ms;
        if (q == 0) q = 1;
        if (q > 255) q = 255;
        nack_in nin{}; nin.reason = protocol::nack_reason_busy_rx; nin.ctr_lo = d.ctr_lo4;
        nin.payload = static_cast<uint8_t>(q); nin.to = from; nin.mobile_to = done_mobile;
        uint8_t nbuf[4]; const size_t nl = pack_nack(nin, std::span<uint8_t>(nbuf, sizeof nbuf));
        tx_with_retry(nbuf, nl, static_cast<int16_t>(_cfg.routing_sf), FrameTag::nack);
        MR_EMIT("nack_tx", EF_I("to", from), EF_I("reason", protocol::nack_reason_busy_rx),
                EF_I("ctr", d.ctr));
        become_free();
        return;
    }
    // ACK on routing_sf (2-bit SNR bucket). R4.2: piggyback OUR budget tier, capped at CRITICAL (the
    // protocol caps the forward hint at CRITICAL per Lua dv:11054 — a node already >=CRITICAL refuses
    // the RTS with a BUDGET NACK and rarely ACKs; EXHAUSTED is the reverse-NACK's concern). So the
    // sender learns our congestion in the FORWARD direction. Fires for a fresh DATA and a same-prev-hop dup.
    const BudgetTier my_tier = compute_budget_tier();
    const uint8_t hint = (static_cast<uint8_t>(my_tier) > static_cast<uint8_t>(BudgetTier::critical))
                         ? static_cast<uint8_t>(BudgetTier::critical) : static_cast<uint8_t>(my_tier);
    ack_in ain{}; ain.ctr_lo = d.ctr_lo4; ain.budget_hint = hint;
    ain.snr_bucket = bucket_of_snr_2b(protocol::db_to_q4(meta.snr_db)); ain.to = from;
    // §mobile: if the DM originator is a mobile/team member (its RTS was mobile_src -> _pending_rx->mobile_from), the ACK's
    // `to` is a home-assigned/team LOCAL id -> set mobile_to so the originator ACCEPTS it (its gate at handle_ack requires
    // (mobile_to==1)==is_mobile) and a colliding STATIC id ignores it. Without this EVERY mobile/team-ORIGINATED DM fails at
    // the ACK step (retries + dups). 0 for a static originator -> byte-identical.
    ain.mobile_to = done_mobile;
    // Inc 3: warn the sender (via the ACK warn bit) when its observed airtime is in the warn band — the
    // soft sender-side precursor to the hard drop. orig_air = this sender's windowed airtime (post-DATA,
    // computed above for the data_rx diagnostic). cap = share x budget; warn at warn_fraction x cap.
    const uint32_t airtime_cap_a = static_cast<uint32_t>(
        static_cast<double>(protocol::originator_airtime_share) * _duty_cycle_budget_ms);
    ain.warn = (_duty_cycle_budget_ms > 0) &&
               (orig_air > static_cast<uint32_t>(
                   static_cast<double>(protocol::originator_airtime_warn_fraction) * airtime_cap_a));
    uint8_t abuf[3]; const size_t al = pack_ack(ain, std::span<uint8_t>(abuf, 3));
    tx_with_retry(abuf, al, static_cast<int16_t>(_cfg.routing_sf), FrameTag::ack);   // R4.5b: stash + tag the ACK
    MR_EMIT("ack_tx", EF_I("to", from), EF_I("ctr", d.ctr), EF_I("airtime_warn", ain.warn ? 1 : 0));
    // ★★★ §hybrid-rts S2 — THE COMPLETED-FLIGHT STORE, and its position is the contract: it is BELOW the ACK and
    // ABOVE the `live_dup` return, so a lost-ACK RETRY — the case the whole optimisation exists for — refreshes the
    // entry it is about to need again. The two NACK paths above return without ACKing and therefore without
    // storing.
    // ★★ §hybrid-rts S2b (2026-08-09) — **THE INVARIANT IS STATED EXACTLY, BECAUSE "ITS ACK EMITTED" IS NOT
    // LITERALLY TRUE.** Design §4.2's phrasing (and S2's comment here) claimed the store happens after the ACK was
    // *emitted*. It cannot claim that: `tx_with_retry` above may return `deferred_retry_armed` (duty over budget,
    // `node_mac.cpp:1681`) or a busy/too-long rejection, so the ACK may never reach the radio at all.
    // ⇒ THE ACTUAL SAFE INVARIANT THIS STORE RESTS ON: **matching DATA was accepted and an ACK was STAGED/ATTEMPTED
    //   for it, and no NACK path may seed the cache.** That is sufficient, because the cache only ever authorises
    //   answering an EXACT retry of a flight we really did accept — and the later terminal CTS is itself what
    //   safely completes the hop, so a physically-unsent ACK costs a retry, never a false terminal answer.
    // ⛔ DO NOT "fix" this by threading an ACK-completion callback back to here: it needs a much larger
    //   callback/state change, and QA ruled it UNNECESSARY for exactly the reason above. ⛔ `done_from` is the RTS's own `src`, captured before the reservation was dropped — NEVER
    // `meta.src_hint` (the sim oracle; [[B156]]'s sim/metal divergence), and NEVER the local `from` above, which
    // PREFERS `src_hint` and is therefore the wrong identity for a link-keyed store.
    completed_flight_store(done_from, d.dst, done_team, done_id, nowm);
    if (live_dup) { become_free(); return; }                                        // same prev-hop dup -> ACK only
    record_seen_origin(sokey, from, nowm);                                          // record + roll-evict-oldest if full
    // defer deliver/forward by the ACK airtime so it doesn't share a sim step with the ACK.
    _active->_post_ack = PostAck{};
    _active->_post_ack.pending = true; _active->_post_ack.is_forward = !for_me_dst(d.dst);   // §6.4: deliver a DM addressed to our team-plane id too (dual member)
    _active->_post_ack.team_plane = for_team_data;   // ★ §hashbind-plane: carry the PLANE to the deferred ingest (do_post_ack cannot re-derive it — no `next`/`addr_len` there, and _pending_rx is reset above). Same discriminator T6/B already uses for the dedup key; false for every static/non-team frame.
    _active->_post_ack.origin = origin; _active->_post_ack.dst = d.dst; _active->_post_ack.ctr_lo = d.ctr_lo4;
    _active->_post_ack.ctr = d.ctr; _active->_post_ack.flags = d.flags; _active->_post_ack.type = d.type;
    _active->_post_ack.previous_hop = translate_mobile_transit ? done_from : from;
    _active->_post_ack.inner_len = static_cast<uint8_t>(inner.size() <= protocol::max_payload_bytes_hard_cap
                                               ? inner.size() : protocol::max_payload_bytes_hard_cap);
    for (uint8_t i = 0; i < _active->_post_ack.inner_len; ++i) _active->_post_ack.inner[i] = inner[i];
    if (d.crypted) for (uint8_t i = 0; i < 8; ++i) _active->_post_ack.nonce_seed[i] = nseed[i];   // §1b: seed already extracted above (the dedup key) — stash verbatim for the open / forward
    // Clamp the underflow: the exhaustion NACK that guarantees hb_new_remaining>=0 only fires for a FORWARD
    // (d.dst != self, line above) — the DELIVERY case (d.dst==self) is exempt, so a DM that arrived AT us with
    // hops_remaining==0 leaves hb_new_remaining==-1. That value is dead for a plain deliver, but an L2c
    // misdelivery re-forwards from the delivery case, so -1 -> uint8_t 255 (saturating to the 31 max) must not
    // leak into a budget. (L2c re-budgets its leg from rt anyway; this is belt-and-suspenders.)
    _active->_post_ack.fwd_remaining = static_cast<uint8_t>(hb_new_remaining < 0 ? 0 : hb_new_remaining);
    _active->_post_ack.fwd_committed = hb_new_committed;                         // carried into the forward TxItem
    if (translate_mobile_transit) {
        // The mobile's ACK above used ctrM. Only now mint the home's destination-scoped counter, then consume the
        // queue capacity checked before that ACK. The short hold keeps this already-reserved item behind the post-ACK
        // semantic pass; no other producer can steal its slot after handle_data returns.
        const uint16_t ctr_h = next_ctr(d.dst);
        _active->_post_ack.ctr = ctr_h;
        _active->_post_ack.ctr_lo = static_cast<uint8_t>(ctr_h & 0x0F);
        _active->_post_ack.forward_prequeued = true;
        const bool correlation_ready = correlation_slot == kDelegAckNoSlot
            || (ctr_h == admitted_ctr_h
                && deleg_ack_activate(correlation_slot, ctr_h, DelegAckPeer::node_id,
                                      d.dst, active_layer_id(),
                                      /*outward_type=*/d.type,     // §B278 S1a: the forwarded carrier's OWN type
                                      // §B278 S1b §4.3: DIRECT HOSTED-MOBILE TRANSIT — a same-layer static outward
                                      // DATA flight. Every §5 term held at reservation and none of them can have
                                      // changed: this arm forwards the SAME carrier it already inspected.
                                      deleg_custody_activate_verdict(/*arm_carries_custody=*/true, d.type)));
        if (!correlation_ready) {
            // All resource/collision checks ran before the hop ACK, and the loop task is single-threaded. Reaching
            // this means an internal counter/reservation invariant was broken, not ordinary pressure. Never forward
            // without the map; the prequeued marker also prevents do_post_ack from materialising a fallback copy.
            if (correlation_slot != kDelegAckNoSlot)
                deleg_ack_release(hosted_mobile_hash, d.ctr, DelegAckPeer::node_id, d.dst, active_layer_id(),
                                  DelegAckReleaseCause::commit_invariant);
            ++_mobile_ctr_admission_refused_n;
            MR_EMIT("mobile_ctr_commit_failed", EF_I("mobile_hash", static_cast<int64_t>(hosted_mobile_hash)),
                    EF_I("dst", d.dst), EF_I("ctr_m", d.ctr), EF_I("ctr_h", ctr_h));
        } else {
            TxItem it = forward_item_from_post_ack(_active->_post_ack, nowm);
            it.plane = Plane::GLOBAL;
            it.next_attempt_ms = nowm + airtime_routing_ms(3) + 2;
            _active->_tx_queue[_active->_tx_queue_n++] = it;                   // capacity was reserved above
            MR_EMIT("mobile_ctr_translated", EF_I("mobile_hash", static_cast<int64_t>(hosted_mobile_hash)),
                    EF_I("dst", d.dst), EF_I("ctr_m", d.ctr), EF_I("ctr_h", ctr_h));
        }
    }
    (void)_hal.after(airtime_routing_ms(3) + 1, kPostAckTimerId);
}

// =========================================================================================================
// ★★★★ §CUSTODY-G (2026-08-31) — THE `DATA_TYPE_CUSTODY_FAILURE` (0x81) RECEIVER
//      (design §13 the eighteen validations · §7.2 the record mapping · §7.3 the five-step order · §14.1 the
//       Push mapping). This function ENDS the ratified F-before-G intermediate state in which an addressed
//       0x81 died at Slice B's fail-closed tail guard.
//
// ⛔⛔ EVERY §13 TERM IS NAMED SEPARATELY, and that is a gate requirement rather than a style: the battery
//     demands ONE FALSIFIER PER TERM, and a fused boolean would make "which validation refused this record"
//     unanswerable and every mutation indistinguishable from every other. The terms are grouped by the layer
//     that OWNS them, because they are not all the same kind of question:
//
//   FRAME-LEVEL (this function; the record has not been read yet)
//     §13.1  the DATA is PLAINTEXT      — a CRYPTED inner is sealed to us and would have to be opened first;
//                                         a notice is originated `CryptIntent::off` (§9.1), so a crypted one
//                                         is a forgery attempt or a bug either way.
//     §13.2  standard unicast parsing succeeded (`ui != nullptr`).
//
//   CODEC-OWNED (`parse_custody_failure`, frame_codec.cpp — ELEVEN terms behind ONE `nullopt`)
//     §13.3 body >= 24 · §13.4 version == 1 · §13.5 `record_len` in [24, body] · §13.6 flag bit 7 zero (bit 6
//     is ALLOCATED as of §B278 S2. ⚠ CORRECTED 2026-09-02 BY §B278 S4 — this line used to read *"and is
//     refused HERE, at the interim guard below, not by the codec"*, and the guard it named no longer exists:
//     bit 6 now SELECTS THE MODE below rather than refusing the record, and the codec validates the whole
//     §6.2 tail before returning it) ·
//     §13.7 `forwarded` set · §13.8 exactly one stage bit · §13.9 a known nonzero reason · §13.12 the four
//     ids in 1..254 · §13.13 `failed_ctr` nonzero · §13.16 the hash flag agrees with the hash, BOTH ways ·
//     §13.17 reserved bytes zero.
//     ⛔ THEY ARE NOT RE-IMPLEMENTED HERE. §9.2 rules ONE shared pack/parse path; a second offset table is
//        how a 24-byte record ends up meaning two different things. G's native arms drive each of the eleven
//        THROUGH this receiver (a codec-byte break at the wire), which is what proves the receiver actually
//        consults the codec rather than merely importing it.
//
//   RECEIVER-CONTEXT (this function; needs node state the pure codec does not have)
//     §13.10 `failed_plane == static_same_layer` — v1 SUPPORT, not well-formedness. ★ IN TWO HALVES, because
//            the field is a CLAIM and the arrival is the FACT it can be checked against: the body must say
//            `static_same_layer`, AND the frame must not have arrived on the TEAM plane. §9.1 forces
//            `Plane::GLOBAL` on every v1 notice EXACTLY so a team-local-id collision cannot route a
//            static-plane diagnostic onto the team plane — so a team-plane arrival contradicts the record's
//            own plane byte, and consuming it would write a team-plane `origin` into a record documented as
//            a static reporting relay (C3: the planes are separate id-namespaces).
//     §13.11 `failed_origin` == THIS node's static id. ★★ THIS — not the wire `dst`, not a DST_HASH — IS THE
//            ADDRESSEE TEST. Only the ORIGINAL SENDER of the failed DATA consumes a notice; a relay carrying
//            one in transit never reaches this function at all (it is `pa.is_forward` and is forwarded as
//            ordinary transit DATA), and a home proxying one to a hosted mobile forwards it at the DST_HASH
//            last-mile, far above. Three roles, one consumer.
//     §13.14 `failed_type` is neither E2E ACK nor custody failure — the receiver's half of §10.1(11)'s
//            never-about-itself rule. A record claiming a relay lost custody of an ACK or of another notice
//            describes something the generator structurally cannot produce.
//     §13.15 `reporter_layer` == the ACTIVE receiving full layer, in the same-layer v1 case.
//     §13.18 the four count/hop fields fit their PROTOCOL domains (`custody_committed_hops_max` and the three
//            `protocol::` bounds — frame_codec.h names all four in one place).
//
// ⛔⛔ WHAT IS **NOT** CHECKED, STATED SO ITS ABSENCE IS NOT READ AS AN OVERSIGHT (§13's closing paragraph,
//     verbatim: *"The outer origin is the reporter. It is not authenticated. A mismatch between outer context
//     and body invariants is malformed, not evidence."*): **THE RECORD CARRIES NO REPORTER-ID FIELD AT ALL.**
//     There is therefore nothing to cross-check `pa.origin` against, and ⛔ an outer/body reporter-equality
//     check MUST NOT BE INVENTED — it would be a check against a field that does not exist, and it would
//     dress an unauthenticated identity up as a verified one (the standing "a display-shaped field must never
//     make a decision" rule). The reporter is recorded as what it is: a claim.
//
// ★★ THE REJECTION TELEMETRY IS OWNER-RULED AND CLOSED: ONE bounded scalar
//    `custody_failure_reject{type, origin, dst, ctr}` per rejected flight. ⛔ NO body bytes and nothing derived
//    from them · ⛔ NO Push · ⛔ NO storage · ⛔ NO reuse of `Push::reason`. ⛔⛔ AND ⛔ NOT
//    `unsupported_internal`: that event means "this build has no handler for this internal type", and after
//    this function exists that sentence is FALSE for 0x81. Reusing it would be the same defect shape as
//    reporting a success that isn't — a true-sounding event that describes the wrong fact. The field set
//    deliberately MIRRORS `unsupported_internal`'s ruled four, so the bound is the same one the owner ruled on
//    2026-08-30: fixed-size, non-amplifying, at most one per dedup-admitted DATA flight (the radio is the
//    bound, not a counter).
//
// ⛔ NO E2E ACK IS EVER GENERATED for a notice and none is expected: §9.1 clears `E2E_ACK_REQ` at origination,
//    and this function returns before the ordinary deliver tail that would consider one (§7.3 step 5).
// =========================================================================================================
void Node::custody_failure_receive(const PostAck& pa, const data_unicast_inner* ui) {
    // The ONE rejection exit. Named so every arm below is a single line and the emit cannot drift between
    // them; `[[maybe_unused]]` is unnecessary — MR_EMIT compiles to nothing on a device and the lambda with it.
    auto reject = [&]() {
        MR_EMIT("custody_failure_reject", EF_I("type", pa.type), EF_I("origin", pa.origin),
                EF_I("dst", pa.dst), EF_I("ctr", pa.ctr));
    };
    // ---- §13.1 / §13.2 — the FRAME-level terms, before a single record byte is read.
    const bool is_plaintext  = (pa.flags & DATA_FLAG_CRYPTED) == 0;
    const bool inner_parses  = ui != nullptr;
    if (!is_plaintext || !inner_parses) { reject(); return; }
    // ---- §13.3-.9, .12, .13, .16, .17 — the CODEC's eleven, behind the ONE shared parse (§9.2).
    const std::optional<CustodyFailureRecord> parsed = parse_custody_failure(ui->body);
    if (!parsed) { reject(); return; }
    const CustodyFailureRecord& rec = *parsed;
    // ★★★★ §B278 S4 (2026-09-02) — THE MODE SPLIT. ⚠⚠ **CORRECTION IN PLACE, OLD CLAIM KEPT VISIBLE**: from
    //   §B278 S2 until this slice this spot carried the INTERIM REFUSAL
    //     `if (custody_record_is_translated(rec.notice_flags)) { reject(); return; }`
    //   whose comment said *"Until S4 lands, nothing produces this form and NOTHING may consume it"*. S3 made
    //   the home a PRODUCER; **S4 is the slice that was named there, and it is now landed** — the blanket
    //   refusal is REPLACED by design §8.1/§8.2's split direct-vs-translated contextual validation. A
    //   translated record is still refused by every node that is not its intended configured mobile, and the
    //   DIRECT path below keeps §CUSTODY-G's landed terms byte-for-byte.
    //   ⓘ WHY THE FLAG STILL DECIDES SOMETHING HERE: before S2 a bit-6 record died at the codec's reserved
    //     mask; S2 allocated bit 6, so without a split §13's eighteen terms would run on a translated record —
    //     the TRANSLATING HOME's own static id sits in `failed_origin`, so §13.11 would pass AT THAT HOME and
    //     it would store and push its own translation as a direct report about itself. The split is what keeps
    //     that false: `addressed_to_us` is a DIRECT-ONLY term, and the translated arm demands
    //     `_cfg.is_mobile` (§8.2 rule 3's `pa.origin == failed_origin` is satisfied at H1, and it is the
    //     configured-mobile term — not the origin term — that refuses H1's own translation; §B278-S4/4).
    const bool translated = custody_record_is_translated(rec.notice_flags);
    // ⛔ THE ONE TAIL READER (§6.3), CALLED EXACTLY ONCE, AND ⛔ NOT A SECOND VALIDATION TABLE. Every §6.3 tail
    //   term (reporter in 1..254, a defined `target_kind`, nonzero `mobile_ctr`, nonzero and kind-valid
    //   `target_value`, the node-id `== failed_dst` equality and the optional hash cross-check) was ALREADY
    //   applied by `parse_custody_failure` above, which validates a bit-6 record THROUGH THIS SAME READER.
    //   ⇒ a translated record that parsed HAS a tail that reads, so the refusal below is a codec-COHERENCE
    //   tripwire (the two would have to disagree), never a receiver-owned policy term. ⓘ It is the reason the
    //   receiver never spells a byte offset: the offsets live in frame_codec.cpp and nowhere else.
    std::optional<CustodyTranslatedTail> tail;
    if (translated) {
        tail = parse_custody_translated_tail(ui->body, rec);
        if (!tail) { reject(); return; }
    }
    // ---- §13.10 — v1 plane SUPPORT, in its two halves (see the banner). The reserved plane values PARSE;
    //      refusing them is this layer's job, not the codec's.
    const bool plane_supported = rec.failed_plane == CustodyFailurePlane::static_same_layer;
    const bool arrived_static  = !pa.team_plane;
    // ---- §13.11 — the ADDRESSEE test. `_node_id` is the active leaf's static id (node.h).
    //      ★ §B278 S4: **DIRECT-ONLY.** A translated record is not about a flight THIS node originated — it is
    //      about the HOME's outward flight — so `failed_origin` is H1's id there and this term must not run.
    const bool addressed_to_us = rec.failed_origin == _node_id;
    // ---- §13.14 — never about an ack, never about another notice.
    const bool type_reportable = rec.failed_type != DATA_TYPE_E2E_ACK
                              && rec.failed_type != DATA_TYPE_CUSTODY_FAILURE;
    // ---- §13.15 — the same-layer v1 case: the reporter's layer IS our receiving layer.
    //      ★ §B278 S4: SHARED — direct mode requires it outright, and §8.2 rule 7's NO-HASH arm requires it
    //      too (the hosted last mile is same-layer by construction). ⛔ The HASH arm deliberately does NOT:
    //      a re-homed mobile may be reached through a different home, and the stable hash is what identifies
    //      it there. ONE spelling for both (U1) — a second `reporter_layer == active_layer_id()` is how the
    //      two arms would drift apart.
    const bool layer_matches   = rec.reporter_layer == active_layer_id();
    // ---- §13.18 — the four count/hop domains, each against its EXISTING authority (frame_codec.h).
    const bool counts_in_domain = rec.requeue_count      <= protocol::cascade_requeue_max
                               && rec.alternatives_tried <= protocol::max_rt_candidates
                               && rec.committed_hops     <= custody_committed_hops_max
                               && rec.remaining_hops     <= protocol::hop_budget_max_initial;
    // =====================================================================================================
    // ★★★★ §B278 S4 — THE TWO CONTEXTS. Everything above is COMMON (design §8.2 rule 1: *"every common
    //   frame/codec/count/type rule from the direct receiver"*, plus rule 2's plaintext/static arrival, which
    //   `is_plaintext` and `arrived_static` already own). Only the ADDRESSEE question differs, because the two
    //   forms answer *"is this report mine?"* with different evidence:
    //     DIRECT      — I originated the failed flight, so my own static id is in the record (§13.11) and the
    //                   reporting relay shares my layer (§13.15). UNCHANGED from §CUSTODY-G, byte for byte.
    //     TRANSLATED  — the failed flight was the HOME's, on my behalf. My evidence is therefore (a) that I am
    //                   a configured mobile at all, (b) that the DATA carrying the report comes from the very
    //                   node the record names as the failed origin, and (c) that this carrier really is
    //                   addressed to ME — by my stable hash when one is carried, or, on the ordinary hosted
    //                   direct-transit form which carries none, by an ACTIVE registration to that same home
    //                   on the matching layer.
    // ⛔⛔ IT IS NOT AUTHENTICATION AND NOTHING MAY BE INFERRED FROM ACCEPTANCE (§8.2's closing sentence,
    //    verbatim: *"The record remains an unauthenticated claim; no trust, key, route, membership or retry
    //    decision follows from it."*). Acceptance means only "this is plausibly about my operation".
    // =====================================================================================================
    // ---- §8.2 rule 7, arm one: the carrier is HASH-addressed. `send_by_hash` reaches a re-homed mobile
    //      through its CURRENT home with `DST_HASH == the mobile hash` while `pa.origin` is still the OLD home
    //      H1 that owns the failed flight — so the hash, not the home relation, is what makes it ours here.
    //      ⓘ `do_post_ack` already redirects a DST_HASH that is not ours (`l2c_handle_misdelivery`) far above,
    //        so on the production path this term is defence in depth; it is named anyway because it is a
    //        §8.2 REQUIREMENT, and the white-box seam drives the case the MAC cannot deliver.
    const bool hash_addressed  = ui->has_dst_hash;
    const bool hash_is_ours    = ui->dst_key_hash32 == _key_hash32;
    // ---- §8.2 rule 7, arm two: NO `DST_HASH` — the ordinary direct-host form. `send_by_hash` passes
    //      `override_dst_hash = 0` and hosted local ids are deliberately absent from `_id_bind`, so the home
    //      cannot reconstruct one. The mobile's evidence is then its OWN live registration to that home.
    //      ⛔ `mobile_registered()` / `mobile_home_id()` are the EXISTING accessors and have inert
    //        `false`/`0` stubs when `MR_FEAT_MOBILE` is compiled out, so a gateway build is inert here by
    //        construction (C3) rather than by a second `#if`.
    const bool homed_to_reporter = mobile_registered() && mobile_home_id() == pa.origin;
    // ---- §8.2 rule 3 — the translating DATA's origin IS the home which originated the failed static flight.
    const bool home_originated   = pa.origin == rec.failed_origin;
    // ---- §8.2's configured-mobile requirement. ★ THIS is the term that refuses H1's own translation, and it
    //      is why a STATIC node can never consume this form no matter what the record says.
    const bool mobile_receiver   = _cfg.is_mobile;
    const bool direct_context     = addressed_to_us && layer_matches;
    const bool translated_context = mobile_receiver && home_originated
                                 && (hash_addressed ? hash_is_ours : (homed_to_reporter && layer_matches));
    if (!(plane_supported && arrived_static && type_reportable && counts_in_domain
          && (translated ? translated_context : direct_context))) { reject(); return; }

    // =====================================================================================================
    // §7.3's FIVE STEPS. ⛔⛔ THE ORDER IS THE CONTRACT, not an implementation detail: the Push carries the
    //   sequence the STORE assigned, so the app can unify live + pulled by seq and detect a dropped live push
    //   (the contract's model B). Pushing first would have nothing to carry.
    //     (1) parse + validate       — done, above.
    //     (2) append the outcome     — `record_custody_failure`, §7.2's mapping fixed inside `Inbox` (U2).
    //     (3) obtain the assigned seq under the EXISTING gap-tolerant model — the return value.
    //     (4) enqueue the live Push carrying it.
    //     (5) return WITHOUT ordinary DM delivery or E2E-ACK generation — this function's `return`.
    // =====================================================================================================
    // ⛔ `record_len` BYTES, NOT 24: §7.2 stores *"the validated custody record, including any accepted future
    //    tail"*, and §9.2 makes `record_len` the authority on how many bytes that is. A v1 reader INTERPRETS
    //    the first 24 and RETAINS the rest — dropping the tail would silently truncate a newer reporter's
    //    record on the one node that still had it. Bounded by construction: the codec already refused
    //    `record_len > ui->body.size()`, and `ui->body.size() <= protocol::max_payload_bytes_hard_cap`, which
    //    is exactly `protocol::inbox_max_body` and exactly `sizeof(Push::body)`.
    const uint8_t  rec_len = rec.record_len;
    const uint8_t* rec_bytes = ui->body.data();
    // ★★★★ §B278 S4 — §8.3's TWO MAPPINGS, DERIVED ONCE AND THEN USED EVERYWHERE (U2: one conversion path, never
    //   a carrier rebuilt field-by-field at a second site). The store, the Push and the factual telemetry all
    //   read THESE THREE VALUES, so the public identity of a report cannot differ between the record the app
    //   pulls, the push it receives live and the event the corpus counts.
    //     direct      origin = `pa.origin` (the OUTER reporting relay) · ctr = `failed_ctr` (ctrH)
    //                 · layer = the ACTIVE receiving layer                       — §CUSTODY-G, UNCHANGED.
    //     translated  origin = `tail.original_reporter` (the relay that reported to the HOME — the outer origin
    //                 here is the home, which is a translator and not the reporter) · ctr = `tail.mobile_ctr`
    //                 (ctrM — the counter the MOBILE is waiting on; ctrH stays readable inside the body)
    //                 · layer = `rec.reporter_layer` (the layer the failure happened on, which need not be the
    //                 layer this carrier arrived over — the hash arm may cross homes).
    //   ⛔ `Push::dst` is `rec.failed_dst` in BOTH forms: it is the static destination the flight died toward.
    //      §8.4's mobile-visible target is a BODY field and is rendered from the tail, never smuggled in here.
    const uint8_t  out_origin = translated ? tail->original_reporter : pa.origin;
    const uint16_t out_ctr    = translated ? tail->mobile_ctr        : rec.failed_ctr;
    const uint8_t  out_layer  = translated ? rec.reporter_layer      : active_layer_id();
    const uint32_t seq = _inbox.record_custody_failure(out_origin, out_ctr, out_layer,
                                                       rec_bytes, rec_len, _hal.now());   // steps (2)+(3)
    // ---- step (4): §14.1's carrier mapping, verbatim. ⛔ `Push` does not grow and ⛔ `reason` stays `none`.
    Push pu{};
    pu.kind     = PushKind::custody_failure;
    pu.origin   = out_origin;             // the reporting relay — unauthenticated, recorded as a claim
    pu.dst      = rec.failed_dst;         // §15.2's correlation pair, half one
    pu.ctr      = out_ctr;                //   … half two. ⛔ never matched by counter alone
    pu.layer_id = out_layer;
    pu.seq      = seq;                    // 0 IFF storage is disabled (§7.3) — ⛔ never a persistence proof
    pu.body_len = rec_len;                // ⛔ `record_len`, so an accepted FUTURE tail rides whole (§8.3)
    for (uint8_t i = 0; i < rec_len; ++i) pu.body[i] = rec_bytes[i];
    enqueue_push(pu);
    // KEEP for the sim analyzer + the corpus instrument (free on metal — MR_EMIT is device-stripped). Scalars
    // only, the same bound the rejection carries. ⛔ Its NAME, FIELD ORDER and integer types are unchanged, and
    // for a DIRECT record every value is the one §CUSTODY-G emitted — the corpus's eleven receipts must not move.
    MR_EMIT("custody_failure_rx", EF_I("reporter", out_origin), EF_I("dst", rec.failed_dst),
            EF_I("ctr", out_ctr), EF_I("seq", static_cast<int64_t>(seq)));
    // ★★★★ §B278 S4 — TRANSLATED MODE ENDS HERE, AND THE `return` IS THE CONTRACT. Everything below is S3's
    //   HOME-side lookup and origination: a MOBILE holds no delegated-flight ring at all, so entering it would
    //   at best scan an empty ring and at worst let a report about someone else's flight re-originate a third
    //   copy. ⛔ Neither mode reaches ordinary DM delivery and neither generates an E2E ACK — that is still the
    //   function's own final `return` (§7.3 step 5), which this one mirrors.
    if (translated) return;

    // =====================================================================================================
    // ★★★★ §B278 S3 (2026-09-02) — HOME CORRELATION AND TRANSLATED-CUSTODY ORIGINATION (design §7 steps 4-7).
    //
    // ⛔⛔ THE POSITION IS THE CONTRACT, AND IT IS THE WHOLE OF S3's ORDERING CLAIM: everything above has
    //     ALREADY happened — the ORIGINAL direct record is stored at its OWN received `record_len` and H1's
    //     live Push carrying the assigned `seq` is enqueued — so translation can neither suppress, delay nor
    //     rewrite this node's own diagnostic. A lookup placed before the store would make the local outcome
    //     depend on whether a mobile happened to be correlated; §7's sentence *"Translation never suppresses
    //     or rewrites H1's original diagnostic"* is implemented by these lines being BELOW those lines.
    //
    // ⛔ THIS FUNCTION STILL DOES NOT RELEASE THE RECEIVED CARRIER. Its caller (the 0x81 arm of `do_post_ack`)
    //   owns the single `become_free()`, exactly as it did before S3, and the SEND-BEFORE-RELEASE order is the
    //   landed MOBILE_SEND re-origination precedent a few hundred lines below: `become_free()` is also the
    //   queue-drain pump, so releasing first would change WHEN the translated item may begin.
    //   ⓘ `enqueue_data` runs its own `become_free()` at the end of every admitted send (node_mac.cpp) — that
    //     indirect pump is established behaviour on this exact path and is NOT a second release of this frame.
    //
    // ⛔ NOTHING HERE CAN RECURSE. The outgoing carrier is itself `DATA_TYPE_CUSTODY_FAILURE`, and the custody
    //   GENERATOR excludes 0x81 (`node_cascade.cpp` `type_reportable`), so a translated report that dies in
    //   transit produces telemetry and never another notice; §13.14 above refuses a record ABOUT an 0x81 at the
    //   receiving end. Both halves are proven by named cases rather than argued.
    // =====================================================================================================
    DelegCustodyAction action{};
    uint8_t matches = 0;
    const DelegCustodyLookup lookup = deleg_custody_lookup(rec, pa.origin, action, matches);
    if (lookup == DelegCustodyLookup::no_match) {
        // A live delegated population exists and this report belongs to none of it. ⛔ Scalars only.
        MR_EMIT("deleg_custody_no_map", EF_I("dst", rec.failed_dst), EF_I("ctr_h", rec.failed_ctr),
                EF_I("type", rec.failed_type), EF_I("layer", rec.reporter_layer));
    } else if (lookup == DelegCustodyLookup::ambiguous) {
        // Two live rows are wire-INDISTINGUISHABLE for this report. Forward NOTHING and guess NOTHING (§4.4).
        MR_EMIT("deleg_custody_ambiguous", EF_I("dst", rec.failed_dst), EF_I("ctr_h", rec.failed_ctr),
                EF_I("type", rec.failed_type), EF_I("layer", rec.reporter_layer),
                EF_I("matches", matches));
    } else if (lookup == DelegCustodyLookup::exact) {
        // §6.2's 32 bytes, built by the ONE translated packer (§6.3) from the normalized 24-byte copy and the
        // row's tail. ⛔ A pack refusal is a bounded FORWARD REFUSAL and never a licence to hand-build bytes.
        uint8_t body32[custody_record_translated_len];
        const size_t packed = pack_custody_failure_translated(action.record, action.tail,
                                                              std::span<uint8_t>(body32, sizeof body32));
        SendDispatch dispatch{};
        bool forwarded = false;
        if (packed == custody_record_translated_len) {
            // ⛔ EXACTLY ONE ORIGINATION, THROUGH THE EXISTING MOBILE LOCATOR — `send_by_hash` owns direct
            //   hosted delivery, the cached remote home, the park and H-resolution, and B278 creates no second
            //   one and never inspects `_mobile_reg` itself (§7).
            //   · `flags = 0`      -> NO `DATA_FLAG_E2E_ACK_REQ`: this is evidence, not a message awaiting a reply
            //   · `CryptIntent::off` -> plaintext, exactly as the direct v1 notice it carries (§9.1)
            //   · `reply_to_hash = 0` + `mobile_ctr = 0` -> NOT a delegated re-origination: no reverse-ACK row
            //     is reserved, activated or released by this send, so it cannot consume a B278 row of its own
            //   · `Plane::GLOBAL`  -> the static plane, stated rather than inferred (§9.1's rule for a notice)
            //   · `type != 0`      -> no INTRO auto-attach; and 0x81's trait has NO generic send lifecycle, so a
            //     refusal below cannot become a user-visible `send_failed`
            (void)send_by_hash(action.mobile_hash, body32, custody_record_translated_len, /*flags=*/0,
                               CryptIntent::off, /*reply_to_hash=*/0, /*mobile_ctr=*/0, Plane::GLOBAL,
                               DATA_TYPE_CUSTODY_FAILURE, /*suppress_intro=*/false, &dispatch);
            // QUEUED or PARKED are both "the outcome is on its way": a park is stored under the mobile's hash
            // and drains on the H resolution with its type and its 32 bytes intact. ⛔ `refused`/`none` are NOT,
            // and they leave the row `eligible` so a genuinely fresh repeat report can retry (§4.5).
            if (dispatch.admit == SendDispatch::Admit::queued
                || dispatch.admit == SendDispatch::Admit::parked)
                forwarded = deleg_custody_mark_forwarded(action);
        }
        if (forwarded)
            MR_EMIT("deleg_custody_forwarded",
                    EF_I("mobile_hash", static_cast<int64_t>(action.mobile_hash)),
                    EF_I("dst", rec.failed_dst), EF_I("ctr_h", rec.failed_ctr),
                    EF_I("ctr_m", action.ctr_m), EF_I("type", rec.failed_type));
        else
            // ONE refusal vocabulary for all three causes (pack refusal, `none`/`refused` dispatch, a failed
            // identity recheck) — the brief forbids inventing a second one without review. ⛔ No `send_failed`,
            // no Push, no stored record, no retry, and NEVER a custody notice about this custody carrier.
            MR_EMIT("deleg_custody_forward_refused",
                    EF_I("mobile_hash", static_cast<int64_t>(action.mobile_hash)),
                    EF_I("dst", rec.failed_dst), EF_I("ctr_h", rec.failed_ctr),
                    EF_I("ctr_m", action.ctr_m), EF_I("type", rec.failed_type));
    }
    // ⓘ `DelegCustodyLookup::no_live_rows` falls through SILENTLY and that is the ruled shape: it is the normal
    //   state of every v1-only node (and of a node whose row already ACKed, already forwarded, or expired), so a
    //   diagnostic there would fire behind every ordinary custody receipt.
    // ---- step (5): return. ⛔ No `record_dm`, no `msg_recv`, no E2E ack. The caller calls `become_free()`.
}

// =========================================================================================================
// §remote-admin v2 SLICE 1b (2026-09-06) — CAPABILITY-OWNED PRE-TAIL REMOTE RECEIVE (R-RA-8 / R-RA-19 / R-RA-27).
//
// ★★★ WHAT CHANGED, IN ONE LINE: the ONE shared, UNGATED `REMOTE_CMD || REMOTE_RESP` staging arm became TWO
//     capability-owned entry points selected by a PURE routing decision, and a type whose owner is compiled out is
//     no longer staged at all — it falls to the existing fail-closed internal guard.
//
// ⛔⛔ THIS IS A BEHAVIOUR CHANGE, NOT A NEUTRAL REFACTOR, AND THE OWNER RULED IT (R-RA-27 item 1, M3: MeshRoute is
//     not deployed). Two consequences, both intended and neither a defect to "repair":
//       · a MOBILE (client-only) IGNORES an incoming `REMOTE_CMD` — unowned, guard-dropped, one scalar
//         `unsupported_internal`, no staging into the inert `remote_exec` stub any more. Externally identical:
//         neither shape ever answered (R-RA-27 item 3);
//       · a STATIC/GATEWAY build (accept-only) no longer receives `REMOTE_RESP` — the legacy USB `rcmd` issuer on
//         those nodes stops seeing its replies until Slice 9 deletes that issuer. ⛔ Do NOT restore it with
//         `|| MR_FEAT_REMOTE_MGMT`, a fallback owner or a firmware edit: the design's earlier sentence "under the
//         legacy gate their bodies remain behaviour-identical" is SUPERSEDED for exactly this case. The bodies stay
//         byte-identical WHERE AN OWNER EXISTS; ownership itself follows R-RA-8 strictly.
//
// Both endpoints now require SOURCE_HASH and use bounded role-owned state. The CLIENT replacement
// counts and drops legacy responses; no old-format fallback or silent body clamp remains.
// ⛔ AND THE ORDER IS LOAD-BEARING: this seam stays where the legacy arm stood — BEFORE the SEALED_RELAY and
//   CRYPTED open steps — because a v2 request is RPC-encrypted INSIDE a plaintext-framed DM (design §8). Moving it
//   past the open steps, or moving the fail-closed guard ahead of a forwarding role, is out of scope by ruling.
// =========================================================================================================

// THE PURE DECISION. No state, no `this`, total over the 256 type values. See node.h for why the two capabilities
// arrive as ARGUMENTS rather than as `#if`s read inside: it is the only way the `{1,1}` host binary can execute the
// two disabled-role arms, and R-RA-27 forbids a runtime role gate or a test-only macro override as the alternative.
Node::RadminRxOwner Node::radmin_rx_owner(uint8_t type, bool client_on, bool accept_on)
{
    if (type == DATA_TYPE_REMOTE_CMD)  return accept_on ? RadminRxOwner::command_accept  : RadminRxOwner::none;
    if (type == DATA_TYPE_REMOTE_RESP) return client_on ? RadminRxOwner::response_client : RadminRxOwner::none;
    return RadminRxOwner::none;   // every other type belongs to another handler — this decision never steals one
}




#if MR_FEAT_RADMIN_CLIENT
bool NodeRadminClientCarrier::tx_queue_full() const { return node_.tx_queue_full(); }
RemoteClientSend NodeRadminClientCarrier::submit_request(const RemoteClientRoute& route, RemoteSource,
    const RemoteCarrier&, std::span<const uint8_t> body, bool e2e_ack) {
    return node_.remote_client_submit(route, body, e2e_ack);
}
RemoteClientSend NodeRadminClientCarrier::submit_ack(const RemoteClientRoute& route, RemoteSource,
    const RemoteCarrier&, std::span<const uint8_t> body) {
    return node_.remote_client_submit(route, body, false);
}
RemoteClientSend Node::remote_client_submit(const RemoteClientRoute& route, std::span<const uint8_t> body, bool e2e_ack) {
    if (!_cfg.is_mobile || !mobile_registered()) return RemoteClientSend::unavailable;
    if (tx_queue_full()) return RemoteClientSend::full;
    if (e2e_ack && e2e_ack_ring_full()) return RemoteClientSend::correlation_full;
    const uint8_t flags = e2e_ack ? DATA_FLAG_E2E_ACK_REQ : 0;
    uint16_t ctr = 0;
    if (route.hop_count) {
        ctr = delegate_send_layer(route.target_hash, route.hops, route.hop_count, DATA_TYPE_REMOTE_CMD,
                                  body.data(), static_cast<uint8_t>(body.size()), flags);
        if (!ctr) return RemoteClientSend::unavailable;
    } else {
        SendDispatch dispatch{};
        (void)send_by_hash(route.target_hash, body.data(), static_cast<uint8_t>(body.size()), flags,
            CryptIntent::off, 0, 0, Plane::GLOBAL, DATA_TYPE_REMOTE_CMD, /*suppress_intro=*/true, &dispatch);
        switch (dispatch.admit) {
            case SendDispatch::Admit::queued: ctr = dispatch.ctr; break;
            case SendDispatch::Admit::parked: // the registered-mobile arm precedes parking
            case SendDispatch::Admit::refused: return RemoteClientSend::full;
            case SendDispatch::Admit::none: return RemoteClientSend::unavailable;
        }
    }
    remote_client_carrier_sent(_remote_client, body, ctr);
    return RemoteClientSend::queued;
}
#endif

#if MR_FEAT_RADMIN_ACCEPT
// ACCEPT-OWNED. (⛔ This marker line is LOAD-BEARING, not decoration: `tools/probe_features/ownership.py`'s
// W-OWNER-CMD / W-WIDEN-ACCEPT controls anchor their one-match edit on exactly `#if MR_FEAT_RADMIN_ACCEPT`
// followed by it, so moving or rewording it turns two ownership controls into instrument errors.)
// =========================================================================================================
// §remote-admin v2 SLICE 5 — THE ACCEPT-OWNED v2 ADMISSION, AND IT **REPLACES** THE LEGACY STAGING.
//
// ★★★ WHAT CHANGED, IN ONE LINE: this arm used to call `remote_inbound_stage(pa, ui, false)` — one unconditional
//     246-byte slot keyed on an 8-bit origin, requiring no `SOURCE_HASH` and silently clamping an over-cap body,
//     drained into the legacy `remote_exec` whitelist. It now runs the ruled v2 path: require the source hash,
//     refuse over-cap, decode/authenticate through the Slice 2 codec, classify against the bounded seen table,
//     reserve the partitioned ingress — and, for a BOOTSTRAP alone, answer on air.
//
// ⛔⛔ THIS ENDS TARGET-SIDE LEGACY `rcmd` EXECUTION, AND THE OWNER RULED IT (R-RA-27's hand-off, R-RA-31).
//     There is ⛔ NO FALLBACK: an absent `SOURCE_HASH`, an old-format body, a malformed `ctl` or a failed
//     authentication is REFUSED here and is never retried through `admin_auth`/`remote_exec`. The bench's
//     static/gateway `rcmd` round trip was already SUSPENDED at Slice 1b; Slice 5 is where the receive half is
//     actually removed. Slice 9 deletes the remaining legacy issuer/definitions.
//
// ⛔ WHAT THIS ARM STILL DOES NOT DO (mark done-vs-missing IN CODE):
//     · ⛔ NO EXECUTION and no dispatcher context — the verdict is what Slice 7b/6 act on.
//     · ⛔ NO output/terminal/ACK/rollover/protocol-error reply. `already_acknowledged` and `session_full` are
//       classified and NOT answered; the only frame this slice ever emits is the bootstrap response.
//     · ⛔ NO transcript or deferred-action reservation — those rows do not exist yet (R-RA-22 / 7b).
// =========================================================================================================

// Build the two REAL carrier descriptors: the leg the request ARRIVED on, and the leg an answer would LEAVE on.
// ⛔ Neither is a convenient shape — both are derived from the parsed inner and this node's own layer, because
//   `remote_body_cap` is the ONE capacity authority and it must be asked about the frame that actually exists.
// ⓘ `addr_len` is 0 on BOTH, and that is a fact rather than a default: `PostAck` deliberately carries neither
//   `next` nor `addr_len` (node_carriers.h), and `addr_len` is a HEADER field that costs no inner byte — so it
//   cannot change either cap. Anything that could is read from `pa.flags` / `ui` directly.
void Node::radmin_build_carriers(const PostAck& pa, const data_unicast_inner& ui, RemoteRxInput& in) const
{
    in.request_carrier = RemoteCarrier{};
    in.request_carrier.outer_data_type     = pa.type;
    in.request_carrier.enclosed_type       = 0;
    in.request_carrier.wrapper             = false;   // a home UNWRAPS a MOBILE_SEND before this seam; we see the real type
    in.request_carrier.cross_layer         = ui.has_cross_layer;
    in.request_carrier.path_depth          = ui.has_cross_layer ? ui.n_layers : 0;
    in.request_carrier.path_cursor         = ui.has_cross_layer ? ui.cur      : 0;
    in.request_carrier.addr_len            = 0;
    in.request_carrier.dst_hash_on_wire    = ui.has_dst_hash;
    in.request_carrier.source_hash_on_wire = true;    // checked by the caller BEFORE this is built (R-RA-13)
    in.request_carrier.outer_crypted       = (pa.flags & DATA_FLAG_CRYPTED) != 0;

    // The REPLY leg. Same-layer answers by hash; a cross-layer request is answered on the REVERSED path at the
    // SAME depth with `cur = 1` (`enqueue_cross_layer`'s own origination shape), and it always carries DST_HASH
    // and SOURCE_HASH (node_mac.cpp stamps both unconditionally on that path).
    // The captured RETURN metadata. Same-layer zeroes the path bytes, the count and the cursor; cross-layer
    // retains EVERY validated received field. `origin` is diagnostic and is ⛔ never a reply identity.
    in.route = ReplyRoute{};
    in.route.origin  = pa.origin;
    in.route.carrier = static_cast<uint8_t>(ui.has_cross_layer && ui.n_layers >= 2
                                            ? RadminCarrierKind::cross_layer : RadminCarrierKind::same_layer);
    if (in.route.carrier == static_cast<uint8_t>(RadminCarrierKind::cross_layer)) {
        in.route.n_layers = ui.n_layers;
        in.route.cur      = ui.cur;
        for (uint8_t i = 0; i < ui.n_layers && i < protocol::gw_env_max_hops; ++i)
            in.route.layer_ids[i] = ui.layer_ids[i];
    }
    in.reply_carrier = remote_reply_carrier(in.route);
}

// ONE return-route transmitter, shared by bootstrap and transcript frames. Admission is the
// transport's own fact, never inferred from a counter. Bootstrap trace bytes stay unchanged.
Node::SendDispatch Node::radmin_send_response(uint32_t source_hash, const ReplyRoute& route,
                                            const uint8_t* body, uint8_t len,
                                            [[maybe_unused]] uint8_t slot, bool bootstrap)
{
    SendDispatch dsp{};
    dsp.admit = SendDispatch::Admit::refused;
    // ⛔ THE REPLY DST IS THE CAPTURED, AUTHENTICATED CONTROLLER SOURCE. A zero value is an explicit SEND
    //    FAILURE — ⛔ never a fallback to `pa.origin`, which is an 8-bit local id that aliases across leaves.
    if (source_hash == 0) {
        MR_EMIT("radmin_reply_no_dst", EF_I("slot", slot));
        return dsp;
    }
    if (route.carrier == static_cast<uint8_t>(RadminCarrierKind::cross_layer)) {
        // §6.6 — reverse the captured COMPLETE path ONCE, then validate it. `send_xl_ack`'s PRINCIPLE is reused
        // (a cross-layer answer is a NORMAL send on the reversed path); ⛔ its ACK payload and its type are not.
        const uint8_t n = route.n_layers;
        if (n < 2 || n > protocol::gw_env_max_hops || route.cur >= n) {
            MR_EMIT("radmin_reply_bad_path", EF_I("n_layers", n), EF_I("cur", route.cur));
            return dsp;
        }
        uint8_t rev[protocol::gw_env_max_hops] = {};
        for (uint8_t i = 0; i < n; ++i) rev[i] = route.layer_ids[n - 1 - i];
        // The DESTINATION-side end of the received path must be OUR active layer, and the far ORIGIN end must be
        // a real layer. ⛔ Neither is assumed: a path that does not terminate here cannot be reversed into a
        // return leg, and substituting a same-layer reply for it would answer the wrong node.
        if (rev[0] != active_layer_id() || rev[n - 1] == 0) {
            MR_EMIT("radmin_reply_bad_path", EF_I("rev0", rev[0]), EF_I("mine", active_layer_id()));
            return dsp;
        }
        // ⛔ Only the REVERSED DESTINATION HOPS are handed over: `originate_layer_path` prepends our own layer
        //    as path[0] itself, so passing `rev` whole would duplicate it.
        // Slice 5's rc was trace-only and needed [[maybe_unused]] on device (B169 idiom).
        // 7b-1 consumes it for admission too; it is no longer a device-stripped-only reader.
        uint16_t out_ctr = 0;
        const CmdCode rc = originate_layer_path(source_hash, rev + 1, static_cast<uint8_t>(n - 1),
                                                body, len, /*flags=*/0, out_ctr,
                                                /*type=*/DATA_TYPE_REMOTE_RESP, /*override_source_hash=*/0);
        dsp.admit = rc == CmdCode::queued ? SendDispatch::Admit::queued : SendDispatch::Admit::refused;
        dsp.ctr = out_ctr;
        if (bootstrap) {
            MR_EMIT("radmin_bootstrap_tx", EF_S("leg", "cross_layer"),
                EF_I("slot", slot),
                EF_I("to_hash", static_cast<int64_t>(source_hash)),
                EF_I("queued", rc == CmdCode::queued ? 1 : 0), EF_I("ctr", out_ctr));
        }
    } else {
        // §6.5 — explicit GLOBAL plane, explicit REMOTE_RESP type, `CryptIntent::off`, ZERO optional ACK flags,
        // no delegated override and no INTRO attach. ⛔ THE ADMISSION FACT IS `SendDispatch`, ⛔ not the return
        // value: a non-zero ctr survives a full TX queue and a zero one covers a stored PARK, a full parked ring
        // and a loud refusal alike ([[B333]]). ⛔ `send_by_hash` has NO `app_dm` parameter — that belongs to
        // `do_send`/`enqueue_data`, which this path reaches with `app_dm = true` and therefore stamps our OWN
        // `SOURCE_HASH` (the target's routing identity) and obeys DST_HASH admission.
        (void)send_by_hash(source_hash, body, len, /*flags=*/0, CryptIntent::off,
                           /*reply_to_hash=*/0, /*mobile_ctr=*/0, Plane::GLOBAL,
                           /*type=*/DATA_TYPE_REMOTE_RESP, /*suppress_intro=*/true, &dsp);
        if (bootstrap) {
            MR_EMIT("radmin_bootstrap_tx", EF_S("leg", "same_layer"),
                EF_I("slot", slot),
                EF_I("to_hash", static_cast<int64_t>(source_hash)),
                EF_I("admit", static_cast<int64_t>(dsp.admit)), EF_I("ctr", dsp.ctr));
        }
    }
    return dsp;
}

void Node::radmin_send_reply(RemoteRxResult& res)
{
    if (!res.has_reply) return;
    const SendDispatch dsp = radmin_send_response(res.source_hash, res.route, res.reply, res.reply_len,
                               res.controller_slot, res.verdict == RemoteAdmitVerdict::bootstrap_answered);
    if (dsp.admit != SendDispatch::Admit::queued && dsp.admit != SendDispatch::Admit::parked)
        remote_counter_increment(_radmin_session, RadminCounter::response_enqueue_failure);
    crypto_wipe(res.reply, sizeof res.reply);
    // ⛔ RELEASED ON THE CHECKED OUTCOME, whatever it was. A PARKED copy is transport-owned and is not aired TX
    //    yet; this slice adds ⛔ no application retry scheduler for it (design §7.2: a lost bootstrap response is
    //    recovered by the controller REPEATING the read-only request, which is exactly what makes it safe).
    remote_session_staging_release(_radmin_session, res.staging_index);
}

bool Node::radmin_service_control()
{
    // TX pressure is a defer, not preparation: no entropy draw, encoding, mutation or failure counter.
    if (tx_queue_full()) return false;
    RadminControlView view{};
    if (!remote_control_next(_radmin_session, view)) return false;
    uint8_t completed = 0;
    const auto decision = remote_control_check(_radmin_session, view, completed);
    if (decision == RadminControlDecision::stale) return false;
    const auto counters_before = radmin_counters();
    uint64_t fresh_epoch = 0;
    if (decision == RadminControlDecision::ready) {
        if (!admin_draw_epoch(fresh_epoch)) fresh_epoch = 0;
    }
    uint8_t body[kRemoteOverheadRolloverResult] = {};
    size_t len = 0;
    RemoteSessionInstall plan{};
    bool install = false;
    const RemoteStatus encoded = remote_control_prepare(_radmin_session, view, fresh_epoch, body, len, plan, install);
    if (encoded != RemoteStatus::ok) {
        remote_counter_increment(_radmin_session, RadminCounter::response_seal_failure);
        remote_control_release(_radmin_session, view);
    } else {
        // The entire reply exists under the old base/session credentials before the non-failing install.
        // A lost reply cannot resurrect old work; the controller recovers with read-only bootstrap.
        if (install) admin_session_commit(plan);
        else remote_control_release(_radmin_session, view);
        const SendDispatch dsp = radmin_send_response(view.source_hash, view.route, body, static_cast<uint8_t>(len),
                                                      view.slot, /*bootstrap=*/false);
        if (dsp.admit != SendDispatch::Admit::queued && dsp.admit != SendDispatch::Admit::parked)
            remote_counter_increment(_radmin_session, RadminCounter::response_enqueue_failure);
    }
    crypto_wipe(body, sizeof body);
    crypto_wipe(&plan, sizeof plan);
    crypto_wipe(&fresh_epoch, sizeof fresh_epoch);
    radmin_report_counters(counters_before);
    radmin_expiry_arm();
    return true;
}

RadminSend Node::radmin_send_open_frame()
{
    if (tx_queue_full()) return RadminSend::none;
    const uint8_t i = remote_open_next(_radmin_session);
    if (i == kRadminNoSlot) return RadminSend::none;
    const auto counters_before = radmin_counters();
    uint8_t body[kRadminBodyBytes] = {};
    size_t len = 0;
    const RemoteStatus encoded = remote_open_encode(_radmin_session, i, body, len);
    if (encoded != RemoteStatus::ok || len > sizeof body) {
        crypto_wipe(body, sizeof body);
        remote_counter_increment(_radmin_session, RadminCounter::response_seal_failure);
        radmin_report_counters(counters_before);
        return RadminSend::refused;
    }
    const auto& row = _radmin_session.staging[i];
    const SendDispatch dsp = radmin_send_response(row.peer_source_hash, row.route, body, static_cast<uint8_t>(len),
                                                  kRadminNoSlot, /*bootstrap=*/false);
    crypto_wipe(body, sizeof body);
    if (dsp.admit == SendDispatch::Admit::queued || dsp.admit == SendDispatch::Admit::parked) {
        remote_open_sent(_radmin_session, i);
        return dsp.admit == SendDispatch::Admit::queued ? RadminSend::queued : RadminSend::parked;
    }
    remote_counter_increment(_radmin_session, RadminCounter::response_enqueue_failure);
    radmin_report_counters(counters_before);
    return RadminSend::refused;
}

RadminSend Node::radmin_send_frame()
{
    if (tx_queue_full()) return RadminSend::none;
    const uint8_t si = remote_transcript_next(_radmin_session);
    if (si == kRadminNoSlot) return RadminSend::none;
    uint8_t body[kRadminBodyBytes] = {};
    size_t len = 0;
    const RemoteStatus encoded = remote_transcript_encode(_radmin_session, si, body, len);
    if (encoded != RemoteStatus::ok || len > sizeof(body)) {
        crypto_wipe(body, sizeof(body));
        // B374: completion freezes the result; a later seal refusal must never substitute
        // another plaintext in its nonce space. Leave this pending sequence for the next pass.
        if (_radmin_session.response_seal_failure != UINT16_MAX)
            ++_radmin_session.response_seal_failure;
        MR_EMIT("radmin_response_seal_failure", EF_I("count", _radmin_session.response_seal_failure));
        return RadminSend::refused; // no transport attempt, hence no enqueue-failure accounting
    }
    const auto& e = _radmin_session.seen[si];
    const SendDispatch dsp = radmin_send_response(e.record.source_hash, e.route, body, static_cast<uint8_t>(len),
                                                  e.record.controller_slot, /*bootstrap=*/false);
    crypto_wipe(body, sizeof(body));
    if (dsp.admit == SendDispatch::Admit::queued || dsp.admit == SendDispatch::Admit::parked) {
        remote_action_owned(_radmin_session, si, _hal.now()); // first scheduled TERMINAL ownership only
        remote_transcript_sent(_radmin_session, si);
        radmin_expiry_arm();
        return dsp.admit == SendDispatch::Admit::queued ? RadminSend::queued : RadminSend::parked;
    }
    if (_radmin_session.response_enqueue_failure != UINT16_MAX)
        ++_radmin_session.response_enqueue_failure;
    MR_EMIT("radmin_response_enqueue_failure", EF_I("count", _radmin_session.response_enqueue_failure));
    return RadminSend::refused;
}

// THE ACCEPT ENTRY POINT. A v2 remote command addressed to us.
void Node::rx_remote_cmd_accept(const PostAck& pa, const data_unicast_inner* ui)
{
    const auto counters_before = radmin_counters();
    // ★★ R-RA-13, DISCHARGED: `SOURCE_HASH` is MANDATORY on every RPC carrier. A frame whose standard unicast
    //    parse failed, or which carries no source hash, is REFUSED — ⛔ never keyed on `pa.origin` instead.
    if (!ui || !ui->has_source_hash) {
        remote_counter_increment(_radmin_session, RadminCounter::inbound_refusal);
        radmin_report_counters(counters_before);
        MR_EMIT("radmin_rx_refused", EF_S("verdict", "silent_no_source"), EF_I("origin", pa.origin));
        return;
    }
    RemoteRxInput in{};
    in.now_ms     = _hal.now();
    in.outer_type = pa.type;
    in.body       = ui->body;
    in.source     = RemoteSource{ /*present=*/true, ui->source_hash };
    in.reply_permitted = !tx_queue_full();
    radmin_build_carriers(pa, *ui, in);

    RemoteRxResult res{};
    remote_session_receive(_radmin_session, in, res);
    MR_EMIT("radmin_rx", EF_S("verdict", remote_admit_name(res.verdict)),
            EF_I("slot", res.controller_slot),
            EF_I("src_hash", static_cast<int64_t>(res.source_hash)),
            EF_I("seen", res.seen_index), EF_I("ingress", res.ingress_index));
    radmin_send_reply(res);      // only fully encoded bootstrap/admission/protocol replies reach the sender
    // R-RA-49: carrier ownership only after the authenticated admission/replay boundary.
    if ((pa.flags & DATA_FLAG_E2E_ACK_REQ) &&
        (res.verdict == RemoteAdmitVerdict::admit || res.verdict == RemoteAdmitVerdict::replay_transcript ||
         res.verdict == RemoteAdmitVerdict::already_acknowledged)) {
        if (pa.flags & DATA_FLAG_CROSS_LAYER) send_xl_ack(*ui, pa.ctr);
        else send_e2e_ack(pa.origin, pa.ctr, ui->source_hash);
    }
    radmin_report_counters(counters_before);
    // Recompute the earliest deadline from CURRENT rows after every classified intake, including refusals.
    // Refusal accounting can change counters; open intake may also expire older staging/capture pairs before
    // refusing, so the remaining rows can require a different expiry deadline.
    radmin_expiry_arm();
}
#endif

#if MR_FEAT_RADMIN_ACCEPT || MR_FEAT_RADMIN_CLIENT
// One timer and one snapshot serve the bounded records of the compiled product profile.
void Node::radmin_expiry_arm() {
    const uint64_t now = _hal.now();
    uint64_t earliest = ~uint64_t{0};
    bool armed = false;
#if MR_FEAT_RADMIN_ACCEPT
    earliest = remote_session_earliest_deadline(_radmin_session);
    armed = _radmin_session.action.phase == RemoteActionPhase::armed;
#endif
#if MR_FEAT_RADMIN_CLIENT
    const auto left = remote_client_next_expiry(_remote_client, static_cast<uint32_t>(now));
    if (left != UINT32_MAX) {
        const uint64_t client_due = now + left;
        if (client_due < earliest) earliest = client_due;
    }
#endif
    if (earliest == ~uint64_t{0} && !armed) { _hal.cancel(kRadminExpiryTimerId); return; }
    (void)_hal.after(earliest > now ? static_cast<uint32_t>(earliest - now) : 0, kRadminExpiryTimerId);
}
void Node::radmin_expiry_fire() {
    const uint64_t now = _hal.now();
#if MR_FEAT_RADMIN_ACCEPT
    const uint8_t released = remote_session_expire(_radmin_session, now);
    if (released) MR_EMIT("radmin_expired", EF_I("rows", released));
#endif
#if MR_FEAT_RADMIN_CLIENT
    remote_client_expire(_remote_client, static_cast<uint32_t>(now));
#endif
    radmin_expiry_arm();
}
#endif

#if MR_FEAT_RADMIN_CLIENT
// CLIENT-OWNED. Addressed responses enter only the captured controller request, never the app inbox.
void Node::rx_remote_resp_client(const PostAck& pa, const data_unicast_inner* ui) {
    const auto before = _remote_client.counters;
    RemoteCarrier carrier{};
    carrier.outer_data_type = pa.type;
    if (ui) {
        carrier.cross_layer = ui->has_cross_layer;
        carrier.path_depth = ui->has_cross_layer ? ui->n_layers : 0;
        carrier.path_cursor = ui->has_cross_layer ? ui->cur : 0;
        carrier.dst_hash_on_wire = ui->has_dst_hash;
        carrier.source_hash_on_wire = ui->has_source_hash;
        carrier.outer_crypted = (pa.flags & DATA_FLAG_CRYPTED) != 0;
    }
    remote_client_receive(_remote_client, pa.type, ui ? ui->body : std::span<const uint8_t>{},
                          {ui && ui->has_source_hash, ui ? ui->source_hash : 0}, carrier,
                          static_cast<uint32_t>(_hal.now()));
    if (_remote_client.counters.unmatched_response != before.unmatched_response)
        MR_EMIT("radmin_client_drop", EF_S("reason", "unmatched_response"));
    if (_remote_client.counters.auth_failure != before.auth_failure)
        MR_EMIT("radmin_client_drop", EF_S("reason", "auth_failure"));
    if (_remote_client.counters.assembly_failure != before.assembly_failure)
        MR_EMIT("radmin_client_drop", EF_S("reason", "assembly_failure"));
    radmin_expiry_arm();
}
#endif

void Node::do_post_ack() {
    if (!_active->_post_ack.pending) return;
    const PostAck pa = _active->_post_ack;
    _active->_post_ack.pending = false;
    // B161: one canonical plaintext-unicast parse serves both destination consumers and relay snoops. A typed answer
    // without this envelope may complete its hop exchange, but it earns no semantic state change.
    auto ui = parse_unicast_inner(std::span<const uint8_t>(pa.inner, pa.inner_len), pa.flags);
    if (!pa.is_forward) {
        // The optional DST_HASH prefix + cross-layer path are read from pa.flags by the shared parse above.
        // §mobile delegated hash-locate (2026-07-11): a hosted mobile handed us (its home) a PLAINTEXT payload to send to
        // ui->dst_key_hash32 (the target). RE-ORIGINATE via send_by_hash (existing resolve/park machinery), stamping
        // SOURCE_HASH = the requesting mobile's hash (ui->source_hash) so the target's E2E-ack routes back to the MOBILE,
        // not us. VERIFY source_hash is one of OUR mobiles (else the reply couldn't return here + reject a spoof). Checked
        // BEFORE the last-mile fork so a MOBILE_SEND wrapper is never forwarded verbatim. _mobile_reg_n>0 -> non-host inert.
        // ★★★ R-RA-25 / [[B296]] SHAPE 2 — **A MOBILE WRAPPER WITHOUT ITS MANDATORY SOURCE HASH IS REFUSED HERE,
        //   NOT DELIVERED.** The fork below REQUIRES `has_source_hash` (it is the delegation identity: whose reply
        //   this home must last-mile, and whose spoof it must reject). When the field was absent the fork was simply
        //   SKIPPED — and because `DATA_TYPE_MOBILE_SEND` is APPLICATION-bearing (`frame_codec.h`, `internal =
        //   false`), the fail-closed unknown-internal guard below (`data_type_traits(pa.type).internal`) does not catch it either. So the wrapper
        //   fell all the way to the ORDINARY DELIVERY TAIL and the raw wrapper body was `record_dm`'d + `msg_recv`'d
        //   into THIS HOME'S OWN INBOX, from the mobile's local id, with `sender_hash = 0`. The mobile saw `queued`
        //   and a link ACK; the target saw nothing; no `send_failed` anywhere. The sender-side half is fixed in
        //   `enqueue_data` (SOURCE_HASH is now unconditional), and THIS is the receiver-side half — the two are
        //   independent, because a malformed wrapper can also arrive from a peer this node does not control.
        // ⛔ SCOPE, STATED: `pa.type == DATA_TYPE_MOBILE_SEND` and `_mobile_reg_n > 0` — the HOME-CONSUMER boundary
        //   only, inside the `!pa.is_forward` (we are the destination) block, so a TRANSIT relay is untouched and a
        //   non-host node is byte-identical. It does NOT alter the hosted last mile: that fork serves ORDINARY DMs
        //   addressed to a mobile we host, and a MOBILE_SEND wrapper was never a legal payload for it (the note
        //   above: *"a MOBILE_SEND wrapper is never forwarded verbatim"*) — refusing is the completion of that rule,
        //   not an exception to it. ⛔ `ui->has_dst_hash` is deliberately NOT hoisted into this guard: R-RA-25 rules
        //   on the SOURCE hash, and widening the refusal is a separate decision (C1).
        // ⓘ ONE named, SCALAR-ONLY emit and `become_free()`. No body telemetry (the delivery tail's `payload` field
        //   is precisely what must not be reproduced on a refusal path), no Push, no record, no synthetic lifecycle,
        //   no change to the type-trait table or to the fail-closed guard.
        if (pa.type == DATA_TYPE_MOBILE_SEND && _active->_mobile_reg_n > 0 && !(ui && ui->has_source_hash)) {
            MR_EMIT("mobile_send_no_source_hash", EF_I("origin", pa.origin), EF_I("dst", pa.dst), EF_I("ctr", pa.ctr));
            become_free();
            return;
        }
        if (pa.type == DATA_TYPE_MOBILE_SEND && _active->_mobile_reg_n > 0 && ui && ui->has_dst_hash && ui->has_source_hash) {
            // ★★★ §MH-S5-FIX2 (owner-ruled 2026-08-10, ledger §1.14) — **"OURS" IS A LIVE DIRECT ROW, NOT A HASH MATCH.**
            // This scan had NO row-kind test at all, so a redirect or expired row licensed full UPSTREAM DELEGATION
            // (re-origination on the mobile's behalf, under its SOURCE_HASH) from a home that had already recorded the
            // mobile moving away — the same *"identity is the whole tuple"* defect [[B172]] closed at the roster, the
            // last mile and both coverage readers.
            // ⛔⛔ §MH-S5-FIX's justification for leaving it — *"the mobile is physically in range if it is asking"* —
            //   IS WITHDRAWN AND WAS FALSE: a mobile delegates through the ordinary ROUTED `do_send` to its home
            //   (`node_channel.cpp` `do_send_channel_delegated`, `node_hashlocate.cpp` `send_by_hash`), so a
            //   MOBILE_SEND reaches this home over an arbitrary number of hops. ⚠ An inference about radio range is
            //   never a substitute for the recorded state.
            // ★★ AND THE SECOND CONSEQUENCE IS WHY IT COULD NOT BE LEFT: on a re-origination failure the arms below
            //   call `presence_mark_deleg_fail()`, which set the one-shot on the REDIRECT row — and [[B172]]'s roster
            //   filter means no roster will ever carry it, so the failure became UNREPORTABLE and its absence read as
            //   success. Refusing here is what stops that bit ever being aimed at an unadvertised row (and
            //   `presence_mark_deleg_fail` now refuses it a second time, at the setter).
            // ⓘ CONSEQUENCE, STATED: a refused wrapper falls to the `become_free(); return;` below — the same silent
            //   drop a SPOOFED `source_hash` has always taken. ⛔ No new emit and no "forward it to `redirect_home_id`"
            //   shortcut: neither is asked for by any spec section here, and C1 keeps both out of a corrective slice.
            //   The mobile's own retry / E2E-ack deadline is the backstop, and its CURRENT home is what owes it a
            //   `deleg_fail` signal — this home cannot deliver one it may no longer roster.
            bool ours = false;
            for (uint8_t i = 0; i < _active->_mobile_reg_n; ++i)
                if (_active->_mobile_reg[i].key_hash32 == ui->source_hash && host_row_live_direct(i)) { ours = true; break; }
            const bool reserved_reverse_ack = (pa.flags & DATA_FLAG_E2E_ACK_REQ) != 0;
            // §B278 S1b F6: each of this lambda's four fire sites states its OWN release cause; the helper cannot
            // infer one (a bad XL path and a spoofed source leave byte-identical rows).
            auto release_reverse_ack = [&](DelegAckReleaseCause cause) {
                if (reserved_reverse_ack)
                    deleg_ack_release(ui->source_hash, pa.ctr, DelegAckPeer::key_hash,
                                      ui->dst_key_hash32, active_layer_id(), cause);
            };
            if (ours && (pa.flags & DATA_FLAG_MS_ENCLOSED_TYPE) && ui->body.size() >= 2 && ui->body[0] == DATA_TYPE_CHANNEL_POST) {
                // §S7 T-B: a delegated GLOBAL/leaf channel post. Body = [DATA_TYPE_CHANNEL_POST][channel_id][text].
                // Re-originate via do_send_channel under OUR OWN origin/ctr (the home mints; the wrapper's DST_HASH =
                // the mobile's own hash is a placeholder — never used here). Anti-spam bills the HOME + our self-GATE
                // applies (deliberate: hosting implies consenting to the mobile's channel share).
                release_reverse_ack(DelegAckReleaseCause::carrier_ineligible);   // channel posts do not use the delegated DM E2E map
                do_send_channel(ui->body[1], ui->body.data() + 2, static_cast<uint8_t>(ui->body.size() - 2));
                become_free();
                return;
            }
            if (ours && ui->has_cross_layer) {
                // §S1: a CROSS_LAYER delegation. The wrapper carries the DEST path (user hops) + an enclosed-type body
                // prefix. Prepend OUR layer + re-validate fail-loud (== the node.cpp send_layer rules), then originate via
                // the explicit-path machinery stamping SOURCE_HASH = the mobile (so the far recipient's ack routes back
                // here) + the ctr_H->ctr_M map so the ack reaches the mobile with its own ctr (§GapB p2). enclosed_type
                // (0 = plain DM, E2E_ACK = a delegated ack) is threaded through as the re-originated frame TYPE (§1b-4).
                const uint8_t  etype   = ui->body.size() >= 1 ? ui->body[0] : 0;
                const uint8_t* payload = ui->body.size() >= 1 ? ui->body.data() + 1 : nullptr;
                const uint8_t  plen    = ui->body.size() >= 1 ? static_cast<uint8_t>(ui->body.size() - 1) : 0;
                bool valid = ui->n_layers >= 1 && ui->n_layers <= protocol::gw_env_max_hops - 1
                             && ui->layer_ids[0] != active_layer_id();   // 1 + n_layers must fit; hops[0] != our own layer
                for (uint8_t i = 0; valid && i < ui->n_layers; ++i) if (ui->layer_ids[i] == 0) valid = false;
                if (!valid) {
                    release_reverse_ack(DelegAckReleaseCause::invalid_path);
                    MR_EMIT("xl_delegate_bad_path", EF_I("n", ui->n_layers), EF_I("m", static_cast<int64_t>(ui->source_hash)));
                    presence_mark_deleg_fail(ui->source_hash);   // §B2: signal the mobile via the next roster's deleg_fail bit
                } else {
                    uint16_t hctr = 0;
                    const uint8_t reflags = (etype == DATA_TYPE_E2E_ACK) ? 0
                                            : static_cast<uint8_t>(pa.flags & (DATA_FLAG_E2E_ACK_REQ | DATA_FLAG_PRIORITY));
                    const CmdCode code = originate_layer_path(ui->dst_key_hash32, ui->layer_ids, ui->n_layers,
                                                              payload, plen, reflags, hctr,
                                                              /*type=*/etype, /*override_source_hash=*/ui->source_hash);
                    if (code == CmdCode::queued) {
                        if (etype != DATA_TYPE_E2E_ACK && reserved_reverse_ack) {
                            // ⛔ §B278 S1b §4.3 ACK-ONLY ARM 3 of 4 — the WRAPPER'S OWN CROSS-LAYER BRANCH. §5(6)
                            //    excludes it outright, and the reservation already knew (`ui->has_cross_layer` is
                            //    parsed before the hop ACK), so this row was born `none` and is CONFIRMED `none`
                            //    here from the arm's own final type. ACK obligation kept, custody never granted.
                            if (!deleg_ack_put(ui->source_hash, hctr, pa.ctr,
                                              DelegAckPeer::key_hash, ui->dst_key_hash32,
                                              DelegAckPeer::key_hash, ui->dst_key_hash32, active_layer_id(),
                                              /*outward_type=*/etype,   // §B278 S1a: the re-originated frame's TYPE
                                              deleg_custody_activate_verdict(/*arm_carries_custody=*/false, etype)))
                                presence_mark_deleg_fail(ui->source_hash);
                        }
                    } else {
                        release_reverse_ack(DelegAckReleaseCause::dispatch_refused);
                        MR_EMIT("xl_delegate_no_route", EF_I("m", static_cast<int64_t>(ui->source_hash)), EF_I("code", static_cast<int>(code)));
                        presence_mark_deleg_fail(ui->source_hash);   // §B2: signal the mobile via the next roster's deleg_fail bit
                    }
                }
                become_free();
                return;
            }
            if (ours) {
                // §S2: a SAME-LAYER delegated send. Default = a plain re-origination (byte-identical). If the wrapper
                // set DATA_FLAG_MS_ENCLOSED_TYPE, its body is [enclosed_type:1][payload] (a delegated INTRO): strip the
                // marker + the type byte, and re-originate with that TYPE (send_by_hash type=etype -> no re-attach, the
                // key prefix rode from the mobile). The reply routes back by SOURCE_HASH -> our proxy -> last-mile;
                // mobile_ctr -> the ctr_H->ctr_M reverse-ack map so the target's E2E-ack reaches the mobile with ITS ctr.
                const uint8_t* wb = ui->body.data(); uint8_t wl = static_cast<uint8_t>(ui->body.size()); uint8_t etype = 0;
                uint8_t reflags = pa.flags & (DATA_FLAG_E2E_ACK_REQ | DATA_FLAG_PRIORITY);   // plain path: unchanged (byte-identical)
                if ((pa.flags & DATA_FLAG_MS_ENCLOSED_TYPE) && wl >= 1) {
                    etype = wb[0]; wb += 1; wl = static_cast<uint8_t>(wl - 1);
                    reflags = pa.flags & DATA_FLAG_E2E_ACK_REQ;                              // strip the marker from the re-originated flags
                }
                // B251 QG: the minted counter is not admission authority — enqueue_data returns it even when its
                // queue is full. send_by_hash consumes this dispatch to emit/activate only for a STORED outward item,
                // retain a genuine park, or release the pre-ACK reservation on refusal.
                SendDispatch dispatch{};
                (void)send_by_hash(ui->dst_key_hash32, wb, wl, reflags, CryptIntent::off,
                                   /*reply_to_hash=*/ui->source_hash, /*mobile_ctr=*/pa.ctr, Plane::AUTO, /*type=*/etype,
                                   /*suppress_intro=*/false, &dispatch);   // plaintext-only (v1)
            } else {
                release_reverse_ack(DelegAckReleaseCause::source_not_owned);   // spoofed/stale source: no later resolver can consume it
            }
            become_free();
            return;
        }
        // §mobile 3a: HOST last-mile forward — a DM addressed to ME whose inner dst_hash is a mobile I HOST -> re-address it
        // to the mobile's LOCAL id with the addr_len=1 mark (Slice 1). The inner rides VERBATIM (E2E-sealed to the mobile;
        // the host re-addresses, never decrypts — like the cross-layer bridge). Gated on _mobile_reg_n>0 -> a non-host is
        // byte-identical. Runs BEFORE the cross-layer/H-answer/deliver forks (the DM's dst_hash != our key routed us here as proxy).
        if (ui && ui->has_dst_hash && ui->dst_key_hash32 != _key_hash32 && _active->_mobile_reg_n > 0) {
            for (uint8_t i = 0; i < _active->_mobile_reg_n; ++i) {
                if (_active->_mobile_reg[i].key_hash32 == ui->dst_key_hash32) {
                    // ★★★ §MH-S5-FIX [[B172]] — spec §9.2: *"redirect rows never RESERVE LAST-MILE SERVICE"*. A hash
                    // match alone is NOT hosting: the row's identity is `(hash, local_id, direct-vs-redirect)`, and a
                    // redirect row's `mobile_local_id` names an id AT THIS HOME where the mobile no longer is — so
                    // re-addressing to it aired a 1-hop DM at a mobile that had moved away. The expired half comes
                    // with the shared predicate (§9.1/[[B173]]).
                    // ⓘ CONSEQUENCE, STATED because it is a behaviour path and not just a refusal: the DM now falls
                    //   through to the ordinary forks below. For a plain DM that is `l2c_handle_misdelivery`, which
                    //   PARKS it and floods a HARD H for the hash — i.e. the sender's traffic follows the mobile via
                    //   the hash plane, which is exactly the mechanism §9.2 keeps the redirect alive FOR (the H answer
                    //   at `node_hashlocate.cpp` reads `redirect_home_id` first and is deliberately not liveness-
                    //   gated). ⛔ A direct "forward it to `redirect_home_id`" shortcut was NOT added here: that is new
                    //   behaviour no spec section asks for at this site, and C1 keeps it out of a corrective slice.
                    if (!host_row_live_direct(i)) continue;
                    if (_active->_tx_queue_n < kTxQueueCap) {              // best-effort (match the bridge: drop if full)
                        TxItem it{};
                        it.origin     = pa.origin;                        // PRESERVE the real originator (anti-spam)
                        it.dst        = _active->_mobile_reg[i].mobile_local_id;
                        it.addr_len   = 1;                                // §mobile: next is a mobile local-id (Fix 1 -> RTS mark)
                        it.mobile_src = false;                            // a host forward, NOT a mobile origination
                        it.is_forward = true;
                        it.ctr = pa.ctr; it.ctr_lo = pa.ctr_lo;           // carry the flight id
                        it.flags = pa.flags; it.type = pa.type;
                        it.inner_len = pa.inner_len;
                        for (uint8_t j = 0; j < pa.inner_len; ++j) it.inner[j] = pa.inner[j];   // inner VERBATIM (E2E-sealed)
                        // §GapB p2: a DELEGATED-send ack arrives here addressed to the mobile (DST_HASH=M). It carries
                        // ctr_H (the home's re-origination ctr); the mobile awaits ctr_M. Rewrite the 2-B body in place
                        // via the (mobile_hash, ctr_H)->ctr_M map (keying by hash, NOT the acker id — XL ids alias). A
                        // map miss (a DIRECT send, or a plain DM) leaves the bytes verbatim. Covers same-layer AND XL acks.
                        if (pa.type == DATA_TYPE_E2E_ACK && ui->body.size() >= 2) {
                            const uint16_t acked = static_cast<uint16_t>(ui->body[0] | (ui->body[1] << 8));
                            uint16_t m_ctr = acked;
                            const bool xl_ack = (pa.flags & DATA_FLAG_CROSS_LAYER) != 0
                                             && ui->has_source_hash && ui->source_hash != 0;
                            const DelegAckPeer return_kind = xl_ack ? DelegAckPeer::key_hash : DelegAckPeer::node_id;
                            const uint32_t return_peer = xl_ack ? ui->source_hash : pa.origin;
                            if (deleg_ack_translate(ui->dst_key_hash32, acked, return_kind,
                                                   return_peer, active_layer_id(), m_ctr)) {
                                const size_t boff = static_cast<size_t>(ui->body.data() - pa.inner);
                                if (boff + 1 < sizeof it.inner) {
                                    it.inner[boff]     = static_cast<uint8_t>(m_ctr & 0xFF);
                                    it.inner[boff + 1] = static_cast<uint8_t>(m_ctr >> 8);
                                }
                                // §B278 S1b F6: `mobile_hash` + `ctr_h` are APPENDED (existing fields keep their
                                // names and order). Both are already live here — `ui->dst_key_hash32` is the mobile
                                // whose row just translated, `acked` is the home counter it was keyed by — so the
                                // offline census can bind a reverse ACK to its row DIRECTLY instead of going through
                                // the registration authority, which could not decide a re-used local id.
                                MR_EMIT("mobile_reverse_ack", EF_I("local", it.dst), EF_I("ctr", m_ctr),
                                        EF_I("mobile_hash", static_cast<int64_t>(ui->dst_key_hash32)),
                                        EF_I("ctr_h", acked));
                            }
                        }
                        _active->_tx_queue[_active->_tx_queue_n++] = it;
                        MR_EMIT("mobile_lastmile_fwd", EF_I("local", it.dst), EF_I("origin", it.origin));
                    }
                    become_free();
                    return;                                              // handled -> do NOT fall into bridge/H-answer/deliver
                }
            }
        }
        // Slice 4c.1 (the bridge KEYSTONE): a CROSS_LAYER DM in TRANSIT through this gateway -> BRIDGE it to the next
        // layer BEFORE any type-based consume (so a 4e cross-layer E2E-ack passing through bridges, not gets consumed).
        // dst_hash == our key => we ARE the recipient: fall through to the normal handling (E2E-ack confirm / deliver to
        // inbox). A malformed CROSS_LAYER inner is REFUSED (drop) — its layer-path bytes must never reach the app as body.
        if (pa.flags & DATA_FLAG_CROSS_LAYER) {
            if (!ui || !ui->has_cross_layer) { become_free(); return; }
            if (!(ui->has_dst_hash && ui->dst_key_hash32 == _key_hash32)) { bridge_cross_layer(pa, *ui); return; }
        }
        if (pa.type == DATA_TYPE_MOBILE_H_ANSWER) {   // §mobile 4a: a mobile-proxy answer -> cache M->home only (NO id_bind, NO deliver)
            if (ui && canonical_typed_answer_body_valid(pa.type, ui->body))
                on_mobile_hash_bind_response(ui->body.data(), static_cast<uint8_t>(ui->body.size()));
            become_free();
            return;
        }
        if (pa.type == DATA_TYPE_MOBILE_H_ANSWER_PUBKEY) {   // §mobile Part 2 Fix 8: a home's WANT_PUBKEY answer -> cache peer_key(M) + M->home (NO id_bind, NO deliver)
            if (ui && canonical_typed_answer_body_valid(pa.type, ui->body))
                on_mobile_hash_bind_pubkey_response(ui->body.data(), static_cast<uint8_t>(ui->body.size()));
            become_free();
            return;
        }
        if (pa.type == DATA_TYPE_MOBILE_BREADCRUMB) {   // §mobile 4b: a moved mobile's redirect note -> record it against my _mobile_reg[M]
            if (ui && ui->has_source_hash && ui->body.size() >= 3 && _active->_mobile_reg_n > 0)
                for (uint8_t i = 0; i < _active->_mobile_reg_n; ++i)
                    if (_active->_mobile_reg[i].key_hash32 == ui->source_hash) {   // attribute: only M can move M (SOURCE_HASH)
                        _active->_mobile_reg[i].redirect_home_id    = ui->body[0];
                        _active->_mobile_reg[i].redirect_epoch      = ui->body[1];
                        _active->_mobile_reg[i].redirect_home_layer = ui->body[2];   // §5b: the new home's LAYER
                        // ★★ §MH-S5 §9.2 — **"STAMP THE ROW'S LIFETIME CLOCK AT BREADCRUMB RECEIPT."** The row has
                        // just changed KIND (direct -> redirect) and §9.2 gives the redirect its own full
                        // `mobile_liveness_ms` from *this* moment, so stale senders holding the 5-minute mobile-home
                        // cache have a bounded window to follow it. `last_heard_ms` IS the row's lifetime clock and
                        // `mobile_reg_age_out()` applies one predicate to both kinds (node_join.cpp) — ⛔ a second
                        // `redirect_stamp_ms` member was declined there (8 B × 16 × MR_N_LAYERS ⇒ D2).
                        // ⓘ SAFE FOR THE PROXY GATE, checked not assumed (V1, `node_hashlocate.cpp`): the H-answer
                        //   tests `redirect_home_id != 0` FIRST and that arm is deliberately NOT liveness-gated, so a
                        //   fresher stamp can never resurrect a DIRECT proxy answer for a row that now redirects.
                        _active->_mobile_reg[i].last_heard_ms       = _hal.now();
                        // ★★ §MH-S5-FIX2 finding C — **CLEAR THE `deleg_fail` ONE-SHOT WHEN THE ROW CHANGES KIND.**
                        // The bit is a promise to tell the mobile, on the NEXT ROSTER, that a delegated send was
                        // dropped ([[B172]]'s §B2 one-shot). This row has just stopped being advertised at all, so the
                        // promise can no longer be kept and the bit would sit here until a re-CLAIM or expiry.
                        // ⛔ §MH-S5-FIX called that *"self-clearing"*; that word is WITHDRAWN — nothing clears it.
                        // ★ It also closes a RACE the setter's own refusal cannot: delegation accepted while the row
                        //   was still DIRECT, this breadcrumb arriving BEFORE the failure was recorded. Both orders now
                        //   end with the bit clear.
                        _active->_mobile_reg[i].deleg_fail         = false;
                        MR_EMIT("mobile_redirect_recorded", EF_I("m", i), EF_I("to", ui->body[0]), EF_I("epoch", ui->body[1]));
                        break;
                    }
            become_free(); return;   // consumed (routing info, NOT delivered/inbox'd); no match / non-host -> just drop
        }
        // §S6: DATA_TYPE_MOBILE_PUBKEY_PUSH (0x94, ordinal 12 before the §CUSTODY-A namespace transition) is RETIRED —
        // key custody now rides the presence probe's HAS_PUBKEY block (presence_ingest_probe), confirmed by the roster's
        // has_key bit. No mobile emits it any more, and its handler was deleted, so an addressed one has NO arm here.
        // ⛔ CORRECTED 2026-08-29 (A0-F10b): this used to call that fall-through "harmless". IT IS NOT. There is no
        // default arm in this dispatch, so the frame reaches the generic deliver tail below and its 32 RAW KEY BYTES are
        // record_dm'd and msg_recv-pushed to the app AS MESSAGE TEXT (characterized by test §A0-4). The fleet reflashing
        // together is why it is not reachable in practice — it is not why it would be safe. Slice B's fail-closed
        // internal-range arm is what actually makes it a drop.
        if (pa.type == DATA_TYPE_MOBILE_LAYER_QUERY && _cfg.n_layers == 2 && ui && ui->has_source_hash) {   // §mobile 5a: a mobile asks THIS gateway for its bridged layers
            uint8_t body[protocol::max_payload_bytes_hard_cap]; uint8_t off = 1; body[0] = 0;   // [count][records…]
            uint8_t cnt = 0;
            for (uint8_t i = 0; i < _cfg.n_layers; ++i) {
                LayerRecord r{};
                r.layer_id = _cfg.layers[i].layer_id; r.sf = _cfg.layers[i].routing_sf;
                r.freq_khz = protocol::mhz_to_khz(_cfg.layers[i].freq_mhz);
                r.bw_hz = _cfg.layers[i].bw_hz ? _cfg.layers[i].bw_hz : _cfg.radio_bw_hz;
                r.name_len = _cfg.leaf_name_len;
                for (uint8_t k = 0; k < r.name_len && k < protocol::leaf_name_max; ++k) r.name[k] = _cfg.leaf_name[k];
                const size_t n = pack_layer_record(r, std::span<uint8_t>(body + off, sizeof(body) - off));
                if (n == 0) break;
                off = static_cast<uint8_t>(off + n); ++cnt;
            }
            body[0] = cnt;
            // reply to origin (=home_id) with dst_hash=M -> the home last-mile-forwards it to the mobile (reuse the mobile-delivery path)
            (void)enqueue_data(pa.origin, body, off, DATA_FLAG_DST_HASH, "mobile_layer_answer",
                               /*app_dm=*/false, DATA_TYPE_MOBILE_LAYER_ANSWER, CryptIntent::off, /*override_dst_hash=*/ui->source_hash);
            MR_EMIT("mobile_layer_answer_tx", EF_I("to", pa.origin), EF_I("count", cnt));
            become_free(); return;
        }
#if MR_FEAT_MOBILE
        if (pa.type == DATA_TYPE_MOBILE_LAYER_ANSWER && _cfg.is_mobile) {   // §mobile 5a: the mobile ingests the learned layer directory
            if (ui) learned_layers_ingest(ui->body.data(), ui->body.size());
            become_free(); return;
        }
        if (pa.type == DATA_TYPE_MOBILE_KEY_FORWARD && _cfg.is_mobile) {   // §S3 part2: the home forwarded a reqpubkey requester's key -> cache it (closes the recipient-side decrypt gap)
            if (ui) on_mobile_key_forward(ui->body.data(), static_cast<uint8_t>(ui->body.size()));
            become_free(); return;
        }
#endif
        if (pa.type == DATA_TYPE_H_ANSWER || pa.type == DATA_TYPE_AUTHORITATIVE_H_ANSWER) {   // a hash-bind answer for us -> consume (routing info, NOT a DM)
            if (ui && canonical_typed_answer_body_valid(pa.type, ui->body))
                on_hash_bind_response(ui->body.data(), static_cast<uint8_t>(ui->body.size()),
                                      pa.type == DATA_TYPE_AUTHORITATIVE_H_ANSWER, pa.team_plane);   // ★ §hashbind-plane: a TEAM-plane answer must not write the static _id_bind
            become_free();
            return;
        }
        if (pa.type == DATA_TYPE_AUTHORITATIVE_H_ANSWER_PUBKEY) {   // E2E §6: the owner's pubkey answer -> cache (routing/key info, NOT a DM)
            if (ui) on_hash_bind_pubkey(ui->body.data(), static_cast<uint8_t>(ui->body.size()));   // Wave 2: AUTHORITATIVE_H_ANSWER_PUBKEY is now a standard DM -> the pubkey is the BODY (past [dst_hash?][origin])
            become_free();
            return;
        }
        // §remote-admin v2 SLICE 1b: OTA remote diagnostics, dispatched by the CAPABILITY that owns the type.
        // ⛔ CORRECTED HERE 2026-09-06 (R-RA-27), old shape visible: this WAS one ungated arm
        //   `if (pa.type == DATA_TYPE_REMOTE_CMD || pa.type == DATA_TYPE_REMOTE_RESP)` that staged BOTH types on
        //   EVERY build. It is now two owned entry points; a type whose owner is compiled out takes NO arm here and
        //   reaches the fail-closed internal guard below. Full rationale + the deferred obligations: the block
        //   ahead of `do_post_ack`. The two `#if`s are what actually compile the consumer OUT of a product image;
        //   the decision's own `none` is what makes the same split testable inside the `{1,1}` host binary.
        const RadminRxOwner radmin_owner = radmin_rx_owner(pa.type, MR_FEAT_RADMIN_CLIENT, MR_FEAT_RADMIN_ACCEPT);
#if MR_FEAT_RADMIN_ACCEPT
        if (radmin_owner == RadminRxOwner::command_accept) {
            rx_remote_cmd_accept(pa, ui ? &*ui : nullptr);
            become_free();
            return;
        }
#endif
#if MR_FEAT_RADMIN_CLIENT
        if (radmin_owner == RadminRxOwner::response_client) {
            rx_remote_resp_client(pa, ui ? &*ui : nullptr);
            become_free();
            return;
        }
#endif
        // ⛔ THERE IS DELIBERATELY NO `none` ARM (R-RA-27): an un-owned remote type consumes NOTHING here — no slot
        //   write, no early return, no new drop branch and no telemetry — it simply continues down this chain to
        //   the EXISTING fail-closed internal guard below. The cast is [[B169]] hygiene only: a configuration
        //   compiling NEITHER arm would otherwise take a board-only `-Wunused-variable` that native cannot see,
        //   and mr_features.h already `#error`s that configuration on a board.
        (void)radmin_owner;
        if (pa.type == DATA_TYPE_E2E_ACK) {              // an end-to-end ACK for a DM we originated -> confirm + RECORD a receipt, not deliver
            // The acked ctr from the parsed inner BODY — uniform across all ack shapes now (§GapB): whatever optional
            // fields precede it (DST_HASH / CROSS_LAYER path / SOURCE_HASH), parse_unicast_inner lands ui->body on the
            // 2-B ctr. A raw fallback (no parse) reads [origin][ctr_lo][ctr_hi]. Same value on the plain path -> s18-safe.
            const uint16_t acked = (ui && ui->body.size() >= 2)
                                   ? static_cast<uint16_t>(ui->body[0] | (ui->body[1] << 8))
                                   : ((pa.inner_len >= 3) ? static_cast<uint16_t>(pa.inner[1] | (pa.inner[2] << 8)) : 0);
            // §GapB: the same-layer reverse-ack fork (SOURCE_HASH-marked) is RETIRED. A delegated-recipient ack now
            // arrives DST_HASH-addressed and is last-miled + ctr-rewritten by the generic hosted-mobile fork (:699),
            // BEFORE reaching here. So an ack that reaches HERE is genuinely for one of OUR own sends -> record + push.
            // Cross-layer: the acker's STABLE key (the 8-bit origin aliases across leaves) -> the companion's match key.
            // Same-layer: (origin, ctr) suffices, acker_hash=0.
            const uint32_t acker_hash = ((pa.flags & DATA_FLAG_CROSS_LAYER) && ui && ui->has_source_hash) ? ui->source_hash : 0;
            _inbox.record_ack(pa.origin, acked, active_layer_id(), _hal.now(), acker_hash);   // durable receipt (DM store); inert if no backend (sim)
            Push pu{}; pu.kind = PushKind::send_e2e_acked; pu.dst = pa.origin; pu.ctr = acked; pu.sender_hash = acker_hash; enqueue_push(pu);   // live fast-path (E2E-ACKED ctr=X from=D); sender_hash = the acker's stable key (XL) so the app matches (sender_hash,ctr)
            e2e_ack_clear(pa.origin, acked, acker_hash);   // ★ shelf item (i): CLEAR the pending-ack deadline (emit-free) — mirrors the {dst,ctr,sender_hash} just pushed. A LATE ack (past the deadline) finds nothing -> no-op.
            MR_EMIT("e2e_ack_rx", EF_I("from", pa.origin), EF_I("ctr", acked));  // KEEP for the sim analyzer (free on metal)
            become_free();
            return;
        }
        // L2c verify-on-delivery (NON-cross-layer; cross-layer was forked above): DST_HASH present and naming a key
        // that ISN'T ours => an id collision misdelivered this DM. Heal the collision + redirect to the real owner.
        if (ui && ui->has_dst_hash && ui->dst_key_hash32 != _key_hash32) {
            l2c_handle_misdelivery(pa, ui->dst_key_hash32);     // forward to the real owner (identity-preserving)
            return;                                             // l2c re-kicks the queue itself (become_free)
        }
        // ★★★★ §CUSTODY-G (2026-08-31) — **THE 0x81 CONSUMER, AND THE END OF THE RATIFIED INTERMEDIATE STATE.**
        // Until this line existed, an addressed `DATA_TYPE_CUSTODY_FAILURE` fell all the way to Slice B's
        // fail-closed tail guard and was dropped with one `unsupported_internal` (test §CUSTODY-F/7, now
        // re-anchored). §13's opening sentence — *"An addressed `DATA_TYPE_CUSTODY_FAILURE` is consumed before
        // ordinary DM delivery"* — is what this arm implements.
        //
        // ⛔⛔ THE POSITION IS THE CONTRACT, and it is the SAME doctrine the Slice-B guard's own banner states
        //    twelve lines below: a frame this node is the WIRE DESTINATION of is not necessarily a frame this
        //    node is the SUBJECT of. Every role that must FORWARD an 0x81 has already run and returned:
        //      (a) ordinary relay forwarding — the `else` arm of `if (!pa.is_forward)`; never reaches here;
        //      (b) the cross-layer BRIDGE    — :1720-1722, returns long before this line;
        //      (c) the hosted-mobile LAST-MILE by DST_HASH — :1656-1712. ★ A home is the outer wire destination
        //          but only a PROXY for its hosted mobile: a notice addressed THROUGH the home must still be
        //          forwarded, and the MOBILE is the node entitled to decide whether it is the failed origin;
        //      (d) `l2c_handle_misdelivery` — an id-collision redirect, immediately above.
        //    ⓘ (d) is UNREACHABLE for a genuine v1 notice and the arm is placed after it anyway: §9.1 originates
        //      the notice `app_dm = false` with `override_dst_hash = 0`, and `enqueue_data` gates BOTH the
        //      DST_HASH and SOURCE_HASH prefixes on `app_dm` — so `ui->has_dst_hash` is false by construction.
        //      Sitting after the redirect costs nothing and means a CRAFTED notice cannot eat one.
        // ⛔ AND IT IS **BEFORE** THE TWO OPEN PATHS BELOW (SEALED_RELAY / CRYPTED trial decrypt), because
        //    §13.1 requires the DATA to be PLAINTEXT: a crypted 0x81 must be refused, not trial-decrypted.
        // ⛔ THE SLICE-B GUARD IS UNTOUCHED AND STILL PROTECTS EVERYTHING ELSE. This arm consumes exactly one
        //    type; every OTHER unhandled internal type still reaches the guard and is still dropped there. The
        //    paired native case proves both halves at once, which is the only honest way to state a transition.
        if (pa.type == DATA_TYPE_CUSTODY_FAILURE) {
            custody_failure_receive(pa, ui ? &*ui : nullptr);
            become_free();
            return;
        }
        // §S2 DATA_TYPE_INTRO (0x01): a PLAINTEXT first-contact DM addressed to US, body = [ed_pub 32][name_len][name][text].
        // Verify ed_pub[:4] == SOURCE_HASH (the peerkey self-consistency rule), cache the sender's key AUTHORITATIVE +
        // name (fires peer_key_cached), STRIP the prefix, and fall through to the NORMAL deliver (enc absent; dedup
        // (sender_hash,ctr) unchanged; the INTRO framing is transport detail). Malformed/inconsistent/short -> DROP
        // loud (telemetry), never deliver raw key bytes. NOT crypto-gated on the receive side: a node WITHOUT an
        // identity can still cache a peer's key (peer_key_set) — but s18 never receives one (nobody attaches, §S2 gate).
        if (pa.type == DATA_TYPE_INTRO) {
            if (!ui || !ui->has_source_hash || ui->body.size() < 33) {                          // needs SOURCE_HASH + at least [ed_pub 32][name_len]
                MR_EMIT("intro_reject", EF_I("reason", 1), EF_I("ctr", pa.ctr)); become_free(); return;
            }
            const uint8_t* ed = ui->body.data();
            const uint32_t ed_hash = key_hash32_of(ed);   // §P2-6: identity.h owns the LE(ed_pub[:4]) derivation
            if (ed_hash != ui->source_hash) {                                                    // self-consistency: the attached key MUST hash to the claimed sender
                MR_EMIT("intro_reject", EF_I("reason", 2), EF_I("hash", static_cast<int64_t>(ui->source_hash))); become_free(); return;
            }
            uint8_t nlen = ui->body[32]; if (nlen > 32) nlen = 32;
            if (static_cast<size_t>(33) + nlen > ui->body.size()) {                              // the name field overruns the frame
                MR_EMIT("intro_reject", EF_I("reason", 3), EF_I("nlen", nlen)); become_free(); return;
            }
            const char* nm = nlen ? reinterpret_cast<const char*>(ui->body.data() + 33) : nullptr;
            if (!peer_key_set(ui->source_hash, ed, PeerKeyConf::authoritative, nm, nlen)) {       // (re-derives + re-checks ed_pub[:4]==hash)
                MR_EMIT("intro_reject", EF_I("reason", 4), EF_I("hash", static_cast<int64_t>(ui->source_hash))); become_free(); return;
            }
            MR_EMIT("peer_key_cached", EF_I("hash", static_cast<int64_t>(ui->source_hash)), EF_I("node", pa.origin));
            push_peer_key_cached(ui->source_hash);                                               // §7: the app's "secure send ready" (+ the cached name)
            ui->body = ui->body.subspan(static_cast<size_t>(33) + nlen);                         // STRIP -> deliver the remaining message as a plain DM (fall through)
        }
        // E2E OPEN (§1a sealed-sender): a CRYPTED DM carries NO cleartext sender hint -> TRIAL DECRYPT over the cached
        // peer keys; the Poly1305 tag identifies the sender + opens the sealed {source_hash + location + body}. The seed
        // rides the trailer. FAIL LOUD: no cached key opens it -> SILENT DROP (never deliver ciphertext to the app).
        uint32_t dec_source_hash = 0; bool dec_has_loc = false; int32_t dec_lat = 0, dec_lon = 0;
        // ADDENDUM 4 (2026-06-25): static, NOT stack. do_post_ack is non-reentrant (one timer fires at a time in the
        // single loop task) and is the deepest path on the cramped 4 KB FreeRTOS loop stack; the DWT watchpoint caught
        // route_strictly_better (reached via send_e2e_ack, below) overflowing right here. Moving these ~480 B of
        // payload buffers off the frame restores the headroom at the exact overflow point. e2e_open_trial fills
        // dec_body before any read; dec_body_len stays a fresh local (re-set each call).
        static uint8_t dec_body[protocol::max_payload_bytes_hard_cap]; uint8_t dec_body_len = 0;
        uint32_t dec_origin = pa.origin;   // §1a: for CRYPTED the trial recovers origin (== cleartext now; from the seal at 1c)
        bool crypted_ok = false;
        // §S4 DATA_TYPE_SEALED_RELAY (0x03): a PLAINTEXT-framed DM whose BODY = [seal_ctr 2][seed8 8][ct‖tag], sealed to US by
        // the CLEAR SOURCE_HASH (a mobile delegating via its home, or a static crossing a layer). DIRECTED open (no trial:
        // the sender is named in the clear); e2e_open_relay verifies the SEALED source_hash == the clear one (anti-spoof)
        // and IGNORES the sealed origin byte (§1c layer-local garbage). Success -> crypted_ok + fall into the shared
        // deliver as an ENCRYPTED DM (enc=1). Fail/short/spoof -> SILENT DROP (never deliver ciphertext). NOT gated on
        // _crypto_ready in the wire dispatch, but e2e_open_relay refuses without an identity -> s18-inert (no seals).
        if (pa.type == DATA_TYPE_SEALED_RELAY) {
            if (!ui || !ui->has_source_hash || !e2e_open_relay(ui->body.data(), ui->body.size(), ui->source_hash, dec_body, dec_body_len)) {
                MR_EMIT("e2e_open_no_key", EF_I("ctr", pa.ctr), EF_I("relay", 1));   // no key / tag fail / spoof -> DROP
                become_free(); return;
            }
            crypted_ok = true; dec_source_hash = ui->source_hash;   // the CLEAR (and seal-verified) sender is the identity
        }
        if (pa.flags & DATA_FLAG_CRYPTED) {
            // §1a sealed-sender: no cleartext sender hint -> TRIAL DECRYPTION over the cached keys; the tag identifies it.
            uint32_t trial_sender = 0;
            if (!e2e_open_trial(pa.inner, pa.inner_len, pa.nonce_seed, pa.flags, pa.ctr, trial_sender, dec_origin,
                                dec_source_hash, dec_has_loc, dec_lat, dec_lon, dec_body, dec_body_len)) {
                MR_EMIT("e2e_open_no_key", EF_I("ctr", pa.ctr));            // no cached key opens it -> SILENT DROP (no push/ack/inbox)
                become_free(); return;
            }
            crypted_ok = true; (void)trial_sender;   // dec_source_hash (sealed, anti-spoof-verified) == trial_sender = the sender
        }
        // §team-ch-key T-K3 (DATA_TYPE_TEAM_KEY_GRANT = 0xA2): a teammate GRANTED us the team CONTENT keypair. Placed HERE — after BOTH open
        // paths, before the shared deliver — because the body is SEALED, so nothing above this point can read it.
        // ★ SEALED-ONLY IS ENFORCED ON RECEIPT TOO, not just at origination: a plaintext grant is either a bug in a
        // peer or an attacker feeding us a key we would then encrypt the team's traffic under, so refuse it loudly and
        // NEVER fall through (the body would otherwise be delivered as inbox text = 37 raw key bytes in the app).
        // CONSUMED unconditionally — every outcome, adopt or refusal, returns here: no inbox record, no msg_recv push,
        // no E2E ack (v1 carries no ack request on a grant; the receiver's team_key_received push is the app-level
        // confirmation and a re-grant is idempotent). Ungated by MR_FEAT_TEAM on purpose: on a MR_FEAT_TEAM 0 build
        // team_key_grant_receive answers no_team by construction, which is still a loud consume rather than a delivery.
        if (pa.type == DATA_TYPE_TEAM_KEY_GRANT) {
            if (!crypted_ok) {
                MR_EMIT("team_key_grant_reject", EF_I("reason", static_cast<int>(TeamKeyGrantRx::not_sealed)),
                        EF_I("from", pa.origin), EF_I("ctr", pa.ctr), EF_I("len", pa.inner_len));
                become_free(); return;
            }
            (void)team_key_grant_receive(dec_body, dec_body_len, dec_source_hash, pa.origin);   // emits/pushes its own outcome
            become_free(); return;
        }
        // ★★★★ §CUSTODY-B (2026-08-30) — THE FAIL-CLOSED PROTOCOL-INTERNAL GUARD (design §6.2(2); closes the
        //       runtime half of [[B264]]). Every wired internal handler above CONSUMES and RETURNS, so a healthy
        //       internal frame never reaches this line. Anything internal that DOES reach it is, by construction,
        //       UNHANDLED on this build — so it is dropped here instead of falling through to `record_dm`,
        //       `msg_recv` and the inbox as message text.
        //   ⓘ 2026-08-31 (§CUSTODY-G): `DATA_TYPE_CUSTODY_FAILURE` (0x81) JOINED the wired handlers above and no
        //     longer arrives here. ⛔ NOTHING ABOUT THIS GUARD CHANGED — it was never 0x81-specific, and it still
        //     protects every other internal type, allocated or not. The paired case in
        //     `test/test_custody_receive_g.cpp` measures exactly that: 0x81 consumed, another internal type still
        //     guard-dropped, in one test. A transition stated as "the guard weakened" would be false.
        //
        // ⛔⛔ THE PREDICATE IS "traits.internal REACHED THE ORDINARY-DELIVERY TAIL", FULL STOP — ⛔ NOT
        //     `internal && !known`. `known` means ALLOCATED AND UNDERSTOOD; it does NOT prove a handler RAN.
        //     `MOBILE_KEY_FORWARD` (0x96) is the standing proof: it is `known = true`, and its consuming fork is
        //     gated on `is_mobile` AND `#if MR_FEAT_MOBILE` (:1801), so on a static / gateway / MR_FEAT_MOBILE-0
        //     build an addressed one arrives here with nobody having handled it — and the weaker predicate would
        //     put 32 raw requester-key bytes in the inbox as text (A0-F11). §18.2's control mutates the guard to
        //     `internal && !known` and REQUIRES it to go RED.
        //
        // ⛔ PLACEMENT IS LOAD-BEARING and is AFTER all THREE forwarding roles, because a frame this node is the
        //    wire destination of is not necessarily a frame this node is the SUBJECT of (design §6.2(3)):
        //      (a) ordinary relay forwarding      — the `else` arm of `if (!pa.is_forward)` (:2010); never here;
        //      (b) the cross-layer BRIDGE         — :1720-1722, which `return`s long before this line;
        //      (c) the hosted-mobile LAST-MILE by DST_HASH — :1656-1712. ★ THIS IS THE ONE A GUARD PLACED
        //          "at the top of the destination branch" WOULD EAT: a home is the outer wire destination but
        //          only a PROXY for its hosted mobile, so an unknown-internal frame addressed THROUGH the home
        //          to its mobile must still be forwarded. The mobile — not the home — is the node entitled to
        //          decide it has no handler. §18.2's control drops that arm and requires RED.
        //
        // ⛔ WHAT THIS IS NOT (§6.3): not a custody-report exclusion, not sealing, not trust, not priority, not
        //    an airtime exemption. It changes NOTHING about the hop exchange that already completed — the CTS,
        //    the DATA and the link ACK all happened above; this is the SEMANTIC verdict only.
        //
        // ★★ THE TELEMETRY BOUND, OWNER-RULED 2026-08-30 (S0 ruling, Option A) AND RECORDED VERBATIM:
        //      "«Bounded» means fixed-size and non-amplifying — one scalar-only emit per dedup-admitted distinct
        //       flight — not a wall-clock rate limit. A sender varying flight identity can still produce one
        //       event per physically accepted exchange."
        //    ⇒ At most one fixed-size `unsupported_internal` event per dedup-admitted DATA flight. No body bytes,
        //      no Push, no storage, and no secondary event generation. WHY that is the honest bound, and ⛔ NOT
        //      the originator throttle (a hostile sender can simply ignore that one):
        //      · every event costs the attacker a COMPLETE physical DATA exchange, so telemetry cannot amplify
        //        one frame into many records — the bound is the radio, not a counter;
        //      · same-flight retries never arrive here at all: the per-frame dedup drops them (`dup_drop`, :1373);
        //      · `MR_EMIT` is DEVICE-STRIPPED (`MESHROUTE_NO_TELEMETRY`), so permanent Node state added to
        //        regulate this would spend real RAM on EVERY board env policing something that is not there;
        //        ⛔ CORRECTED 2026-09-06 ([[B307]]), old claim visible: this said *"on all ten board envs"*. The
        //        count was already stale — `platformio.ini` resolves to THIRTEEN board environments today (4
        //        mobile + 4 gateway + 5 static). A count in prose rots; the argument does not depend on one;
        //      · complete occurrence reporting is what keeps the native/sim diagnostics and the event-level
        //        corpus instrument able to see this at all — a windowed emit hides occurrences (the same reason
        //        `_team_ch_nokey_push_next_ms`'s telemetry twin is deliberately un-limited, node.h);
        //      · and the fail-closed BEHAVIOUR is UNCONDITIONAL — drop, `become_free()`, nothing inboxed —
        //        regardless of telemetry, so a stripped build is exactly as safe as a native one.
        //    ⛔ FIELDS ARE RULED AND CLOSED: `type, origin, dst, ctr`. ⛔ NEVER the body or anything derived from
        //      it — the whole defect class this guard closes is raw key material reaching a text sink, and the
        //      `delivered` emit twelve lines below (the ONE payload-carrying emit in lib/core) is precisely what
        //      it must not become. §18.2's control adds a body field and requires RED.
        if (data_type_traits(pa.type).internal) {
            MR_EMIT("unsupported_internal", EF_I("type", pa.type), EF_I("origin", pa.origin),
                    EF_I("dst", pa.dst), EF_I("ctr", pa.ctr));
            become_free();
            return;
        }
        // deliver: body from the parsed inner (raw inner[1..] fallback — origin at inner[0] — if it didn't parse).
        static char body[protocol::max_payload_bytes_hard_cap + 1];   // ADDENDUM 4: static (non-reentrant) — paired with dec_body, off the do_post_ack stack frame
        uint8_t blen;
        if (crypted_ok) { blen = dec_body_len;                              // the DECRYPTED body (sealed region opened above)
                          for (uint8_t i = 0; i < blen; ++i) body[i] = static_cast<char>(dec_body[i]); }
        else if (ui)    { blen = static_cast<uint8_t>(ui->body.size());
                          for (uint8_t i = 0; i < blen; ++i) body[i] = static_cast<char>(ui->body[i]); }
        else            { blen = (pa.inner_len > 1) ? static_cast<uint8_t>(pa.inner_len - 1) : 0;
                          for (uint8_t i = 0; i < blen; ++i) body[i] = static_cast<char>(pa.inner[1 + i]); }
        body[blen] = '\0';
        MR_EMIT("delivered", EF_I("origin", dec_origin), EF_I("dst", pa.dst), EF_I("ctr", pa.ctr), EF_S("payload", body));  // dm_delivery keys (dst, payload)
        // sender_hash = the origin's stable key_hash32 (when SOURCE_HASH was set) — the app's DM dedup identity.
        const uint32_t sender_hash = crypted_ok ? dec_source_hash : ((ui && ui->has_source_hash) ? ui->source_hash : 0);
        // Record-on-delivery FIRST (the FINAL-destination deliver path, once per delivered DM): it returns the
        // inbox seq (0 if disabled). The live msg_recv push then carries the SAME sender_hash + seq as the pulled
        // record -> the app dedups by (sender_hash, ctr) and detects a dropped live push by the seq (model B).
        const uint8_t rx_layer = active_layer_id();   // §2/Q13: which layer this DM arrived on (disambiguates origin on a gateway)
        // §GapA: the SENDER's layer (the preserved XL path's first entry) so the recipient can build the (layer_path, hash)
        // REPLY address. 0 for a same-layer / non-XL DM. Computed BEFORE record so the durable record carries it too (§GapA-durable).
        const uint8_t origin_layer = (ui && ui->has_cross_layer && ui->n_layers >= 1) ? ui->layer_ids[0] : 0;
        const uint32_t seq = _inbox.record_dm(dec_origin, sender_hash, pa.ctr, rx_layer,
                                              reinterpret_cast<const uint8_t*>(body), blen, _hal.now(), /*enc=*/crypted_ok ? 1 : 0, origin_layer);  // §8b + §GapA-durable
        Push pu{}; pu.kind = PushKind::msg_recv; pu.origin = dec_origin; pu.dst = pa.dst; pu.ctr = pa.ctr;   // §1a: recovered origin for CRYPTED
        pu.layer_id = rx_layer; pu.sender_hash = sender_hash; pu.seq = seq; pu.enc = crypted_ok;   // §8b: was this DM sealed?
        pu.origin_layer = origin_layer;   // 0 -> the JSON omits it (byte-identical)
        pu.body_len = blen; for (uint8_t i = 0; i < blen; ++i) pu.body[i] = static_cast<uint8_t>(body[i]);
        // LOCATION (spec §5): the sender piggybacked its 6-B location -> surface it to the app on the Push (always
        // compiled — the companion renders it) + a peer_location telemetry for the sim/gate (device-stripped).
        // ★★ §AB4 (2026-07-31): the "firmware-side peer-location cache" this comment used to call an optional follow-up
        // IS NOW BUILT — the _peer_loc retention below. Nothing about the extraction changed: this block already parsed
        // the position and already distinguished sealed from plaintext, so the whole slice is the one peer_loc_set call
        // (U1 — no second extraction, no second sealed/plaintext test, no second emit).
        const bool    loc_present = crypted_ok ? dec_has_loc : (ui && ui->has_location);
        const int32_t loc_lat     = crypted_ok ? dec_lat : (ui ? ui->lat_e7 : 0);
        const int32_t loc_lon     = crypted_ok ? dec_lon : (ui ? ui->lon_e7 : 0);
        if (loc_present) {
            pu.has_location = true; pu.lat_e7 = loc_lat; pu.lon_e7 = loc_lon;
            MR_EMIT("peer_location", EF_I("origin", dec_origin), EF_I("hash", static_cast<int64_t>(sender_hash)), EF_I("lat_e7", loc_lat),
                    EF_I("lon_e7", loc_lon));
            // ★★★ §AB4 RETENTION (address-book spec §2.7). `sender_hash` is already in scope right above and is exactly
            // the key the book needs (§1.2: ids are addresses, the hash is the identity).
            // ★★ AUTHENTICATED ONLY — the C2 gate, and the reason it is HERE rather than inside peer_loc_set: this is
            // where the evidence lives. `crypted_ok` means the inner OPENED with OUR key, so the position is anchored
            // PAIRWISE ⇒ PeerLocSrc::peer, "this specific peer said so". The send side makes that airtight in the other
            // direction: node_mac.cpp REFUSES a `-l` DM that would not be sealed (`unsealable`), so our own firmware can
            // never air a plaintext position at all.
            // ⇒ a plaintext DATA_FLAG_LOCATION (an older or foreign node, or a spoof) is parsed and pushed EXACTLY as
            // before but NEVER retained, because an unauthenticated position is spoofable by anyone in range and a
            // spoofed position in an address book is worse than an absent one — the UI presents it as fact.
            // `sender_hash == 0` is folded into the same refusal: with no identity there is nothing to key it by, so it
            // is unattributable for the same reason even if the frame was sealed.
            // ★ O6 (owner-ruled): the refusal EMITS rather than dropping silently — visibility with no behaviour change,
            // and a spoof attempt becomes observable. `enc` distinguishes "not sealed" from "sealed but hashless".
            if (crypted_ok && sender_hash) {
                (void)peer_loc_set(sender_hash, loc_lat, loc_lon, PeerLocSrc::peer);   // false only for hash 0, excluded above
            } else {
                MR_EMIT("peer_location_unauth", EF_I("origin", dec_origin), EF_I("hash", static_cast<int64_t>(sender_hash)),
                        EF_I("lat_e7", loc_lat), EF_I("lon_e7", loc_lon), EF_I("enc", crypted_ok ? 1 : 0));
            }
        }
        enqueue_push(pu);                                // app channel: the inbound message (live notify, seq-stamped)
        // E2E ACK requested -> reply with the acked ctr. §GapB: CROSS_LAYER -> a NORMAL send on the reversed path
        // (send_xl_ack: STATIC recipient originates, MOBILE recipient delegates via its home); else the same-layer ack.
        if (pa.flags & DATA_FLAG_E2E_ACK_REQ) {
            if ((pa.flags & DATA_FLAG_CROSS_LAYER) && ui) send_xl_ack(*ui, pa.ctr);
            else                                          send_e2e_ack(dec_origin, pa.ctr, sender_hash);   // §1a: ack the recovered origin; §mobile: sender_hash a hosted mobile -> last-mile the ack (origin==my id => self-send)
        }
        become_free();
    } else {
        // §intra-layer-relay (2026-07-05): a GATEWAY does NOT relay other nodes' same-leaf traffic by default (design §6).
        // A cross-layer transit DM is addressed TO the gateway (dst==_node_id -> the deliver/BRIDGE branch above), so ANY
        // forward (dst!=_node_id) reaching HERE on a gateway is an intra-leaf relay -> DROP (unless the operator opted in).
        // The cross-layer bridge (drain_xl_handoffs re-inject) is a SEPARATE originated-TX path, NOT this received-DATA
        // forward, so it is unaffected. Belt-and-suspenders to the sender-side next_hop_selectable gate (Edit 3).
        if (_cfg.is_gateway && !_cfg.intra_layer_relay) {
            MR_EMIT("gateway_intra_relay_drop", EF_I("dst", pa.dst), EF_I("origin", pa.origin));
            become_free();
            return;
        }
        // C.2 cache-on-pass: a relayed hash-bind answer is cleartext -> snoop the binding before forwarding.
        if (pa.type == DATA_TYPE_H_ANSWER || pa.type == DATA_TYPE_AUTHORITATIVE_H_ANSWER) {
            if (ui && canonical_typed_answer_body_valid(pa.type, ui->body))
                on_hash_bind_snoop(ui->body.data(), static_cast<uint8_t>(ui->body.size()),
                                   pa.type == DATA_TYPE_AUTHORITATIVE_H_ANSWER, pa.team_plane);   // ★ §hashbind-plane: cache-on-pass of a TEAM-plane answer must not write the static _id_bind
        }
        else if (pa.type == DATA_TYPE_AUTHORITATIVE_H_ANSWER_PUBKEY) {   // E2E §6: cache-on-pass — no `ui` on the forward path, so skip [dst_hash?][origin] to reach the pubkey BODY (Wave 2 standard DM; no SOURCE_HASH on this app_dm=false type)
            const uint8_t off = static_cast<uint8_t>((pa.flags & DATA_FLAG_DST_HASH ? 4 : 0) + 1);
            if (pa.inner_len > off) on_hash_bind_pubkey(pa.inner + off, static_cast<uint8_t>(pa.inner_len - off));
        }
        if (pa.forward_prequeued) {                         // B251: queue row + translated ctrH already belong to this accepted flight
            become_free();
            return;
        }
        TxItem it = forward_item_from_post_ack(pa, _hal.now());
        if (_active->_tx_queue_n < kTxQueueCap) _active->_tx_queue[_active->_tx_queue_n++] = it;
        become_free();
    }
}

// ---- Slice 4c.1: cross-layer DM bridge (the keystone) ------------------------------------------------------------
// Resolve key_hash32 -> node_id on a SPECIFIC leaf's id_bind. NEVER via _active-> : the bridge writes a NON-active
// leaf, and any _active-> deref mid-resolve would read/corrupt the wrong leaf's state (the subtlest aliasing trap).
// Mirrors id_bind_find_by_hash's match (key + not-expired, self exempt) but on _layers[leaf]. -1 = unknown.
int Node::id_on_leaf_by_hash(uint8_t leaf, uint32_t key_hash32) const {
    if (leaf >= _n_layers) return -1;
    const LayerRuntime& L = _layers[leaf];
    const uint64_t now = _hal.now();
    for (uint16_t i = 0; i < L._id_bind_n; ++i) {
        if (L._id_bind[i].key_hash32 != key_hash32) continue;
        const bool self_keep = (L._id_bind[i].node_id == _cfg.layers[leaf].node_id && L._id_bind[i].key_hash32 == _key_hash32);
        if (!self_keep && _cfg.id_bind_ttl_ms > 0
            && (now - L._id_bind[i].last_seen_ms) >= _cfg.id_bind_ttl_ms) continue;   // expired -> skip
        return L._id_bind[i].node_id;
    }
    return -1;
}

// Loop suppression: seed the TARGET leaf's _seen_origins for the re-inject's (origin, dst, ctr) so when THIS gateway
// later hears its own relay on that leaf it is caught as a live_dup (ACK-only, no re-bridge / re-forward). Mirrors
// record_seen_origin but on _layers[leaf] (the bridge writes a non-active leaf).
void Node::seed_seen_origin_on_leaf(uint8_t leaf, uint8_t origin, uint8_t dst, uint16_t ctr) {
    if (leaf >= _n_layers) return;
    // PLAINTEXT-namespace key (< 2^32), matching handle_data's non-CRYPTED sokey. (A CRYPTED DM never reaches a gateway
    // bridge — e2e_dm + cross-layer is refused — so this path is always plaintext.)
    const uint64_t sokey = (static_cast<uint64_t>(origin) << 24) | (static_cast<uint64_t>(dst) << 16) | ctr;
    const uint64_t now = _hal.now();
    _layers[leaf]._seen_origins[sokey]     = now + protocol::seen_origin_ttl_ms;
    _layers[leaf]._seen_origin_from[sokey] = _node_id;   // we re-injected it
}

// Buffer a handoff into the node-global ring; false = full (the caller REFUSES loud — never drop-oldest a transit DM).
bool Node::push_xl_handoff(const XlHandoff& h) {
    for (uint8_t i = 0; i < protocol::cap_gateway_handoffs; ++i)
        if (!_xl_handoffs[i].valid) { _xl_handoffs[i] = h; return true; }
    return false;
}

void Node::bridge_cross_layer(const PostAck& pa, const data_unicast_inner& ui) {
    // L13 (2026-07-04): a SINGLE-layer node NEVER bridges — only a dual-layer gateway (n_layers==2) does. Without
    // this guard a crafted CROSS_LAYER DM whose target_layer_id == our own single leaf's layer_id would match the
    // loop below (target_leaf=0), fill the cap-1 handoff slot, and induce an H-flood for up to ~60 s (a cheap DoS).
    // Refuse at the top (the caller relies on us to become_free()+return, matching the no-leaf-match early-refuse).
    if (_n_layers < 2) { become_free(); return; }
    // ui.has_cross_layer is guaranteed by the caller. The next layer to ENTER = layer_ids[cur].
    const uint8_t target_layer_id = ui.layer_ids[ui.cur];
    // Which of OUR leaves carries that layer_id? (A gateway owns 2.) Not one of ours -> REFUSE loud (no default leaf).
    // §xl-nibble-match (2026-07-05, metal): match by the LEAF NIBBLE, not the full 8-bit id. A single-layer originator
    // reports active_layer_id() == leaf_id (the NIBBLE, since layers[0].layer_id = leaf_id when n_layers==1), so a
    // reversed 4e path can carry a nibble (e.g. 4) where the gateway holds the full id (100). The nibble is the canonical
    // wire identity; validate_gateway_layers (node.cpp) guarantees DISTINCT nibbles, so it's unambiguous — and it aligns
    // with select_gateway_for_leaf + the 4e's own `rev[1] & 0x0F`.
    int target_leaf = -1;
    for (uint8_t i = 0; i < _n_layers; ++i) if ((_cfg.layers[i].layer_id & 0x0F) == (target_layer_id & 0x0F)) { target_leaf = i; break; }
    if (target_leaf < 0) {
        MR_EMIT("xl_bridge_refused", EF_I("reason", 1), EF_I("target_layer", target_layer_id), EF_I("origin", pa.origin), EF_I("ctr", pa.ctr));
        become_free(); return;
    }
    // The stable recipient identity (dst_hash) must be present + resolvable on the TARGET leaf. Unknown binding ->
    // Slice 4f defers (H-flood + handoff TTL); v1 (4c.1) REFUSES loud (drop, NEVER a silent reroute).
    if (!ui.has_dst_hash) {
        MR_EMIT("xl_bridge_refused", EF_I("reason", 2), EF_I("origin", pa.origin), EF_I("ctr", pa.ctr));
        become_free(); return;
    }
    int dst_node = id_on_leaf_by_hash(static_cast<uint8_t>(target_leaf), ui.dst_key_hash32);   // -1 = unknown -> 4f DEFERS (resolve at drain + H-flood), never drops
    if (dst_node < 0) {                                          // §5b: a MOBILE? resolve to its home on the target leaf (the home last-mile-forwards; inner dst_hash=M rides intact)
        const int mhome = mobile_home_on_leaf(static_cast<uint8_t>(target_leaf), ui.dst_key_hash32);
        if (mhome > 0) dst_node = mhome;
    }
    // Advance cur ONLY if a further gateway hop remains (multi-gateway, reserved). v1: cur == n_layers-1 -> unchanged.
    uint8_t new_cur = ui.cur;
    if (static_cast<uint8_t>(ui.cur + 1) < ui.n_layers) new_cur = static_cast<uint8_t>(ui.cur + 1);
    // The re-inject inner is the ORIGINAL preserved verbatim (dst_hash + the full layer-path + origin + source_hash +
    // body); only the cursor byte is patched for a multi-gw advance. dst_node 0 = UNRESOLVED (drain re-resolves + H-floods).
    XlHandoff h{};
    h.valid = true; h.target_leaf = static_cast<uint8_t>(target_leaf);
    h.dst_node_id = (dst_node > 0) ? static_cast<uint8_t>(dst_node) : 0;
    h.dst_key_hash32 = ui.dst_key_hash32;                     // 4f: re-resolve + H-flood the binding on the target leaf
    h.origin = pa.origin; h.ctr = pa.ctr; h.ctr_lo = pa.ctr_lo; h.flags = pa.flags; h.type = pa.type;
    for (int i = 0; i < 8; ++i) h.nonce_seed[i] = pa.nonce_seed[i];   // S1: CRYPTED transit DM keeps the originator's seed across the bridge
    h.inner_len = pa.inner_len;
    for (uint8_t i = 0; i < pa.inner_len; ++i) h.inner[i] = pa.inner[i];
    if (new_cur != ui.cur) {                                   // patch cur (layer-path offset = dst_hash?4:0; cur byte at off+1)
        const uint8_t off = static_cast<uint8_t>(ui.has_dst_hash ? 4 : 0);
        if (static_cast<size_t>(off) + 1 < h.inner_len) h.inner[off + 1] = new_cur;
    }
    h.queued_at_ms = _hal.now();
    if (!push_xl_handoff(h)) {                                 // full -> REFUSE loud (the sender's E2E ack just won't come)
        MR_EMIT("xl_handoff_full", EF_I("origin", pa.origin), EF_I("dst", dst_node), EF_I("ctr", pa.ctr));
        become_free(); return;
    }
    // (The loop-suppression seed moves to the DRAIN: for an UNRESOLVED handoff dst_node isn't known yet; the drain
    //  seeds _seen_origins right before building the re-inject, once the recipient id is resolved on the target leaf.)
    MR_EMIT("xl_bridge", EF_I("origin", pa.origin), EF_I("dst", dst_node), EF_I("ctr", pa.ctr),
            EF_I("target_leaf", target_leaf), EF_I("cur", new_cur), EF_I("resolved", dst_node > 0 ? 1 : 0));
    become_free();                                            // drains (resolved) or defers + H-floods (unresolved) on the target leaf's window
}

// Called from activate_layer(leaf) with _active == &_layers[leaf]: move every handoff targeting this leaf into its
// tx_queue as a fresh-budget RELAY leg (identity preserved — mirrors l2c_enqueue_forward; + is_gw_relay + the DM type).
void Node::drain_xl_handoffs_for_leaf(uint8_t leaf) {
    if (leaf >= _n_layers || &_layers[leaf] != _active) return;   // the drain is _active-COUPLED (re-resolve/flood/rt/enqueue use _active) — refuse a wrong-leaf call
    const uint64_t now = _hal.now();
    for (uint8_t i = 0; i < protocol::cap_gateway_handoffs; ++i) {
        XlHandoff& h = _xl_handoffs[i];
        if (!h.valid || h.target_leaf != leaf) continue;
        // Slice 4f: an UNRESOLVED handoff (binding unknown at bridge) re-resolves on THIS (now-active target) leaf's
        // id_bind. Found -> drain below. Still unknown -> H-flood the binding on this leaf (throttled, one per visit)
        // + keep deferred; on the TTL -> give up LOUD (X's DM retry recovers it — an ack/transit DM never floods home).
        if (h.dst_node_id == 0) {
            const int rid = id_bind_find_by_hash(h.dst_key_hash32);   // _active == &_layers[leaf] here
            const int mhome = (rid > 0) ? -1 : mobile_home_find(h.dst_key_hash32);   // §5b: a mobile? resolve to its home on THIS (target) leaf
            if (rid > 0) {
                h.dst_node_id = static_cast<uint8_t>(rid);
            } else if (mhome > 0) {                                  // §5b: the mobile's home on this leaf -> deliver there (home last-mile-forwards; inner dst_hash=M intact)
                h.dst_node_id = static_cast<uint8_t>(mhome);
                MR_EMIT("xl_mobile_resolved", EF_I("home", mhome), EF_I("ctr", h.ctr), EF_I("leaf", leaf));
            } else if (now - h.queued_at_ms >= protocol::gateway_handoff_defer_ttl_ms) {
                MR_EMIT("xl_handoff_giveup", EF_I("origin", h.origin), EF_I("ctr", h.ctr), EF_I("dst_hash", static_cast<int64_t>(h.dst_key_hash32)), EF_I("leaf", leaf));
                h.valid = false;                                     // TTL exceeded -> DROP loud
                continue;
            } else {
                if (h.last_h_flood_ms == 0 || now - h.last_h_flood_ms >= protocol::gateway_handoff_reflood_ms) {  // 0 = never flooded -> fire now
                    emit_hash_query(h.dst_key_hash32, /*hard=*/false);   // flood an H query on THIS leaf (we're on it now)
                    // ONE H query resolves the binding for EVERY pending handoff to this hash -> stamp them all so
                    // siblings don't re-flood the SAME query this pass / window (review #4: no duplicate floods).
                    for (uint8_t j = 0; j < protocol::cap_gateway_handoffs; ++j)
                        if (_xl_handoffs[j].valid && _xl_handoffs[j].dst_node_id == 0 && _xl_handoffs[j].dst_key_hash32 == h.dst_key_hash32)
                            _xl_handoffs[j].last_h_flood_ms = now;
                    MR_EMIT("xl_handoff_h_flood", EF_I("ctr", h.ctr), EF_I("dst_hash", static_cast<int64_t>(h.dst_key_hash32)), EF_I("leaf", leaf));
                }
                continue;                                            // keep deferred -> re-resolve on a later visit / the H-answer
            }
        }
        // resolved -> build the relay leg. KEEP the slot until the enqueue SUCCEEDS: a transient queue-full RETRIES
        // next visit (like the deferred path), NEVER drops a resolved transit DM (review HIGH #1).
        if (_active->_tx_queue_n >= kTxQueueCap) {
            MR_EMIT("xl_handoff_queue_full_retry", EF_I("origin", h.origin), EF_I("dst", h.dst_node_id), EF_I("ctr", h.ctr));
            continue;                                          // h.valid stays true -> retried on the next window
        }
        // Loop suppression (moved here from the bridge, 4f): seed THIS leaf so we live_dup our own re-inject.
        seed_seen_origin_on_leaf(leaf, h.origin, h.dst_node_id, h.ctr);
        TxItem it{};
        it.origin = h.origin; it.dst = h.dst_node_id; it.ctr = h.ctr; it.ctr_lo = h.ctr_lo;
        it.flags = h.flags; it.type = h.type; it.is_forward = true; it.is_gw_relay = true; it.previous_hop = 0;
        for (int i = 0; i < 8; ++i) it.nonce_seed[i] = h.nonce_seed[i];   // S1: CRYPTED transit DM keeps its nonce seed on the re-inject leg
        RtEntry* rte = rt_find(h.dst_node_id);                // FRESH budget from THIS (target) leaf's route to the recipient
        const uint8_t rt_hops = (rte && rte->n > 0) ? rte->candidates[0].hops : 1;
        const int rem = static_cast<int>(rt_hops) + protocol::hop_budget_slack;
        it.fwd_remaining = static_cast<uint8_t>(rem > protocol::hop_budget_max_initial ? protocol::hop_budget_max_initial : rem);
        it.fwd_committed = 0;
        it.inner_len = (h.inner_len > protocol::max_payload_bytes_hard_cap) ? protocol::max_payload_bytes_hard_cap : h.inner_len;
        for (uint8_t k = 0; k < it.inner_len; ++k) it.inner[k] = h.inner[k];
        it.enqueue_time_ms = _hal.now();
        _active->_tx_queue[_active->_tx_queue_n++] = it;
        h.valid = false;                                       // consume the slot ONLY after a successful enqueue (review HIGH #1)
        MR_EMIT("xl_handoff_drained", EF_I("origin", h.origin), EF_I("dst", h.dst_node_id), EF_I("ctr", h.ctr), EF_I("leaf", leaf));
    }
    // activate_layer calls become_free() right after this -> the drained relay leg gets serviced in this window.
}

void Node::handle_ack(const uint8_t* bytes, size_t len, const RxMeta& meta) {
    auto pk = parse_ack(std::span<const uint8_t>(bytes, len));
    if (!pk) return;
    const ack_out& k = *pk;
    if (!for_me_dst(k.to) || ((k.mobile_to == 1) != _cfg.is_mobile)) return;   // §mobile 3b/6.4: an ACK to EITHER of our plane ids (node_id OR team_local_id), mobile_to matching our kind; a colliding static id ignores it (byte-identical when _team_local_id==0)
    if (!_active->_pending_tx || !_active->_pending_tx->awaiting_ack || _active->_pending_tx->ctr_lo != k.ctr_lo) return;
    // src-less by design (see handle_cts): to+ctr_lo already identifies the ACK as our next-hop's. The
    // src_hint cross-check is SIM-ONLY, so gate it on availability rather than REJECTING when absent — the
    // old `src_hint < 0 ||` dropped EVERY ack on metal (device src_hint=-1), so the DM never completed.
    if (meta.src_hint >= 0 && static_cast<uint8_t>(meta.src_hint) != _active->_pending_tx->next) return;  // (cf. NACK gate, Lua dv:10300)
    _hal.cancel(kAckTimeoutTimerId);
    _hal.cancel(kRetryBackoffTimerId);                   // drop a stale retry armed by a just-fired ack_timeout
    // Learn the ACK sender (= our next-hop) as a 1-hop neighbour (Lua learn_rx_source / ack_frame).
    // §mobile 3b A1: a last-mile flight's next-hop is a mobile LOCAL id -> keep it OUT of the global rt (same principle as
    // the RTS-learn skip at :47; else rt_find(that id) resolves to the mobile). §6.4: a team DM's next is a team LOCAL id
    // too (addr_len=0 but is_team_peer) -> also skip. addr_len==0 + no team peers on every normal flight -> unchanged.
    // §team-parity T0: plane made explicit (was the default). Static reduction: `false` IS the old default.
    // ✔ §team-parity T2 (§3/T2 row 5) — the LEARN half is DONE by the else-arm below; this guard is UNCHANGED (I2).
    if (!(next_is_local_id(_active->_pending_tx->addr_len, _active->_pending_tx->next))
        && learn_direct_neighbor(_active->_pending_tx->next, protocol::db_to_q4(meta.snr_db), false, /*team_plane=*/false)) schedule_triggered_beacon();
#if MR_FEAT_TEAM
    // ✔ §team-parity T2 (§3/T2 row 5): an ACK from OUR next-hop on a TEAM flight is the strongest 1-hop proof there is —
    // it carried our DATA. Same else-arm algebra as the CTS site: !next_is_local_id false is the only path in, so the arm
    // fires exactly on the traffic the guard excludes; is_team_peer is our own state (no id admitted); team_id==0 ⇒ inert.
    // ⚠ §team-parity T5 — ROW 5's "team confirm" IS REFUSED, AND THE SPEC/T2 NOTE THAT ASKED FOR IT WAS WRONG. T5 built the
    // team bidi plane, so "there is nothing to write it to" no longer applies; the reason is now stronger. MEASURED AT
    // SOURCE: note_link_confirmed has exactly TWO callers in the whole engine — the CTS site (:506/:519) and the beacon
    // heard-set scan (node_beacon.cpp) — so THE STATIC PLANE PERFORMS NO BIDI CONFIRM ON AN ACK EITHER. Adding one here
    // for the team plane would not be parity, it would be a team-ONLY mechanism the static plane lacks (the exact inverse
    // of this arc's mandate), and it would be pure decoration: an ACK is structurally unreachable without a CTS for the
    // same flight (`awaiting_ack` is set only inside do_data_tx / its stash-retry and re-issue twins, all of which run
    // after handle_cts's kCtsToDataGapTimerId), so the team confirm has ALREADY fired microseconds earlier on this very
    // flight and would only restamp an identical second. ⇒ REFUSED as a forced fit, per the gate method's §C. The team
    // LIVENESS confirm does happen here, inside learn_direct_neighbor's team branch. If a future slice ever gives the
    // static plane an ACK-time confirm, add BOTH arms together.
    else if (is_team_peer(_active->_pending_tx->next)
             && learn_direct_neighbor(_active->_pending_tx->next, protocol::db_to_q4(meta.snr_db), false, /*team_plane=*/true)) schedule_triggered_beacon();
#endif
    // R4.2: consume the ACK's piggybacked budget_hint -> learn the next-hop's tier in the FORWARD
    // direction (the NACK only covers the reverse). local_only=true: rerank routes but DON'T dirty /
    // schedule a beacon (so NO triggered-beacon draw on the forward path). Lua dv:10341-10344.
    [[maybe_unused]] int ack_budget_reranked = 0;
    if (k.budget_hint > static_cast<uint8_t>(BudgetTier::healthy)
        && !(next_is_local_id(_active->_pending_tx->addr_len, _active->_pending_tx->next))) {   // §mobile: never re-rank a static route from a mobile/team LOCAL next (mirror the ACK-learn guard)
        const uint8_t tier = (k.budget_hint > static_cast<uint8_t>(BudgetTier::critical))
                             ? static_cast<uint8_t>(BudgetTier::critical) : k.budget_hint;
        // the ACK is from our next-hop (matched above) — use that, not src_hint (sim-only / -1 on device).
        ack_budget_reranked = mark_neighbor_budget_tier(_active->_pending_tx->next,
                                                        tier, "ack_budget", /*local_only=*/true);
    }
    // Inc 3: a warn'd ACK means our next-hop considers us near its airtime cap. Honest back-off — park new
    // DM originations until the warn window expires (the hard receiver-side drop is the backstop). The
    // window self-clears: as our airtime ages out of the neighbour's window it stops setting the bit.
    if (k.warn) {
        _ack_warn_until = _hal.now() + protocol::originator_ack_warn_backoff_ms;
        MR_EMIT("originator_warned_by_ack", EF_I("from", _active->_pending_tx->next), EF_I("ctr_lo", k.ctr_lo),
                EF_I("backoff_until_ms", static_cast<int64_t>(_ack_warn_until)));
    }
    MR_EMIT("ack_rx", EF_I("from", _active->_pending_tx->next), EF_I("origin", _active->_pending_tx->origin),
            EF_I("dst", _active->_pending_tx->dst), EF_I("ctr", _active->_pending_tx->ctr), EF_I("budget_hint", k.budget_hint),
            EF_I("budget_reranked", ack_budget_reranked), EF_I("airtime_warn", k.warn ? 1 : 0));  // ACK is from our next-hop (src_hint=-1 on metal)
    // §CUSTODY-B §6.2(5): `send_acked` is the GENERIC user-send hop-ack outcome, so a protocol-internal flight
    // does not raise one — the app must not see a hop ACK for an E2E ack / hash answer under a ctr it never
    // minted. ⛔ The PROTOCOL-SPECIFIC results are untouched (§6.2(6)): `send_e2e_acked` still fires on receipt
    // of a DATA_TYPE_E2E_ACK (node_mac_rx.cpp, the E2E-ACK arm), and `team_key_received` still fires on a grant.
    if (data_type_traits(_active->_pending_tx->type).generic_send_lifecycle)
    { Push pu{}; pu.kind = PushKind::send_acked; pu.dst = _active->_pending_tx->dst; pu.ctr = _active->_pending_tx->ctr; enqueue_push(pu); }
    _active->_pending_tx.reset();
    become_free();
}

// The sender's NACK handler (dv:10365). A NACK is faster feedback than the timeout:
// LOOP_DUP -> cascade to an alt (or direct giveup); BUSY_RX -> mark the peer blind +
// wait-same-hop (short busy) or requeue (long busy). BUDGET/HOP_BUDGET deferred.
void Node::handle_nack(const uint8_t* bytes, size_t len, const RxMeta& meta) {
    auto pn = parse_nack(std::span<const uint8_t>(bytes, len));
    if (!pn) return;
    const nack_out& n = *pn;
    // §mobile: mirror the ACK gate — a NACK to a mobile/team LOCAL id carries mobile_to=1 (accepted by the mobile, IGNORED
    // by a colliding STATIC id). Without this a static node whose global id == a mobile's local id could mis-consume a NACK
    // meant for the mobile (a spurious back-off/reroute). mobile_to==0 for a static originator -> byte-identical.
    if (!for_me_dst(n.to) || ((n.mobile_to == 1) != _cfg.is_mobile)) return;   // §6.4: not for EITHER of our plane ids (node_id / team_local_id)
    if (!_active->_pending_tx) return;                                       // no flight to react on
    if (_active->_pending_tx->ctr_lo != n.ctr_lo) return;                    // stale (different flight). L9 NOTE: WIRE-bounded — a NACK carries only the 4-bit ctr_lo, not flight_gen, so a NACK for a since-replaced flight with an ALIASED ctr_lo (1/16) can still match here. Fully fixing needs more wire ctr bits (a frame change, out of scope); the LOCAL re-arm paths (retry-stash, nack-wait) are now flight_gen-exact.
    if (meta.src_hint >= 0 && static_cast<uint8_t>(meta.src_hint) != _active->_pending_tx->next) {
        MR_EMIT("nack_drop_unexpected_src", EF_I("from", static_cast<uint8_t>(meta.src_hint)));
        return;
    }
    // Learn the NACK sender (= our next-hop) as a 1-hop neighbour (Lua learn_rx_source / nack_frame).
    // §mobile: same mobile/team LOCAL-id guard as the ACK/CTS learns — never install a local id in the static _rt.
    // §team-parity T0: plane made explicit (was the default). Static reduction: `false` IS the old default.
    // ✔ §team-parity T2 (§3/T2 row 6) — DONE by the else-arm below; this guard is UNCHANGED (I2).
    if (!(next_is_local_id(_active->_pending_tx->addr_len, _active->_pending_tx->next))
        && learn_direct_neighbor(_active->_pending_tx->next, protocol::db_to_q4(meta.snr_db), false, /*team_plane=*/false)) schedule_triggered_beacon();
#if MR_FEAT_TEAM
    // ✔ §team-parity T2 (§3/T2 row 6): a NACK from OUR next-hop on a TEAM flight still proves it heard us and is 1 hop
    // away — the flight failed, the LINK did not. Same else-arm algebra and the same inertness at team_id==0 as rows 3/5.
    // (No bidi/confirm half in this row; the static twin has none either — a NACK confirms reachability, not quality.)
    else if (is_team_peer(_active->_pending_tx->next)
             && learn_direct_neighbor(_active->_pending_tx->next, protocol::db_to_q4(meta.snr_db), false, /*team_plane=*/true)) schedule_triggered_beacon();
#endif
    _hal.cancel(kRtsTimeoutTimerId);                                // faster than the timeout (dv:10390)
    _hal.cancel(kAckTimeoutTimerId);
    _active->_pending_tx->awaiting_cts = false; _active->_pending_tx->awaiting_ack = false;
    PendingTx& pt = *_active->_pending_tx;

    if (n.reason == protocol::nack_reason_loop_dup) {
        [[maybe_unused]] const uint8_t from_next = pt.next;
        mark_tried(pt, pt.next);
        const uint8_t alt = pick_next_cascade_hop(pt);
        if (alt != 0) {                                            // cascade to an alt (NO jitter)
            MR_TELEMETRY(
                EventField f[] = { { .key = "origin",   .type = EventField::T::i64, .i = pt.origin },
                                   { .key = "dst",      .type = EventField::T::i64, .i = pt.dst },
                                   { .key = "ctr",      .type = EventField::T::i64, .i = pt.ctr },
                                   { .key = "from_next", .type = EventField::T::i64, .i = from_next },
                                   { .key = "next",     .type = EventField::T::i64, .i = alt } };
                _hal.emit("path_cascade", f, 5);
                _hal.emit("tx_loop_alt", f, 5); );
            pt.next = alt;
            pt.retries_left = effective_rts_max_retries(pt.requeue_count);
            pt.retry_attempt = 0;                                 // cascade -> a NEW contention context: reset the backoff growth (spec 2026-06-26)
            tx_rts_retry();
        } else {                                                  // LOOP_DUP miss -> DIRECT giveup (NOT requeue, dv:10588)
            MR_TELEMETRY(
                EventField f[] = { { .key = "dst", .type = EventField::T::i64, .i = pt.dst },
                                   { .key = "ctr", .type = EventField::T::i64, .i = pt.ctr } };
                _hal.emit("path_cascade_exhausted", f, 2);
                _hal.emit("rts_giveup", f, 2); );
            giveup_flight(SendFailReason::no_cts, pt.dst, pt.ctr);   // §3-A.5: no_cts (was reason=none). §CUSTODY-E: the reason is NAMED, not parsed out of a literal event string
        }
        return;
    }

    if (n.reason == protocol::nack_reason_busy_rx) {
        const uint64_t now = _hal.now();
        const uint64_t busy_for = static_cast<uint64_t>(n.payload) * protocol::nack_busy_quantum_ms;
        MR_EMIT("nack_rx", EF_I("from", pt.next), EF_I("reason", protocol::nack_reason_busy_rx),
                EF_I("busy_ms", static_cast<int64_t>(busy_for)));
        // §mobile (plane-separation re-audit): only blind a GLOBAL next-hop. A mobile/team LOCAL-id next (addr_len=1 /
        // is_team_peer) must not write the static _blind_until plane (a §18-colliding static route would be blinded).
        // Mirrors the OTHER blind guard (the HOP_BUDGET/BUDGET NACK path). Inert on s18 -> byte-identical.
        if (busy_for > 0 && !(next_is_local_id(pt.addr_len, pt.next))) {   // mark the peer blind, max-merge (dv:10627)
            const uint64_t until = now + busy_for;
            auto bit = _active->_blind_until.find(pt.next);
            _active->_blind_until[pt.next] = (bit != _active->_blind_until.end() && bit->second > until) ? bit->second : until;
            MR_EMIT("blind_observed", EF_I("next", pt.next));
        }
        if (busy_for <= protocol::nack_wait_threshold_ms) {        // short busy -> wait SAME hop
            const int jit = _hal.rand_range(0, static_cast<int>(retry_jitter_ms()) + 1);   // N1 (the only new draw)
            const uint32_t wait = static_cast<uint32_t>(busy_for) + 1 + static_cast<uint32_t>(jit);
            _nack_wait_flight_gen = pt.flight_gen; _nack_wait_pending = true;   // L9: key the BUSY_RX re-RTS wait on the exact flight (was pt.ctr_lo)
            (void)_hal.after(wait, kNackWaitTimerId);
        } else {                                                  // long busy -> requeue SAME hop (verbatim meta)
            TxItem it = txitem_from_pending(pt);   // S1: full identity+crypto core (incl. nonce_seed — the uncited long-busy drop)
            it.requeue_count = pt.requeue_count; it.enqueue_time_ms = pt.enqueue_time_ms;   // VERBATIM (no ++/backoff)
            it.next_attempt_ms = 0;
            MR_EMIT("tx_requeued", EF_I("dst", pt.dst), EF_I("ctr", pt.ctr));
            if (_active->_tx_queue_n < kTxQueueCap) {
                _active->_tx_queue[_active->_tx_queue_n++] = it;
            } else {                                              // queue full -> can't requeue; give up loudly
                MR_TELEMETRY(
                    EventField gf[] = { { .key = "dst", .type = EventField::T::i64, .i = pt.dst },
                                        { .key = "ctr", .type = EventField::T::i64, .i = pt.ctr } };
                    _hal.emit("path_cascade_exhausted", gf, 2);
                    _hal.emit("rts_giveup", gf, 2); );
                // [[B268]] blocker-1: the `giveup_flight` twin — same shared helper, same `generic_owed = true`
                // (this site always owed one). NOT `giveup_flight` itself: the reset + become_free below are
                // shared with the requeue arm above.
                terminal_carrier_outcome(pt.type, !pt.has_previous_hop, /*generic_owed=*/true,
                                         SendFailReason::no_cts, pt.dst, pt.ctr);   // §3-A.5: no_cts (§CUSTODY-E: named, not string-parsed)
            }
            _active->_pending_tx.reset();
            become_free();
        }
        return;
    }

    if (n.reason == protocol::nack_reason_hop_budget) {
        // TERMINAL (dv:10487): the route was longer than the budget assumed. Bump
        // rt[dst].hops UPWARD so a FUTURE send (new ctr) budgets correctly, then DROP
        // (no retry/cascade — a same-ctr retry would recompute the same too-small
        // budget). committed (the NACK payload high nibble) is a lower bound on the
        // true distance. This bump feeds do_data_tx's initial-budget computation.
        const uint8_t committed = static_cast<uint8_t>((n.payload >> 4) & 0x0f);
        RtEntry* e = rt_find(pt.dst);
        if (e != nullptr && e->n > 0) {
            const int want = (committed + 1 > e->candidates[0].hops) ? (committed + 1)
                                                                     : e->candidates[0].hops;
            const uint8_t new_hops = static_cast<uint8_t>(want > 15 ? 15 : want);   // 4-bit DV field clamp
            if (new_hops != e->candidates[0].hops) {
                e->candidates[0].hops = new_hops;
                // §3-A.5: route through the shared emit_rt_update (was a hand-rolled 4-field emit missing `score`); keep the
                // slot string. Carries the route's current score so the rt_update schema matches the beacon-merge sites.
                emit_rt_update(_hal, pt.dst, e->candidates[0].next_hop, e->candidates[0].score, new_hops, "hop_budget_nack");
            }
        }
        MR_EMIT("nack_rx", EF_I("from", pt.next), EF_I("reason", protocol::nack_reason_hop_budget), EF_I("committed", committed));
        MR_TELEMETRY(
            EventField gf[] = { { .key = "dst", .type = EventField::T::i64, .i = pt.dst },
                                { .key = "ctr", .type = EventField::T::i64, .i = pt.ctr } };
            _hal.emit("path_cascade_exhausted", gf, 2);
            _hal.emit("rts_giveup", gf, 2); );
        giveup_flight(SendFailReason::no_cts, pt.dst, pt.ctr);   // §3-A.5: no_cts (was reason=none). §CUSTODY-E: named, not string-parsed
        return;
    }

    if (n.reason == protocol::nack_reason_budget) {
        // R4.1 (Lua dv:10406-10453): the next hop refused on its own duty budget. Blind it for a
        // tier-scaled window + requeue the flight (the re-issue skips the now-blind hop via
        // pick_next_cascade_hop -> alt, or originator-defer / forwarder-drop). The blind window is
        // short-term "don't try right now"; the routing-grade persistent demotion is R4.2.
        const uint8_t tier = static_cast<uint8_t>((n.payload >> 4) & 0x0f);                // inline decode
        uint32_t blind_ms = protocol::budget_blind_critical_ms;                            // tier==CRITICAL default
        if      (tier >= static_cast<uint8_t>(BudgetTier::exhausted)) blind_ms = protocol::budget_blind_exhausted_ms;
        else if (tier <= static_cast<uint8_t>(BudgetTier::strained))  blind_ms = protocol::budget_blind_strained_ms;
        const uint64_t until = _hal.now() + blind_ms;                                      // max-merge (dv:10416-10422)
        auto bit = _active->_blind_until.find(pt.next);
        if (!(next_is_local_id(pt.addr_len, pt.next))                        // §mobile: never blind a static route on a mobile/team LOCAL next (mirror the NACK-learn guard)
            && (bit == _active->_blind_until.end() || until > bit->second)) {
            _active->_blind_until[pt.next] = until;
            MR_EMIT("blind_observed", EF_I("next", pt.next));
        }
        // R4.2: record the persistent neighbor tier (routing-grade demotion beyond the blind window)
        // + rerank affected routes. local_only=false -> dirty + a triggered beacon if a primary moved.
        // Reads pt.next BEFORE try_cascade_requeue resets _active->_pending_tx.
        [[maybe_unused]] const int reranked = (next_is_local_id(pt.addr_len, pt.next))   // §mobile: never re-rank a static route from a mobile/team LOCAL next
            ? 0 : mark_neighbor_budget_tier(pt.next, tier, "nack_budget", /*local_only=*/false);
        MR_EMIT("nack_rx", EF_I("from", pt.next), EF_I("reason", protocol::nack_reason_budget), EF_I("tier", tier),
                EF_I("reranked", reranked));
        // requeue-or-giveup: the helper does both legs (caps -> exhausted+giveup+drop, else
        // requeue@backoff) + _active->_pending_tx.reset() + become_free()/timer (dv:10449-10467). The caps
        // giveup event is "rts_giveup" (Lua dv:10462; "budget_low" is the trigger, not the name).
        // ★ §CUSTODY-E: a BUDGET NACK answers an RTS, so the root stage is `cts` — ⛔ derived from what the flight
        //   was waiting for, NOT from the "rts_giveup" label the emit happens to carry. `repair_attempted = false`
        //   is this path's honest answer: it invokes no `emit_route_request` at all (the duty-budget response is a
        //   blind window + a rerank, never a rediscovery). ⓘ This IS inside the custody seam whenever the requeue
        //   caps fire, and it is a DIFFERENT thing from §9.4's excluded "hop-budget NACK" terminal (:2460), which
        //   gives up DIRECTLY and never enters a selected cascade branch.
        try_cascade_requeue(pt, CustodyRootStage::cts, "rts_giveup", /*repair_attempted=*/false);
        return;
    }

    // BUDGET tier > CRITICAL etc. all handled above. Any other (future) reason: defensive restore
    // of awaiting_cts + re-arm so an unexpected NACK doesn't strand the flight (timeouts cancelled above).
    pt.awaiting_cts = true;
    start_rts_timeout();
}

}  // namespace meshroute
