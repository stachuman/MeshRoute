// MeshRoute — lib/core/node.h
// Author: Stanislaw Kozicki <cgpsmapper@gmail.com>
//
// The protocol node. Depends ONLY on hal.h (no Arduino/RadioLib/sol/json), so
// it runs unchanged on both HAL backends: FirmwareNode in the simulator and the
// MeshCore-PHY device backend. Bounded, fixed-size state (no heap in hot paths).
//
// SCOPE (as built, 2026-06): the Node spans the FULL same-layer + cross-layer stack —
// beacon emit + DV routing (aging/TTL prune/discovery FSM), the MAC data plane (RTS/CTS/
// DATA/ACK/NACK + throttle/triggered/cascade/LBT/NAV), hash-locate (H), E2E DM crypto
// (sealed-sender), node_id DAD + heal, channel gossip + flood, peer-liveness, and the
// dual-layer gateway. The class is split across partial-class TUs (node_*.cpp).
// The ONE unbuilt design slice is R6 leaf-config membership (lineage/epoch/config_hash
// beacon header + CONFIG_PULL) — docs/specs/2026-06-05-identity-leaf-membership-join-design.md
// + the R6 implementation spec. (Historical iteration docs: docs/specs/2026-05-29-r1-* / r2-*.)
#pragma once
#ifndef MESHROUTE_NS
#define MESHROUTE_NS meshroute   // Slice 5 faithful two-lib: gateway variant compiles with -DMESHROUTE_NS=meshroute_gw
#endif
#include "mr_features.h"   // compile-time feature split (MR_FEAT_*); state/APIs below are #if-gated by these
#include "hal.h"
#include "command.h"
#include "inbox.h"
#include "protocol_constants.h"
#include "frame_codec.h"   // §mobile 5a: LayerRecord (the learned-directory record) — codec structs are header-only
#include <cstddef>
#include <cstdint>
#include <map>
#include <vector>
#include <optional>
#include "node_carriers.h"   // value-carrier structs (LayerConfig/NodeConfig/RtEntry/TxItem/... — node-legibility Slice 2, 2026-07-15)
#include "recent_ring.h"     // recent_ring_hit/_mark/_age_out — the ONE bounded seen-recently ring discipline (§3-B.1)
#include "team_seen_ring.h"  // §UI-16 N1: TeamSeen + the pure nearby-team observation ring (read-only; no other plane is touched)
#include "jittered_tx_stash.h"   // jtx_stash_arm/_ring_arm/_ring_armed — the ONE de-storm stash discipline (§3-B.5)
// ★★★ §remote-admin v2 SLICE 5 — the target's session/admission/bootstrap VALUE TYPES and their pure service.
//   Included UNCONDITIONALLY and deliberately: the header carries ⛔ NO `MR_FEAT_RADMIN_*` reference at all (the
//   [[B255]] idiom, and what keeps `tools/probe_features/ownership.py`'s three-file census unchanged by its
//   arrival), so it costs a role that compiles the state OUT exactly nothing but a declaration. The ONE member
//   and every entry point below are `#if MR_FEAT_RADMIN_ACCEPT`.
#include "remote_session.h"
#include "remote_client.h"

namespace MESHROUTE_NS {

#if MR_FEAT_RADMIN_CLIENT
class Node;
// Stack-only binding to the mobile's existing checked DM carrier. Node owns no adapter.
struct NodeRadminClientCarrier final : IRadminCarrier {
    explicit NodeRadminClientCarrier(Node& node) : node_(node) {}
    bool tx_queue_full() const override;
    RemoteClientSend submit_request(const RemoteClientRoute&, RemoteSource, const RemoteCarrier&,
                                    std::span<const uint8_t>, bool e2e_ack) override;
    RemoteClientSend submit_ack(const RemoteClientRoute&, RemoteSource, const RemoteCarrier&,
                                std::span<const uint8_t>) override;
private:
    Node& node_;
};
#endif

struct m_out;          // frame_codec.h — fwd-decl so the channel ingest seam doesn't pull the codec into node.h
struct rts_out;        // frame_codec.h — fwd-decl for the FLOOD RTS-M handler seam (handle_flood_rts)
struct SuspectEntry;   // frame_codec.h — fwd-decl for the §P4 suspect-gossip apply seam (apply_suspect_gossip)
struct beacon_entry;   // frame_codec.h — fwd-decl for the Slice 3 bidi detection scan seam (update_link_bidi_from_beacon)


struct data_unicast_inner;   // frame_codec.h — fwd-decl for bridge_cross_layer's const-ref param (full type in node_mac_rx.cpp)

// ★★★★ §CUSTODY-E (2026-08-31) — **THE TYPED TERMINAL CONTEXT** (design §11), the seam that replaces
//      event-string inference at the SELECTED cascade terminals.
//
// ⛔⛔ IT IS A BOUNDED VALUE AND IT DELIBERATELY HOLDS **NO** `PendingTx`. §11 describes the context as carrying
//     "an immutable reference to the complete live `PendingTx`", and that reference is the terminal helper's OWN
//     `const PendingTx&` PARAMETER — valid ONLY until `_pending_tx.reset()`, which is why it cannot be a member
//     here. Storing one would either dangle (the reset destroys the optional) or force the ~352-byte stack copy
//     §11 forbids outright. ⇒ three bytes, no aliasing, no lifetime question.
//
// ⛔ AND IT IS **NOT** SLICE F's SNAPSHOT. F materializes a bounded 24-byte VALUE snapshot (§9.2) from the live
//    carrier BEFORE the reset and consumes it AFTER `become_free()`; that object does not exist in this slice and
//    nothing here is a stand-in for it. What E owns is the three ANSWERS — stage, cause, repair — that cannot be
//    recovered once the combined cascade state is erased.
struct TerminalCustodyContext {
    CustodyRootStage     stage            = CustodyRootStage::invalid;   // §9.3 bit 1/2 — WHICH exchange it died waiting for
    CustodyFailureReason cause            = CustodyFailureReason::invalid;  // §9.4 — WHY the carrier was finally deleted
    // §9.3 bit 3: this terminal cascade pass INVOKED the repair-request logic (`emit_route_request`). ⛔ It does
    // NOT claim an RREQ was admitted or aired — the rate limiter inside `emit_route_request` may refuse it — and
    // it is set at the CALL, never inferred from a give-up event's name.
    bool                 repair_attempted = false;
};

// ★★★★ §CUSTODY-F (2026-08-31) — **THE BOUNDED VALUE SNAPSHOT** §11 step 7 requires, and the object Slice E's
//      banner above says "does not exist in this slice". It does now.
//
// ⛔⛔ IT IS A **VALUE**, AND THAT IS THE WHOLE POINT (§11, verbatim: *"Do not copy the approximately 352-byte
//     `PendingTx` onto a firmware stack merely to retain 24 diagnostic bytes"*). It holds the §9.2 record — the
//     24 bytes that will be transmitted — plus the one boolean saying whether §10.1's twelve conditions were ALL
//     true. No pointer, no reference, no span into the carrier. ⇒ it stays valid across `_pending_tx.reset()`
//     and `become_free()`, which is exactly the lifetime step 7 demands.
//
// ⛔ THERE IS NO SEPARATE "notice destination" FIELD, deliberately: the notice is addressed to the failed DATA's
//    ORIGINAL SENDER, which IS `rec.failed_origin` (§9.1). A second copy of the same id is a second authority
//    that can disagree with the record it travels with (U2).
//
// ⓘ MEASURED, not asserted: `sizeof(CustodyFailureRecord)` is 28 (the `uint32_t dst_hash32` forces 4-byte
//   alignment over a 24-BYTE WIRE record) and `sizeof(CustodyNoticeSnapshot)` is 32 — a stack local at ONE
//   function, never a `Node` member, so `sizeof(Node)` cannot move. Both are pinned by a native `static_assert`.
struct CustodyNoticeSnapshot {
    bool                 eligible = false;   // §10.1's twelve conditions, ALL answered while the carrier was ALIVE
    CustodyFailureRecord rec{};              // §9.2's v1 body; `rec.failed_origin` is also the notice's `dst`
};

class Node {
public:
    Node(Hal& hal, uint8_t node_id, uint32_t key_hash32, const char* name = nullptr);

    bool on_init(const NodeConfig& cfg);                                 // cfg borrowed; false = REFUSED (bad dual-layer config, §3.2)
    // Reassign identity post-construct (device boots id=0 then loads it from NV; the join runtime sets it
    // too). 0 = unprovisioned (do_send is refused). 0xFF is reserved and ignored.
    void set_identity(uint8_t node_id, uint32_t key_hash32);
    // DP1 (Phase-1 E2E): install the X25519 ECDH secret + our Ed25519 pubkey, so we can seal/open DMs.
    // Identity is GLOBAL (a gateway shares ONE across both layers). Until set, crypto_ready()==false and any
    // seal/open FAILS LOUD (never silently falls back to cleartext). Backends derive these from the /mrid seed
    // (device) or the per-node scenario seed (sim).
    void set_crypto_identity(const uint8_t x_secret[32], const uint8_t ed_pub[32]);
    // §remote-mgmt (spec 2026-07-13): the pinned admin pubkey (trust anchor for gated rcmds) + the replay counter floor.
    // RAM state; fw_main loads from / persists to the NV Blob (admin_pubkey/admin_counter_floor/admin_provisioned).
#if MR_FEAT_REMOTE_MGMT
    bool           admin_provisioned() const { return _admin_provisioned; }
    const uint8_t* admin_pubkey()      const { return _admin_provisioned ? _admin_pubkey : nullptr; }
    uint32_t       admin_counter_floor() const { return _admin_counter_floor; }
    void admin_set_pubkey(const uint8_t ed_pub[32]) { for (int i=0;i<32;++i) _admin_pubkey[i]=ed_pub[i]; _admin_provisioned = true; }
    void admin_load(const uint8_t ed_pub[32], uint32_t floor, bool provisioned) { for (int i=0;i<32;++i) _admin_pubkey[i]=ed_pub[i]; _admin_counter_floor = floor; _admin_provisioned = provisioned; }
    bool admin_counter_check_advance(uint32_t counter) { if (counter > _admin_counter_floor) { _admin_counter_floor = counter; return true; } return false; }
#else
    bool           admin_provisioned() const { return false; }
    const uint8_t* admin_pubkey()      const { return nullptr; }
    uint32_t       admin_counter_floor() const { return 0; }
    void admin_set_pubkey(const uint8_t*) {}
    void admin_load(const uint8_t*, uint32_t, bool) {}
    bool admin_counter_check_advance(uint32_t) { return false; }
#endif
    void on_recv(const uint8_t* bytes, size_t len, const RxMeta& meta);  // bytes valid during call only
    void on_timer(uint32_t timer_id);                                    // dispatch on Node-owned id
    // ★★★ §B186a 2026-08-12 — THE MOBILE TX-OPERATION IDENTITY, and it rides `TxParams::tag` / `BusyInfo::tag`.
    // The four mobile attachment frames are ALL tagged `FrameTag::beacon` at the transmitter (that is deliberate and
    // unchanged — the tag's LOW byte still selects the retry slot and the "BCN" label), so a refusal reported back
    // through `on_radio_busy` could name only "a beacon". `TxParams::tag` is a uint16 of which exactly 3 bits were
    // in use, so the operation travels in its HIGH byte: `tag = (op << 8) | FrameTag`.
    // ⛔ NOT A WIRE CHANGE: `tag` is an opaque host token (hal.h:31). No frame byte moves and no `wire_version` is
    //    touched. ⛔ NOT A LENGTH FIELD either — `BusyInfo` carries `reason`, `tag`, `sf` and `busy_until_ms`, which
    //    is exactly what the refusal report needs, and nothing was added to it.
    // ★ WHY THE HIGH BYTE AND NOT A NEW FIELD: the tag is the ONLY datum that survives the hand-off to the radio
    //   and comes BACK on the asynchronous callback. Anything the Node stores instead would have to be re-associated
    //   with the refused frame afterwards — i.e. reconstructed — which is the defect, not the fix.
    // ⓘ The LOW byte is masked out before every `FrameTag` use (`frame_tag_of`), so retry-slot selection, the
    //   telemetry label and the giveup path see exactly the values they saw before.
    enum class MobileTxOp : uint8_t { none = 0, discover = 1, offer = 2, claim = 3, reclaim = 4 };
    static uint16_t    mobile_tx_tag(MobileTxOp op);          // the TxParams::tag a mobile J frame of `op` carries
    static MobileTxOp  mobile_op_of_tag(uint16_t tag);        // decode the high byte (unknown/out-of-range -> none)
    static const char* mobile_tx_op_name(MobileTxOp op);      // "discover"/"offer"/"claim"/"reclaim"/"none"
    // ★★★ §T1 2026-08-14 — ONE core TX-completion entry, and `on_radio_busy` is now a FOUR-LINE ADAPTER onto it.
    // The two HALs used to drive two different core functions (the simulator the async refusal, the device nothing
    // at all); they now drive ONE. ⛔ The adapter is kept rather than removed: the simulator and ~35 native cases
    // call `on_radio_busy(BusyInfo)` directly, and re-pointing them is a SEPARATE refactor, not this one.
    void on_radio_busy(const BusyInfo& info);                            // deferred-TX retry/giveup (adapter -> on_tx_complete)
    void on_tx_complete(const TxOutcome& info);                          // THE core TX-completion entry (see hal.h for what is built vs missing)
    void on_preamble_detected(uint64_t time_ms);                         // SX1262 IRQ / throttle witness
    CmdResult on_command(const Command& c);                              // the typed app<->firmware seam
    bool      next_push(Push& out);                                      // drain the async push ring (CMD_SYNC_NEXT)
    // Persistent inbox (durable DM + channel history). A backend installs durable stores via
    // inbox().on_init(dm, chan) AFTER Node::on_init; until then the inbox is disabled (record-on-delivery
    // is inert). The node records on its DM/channel deliver paths; a companion pulls incrementally.
    Inbox&    inbox() { return _inbox; }

    // OTA remote diagnostics (`rcmd`, 2026-06-24): a console-style query / response carried over a DATA DM
    // (DATA_TYPE_REMOTE_CMD / _RESP). lib/core is the GENERIC transport — fw_main owns the query whitelist + execution.
    uint16_t send_remote_cmd     (uint8_t dst, const uint8_t* body, uint8_t len);   // -> a DATA_TYPE_REMOTE_CMD DM (rides routing/ACK)
    uint16_t send_remote_response(uint8_t dst, const uint8_t* body, uint8_t len);   // -> a DATA_TYPE_REMOTE_RESP DM
#if MR_FEAT_RADMIN_CLIENT
    RemoteClientState& remote_client() { return _remote_client; }
    const RemoteClientState& remote_client() const { return _remote_client; }
    void remote_client_arm() { radmin_expiry_arm(); }
    uint8_t remote_client_correlation_free() const {
        uint8_t free = 0;
        for (const auto& row : _pending_e2e_acks) free += !row.used;
        return free;
    }
    RemoteClientSend remote_client_submit(const RemoteClientRoute&, std::span<const uint8_t>, bool e2e_ack);
#endif

    // ★★★ §remote-admin v2 SLICE 1b (2026-09-06, R-RA-27 item 2) — **WHICH CAPABILITY OWNS AN INCOMING REMOTE-ADMIN
    //   DATA TYPE.** PURE, state-free and TOTAL: it reads a DataType byte plus the two capability VALUES and answers
    //   with an owner. Production calls it exactly once — in `do_post_ack` (node_mac_rx.cpp) — with the real
    //   `MR_FEAT_RADMIN_CLIENT` / `MR_FEAT_RADMIN_ACCEPT` macros in THIS argument order; the native tests call the
    //   SAME production function with all four `{client, accept}` combinations, which is the only way one host
    //   binary (compiled `{1,1}` by R-RA-17) can exercise the two DISABLED-role arms at all.
    // ⛔ THE ARGUMENTS ARE CAPABILITY VALUES, NOT A RUNTIME ROLE SWITCH: calling this with `{0,1}` does not make a
    //   Node accept-only. There is deliberately NO runtime role state and NO test-only macro override (R-RA-27).
    // ⛔ IT MUST NOT STEAL ANOTHER HANDLER'S TYPE: every DataType other than the two remote ones answers `none`.
    //   `none` CONSUMES NOTHING — no slot write, no early return, no new drop branch and no telemetry of its own;
    //   the receive chain simply continues and the frame reaches the EXISTING fail-closed internal guard, which
    //   drops it with the one ruled scalar `unsupported_internal` (both remote types are `traits.internal`).
    enum class RadminRxOwner : uint8_t {
        none            = 0,   // unowned in this configuration -> falls through to the fail-closed internal guard
        command_accept  = 1,   // DATA_TYPE_REMOTE_CMD,  owned by MR_FEAT_RADMIN_ACCEPT (static + gateway products)
        response_client = 2,   // DATA_TYPE_REMOTE_RESP, owned by MR_FEAT_RADMIN_CLIENT (mobile products)
    };
    static RadminRxOwner radmin_rx_owner(uint8_t type, bool client_on, bool accept_on);

#if MR_FEAT_RADMIN_ACCEPT
    // ★★★ §remote-admin v2 SLICE 5 — THE FIRMWARE-INSTALLED ADMINISTRATION STATE (design §6.5's "live activation").
    //   `lib/core` has no NV access, so the durable `/mradmid` root and the `/mracl` image are INSTALLED into the
    //   Node by `src/`, exactly as the messaging identity is (`set_crypto_identity`, the ruled precedent).
    // ⛔⛔ THE ORDER IS THE CONTRACT AND IT LIVES IN `src/firmware_admin_runtime.h`: every fallible step —
    //    validation, key derivation, the entropy draw — happens in PREPARE, BEFORE the durable save; `commit` is
    //    non-failing and runs only AFTER the save succeeded. A failed save therefore leaves the running pair, ACL,
    //    epochs, seen rows and ingress EXACTLY as they were. ⛔ There is no core->NV read anywhere.
    // ⛔ NOTHING HERE DRAWS ENTROPY, ARMS A TIMER OR EMITS: `admin_draw_epoch` is the ONLY draw and it is called
    //    by the firmware's prepare, never by `on_init`. An unprovisioned Node — every simulator scenario included
    //    — performs ZERO new draws, which is what keeps all 36 deterministic streams byte-identical.
    void        admin_session_commit(const RemoteSessionInstall& plan);
    // ONE checked HAL draw of a 64-bit epoch candidate. `false` = the draw produced no non-zero material and
    // ⛔ NOTHING is written. ⚠ [[B312]] STAYS OPEN: `IHal::rand_bytes` returns `void`, so "non-zero material"
    //    is the strongest honest claim available here — it is ⛔ not a hardware-RNG health guarantee.
    [[nodiscard]] bool admin_draw_epoch(uint64_t& out) const;
    // ⛔ A COLD-BOOT ENTROPY REFUSAL — acceptance OFF, every key cleared, nothing durable touched.
    void        admin_session_entropy_failed();
    [[nodiscard]] AdminReadiness admin_session_readiness() const { return remote_session_readiness(_radmin_session); }
    [[nodiscard]] uint8_t        admin_session_slots()     const { return _radmin_session.acl_occupied; }
    // In-process read-only introspection; contains secret state and must NEVER be rendered to a console.
    [[nodiscard]] const RemoteSessionState& admin_session_state() const { return _radmin_session; }
    [[nodiscard]] bool radmin_next_admitted(RadminIngressView& out);
    [[nodiscard]] bool radmin_reserve_transcript(uint8_t seen_index, uint16_t chunk_bytes);
    void radmin_transcript_append(uint8_t seen_index, const uint8_t* p, size_t n);
    void radmin_transcript_complete(uint8_t seen_index, RemoteTerminal result);
    [[nodiscard]] RadminSend radmin_send_frame();
    void radmin_service_expire();
    [[nodiscard]] bool radmin_service_control();
    [[nodiscard]] bool radmin_next_open(RadminOpenView& out);
    [[nodiscard]] bool radmin_reserve_open(uint8_t index, uint16_t frame_cap);
    void radmin_open_append(uint8_t index, const uint8_t* p, size_t n);
    void radmin_open_complete(uint8_t index, RemoteTerminal result);
    [[nodiscard]] RadminSend radmin_send_open_frame();
    [[nodiscard]] RadminCounters radmin_counters() const { return remote_counters(_radmin_session); }
    [[nodiscard]] RemoteTerminal radmin_prepare_action(uint8_t slot, uint64_t request_id,
                                                       uint8_t kind, uint8_t backend, uint32_t activation_ms);
    [[nodiscard]] bool radmin_take_action(DeferredActionRecord& out);
    [[nodiscard]] RadminActionStatus radmin_action_status() const;
    void radmin_action_result(uint8_t kind, uint8_t outcome);
#endif

    // Exposed for the R3.x determinism golden test. The retry-jitter RANGE is a
    // cross-engine alignment contract: 3*airtime_routing(RTS_LEN=8) must equal
    // the Lua's, or the lua-vs-meshroute forced-retry streams de-align (see the
    // node_mac.cpp definition comment). Pure, const, no side effects.
    // ★★★ OWNER-RULED 2026-08-10 (ledger §1.13): **Lua parity is NOT a final MeshRoute jitter requirement**, and
    //   [[B158]] stays OPEN until MeshRoute-native jitter is measured and selected. ⛔ So this "contract" is a
    //   description of TODAY's value, NOT a reason to refuse a change. ⚠ And this ONE helper drives FOUR unrelated
    //   policies (DM origination · same-hop retry · BUSY_RX release · the LBT backoff, which is retry_jitter_ms()/2)
    //   ⇒ retuning it silently retunes all four. Full owed programme in the node_mac.cpp definition comment.
    uint32_t  retry_jitter_ms() const;                                   // 3*airtime(routing, RTS_LEN=8)

    // R4.0 duty-cycle budget tier (route-free; from the rolling airtime window). Lua dv:3555-3571.
    // Public for the tier-table unit test (the emit only observes >=CRITICAL, so the HEALTHY/STRAINED
    // boundary needs a direct call). Pure, const.
    enum class BudgetTier : uint8_t { healthy = 0, strained = 1, critical = 2, exhausted = 3 };
    BudgetTier compute_budget_tier() const;                              // HEALTHY when duty_cycle<=0 (disabled)
    // id_bind binding provenance + trust. source = WHERE it came from; confidence = whether it may OVERWRITE
    // a conflicting binding. authoritative (self / owner-confirmed hash-bind) overwrites + wins the
    // dedup-by-hash; claimed (beacon / cached / snooped) refuses a same-id conflict.
    enum class IdBindSource : uint8_t { self = 0, bcn = 1, h_query = 2, h_relay = 3 };
    enum class IdBindConf   : uint8_t { claimed = 0, authoritative = 1 };
    // ★★★ §id-hash S1b (2026-08-01, QA finding P1c): emit_hash_query's DISPOSITION. It used to be `void` with FOUR
    // silent early-outs, and `on_command`'s reqpubkey arm returned `queued` regardless — which the BLE transport then
    // turned into `{"ev":"reqpubkey_sent"}`, i.e. the contract's "the on-air request was flooded", for a request that
    // provably never left the node. ⇒ the originator now REPORTS, and the command arm maps the report to an honest
    // CmdCode. ⓘ Widening `void` -> this enum changed ZERO call sites: all four other callers already discarded the
    // (absent) return, and there is no [[nodiscard]] — so this is not the caller sweep C1 would have made a separate
    // slice, it is a return-type widening plus one reader.
    enum class HQueryOutcome : uint8_t {
        sent = 0,          // ★ the TX path ACCEPTED the frame — handed to the radio, or accepted into the LBT defer
                           //   ring. ⚠ NOT a claim of airtime (owner ruling 2026-08-01): a deferred frame reaches the
                           //   radio when a timer fires, so "it flew" is unsatisfiable synchronously. The ONLY value
                           //   that may produce `reqpubkey_sent`. A deferred frame that dies later is reported LATE
                           //   (`tx_deferred_lost`, node.cpp's defer arm).
        degenerate,        // key_hash32 == 0, or it is OUR OWN hash: there is no other node to ask
        no_identity,       // want_pubkey with no crypto identity — the MUTUAL exchange needs our ed_pub
        no_return_route,   // a mobile whose origin is still its own LOCAL id and is not team-scoped: no way back
        encode_failed,     // pack_h refused (the frame did not fit the buffer)
        // ★ §id-hash S1c (QA round 2): tx_initiating DROPPED it — the 4-slot LBT defer ring was full. Distinct from
        // the four above because it is TRANSIENT: the remedy is "retry in a moment", not "change something".
        tx_dropped
    };
    // overheard < authoritative < pinned. pinned = a QR/manually-scanned key (E2E provisioning §1): the MITM-resistant
    // tier — NEVER overwritten by an on-air answer, NEVER LRU-evicted, NEVER aged out (NV-backed on device).
    enum class PeerKeyConf  : uint8_t { overheard = 0, authoritative = 1, pinned = 2 };
    // ★ §AB2: THREE surfaces carry this level as a raw uint8_t, because neither can include this header — command.h's
    // `Push::peer_conf` (node.h includes command.h, not the reverse) and src/device_nv.h's kPeerConf* (the device record
    // layer stays free of the protocol engine). Pin the numeric encoding HERE, at the definition, so a reorder of the
    // enumerators fails the build instead of silently relabelling a stored flash byte or an app-facing JSON string.
    static_assert(static_cast<uint8_t>(PeerKeyConf::overheard)     == 0
               && static_cast<uint8_t>(PeerKeyConf::authoritative) == 1
               && static_cast<uint8_t>(PeerKeyConf::pinned)        == 2,
                  "node.h: PeerKeyConf's numeric encoding is mirrored by command.h Push::peer_conf and device_nv.h "
                  "kPeerConf* — renumbering it relabels a persisted flash byte and the peer_key_cached JSON");
    // ★★★ §AB4 — WHERE A RETAINED POSITION CAME FROM, i.e. WHICH KEY VOUCHES FOR IT (spec §2.7.2). This is a TRUST
    // ANCHOR, not a transport label, and the two anchors are NOT interchangeable:
    //   peer — a DM carrying DATA_FLAG_LOCATION, sealed to US and opened with OUR key. PAIRWISE ⇒ "this specific peer
    //          said so". node_mac.cpp's send gate makes a `-l` DM sealed BY CONSTRUCTION (an unsealed one is refused
    //          `unsealable`), so opening it also proves we hold that peer's key. ★ THE ONLY VALUE REACHABLE TODAY.
    //   team — a team CHANNEL post sealed to the shared team content key. GROUP ⇒ only "some holder of the team key
    //          said so". ✅ LIVE since §chan-crypt CL2b: `send_channel <ch> "…" -t -l -e` packs pack_loc6 into the
    //          SEALED inner (bit1) and node_channel.cpp's ingest_channel_m stores it here. ★ AB4's prediction HELD —
    //          CL2b added a SOURCE and nothing else: one `peer_loc_set` call, no schema change, no new field, no new
    //          PushKind, so the app ships ONE renderer and the weaker claim was never retro-fitted into the stronger
    //          one's slot. ★★ CORRECTED BY §chan-crypt CL2c (owner 2026-08-01): the `team` row is keyed by the
    //          sender's FULL key_hash32 CARRIED IN THE SEALED INNER (bit2, REQUIRED beside bit1), no longer INFERRED
    //          through `_team_keys` — inference failed when no beacon had been heard and mis-attributed after a
    //          DAD-re-picked team_local_id. The carried hash is still cross-checked against the msg-id's 16 hash bits;
    //          a post that fails that, or names a zero hash, is refused outright (no push, no retention).
    // ★★ THE BOUND THIS RECORDS, ACCEPTED DELIBERATELY (the I9 pattern) — DO NOT "FIX" IT: the team content key is
    // SHARED, so sealing a channel post proves MEMBERSHIP, NOT IDENTITY. Every member holds the same team_ch_priv, so
    // ANY KEYHOLDER CAN FORGE ANOTHER MEMBER'S source_hash and publish a false position attributed to a teammate.
    // T-K2's "anti-spoof within the team" means an OUTSIDER cannot spoof a member; it does not and cannot mean a member
    // cannot spoof a member. The owner's model — a hiking group holding one content key trusts itself — is reasonable;
    // `loc_src` is what keeps it HONEST, by never letting a group-anchored position be rendered as a pairwise one.
    enum class PeerLocSrc : uint8_t { peer = 0, team = 1 };
    // Why e2e_seal_inner returned 0 (the seal failed). Lets enqueue_data fail LOUD distinctly per cause instead of
    // treating every 0 as "no pubkey" (which floods a WANT_PUBKEY + drops the DM). no_pubkey is the ONLY case that
    // floods; the rest are local refusals (no_identity=R3, too_large=R2, bad_rng=R7, cross_layer=v1 scope).
    enum class SealOutcome  : uint8_t { ok = 0, no_identity, no_pubkey, too_large, bad_rng, cross_layer };
    bool       is_blind(uint8_t next_hop) const;                         // _blind_until active? (read-only; bounded by neighbour count)
    // ① mobile-as-transit avoidance (Lua dv:1325-1334): learn the is_mobile beacon bit; NEVER relay THROUGH a mobile
    // peer (it roams away), but DO deliver TO one (the next_hop==dest carve-out). Hard-exclude, not a score penalty.
    bool       is_mobile_peer(uint8_t id) const;
#if MR_FEAT_TEAM   // §featuresplit: the TEAM API stubs to inert when off -> call sites (route-select/enqueue_data/handle_rts) unchanged
    bool       is_team_peer(uint8_t id) const;   // §mobile 6.2: id is a KNOWN same-team peer (route to it via _rt_team)
    // ★★ §id-hash S3 (spec 2026-08-01 §3-D1/§3-D2) — THE CONFIDENCE FLOOR REACHES EVERY READER OF _team_keys.
    // `source`/`confidence` are MANDATORY on the setter, exactly as on `id_bind_set` (U1/U3, and C2: a defaulted
    // confidence is precisely the silent fallback that would let S4a's on-air ingest forget to say "this is a claim").
    // The three readers take a FLOOR + an optional `actual` out-param:
    //   • the floor DEFAULTS to `authoritative`, which is what makes S3 inert — every pre-S3 caller keeps its exact
    //     semantics, because today the only writer (a heard beacon) writes `authoritative` and nothing else exists;
    //   • `actual` exists because a caller CANNOT LABEL A CLAIM IT CANNOT SEE (spec §3-D1) — the peer-book row's
    //     `team_authoritative` is filled from it.
    // ★ `team_id_of_key` is the one v1 of the spec missed: it is the REVERSE reader on the LIVE plaintext
    //   send-by-hash path (do_send, node_hashlocate.cpp), so without a floor here a claimed row would leak straight
    //   into sending — spec §3-D7, a claimed binding must never drive an L2c redirect.
    void       team_key_set(uint8_t id, uint32_t key_hash32, IdBindSource source, IdBindConf confidence);   // §enc: cache a same-team peer's key_hash32; team-scoped, NOT _id_bind. §S3: UPGRADE-ONLY — see node_routing.cpp
    bool       team_key_of_id(uint8_t id, uint32_t& out, IdBindConf min = IdBindConf::authoritative, IdBindConf* actual = nullptr) const;      // §enc: team-scoped id->key_hash32 (for a CRYPTED send BY team_local_id); false = unknown/below the floor
    bool       team_id_of_key(uint32_t key_hash32, uint8_t& out_id, IdBindConf min = IdBindConf::authoritative, IdBindConf* actual = nullptr) const;   // §mobile 6.4: reverse team-scoped hash->team_local_id (a PLAINTEXT send-by-hash to a HEARD teammate); false = unknown/below the floor
    // §team-ch-key (T-K1, spec 2026-07-26 §2.1): the TEAM CHANNEL keypair — the CONTENT key, distinct from
    // membership. RAM state; src/fw_main.cpp loads it from / src/firmware_config.cpp persists it to the NV Blob
    // (team_ch_pub / team_ch_priv / team_ch_key_present, v22) — the same shape as the admin_* trio above.
    bool           team_channel_key_present() const { return _team_ch_key_present; }
    const uint8_t* team_channel_pub()  const { return _team_ch_key_present ? _team_ch_pub  : nullptr; }   // nullptr = no key (never a zero buffer a caller could mistake for one)
    const uint8_t* team_channel_priv() const { return _team_ch_key_present ? _team_ch_priv : nullptr; }
    bool team_channel_key_mint();                                                   // `team new`: draw 32 B from the HAL CSPRNG -> canonical pair. false = REFUSED (dead RNG); state untouched
    bool team_channel_key_adopt(const uint8_t pub[32], const uint8_t priv[32]);     // `team new tkpub=/tkpriv=` · T-K4 QR. false = REFUSED (all-zero, or pub doesn't match priv); state untouched
    bool team_channel_key_adopt_priv(const uint8_t priv[32]);                       // §T-K3: adopt from the PRIVATE HALF ALONE (the sealed grant carries only tkpriv) — same derivation path, pub re-derived. false = REFUSED (all-zero/degenerate); state untouched
    void team_channel_key_load(const uint8_t pub[32], const uint8_t priv[32], bool present);   // boot restore from NV — VERBATIM, no re-derivation (mirrors admin_load)
    // §o3-key-lifetime (owner ruling 2026-07-31): DESTROY the pair. The one un-doer beside the four establish paths,
    // and `set_team_id` is its only caller — a content key belongs to the team it was granted for and must not
    // outlive it. NOT reachable from the console: no verb drops a key on its own (the pair is UNRECOVERABLE).
    void team_channel_key_clear();
    // ★★★ §UI-16 N1 (spec 2026-08-22 §2.1) — THE NEARBY-TEAM OBSERVATION CACHE, READ SIDE.
    // Two `const`, allocation-free, bounded accessors over the RAM-only ring in team_seen_ring.h. The
    // retention window is applied HERE, at the read (protocol::team_seen_retain_ms), so a stale entry on
    // a silent radio can never linger readable and no sweep or timer id is needed.
    // ⓘ NO CONSUMER YET, AND THE ONE ARRIVING IS NAMED: §UI-16 slice N2 (PROVISION -> `JOIN TEAM` ->
    // NEARBY) projects each entry to `fingerprint · n/3 · age`. ⛔ N1 adds no screen, verb, push or byte.
    // ⛔ WHAT THESE DO NOT MEAN: an entry is evidence that SOMETHING NEARBY ADVERTISED that team id, and
    // nothing more — not a peer, not a route, not a membership, not a key. The id is public by design.
    uint8_t         team_seen_count() const {
        return team_seen_ring_live_count(_team_seen, _team_seen_n, _hal.now(), protocol::team_seen_retain_ms);
    }
    // The i-th RETAINED entry in first-observed order; nullptr = out of range (the normal end-of-list
    // answer, never a zero record a caller could render as a real observation — the team_channel_pub()
    // nullptr idiom).
    const TeamSeen* team_seen_at(uint8_t i) const {
        return team_seen_ring_live_at(_team_seen, _team_seen_n, i, _hal.now(), protocol::team_seen_retain_ms);
    }
#else
    bool       is_team_peer(uint8_t) const { return false; }
    void       team_key_set(uint8_t, uint32_t, IdBindSource, IdBindConf) {}
    bool       team_key_of_id(uint8_t, uint32_t&, IdBindConf = IdBindConf::authoritative, IdBindConf* = nullptr) const { return false; }
    bool       team_id_of_key(uint32_t, uint8_t&, IdBindConf = IdBindConf::authoritative, IdBindConf* = nullptr) const { return false; }
    // §team-ch-key: inert on a static build (gateway_*, MR_FEAT_TEAM 0) — a node with no team plane can hold no
    // team content key, so the mint/adopt verbs REFUSE (false) rather than silently pretending to succeed (C2).
    bool           team_channel_key_present() const { return false; }
    const uint8_t* team_channel_pub()  const { return nullptr; }
    const uint8_t* team_channel_priv() const { return nullptr; }
    bool team_channel_key_mint() { return false; }
    bool team_channel_key_adopt(const uint8_t*, const uint8_t*) { return false; }
    bool team_channel_key_adopt_priv(const uint8_t*) { return false; }
    void team_channel_key_load(const uint8_t*, const uint8_t*, bool) {}
    void team_channel_key_clear() {}   // §o3-key-lifetime: nothing to destroy — this build holds no team content key
    // §UI-16 N1: inert on a static build (gateway_*, MR_FEAT_TEAM 0) — the ring MEMBERS are compiled out
    // too, so this build costs +0 RAM. A node with no team plane can never act on a nearby team, so the
    // honest answer is an EMPTY list rather than a pretend one (C2). The write site needs no #if: the
    // observe stub below swallows the call, exactly as the mint/adopt stubs do.
    uint8_t         team_seen_count() const { return 0; }
    const TeamSeen* team_seen_at(uint8_t) const { return nullptr; }
#endif
    // §team-ch-key T-K3 (spec §2.3) — the SEALED key-grant DM (DATA_TYPE_TEAM_KEY_GRANT). Both halves live here in
    // lib/core rather than in src/: the RECEIPT is on the RX path anyway, and putting the ORIGINATION beside it means
    // the native suite can drive the whole round trip (no scenario runs a console verb, so a send half left in
    // firmware_config.cpp would have had zero automated coverage — the T-K1/T-K1b lesson).
    // ★ DELIBERATELY NOT MR_FEAT_TEAM-gated, same reasoning as T-K1b's team_export_key: NodeConfig::team_id is ungated
    // and the team_channel_* accessors have #else stubs, so on a MR_FEAT_TEAM 0 build these compile unchanged and
    // answer no_key / no_team BY CONSTRUCTION — ONE app-facing code path, and a stray TEAM_KEY_GRANT can never be delivered
    // as a DM there either (C2: no silent success, no raw key bytes in an inbox).
    // ★★★★ §UI-16 N6b (2026-08-24) — THE SEND PATH'S OWN DISPATCH FACTS, RETURNED INSTEAD OF DISCARDED.
    //      ⛔ IT ADDS NO BEHAVIOUR: every field below is a value the dispatch already computed and threw away, and
    //      the two facts it carries were the two the grant screen was INFERRING and getting wrong (QG, 2026-08-24):
    //        (1) a FULL TX QUEUE silently drops the frame at `node_mac.cpp`'s `_tx_queue_n < kTxQueueCap` while
    //            `enqueue_data` still returns the minted `ctr` ⇒ "a non-zero handle" did NOT mean "admitted";
    //        (2) a FULL PARKED RING stores nothing at `node_hashlocate.cpp`'s `park_send` ⇒ "ctr == 0" did NOT
    //            mean "parked".
    //      ⇒ the ADMISSION is now stated by the layer that performs it, and ⛔ never derived from the counter.
    // ★★★ `dst` IS THE **SEND-TIME RESOLVED** DESTINATION — the id `enqueue_data` addressed, i.e. exactly the value
    //     `push_send_aired_if_owned` later puts on `PushKind::send_aired` (`pu.dst = pt.dst`). A caller correlating
    //     a TxDone edge must use THIS, ⛔ never an id it froze earlier: `send_by_hash` re-resolves the hash against
    //     the CURRENT binding, so a re-DAD between a UI selection and the send changes it.
    struct SendDispatch {
        enum class Admit : uint8_t {
            none = 0,   // ⛔ NO admission point was reached at all. Every path that produces it has ALREADY reported
                        //   the failure through `push_send_failed` (the joining gate, the mobile-no-home gate, the
                        //   seal refusals, the TEAM_KEY_GRANT delegate/cross-layer structural refusals, the TEAM plane with
                        //   no routable team origin). ⓘ The ONE exception is arithmetic-unreachable and named at
                        //   `node_mac.cpp`'s `SealOutcome::cross_layer/ok` arm.
            queued,     // the TxItem was STORED in the TX queue — `ctr` is its origination handle, `dst` its address
            parked,     // the ParkedSend was STORED behind an H resolve — ⛔ no handle exists (`ctr == 0`)
            refused     // ADMISSION REFUSED: the TX queue or the parked ring was FULL. No grant DATA was stored or
                        //   will air; an unresolved-target H lookup may still air. ⛔ No push will ever arrive for
                        //   it. ⛔ This is the case that used to be indistinguishable from `queued`.
                        // ⚠ THE SECOND CLAUSE IS A CORRECTION, ⛔ not a hedge (QG, 2026-08-24): the parked-ring
                        //   arm calls `emit_hash_query` AFTER `park_send` returns, UNCONDITIONALLY — so a refused
                        //   park is ⛔ not radio-silent. That is PRE-EXISTING behaviour this slice deliberately
                        //   did not move; it is MEASURED by `ui16-grant-parkfull-air` (exactly one H frame,
                        //   decoded as an H query), ⛔ never worded around.
        };
        Admit    admit = Admit::none;
        uint8_t  dst   = 0;    // the send-time RESOLVED destination (0 = none was resolved)
        uint16_t ctr   = 0;    // the origination handle of the STORED item (0 = no flight exists)
    };
    enum class TeamKeyGrantTx : uint8_t {
        queued = 0,     // ★ ACTUALLY ADMITTED to the TX queue — `out_ctr` is its handle, `out_dst` its send-time id.
                        //   ⛔ NOT "airborne": physical transmission arrives later as PushKind::send_aired (§T3).
        no_team,        // we are not in a team (team_id == 0) — there is nothing to grant
        no_key,         // we hold no team channel keypair (`team new` mints one; a joiner receives one)
        no_identity,    // no E2E crypto identity, so we cannot seal — and a grant is NEVER sent in the clear
        no_pubkey,      // no AUTHORITATIVE/PINNED pubkey for the target ⇒ the remedy is `reqpubkey <hash>` or a QR import
        self,           // the target hash is OUR OWN key — granting to yourself is a no-op mis-address, not a send
        delegated,      // we are a REGISTERED MOBILE with no resolved binding ⇒ send_by_hash would delegate, and the
                        //   MOBILE_SEND wrapper's enclosed-type slot is already SEALED_RELAY ⇒ the TYPE would be lost
        too_large,      // team_name too long for the body (cannot happen from the console — a defence-in-depth refusal)
        // ★★★ THE THREE §UI-16 N6b ARMS (2026-08-24). They are APPENDED so no existing value moves, and they exist
        //     because all three used to be returned as `queued` — the word was true in one of the four cases.
        parked,         // ★ ACTUALLY STORED behind an H resolve (`send_by_hash`'s park arm). ⛔ No handle exists.
        queue_full,     // ★ ADMISSION REFUSED — the TX queue or the parked ring was FULL. ⛔ Nothing was stored and
                        //   NO GRANT DATA will air (⚠ the parked-ring refusal's pre-existing H lookup still airs,
                        //   unchanged — measured by `ui16-grant-parkfull-air`); ⛔ it is NOT a queued grant and
                        //   ⛔ not an in-flight failure either.
        send_failed     // ★ the send path refused BEFORE any admission point and has ALREADY pushed `send_failed`
                        //   (see SendDispatch::Admit::none for the exhaustive list of the paths that produce it).
    };
    enum class TeamKeyGrantRx : uint8_t {
        adopted = 0,    // key installed (idempotent: a re-grant OVERWRITES — that is how re-keying lands)
        not_sealed,     // the TEAM_KEY_GRANT arrived UNSEALED -> drop loud (a plaintext grant is a bug or an attack)
        bad_len,        // body shorter than the 37-B floor, or [4][1][name_len][32] does not account for it EXACTLY
        long_name,      // name_len > 32 (the codebase-wide name cap) -> malformed body, refuse rather than truncate
        no_team,        // we are not in a team, so no grant can match us
        team_mismatch,  // the grant names a DIFFERENT team (spec §2.3 Q2 ruling: team_id is carried defensively)
        bad_key         // tkpriv is all-zero / degenerate (team_channel_key_derive refused it)
    };
    // §UI-16 N6b: `out_ctr` and `out_dst` are the TWO CORRELATION TERMS of the flight this call created, and they are
    // written TOGETHER — both 0 unless the return is `queued`, because no other outcome has a flight to name.
    TeamKeyGrantTx team_key_grant_send(uint32_t target_hash, const char* name, uint8_t name_len, Plane plane = Plane::AUTO, uint16_t* out_ctr = nullptr, uint8_t* out_dst = nullptr);
    TeamKeyGrantRx team_key_grant_receive(const uint8_t* body, uint8_t body_len, uint32_t granter_hash, uint8_t granter_node);
    // §P2-3 (2026-07-21): is `next` a LOCAL id — a mobile last-mile (addr_len==1) OR a known same-team peer? The guard that
    // keeps a mobile/team LOCAL next OUT of the static node_id-indexed planes (bidi/liveness/rt-rerank). It was hand-pasted at
    // 11 write-sites (node_mac_rx ×9, node_cascade ×2 — two carry "audit-caught missed twin" comments) as
    // `addr_len==1 || is_team_peer(next)`. On a static build is_team_peer stubs false, so the guard is exactly the old inline.
    bool       next_is_local_id(uint8_t addr_len, uint8_t next) const { return addr_len == 1 || is_team_peer(next); }
    // §6.4: a unicast dst is FOR US — our static node_id OR our team-plane id. Off-grid node_id==_team_local_id so the
    // first term already covers it; this matters for a DUAL member (node_id=static id) delivering a DM sent to its team id.
    bool       for_me_dst(uint8_t dst) const {
#if MR_FEAT_TEAM
        return dst == _node_id || (_cfg.team_id != 0 && _team_local_id != 0 && dst == _team_local_id);
#else
        return dst == _node_id;   // no team plane -> only our static id
#endif
    }
    // §P2-1 (mixed-leaf team): the ONE definition of "a team-scoped frame is FOR US" -> LEAF-EXEMPT. A team's `create`
    // fixes the shared PHY; members homed onto DIFFERENT layers (nibbles) share team_id + PHY and MUST stay team-reachable.
    // `their_team` = the frame-carried team id (beacon type-5 TLV / H.team_id / F.team_id / DATA-M team_id). team_id==0
    // (every static, every lone mobile) -> false, so the pre-parse leaf gate stands UNCHANGED (s18/static byte-identical).
    // Consumed at beacon + H + channel M; F/RTS carry the equivalent inline (handle_f_team / team_rts_for_us) — ONE rule,
    // so a fifth RX path can't drift.
    bool       same_team(uint32_t their_team) const { return _cfg.team_id != 0 && their_team == _cfg.team_id; }
    // §P2-1 Level 2 (ruled option (a)): a TEAM member REFUSES a home whose PHY differs from its team-provisioned layers[0]
    // (freq/bw/routing_sf/cr; NOT layer_id — cross-LAYER same-PHY re-home is exactly the supported mixed-leaf case; NOT
    // sf_list — F-SF-1 keeps that across registration). bw/cr are compared EFFECTIVE (0 = inherit the global radio_bw_hz/cr,
    // matching adopt_mobile_phy). team_id==0 -> true (a lone mobile adopts any PHY = today's behavior -> byte-identical).
    bool       team_phy_ok(const LayerConfig& phy) const {
        if (_cfg.team_id == 0) return true;
        const LayerConfig& mine = _cfg.layers[0];
        const uint32_t bw_a = phy.bw_hz  ? phy.bw_hz  : _cfg.radio_bw_hz;
        const uint32_t bw_b = mine.bw_hz ? mine.bw_hz : _cfg.radio_bw_hz;
        const uint8_t  cr_a = phy.cr     ? phy.cr     : _cfg.radio_cr;
        const uint8_t  cr_b = mine.cr    ? mine.cr    : _cfg.radio_cr;
        return phy.freq_mhz == mine.freq_mhz && bw_a == bw_b && phy.routing_sf == mine.routing_sf && cr_a == cr_b;
    }
    // §P2-3 (2026-07-21): a team-scoped unicast (RTS/CTS/DATA/ACK) addressed to OUR team-plane id — the 4× hand-pasted
    // team-acceptance edge (handle_rts team_rts_for_us + team reverse-learn; handle_rts_for_us for_team_rts; handle_data
    // for_team_data). team_id==0 (every static, every lone mobile) -> false, so a static build is byte-identical.
    bool       team_addr_for_us(uint8_t next, uint8_t addr_len) const {
#if MR_FEAT_TEAM
        return _cfg.team_id != 0 && _team_local_id != 0 && next == _team_local_id && addr_len == 1;
#else
        (void)next; (void)addr_len; return false;
#endif
    }
    // §team-parity T6 (spec §3/T6 + the §11 owner ruling, 2026-07-28): "will this OUTBOUND flight be routed on the TEAM
    // plane?" — the SAME predicate rt_find (node_routing.cpp:22) already uses to pick the table, kept as one expression so
    // the identity a flight CLAIMS (stamp_origin) cannot drift from the table it is ROUTED on. TEAM forces the team plane;
    // AUTO dispatches by is_team_peer(dst); GLOBAL forces the static plane even when `dst` numerically collides a
    // teammate's team id (§18) — that carve-out is why this is not simply `plane != GLOBAL`.
    // ⚠ MISSING (deliberate, C1): node_routing.cpp:22 still carries the expression INLINE rather than calling this. It is
    // provably the same expression, but routing rt_find through it is a pure refactor and this is a feature slice — the
    // same C1 split T2 made when it built and then reverted its learn_direct_neighbor hoist. A cleanup slice owns it.
    bool       flight_is_team_plane(Plane plane, uint8_t dst) const {
#if MR_FEAT_TEAM
        return plane == Plane::TEAM || (plane == Plane::AUTO && is_team_peer(dst));
#else
        (void)plane; (void)dst; return false;   // §featuresplit: no team plane -> every flight is static
#endif
    }
    bool       route_uses_mobile_as_transit(uint8_t dest, uint8_t next_hop) const;
    uint8_t    get_neighbor_tier(uint8_t node_id) const;                 // R4.2 tier read (TTL-expiring lazy-prune); public for tests
    void       schedule_triggered_beacon();                             // R4.3 trigger jitter + min-interval defer; public UI/test trigger seam
    int        mark_neighbor_budget_tier(uint8_t node_id, uint8_t tier, const char* source, bool local_only); // :4320; public for tests
    // R4.4 originator anti-spam (dv:3205-3277). track = ledger append (prune+dedup-first); compute = the
    // sliding-window metric. kind: 0=rts, 1=cts. Draw-free. Public for tests.
    void       track_originator_observation(uint8_t sender, uint8_t kind, uint8_t ctr_lo, uint32_t air);
    void       compute_originator_metric(uint8_t sender, int& apparent, uint32_t& total_air,
                                         uint8_t& rts, uint8_t& cts) const;

    // ---- device-console diagnostics: const LIVE reads consumed by fw_main's routes/cfg/status seam.
    uint8_t           node_id()        const { return _node_id; }
#if MR_FEAT_TEAM
    uint8_t           team_local_id()  const { return _team_local_id; }   // §mobile 6.4: the team-plane id (0 = not team-DAD'd)
    void              set_team_local_id(uint8_t id) { _team_local_id = id; _team_dad_pending = false; }   // §mobile 6.4: load a PERSISTED id at boot (id!=0 -> CONFIRMED, no re-DAD, announce + defend) OR ZERO it on leaving the team (id==0)
#else
    uint8_t           team_local_id()  const { return 0; }
    void              set_team_local_id(uint8_t) {}
#endif
    // §per-layer-id (2026-07-05): the id to PERSIST as nv.node_id (restore maps it to layers[0].node_id). A GATEWAY's
    // node_id() is the ACTIVE-leaf mirror (activate_layer stamps _node_id = _active leaf's node_id, flipping with the
    // window) — persisting it clobbers layer0's canonical id. layers[0].node_id is the stable, explicit gateway id (no
    // per-leaf DAD writes it back). A single-layer node has NO per-leaf id + DAD updates only _node_id, so persist that.
    uint8_t           canonical_node_id() const { return _cfg.is_gateway ? _cfg.layers[0].node_id : _node_id; }
    // The FULL 8-bit layer_id of the ACTIVE leaf (a gateway alternates leaves on the window schedule). Public so the
    // device console (`debug on`) can announce which layer the gateway is currently LISTENING on. Single-layer: layers[0].layer_id.
    uint8_t           active_layer_id() const { return _cfg.layers[static_cast<size_t>(_active - &_layers[0])].layer_id; }
    // The ACTIVE leaf's INDEX into _layers[] / _cfg.layers[] (0..n_layers-1) — NOT its wire layer_id (that is
    // active_layer_id() above). Added 2026-07-27 for the layer-explicit paths (flood_state_free / purge_tx_carriers),
    // which must name a leaf that is not necessarily the active one. The four inline `_active - &_layers[0]` uses in
    // this block predate it and are deliberately left alone (C1: converting them is a refactor, not this fix).
    uint8_t           active_layer_index() const { return static_cast<uint8_t>(_active - &_layers[0]); }
    // Per-layer BW/CR (2026-07-04): the ACTIVE leaf's bandwidth/coding-rate for the airtime model — the same
    // runtime->config index idiom as active_layer_id(). 0 in the LayerConfig = inherit the global radio_bw_hz/radio_cr
    // (a single-layer node's sole layer inherits, so these read identically to the scalars = byte-identical behavior).
    uint8_t max_data_sf() const;                                  // highest SF in allowed_sf_bitmap (largest = most robust)
    uint32_t          active_bw_hz()   const {
        const uint32_t b = _cfg.layers[static_cast<size_t>(_active - &_layers[0])].bw_hz;
        return b > 0 ? b : _cfg.radio_bw_hz;
    }
    uint8_t           active_cr()      const {
        const uint8_t c = _cfg.layers[static_cast<size_t>(_active - &_layers[0])].cr;
        return c > 0 ? c : _cfg.radio_cr;
    }
    // §layer-freq (2026-07-27): the ACTIVE leaf's RF carrier in MHz — the third member of the same family
    // (same runtime->config index idiom; 0 in the LayerConfig = inherit the global radio_freq_mhz). Exists so
    // activate_layer can push the EFFECTIVE carrier unconditionally and therefore RESET an inherit-leaf back
    // off the previous leaf's override. Returns 0.0 only when NOTHING configured a carrier (no per-layer
    // override anywhere and no global) — a documented HAL no-op, and the legacy single-carrier behaviour.
    double            active_freq_mhz() const {
        const double f = _cfg.layers[static_cast<size_t>(_active - &_layers[0])].freq_mhz;
        return f > 0.0 ? f : _cfg.radio_freq_mhz;
    }
    uint32_t          key_hash32()     const { return _key_hash32; }
    void              set_name(const char* name, uint8_t len) { _name_len = len > sizeof _name ? (uint8_t)sizeof _name : len; for (uint8_t i = 0; i < _name_len; ++i) _name[i] = name[i]; }   // §1.3: load the /mrid name into the core (for the pubkey exchange + display)
    uint8_t           name_len()       const { return _name_len; }
    uint8_t           effective_name(char* out, uint8_t cap) const;   // §1.3: the stored name, or "MeshRoute node: 0x<hash>" (the STABLE hash — the id can change) when empty. Returns the length written (never null-terminates).
    bool              crypto_ready()   const { return _crypto_ready; }   // DP1: a crypto identity is installed
    const NodeConfig& config()         const { return _cfg; }
    NodeConfig&       mutable_config()       { return _cfg; }   // LIVE tweak of dynamically-read cfg (device `cfg set`):
                                                                // touch ONLY fields the MAC re-reads each use (sf_list/lbt/
                                                                // beacon/nav/hop_cap/leaf_id/gateway), NOT on_init-cached (duty).
    // Live `cfg set` of the radio knobs (control SF / BW / CR / carrier) — updates the config the MAC + airtime
    // read, WITHOUT re-initing the Node (routes / in-flight flight survive). LBT-derived delays are cached at
    // on_init and go stale on a live change, but LBT is off by default and needs a reboot to enable.
    // §layer-freq (2026-07-27): freq_mhz joined the set because a gateway's next window switch pushes
    // active_freq_mhz() — a live `cfg set freq` that left _cfg.radio_freq_mhz stale would retune the radio now
    // and then snap it BACK to the old global on the next INHERIT-leaf activation.
    // ⚠ MISSING (pre-existing, NOT fixed here): this only repairs the INHERIT fallback. On a real board
    // fw_main pre-resolves the inherit into layers[0]/[1].freq_mhz at NV-load, so both leaves hold an
    // EXPLICIT boot carrier that still wins over the updated global — i.e. a live `cfg set freq` on a gateway
    // still snaps back at the next window switch, exactly as before this slice. The cure is to update the
    // per-layer values too (or to stop pre-resolving in fw_main); both change metal behaviour and need a
    // bench-gated slice of their own, so they are deliberately out of scope.
    void set_radio_cfg(uint8_t routing_sf, uint32_t bw_hz, uint8_t cr, double freq_mhz) {
        _cfg.routing_sf = routing_sf; _cfg.radio_bw_hz = bw_hz; _cfg.radio_cr = cr; _cfg.radio_freq_mhz = freq_mhz;
    }
    // R6.3 §2 (provisioning verbs / decision b): re-derive the duty-cycle budget after a LIVE duty change
    // (the join/create verbs, adopt_c_config, cfg-set duty) so enforcement applies without a reboot. Mirrors
    // the on_init derivation (dv:8497) — closes the known duty-live gap (the budget was on_init-cached only).
    void recompute_duty_budget() {
        _duty_cycle_budget_ms = (_cfg.duty_cycle > 0.0)
            ? static_cast<uint64_t>(_cfg.duty_cycle * _cfg.duty_cycle_window_ms) : 0;
    }
    // R6.3 provisioning verbs: reset BOTH the live epoch and the max-seen tracker together (a join/leave -> 0,
    // a create -> 1). Keeps _max_seen_epoch from leaking an old leaf's numbering into a fresh lineage's writes.
    void reset_leaf_epoch_state(uint16_t epoch) { _cfg.config_epoch = epoch; _max_seen_epoch = epoch; }
    // Reset the join FSM so a re-DAD actually RUNS on a reprovision (join/create verbs). set_identity(0) alone leaves
    // _joined set, and CmdKind::join is idempotent-once-joined -> the DAD never fires. Shared with forced_rejoin.
    void reset_join_for_reprovision();
    // Reprovision (join/create/leave verbs ONLY — NOT the heal): the old network's routes are stale. Drop ALL learned
    // routes / id-bindings / gateway schedules so the node starts the new network with a clean table. (The heal keeps
    // its routes — same network, only the id changed — so this is NOT in reset_join_for_reprovision.)
    void clear_routing_state();
    // §clean-team (2026-07-27): the TEAM plane's half of that clear, extracted so it has exactly ONE implementation and
    // TWO callers (U1) — clear_routing_state() above (the static reprovision verbs, which ALSO wipe the static plane)
    // and set_team_id() below (a team switch, which must NOT: the static network did not change, so a HOMED team mobile
    // keeps its static routes, its id-bindings and its home registration). Full inventory + the deliberate
    // NOT-cleared list are documented at the definition (node.cpp).
#if MR_FEAT_TEAM
    void clear_team_routing_state();
#else
    void clear_team_routing_state() {}   // §featuresplit: no team plane compiled in -> nothing to clear
#endif
    // §clean-team-channel + §clean-join-carriers (2026-07-27): drop every carrier that could still put a frame ON THE AIR
    // built from scope/state we are about to invalidate. ONE mechanism, TWO axes (U1) — the axis selects the per-carrier
    // predicate AND the leaf scope; see the definition (node_channel.cpp) for the full carrier table, the dependent-state
    // audit (must-scrub / harmless-and-why / not-affected) and the named residuals. READ IT before "completing" anything
    // it deliberately leaves alone.
    // ★ NOT #if MR_FEAT_TEAM-gated (it used to be, as purge_team_channel_state): the reprovision axis has NOTHING to do
    // with the team plane and `leave` IS dispatched on the gateway build (firmware_commands.cpp — only join/create are
    // MR_N_LAYERS<2), so a team-gated stub would silently stop wiping the channel plane on exactly that profile. Every
    // field the predicates read (ChannelEntry::team_id, FloodState::team_flood, channel_flavor_team) is ungated.
    enum class PurgeAxis : uint8_t {
        team_switch,   // set_team_id(): the OLD TEAM's rows/carriers only — the node's LEAF plane is still valid and SURVIVES. ACTIVE leaf only.
        reprovision,   // clear_routing_state(): the whole NETWORK changed -> EVERY staged/in-flight frame goes, on EVERY leaf.
    };
    void purge_tx_carriers(PurgeAxis axis);
    // §clean-team (2026-07-27, owner bench report "when creating a new team / joining a team, existing team routes need
    // to be cleared"): THE team-switch entry point — every LIVE writer of _cfg.team_id goes through here (`team new`,
    // `team <id>`, `team 0` — `cfg set team_id` was REMOVED 2026-07-31, §team-id-cfg-removal/B27), so the switch is
    // coherent in ONE place instead of per-verb. Returns true iff the team ACTUALLY changed (a same-team no-op clears
    // nothing — nothing is stale — and the caller skips its re-DAD). ⚠ NOT for the boot/NV path, which writes
    // _cfg.team_id directly: at boot nothing is stale AND the persisted team-DAD id must survive (see node.cpp).
    // ★★ B28/R2 (2026-07-31): adopting a NON-ZERO team also sets `_cfg.is_mobile` (role_enforce, node_role.h) — a team
    // member IS a mobile. ONE-DIRECTIONAL: `team 0` never clears it. On a build with MR_FEAT_MOBILE 0 a non-zero team
    // is REFUSED (returns false, nothing moves) instead — see the definition.
    bool set_team_id(uint32_t team_id);
    // `prep-restart` middle-tier reset: drop EVERY volatile/learned table (routes + channel buffer + liveness + pending
    // TX/RX + flood + digest/pull + dedup maps + parked/l2c/mediated) to a fresh-but-PROVISIONED state. KEEPS _cfg
    // (node_id/layer/sf_list/lineage), the crypto identity, and the DAD join — no re-join needed. (node.cpp)
    void clear_learned_state();
    // Set by a verb reprovision (do_dad); join_adopt consumes it to restart discovery ONCE the new id is stable, so the
    // fast-cadence beacons + the REQ_SYNC route-bootstrap go out under the adopted id (not the transient 0).
    void set_rediscover_pending(bool v) { _pending_rediscover = v; }
    void restart_discovery();    // re-enter discovery (fast beacon cadence + REQ_SYNC pull) to rebuild routes
    uint8_t           rt_count()       const { return _active->_rt_count; }
    uint8_t           mobile_reg_count() const { return _active ? _active->_mobile_reg_n : 0; }   // §mobile 2a: mobiles registered to this host (test/diagnostic accessor)
    // ★★★ §MH-S5 §10 / [[B154]] — **THE PER-ROW HOSTING VIEW: DIRECT-OR-REDIRECT PLUS ITS AGE.** §10 required it
    // ("The host `routes`/hosting section should print each row as direct or redirect plus its age") and the FIELD
    // LEDGER reassigned it to S5 because it belongs with §9's row lifetime: the age is exactly the quantity the
    // 25-minute expiry acts on, so a bench operator seeing `age=24m` knows the row is one minute from removal.
    // ⓘ Read-only projection, zero new state. `false` = index past the live count.
    // ⓘ `age_ms` is the ROW LIFETIME clock (§9.2), which for a redirect row is measured from BREADCRUMB RECEIPT —
    //   the same value `mobile_reg_age_out()` tests, so the display and the decision cannot disagree.
    bool              host_mobile_row(uint8_t i, uint32_t& key_hash32, uint8_t& local_id, bool& redirect,
                                      uint8_t& redirect_home_id, uint64_t& age_ms) const {
        if (!_active || i >= _active->_mobile_reg_n) return false;
        const auto& e = _active->_mobile_reg[i];
        key_hash32 = e.key_hash32; local_id = e.mobile_local_id;
        redirect = (e.redirect_home_id != 0); redirect_home_id = e.redirect_home_id;
        const uint64_t now = _hal.now();
        age_ms = (now >= e.last_heard_ms) ? (now - e.last_heard_ms) : 0;
        return true;
    }
    bool              mobile_reg_at(uint8_t i, uint32_t& key_hash, uint8_t& local_id, bool& has_pubkey) const {   // §mobile: read a hosted-mobile entry (the `routes` dump)
        if (!_active || i >= _active->_mobile_reg_n) return false;
        const auto& e = _active->_mobile_reg[i]; key_hash = e.key_hash32; local_id = e.mobile_local_id; has_pubkey = e.has_pubkey; return true; }
    // §mobile console: user/app-driven network control (fw_main handle_mobile reuses the FSM + the pull; NO new wire).
    bool              mobile_autoregister_on() const { return _cfg.mobile_autoregister; }
    // ★★ §B132: THE ONE mobile-hosting eligibility predicate. Every host-side decision consults THIS — the J
    // DISCOVER->OFFER responder (node_join handle_j), the CLAIM acceptance, presence_ingest_probe and
    // presence_emit_roster — and `cfg set host_mobiles` refuses against it. ⚠ NEVER re-spell it inline: the OFFER
    // and the probe each independently spelled `_cfg.is_mobile || !_cfg.host_mobiles` and BOTH were missing the
    // gateway clause, so the SAME defect shipped twice and the probe's comment even asserted the two were the
    // "SAME gate" (they were — both wrong). Four copies is how they drifted; one accessor is why they cannot again (U1).
    //
    // WHY A GATEWAY MUST NEVER BE A HOME (the bench defect): a gateway time-multiplexes ONE radio across two leaves,
    // so for ~half its schedule it is not listening on the mobile's leaf at all. A home owes its mobile last-mile
    // delivery, presence service, hash proxying and home liveness CONTINUOUSLY; a gateway can only owe them half the
    // time. ★ It may still SUCCEED whenever the schedule happens to align — which is exactly what let this hide on the
    // bench (a Heltec registered to gateway identity 5 on leaf 5, then lost it to leaf 6 for half of every period).
    // Intermittent success does not make the home valid.
    //
    // ★★ WHY BOTH `!is_gateway` AND `n_layers == 1` — they look redundant and they are NOT. node.cpp's on_init has
    // the single authoritative derivation `_cfg.is_gateway = (_cfg.n_layers == 2)`, so the identity holds after a
    // SUCCESSFUL on_init. It does NOT hold on the REFUSED path, which is reachable AND NON-FATAL: `_cfg = cfg` lands
    // BEFORE on_init's `validate_gateway_layers` early-return, while the derivation lands AFTER it, and
    // src/fw_main.cpp only PRINTS "config = REFUSED" and keeps running the node. A dual-layer config that fails
    // validation therefore leaves `_cfg.n_layers == 2` with `_cfg.is_gateway` still carrying the value the CALLER
    // passed — on the device a SEPARATELY-persisted NV byte (`cfg.is_gateway = nv.is_gateway`, distinct from
    // `nv.n_layers`), so it can legitimately be false. In that state `!is_gateway` PASSES and only `n_layers == 1`
    // refuses. ⇒ `n_layers == 1` is the strictly stronger, load-bearing clause; `!is_gateway` is kept because it is
    // the field every other gateway site reads, so deleting it would hide the intent. DELETE NEITHER.
    // ⚠ AND IT MUST BE `_cfg.n_layers`, NOT the runtime `_n_layers`: on that same refused path `_n_layers` is never
    // assigned (its write is also after the early return) so it reads 1 and would WRONGLY pass.
    bool              can_host_mobiles() const {
        return _cfg.host_mobiles && !_cfg.is_mobile && !_cfg.is_gateway && _cfg.n_layers == 1;
    }
    // ★★★ §MH-S4 §4.1 — THREE INDEPENDENT PLANES, NOT ONE `registered` BIT. Two of them are state machines
    // and they are ORTHOGONAL: a node can be `attached` with its link `checking`, and it must render as such.
    // The third plane (MESH SERVICE — "can the home reach destination X?") is deliberately NOT a member: its
    // only authority is the result of that specific route/send, so representing it as retained state would be
    // the display-shaped-field defect this arc keeps finding. ⛔ No surface may state or imply that a P roster
    // proves general mesh connectivity (§4.1 / §10).
    enum class MobileAttachState : uint8_t {   // "WHICH static node believes it is our home?"  Authority: a matching chosen-home P roster.
        dormant = 0,   // no home attachment is requested (auto OFF and no `mobile register` yet, or after `mobile unregister`)
        seeking,       // DISCOVER cycles are active; no chosen home; NO previous attachment to recover
        claiming,      // a home/local id was CHOSEN and the CLAIM crossed the admission boundary — roster confirmation PENDING
        attached,      // the chosen home's roster confirmed our (hash, local id, epoch) — the ONLY state the app may read as registered
        recovering     // a PREVIOUSLY ATTACHED home was lost; re-attachment is active (distinct from `seeking` so a surface can say "reconnecting", not "never had a home")
    };
    enum class MobileHomeLink : uint8_t {      // "can this mobile and that home currently communicate, BOTH ways?"  Authority: a recent correlated bidirectional exchange.
        unknown = 0,   // no confirmation yet, or the home-service state is dormant
        confirmed,     // a recent correlated bidirectional exchange with the SELECTED home succeeded
        checking,      // a confirmation is due (a probe went out unanswered), or a genuine home-path failure was attributed to the home
        lost           // the bounded run of presence misses (presence_probe_k_miss) failed
    };
    // ★ ONE enum->string map per plane, and both are `switch` WITH NO `default:` ON PURPOSE. A future enumerator
    // then breaks the build under -Wswitch (gate-blocking per the 2026-07-25 ruling) instead of silently rendering
    // as an empty string — the exact defect class that produced three enum->string bugs the byte-identity gate was
    // structurally blind to. ⛔ Never rewrite these as if-chains: -Wswitch cannot see those.
    // ⛔ AND NOTE WHAT IS ABSENT FROM `home_link_name`: the word "connected", in any spelling. §10 forbids it on
    //    every surface — it claims the MESH plane on the strength of a HOME-plane measurement.
    static const char* attach_state_name(MobileAttachState s) {
        switch (s) {
            case MobileAttachState::dormant:    return "dormant";
            case MobileAttachState::seeking:    return "seeking";
            case MobileAttachState::claiming:   return "claiming";
            case MobileAttachState::attached:   return "attached";
            case MobileAttachState::recovering: return "recovering";
        }
        return "dormant";                                          // C2: unreachable for a valid enumerator; never a silent empty string
    }
    static const char* home_link_name(MobileHomeLink l) {
        switch (l) {
            case MobileHomeLink::unknown:   return "unknown";
            case MobileHomeLink::confirmed: return "confirmed";
            case MobileHomeLink::checking:  return "checking";
            case MobileHomeLink::lost:      return "lost";
        }
        return "unknown";
    }
#if MR_FEAT_MOBILE
    uint8_t           mobile_home_id() const { return _my_mobile_reg.active ? _my_mobile_reg.home_id : 0; }   // §mobile 2b: our host (0 = unregistered)
    // ⛔⛔ §MH-S4 §4.1 — `mobile_registered()` IS NOT THE APP-FACING TRUTH AND MUST NOT BE RENDERED AS ONE.
    // It answers a LINK-LAYER question — *"do we hold an adopted host local id, provisionally or confirmed?"* —
    // and that is exactly what its ~10 in-core readers need: the leaf next-hop-via-home rule
    // (`node_mac.cpp`), the flood/pull-response ingest gates (`node_mac_rx.cpp`), the hash-locate
    // own-hash/proxy rules (`node_hashlocate.cpp`) and the origin stamp. §7.1 step 1 says the offered PHY and
    // local id are adopted **PROVISIONALLY** at CLAIM time, so all of those must keep behaving as they do
    // during `claiming` — promoting this accessor to "attached only" would silently change ROUTING for the
    // duration of the confirmation window, which §MH-S4 does not ask for and which no gate covers.
    // ⇒ THE APP-FACING TRUTH IS `mobile_attached()`, and the plane pair below is what a surface renders.
    bool              mobile_registered()      const { return _my_mobile_reg.active; }
    uint8_t           mobile_local_id()        const { return _my_mobile_reg.my_local_id; }
    uint16_t          mobile_reg_epoch()       const { return _my_mobile_reg.epoch; }
    uint8_t           mobile_home_layer()      const { return _my_mobile_reg.home_leaf_id; }
    // ★★★ §MH-S4 §4.1/§7.1 — THE ONE ACCESSOR AN APP, A CONSOLE OR AN OLED MAY READ AS "registered".
    // True ONLY after a chosen-home roster carried our (hash, local id, epoch) — never on the strength of a
    // CLAIM having been transmitted. This is the §S0-4 defect's fix expressed as a type: the surface can no
    // longer accidentally read the provisional flag, because the provisional flag is a different function.
    bool              mobile_attached()        const { return _mobile_attach_state == MobileAttachState::attached; }
    MobileAttachState mobile_attach_state()    const { return _mobile_attach_state; }
    MobileHomeLink    mobile_home_link()       const { return _mobile_home_link; }
    bool              mobile_home_desired()    const { return _mobile_home_desired; }   // §4.2: the VOLATILE home-service request an explicit `mobile register` sets and `mobile unregister` clears
    uint8_t           mobile_claim_retries()   const { return _mobile_claim_retries; }   // §7.1 steps 5-6: same-epoch re-CLAIMs spent on THIS attachment
    // ★ §MH-S4b §7.1 step 3 / §10 — the SOLICITATION substate of `claiming`: true = the searching solicitation
    // probe is out and its roster deadline is running ("we asked and are waiting"); false = the next confirmation
    // deadline will ASK. ⛔ Meaningless outside `claiming`, and a surface must render it only alongside
    // `attachment == "claiming"`.
    bool              mobile_claim_solicited() const { return _mobile_claim_solicited; }
    // §10: the CURRENT no-host retry WINDOW (§5.2's `min(5 s · 2^attempt, 120 s)` accumulator). 0 = the next
    // DISCOVER is a first try. ⛔ NOT the remaining delay to that attempt — see the §10 field ledger in the spec.
    uint32_t          mobile_retry_window_ms() const { return _mobile_backoff_ms; }
    // ★ §MH-S4 §4.1 — ALWAYS EXPOSE THE AGE OF THE LATEST CONFIRMATION. A confirmation is a point-in-time
    // measurement and the honest display of a point-in-time measurement is its timestamp: prefer
    // "Home confirmed 7 min ago" to an unconditional green "Connected". ⛔ Never claim continuous
    // connectivity during silence. `_ever` is separate from the age so a surface can OMIT the field when
    // nothing was ever confirmed, instead of rendering a 0 that reads as "confirmed just now".
    bool              mobile_home_confirmed_ever() const { return _mobile_home_confirmed_ms != 0; }
    uint64_t          mobile_home_confirm_age_ms() const {
        const uint64_t now = _hal.now();
        return (_mobile_home_confirmed_ms == 0 || now < _mobile_home_confirmed_ms) ? 0 : now - _mobile_home_confirmed_ms;
    }
    uint8_t           learned_layers_count()   const { return _learned_layers_n; }
    const LayerRecord& learned_layer(uint8_t i) const { return _learned_layers[i]; }
#else
    uint8_t           mobile_home_id()         const { return 0; }
    bool              mobile_registered()      const { return false; }
    uint8_t           mobile_local_id()        const { return 0; }
    uint16_t          mobile_reg_epoch()       const { return 0; }
    uint8_t           mobile_home_layer()      const { return 0; }
    bool              mobile_attached()        const { return false; }
    MobileAttachState mobile_attach_state()    const { return MobileAttachState::dormant; }
    MobileHomeLink    mobile_home_link()       const { return MobileHomeLink::unknown; }
    bool              mobile_home_desired()    const { return false; }
    uint8_t           mobile_claim_retries()   const { return 0; }
    bool              mobile_claim_solicited() const { return false; }
    uint32_t          mobile_retry_window_ms() const { return 0; }
    bool              mobile_home_confirmed_ever() const { return false; }
    uint64_t          mobile_home_confirm_age_ms() const { return 0; }
    uint8_t           learned_layers_count()   const { return 0; }
#endif
    uint8_t           bridged_layer_cap()      const { return protocol::cap_bridged_layers; }
    const BridgedLayer& bridged_layer(uint8_t i) const { return _bridged_layers[i]; }
#if MR_FEAT_MOBILE
    // §autoregister ruling (2026-07-21): with mobile_autoregister=false the FSM emits NO DISCOVERs on its own — the app
    // ARMS one here; team-DAD is unaffected.
    // ★★★ §MH-S4 §4.2 — THE ONE-SHOT ARM IS GONE. It was the defect §4.2 names by hand: *"an explicit manual
    // request must not get one unconfirmed RF attempt and silently stop"*. `_mobile_arm_once` was CONSUMED by
    // the first `mobile_discover_fire` (and had to be laboriously RESTORED by `mobile_admission_rejected` for
    // the "the attempt never happened" case), so with autoregister OFF an operator's `mobile register` that
    // met a busy channel, a lost OFFER or a lost CLAIM stopped for good. It is replaced by the VOLATILE
    // home-service-desired state `_mobile_home_desired`: set here, cleared ONLY by `mobile_unregister()` (or a
    // reboot — §4.2's deliberate manual policy: a device that must restore attachment across reboots uses the
    // flag ON). ⇒ MANUAL AND AUTOMATIC STARTS NOW SHARE ONE FSM, differing only in WHO enters `seeking`.
    // ⓘ `mobile_autoregister`'s field and JSON key are untouched (§4.2 compatibility requirement).
    void              mobile_register_current() { mobile_request_home_service(); (void)_hal.after(0, kMobileDiscoverTimerId); }             // DISCOVER on the current PHY now
    void              mobile_register_phy(const LayerConfig& phy) { adopt_mobile_phy(phy); mobile_request_home_service(); (void)_hal.after(0, kMobileDiscoverTimerId); }  // retune + DISCOVER
    void              mobile_register_scan()    { _mobile_scan_idx = 0; mobile_request_home_service(); (void)_hal.after(0, kMobileDiscoverTimerId); }  // cycle [current] ∪ learned
    // ★★ [[B209]] — THE RETUNE-ONLY SEAM, and the NAME is half the fix. `mobile_register_phy` above reads like a
    // retune and is not: it is *retune + AUTHORISE home-service + kick the FSM*, so provisioning calling it silently
    // granted a static-home attachment on a node whose operator had set `mobile_autoregister=false` (metal-confirmed:
    // `autoregister:false` beside `home_desired:true` / `attachment:"seeking"` plus repeated outbound J DISCOVERs).
    // ⭐ THIS ONE RETUNES AND NOTHING ELSE. It does NOT call `mobile_request_home_service()`, does NOT arm
    //   `kMobileDiscoverTimerId`, and does NOT touch `_mobile_attach_state` — so an already-authorised session
    //   survives a team PHY apply untouched (preserved, never cleared, and never re-authorised a second time).
    // ⓘ WHO CALLS WHICH, so the two are not re-conflated: the PROVISIONING transaction's `apply_phy` (the team
    //   plane's PHY step) calls THIS; the explicit console/app verb `mobile register [freq=…]` — which is the
    //   operator ASKING for a home — keeps calling `mobile_register_phy` and must keep authorising + DISCOVERing.
    // ⚠ Not arming the discover timer here does NOT stop team-DAD: the team plane's airtime step is the separate,
    //   last operation `team_dad_fire()` (§6.4), which the transaction fires explicitly. The boot-time arm at
    //   `node.cpp:588` is unchanged — an auto-OFF team member still runs team-DAD with zero DISCOVERs.
    void              mobile_retune_phy(const LayerConfig& phy) { adopt_mobile_phy(phy); }   // ★ RETUNE ONLY — no authorisation, no DISCOVER
    void              mobile_unregister();      // §MH-S4 §4.2/§4.3: clear home-service desired, cancel the FSM timers, drop the attachment -> `dormant`
    void              mobile_send_layer_query(uint8_t gw) {                                                  // manual pull: MOBILE_LAYER_QUERY -> gw
        uint8_t q = 0; (void)enqueue_data(gw, &q, 0, DATA_FLAG_SOURCE_HASH, "mobile_layer_query", false, DATA_TYPE_MOBILE_LAYER_QUERY, CryptIntent::off);
    }
    uint8_t           mobile_offers_n() const { return _mobile_offers_n; }                        // §mobile 2b: OFFERs collected this window (test/diag)
    uint8_t           mobile_scan_idx()   const { return _mobile_scan_idx; }                      // §MH-S4 §10: current scan index / count
    uint8_t           mobile_scan_count() const { return scan_set_count(); }
    uint8_t           mobile_candidate_count() const { return _presence_cand_n; }                 // §MH-S4 §10: candidate homes collected passively
    // ★★★ §MH-S5 §10 / [[B154]] — **THE VERIFIED-CANDIDATE COUNT.** §MH-S4 deliberately left this ABSENT rather than
    // zero-faked; this is it, and it is DERIVED, not stored (zero new state ⇒ `sizeof(Node)` unmoved).
    // ★ "Verified" is §8.1's own definition and BOTH halves are load-bearing:
    //   · `echo_tier != 0xFF` — the candidate echoed one of OUR probes, so BOTH link directions are proven. A
    //     beacon or an echo-less roster proves reception in one direction and willingness to host in NEITHER, and
    //     §8.1 says outright: "⛔ A beacon is only a hint."
    //   · FRESH within `mobile_liveness_ms` (§8.2) — an old verification is not "recent bidirectional
    //     verification". ⛔ Counting stale rows here would make the field disagree with the switching decision it
    //     exists to explain, which is the display-shaped-field defect this plane keeps producing.
    // ⇒ ★ WHAT THE NUMBER IS, STATED EXACTLY, because the sentence that stood here overstated it: it is the count of
    //   candidate rows that are FRESH, COMPATIBLE and BIDIRECTIONALLY VERIFIED — **the eligibility floor, not the
    //   selection.** ⛔ It is NOT "what re-home would consider": `presence_maybe_rehome` additionally applies the
    //   quality delta over the CURRENT home, the 60-second sustained hold, the 5-minute dwell, and the exclusion of
    //   the current home itself — so this count can be non-zero while re-home correctly does nothing (which is
    //   precisely §8.3's "adequate before optimal" behaviour, gate 24). Read it as *"how many candidates are even
    //   admissible"*, never as *"a switch is due"*. ⛔ Do not change the number to chase the old sentence — a golden
    //   test pins it (§MH-S5 §10 / [[B154]]); this correction is to the CLAIM, at the place a reader acts on it.
    uint8_t           mobile_verified_candidate_count() const {
#if MR_FEAT_MOBILE
        const uint64_t now = _hal.now();
        uint8_t n = 0;
        for (uint8_t i = 0; i < _presence_cand_n; ++i) {
            if (_presence_cand[i].echo_tier == 0xFF) continue;
            if (_presence_cand[i].incompatible) continue;
            if (now - _presence_cand[i].last_seen_ms >= protocol::mobile_liveness_ms) continue;
            ++n;
        }
        return n;
#else
        return 0;
#endif
    }
    // ★ §MH-S1 §10 "last result" — the outcome of the mobile's most recent attachment attempt.
    // ⛔ IT IS NOT A LINK STATE. §6.4: a `tx_rejected`/`defer_full` here is a statement about OUR OWN
    // transmitter and must NEVER be rendered as, or promoted into, a home-link verdict (gate 20).
    // ★ MARK DONE-VS-MISSING IN CODE: S1 sets `no_offer`, `tx_rejected` and `defer_full`. The remaining
    // three codes are declared, NOT dead-stripped, and are set by later slices — `claim_unconfirmed` and
    // `confirmed` by S4 (the confirmed-attachment FSM, §7.1), `denied` by S4's DENY handling. A reader
    // must be able to see what the surface will carry, and that it is not carried yet.
    enum class MobileAttemptResult : uint8_t {
        none = 0,          // no attempt has completed since boot
        no_offer,          // S1: the collect-OFFERs window closed with zero OFFERs (the old `mobile_no_host`)
        tx_rejected,       // S1: OUR radio refused the frame (HAL) — says nothing about any home
        defer_full,        // S1: OUR 4-slot LBT defer ring was full — says nothing about any home
        claim_unconfirmed, // S4 (§7.1): CLAIM sent, no matching roster within the confirmation budget
        denied,            // S4: the chosen home DENIED the claimed local id
        confirmed          // S4 (§7.1): the chosen home's roster carried our (hash, local id, epoch)
    };
    MobileAttemptResult mobile_last_result() const { return _mobile_last_result; }
    // §MH-S4 §10 "last result" as a surface string. Same no-`default:` discipline as the two plane namers above.
    // ⛔ `tx_rejected`/`defer_full` are OUR OWN transmitter (§6.4) and must never be rendered as a home-link state.
    static const char* attempt_result_name(MobileAttemptResult r) {
        switch (r) {
            case MobileAttemptResult::none:              return "none";
            case MobileAttemptResult::no_offer:          return "no_offer";
            case MobileAttemptResult::tx_rejected:       return "tx_rejected";
            case MobileAttemptResult::defer_full:        return "defer_full";
            case MobileAttemptResult::claim_unconfirmed: return "claim_unconfirmed";
            case MobileAttemptResult::denied:            return "denied";
            case MobileAttemptResult::confirmed:         return "confirmed";
        }
        return "none";
    }
#else
    uint8_t           mobile_offers_n() const { return 0; }
    uint8_t           mobile_scan_idx()   const { return 0; }
    uint8_t           mobile_scan_count() const { return 0; }
    uint8_t           mobile_candidate_count() const { return 0; }
#endif
    // ★ §MH-S1 §6.1/§6.4 — WHY a rejection reason and not just `tx_initiating`'s bool. That bool fuses two
    // distinct local-transmitter outcomes, and §10 asks for them separately as the mobile's last attempt
    // result: a FULL LBT defer ring (`defer_full`) and a HAL refusal (`tx_rejected`). Both are statements
    // about OUR OWN radio; neither says anything about any home (§6.4). It is threaded as an OPTIONAL
    // out-param, so the ~22 best-effort `tx_initiating` callers are untouched and byte-identical.
    // ⓘ Declared here, in the public block, only because C++ needs it defined before the first member
    //   function that names it (the host-side OFFER handler, ~700 lines below); its readers are all
    //   internal plus the §MH-S1 native cases. It is a value type, not a surface.
    enum class TxAdmission : uint8_t {
        admitted = 0,   // handed to the radio now (or a deliberate RTS-only cancel/duty defer — see lbt_complete)
        deferred,       // accepted INTO the LBT defer ring; it flies when its slot timer fires
        defer_full,     // REFUSED: the 4-slot defer ring was full -> dropped, nothing will retry it
        tx_rejected     // REFUSED: the HAL refused it (full outbound ring / too_long / radio error)
    };
    // ★★ §MH-S2 §5.3.2 item 5 — the pending-OFFER ring's ADMISSION answer. Four outcomes, and the caller's response
    // differs for each, which is exactly why this is not a bool. ⛔ Do NOT confuse it with `TxAdmission` above: that
    // one is our RADIO's answer at the transmission boundary; this one is our SCHEDULER's answer at the DISCOVER.
    // Declared in the public block for the same reason as its neighbour (defined before its first user) plus one
    // more: the §MH-S2 native gate asserts on it directly.
    enum class MobileOfferAdmit : uint8_t {
        armed = 0,   // a free slot took the frame; its jitter deadline is set and the id is RESERVED ([[B137]])
        duplicate,   // this mobile already has an ARMED entry -> coalesced: no new slot, deadline UNMOVED, id RETAINED
        full,        // every slot is in use -> refused explicitly; ⛔ NOTHING armed is evicted or re-timed
        invalid      // the frame is empty or does not fit a slot (the jtx fit-before-draw invariant) -> no draw, no slot
    };
    uint16_t          mobile_offer_ring_full_count() const { return _mobile_offer_ring_full_n; }   // §10 counter: admissions refused `full`
    uint16_t          mobile_offer_reject_count()    const { return _mobile_offer_reject_n; }      // §10 counter: OFFERs our own transmitter refused
    uint16_t          mobile_ctr_admission_refused_count() const { return _mobile_ctr_admission_refused_n; }   // B251: hop ACK withheld because the translated forward could not reserve queue/correlation capacity
    uint8_t           mobile_offers_pending_n() const {                                            // slots IN USE (armed and/or reserved) right now
        uint8_t n = 0;
        for (uint8_t i = 0; i < cap_pending_mobile_offers; ++i)
            if (_pending_mobile_offers[i].reserve_until_ms != 0) ++n;
        return n;
    }
    const RtEntry&    rt_at(uint8_t i) const { return _active->_rt[i]; }   // 0..rt_count()-1; candidates[0] is the primary
#if MR_FEAT_TEAM
    uint8_t           rt_team_count()  const { return _active->_rt_team_count; }   // §mobile 6.2: the TEAM plane (test/diag)
    const RtEntry&    rt_team_at(uint8_t i) const { return _active->_rt_team[i]; }
#else
    uint8_t           rt_team_count()  const { return 0; }
    // rt_team_at: no stub — a !MR_FEAT_TEAM build has no _rt_team; its (test/fw_main-diag) callers are guarded #if MR_FEAT_TEAM
#endif
    // Console testing aid: manually force / drop a route, to stress the routing algorithms with arbitrary or
    // inconsistent routes. route_inject returns true if the candidate took (rt_merge can reject if better candidates
    // already hold the K slots). route_remove drops a dest's whole entry.
    bool route_inject(uint8_t dest, uint8_t next_hop, uint8_t hops, int16_t score_q4) {
        RtCandidate c{}; c.next_hop = next_hop; c.hops = hops; c.score = score_q4;
        c.last_seen_ms = _hal.now(); c.learned_leaf = _cfg.leaf_id;
        rt_merge(dest, c);
        const RtEntry* e = rt_find(dest);
        if (e) for (uint8_t i = 0; i < e->n; ++i) if (e->candidates[i].next_hop == next_hop) return true;
        return false;
    }
    bool route_remove(uint8_t dest) {
        for (uint8_t i = 0; i < _active->_rt_count; ++i)
            if (_active->_rt[i].dest == dest) { rt_remove(i); return true; }
        return false;
    }
    int16_t peer_penalty_q4(uint8_t node_id) const { return liveness_penalty_q4(node_id); }   // liveness (suspect/silent/dead) penalty on a next-hop; routes dump shows effective = score - pen
    LinkBidi          link_bidi_state(uint8_t node_id) const { return static_cast<LinkBidi>(_active->_link_bidi[node_id]); }  // bidi plane read (test/status); unknown for any unprobed link
    uint64_t          link_bidi_confirmed_ms(uint8_t node_id) const { return _active->_link_bidi_confirmed_ms[node_id]; }    // last-confirmation ms (test/status); 0 = never confirmed
#if MR_FEAT_TEAM
    // §team-parity T5: the TEAM-plane twins (test/status). Keyed by team_local_id, read out of the _team_liveness slot —
    // NEVER _link_bidi (invariant I8). No slot for that id => the link was never probed => unknown / 0.
    LinkBidi          team_link_bidi_state(uint8_t team_local_id) const {
        const PeerLiveness* s = team_liveness_find(team_local_id);
        return s ? static_cast<LinkBidi>(s->team_bidi_state) : LinkBidi::unknown;
    }
    uint32_t          team_link_bidi_confirmed_s(uint8_t team_local_id) const {
        const PeerLiveness* s = team_liveness_find(team_local_id);
        return s ? s->team_bidi_confirmed_s : 0u;
    }
#endif
#ifdef MESHROUTE_NATIVE
    uint8_t           link_bidi_at(uint8_t node_id) const { return _active->_link_bidi[node_id]; }   // raw LinkBidi (test/white-box)
    void              test_update_link_bidi_from_beacon(uint8_t advertiser, const beacon_entry* e, uint8_t n, bool complete, bool team_plane = false) { update_link_bidi_from_beacon(advertiser, e, n, complete, team_plane); }  // white-box: drive the Slice-3 detection scan directly (§T5: on either plane)
    void              test_ingest_beacon(const uint8_t* bytes, size_t len, const RxMeta& meta) { ingest_beacon(bytes, len, meta); }  // white-box: drive ingest_beacon directly (Slice 3 end-to-end)
    int16_t           test_team_penalty_q4(uint8_t next_hop) const { return liveness_penalty_q4(next_hop, /*team_plane=*/true); }   // white-box: the team-plane liveness penalty (§clean-join R3 reset check)
    // §S0 (cold-boot mobile-id alias) white-box seams.
    uint8_t           test_find_free_mobile_id(uint32_t key_hash32) { return find_free_mobile_id(key_hash32); }   // top-down allocation + static-exclusion
    bool              test_route_uses_mobile_as_transit(uint8_t dest, uint8_t next) const { return route_uses_mobile_as_transit(dest, next); }   // the transit filter (alias carve)
    // ★ §id-hash S1d test seam: fire one LBT deferred-TX slot's timer. The id range is private and MUST stay so —
    // a test hard-coding 15 would silently drive the wrong timer if the range ever moves.
    void              test_fire_lbt_defer(uint8_t slot) { on_timer(kLbtDeferTimerId + slot); }
    // ★ §id-hash S4b test seam, same rule as the line above: the periodic aging sweep is where the two-stage
    // `reqpubkey` intent times out (spec §5 step 5), and its timer id is private so a test cannot hard-code 2.
    void              test_fire_aging() { on_timer(kAgingTimerId); }
    // B251 retry/backpressure: retire a deliberately unanswered DATA reservation without hard-coding the private id.
    void              test_fire_pending_rx_expiry() { on_timer(kPendingRxExpiryTimerId); }
    uint8_t           test_deleg_ack_live_n() const {
        uint8_t n = 0;
        for (const auto& e : _deleg_acks) if (e.state != DelegAckState::free) ++n;
        return n;
    }
    // §B278 S1b, same shape and same rule as the line above: how many rows hold a given `DelegAckCustody`,
    // flattened to its integer so a test never needs the private enum. Read-only; no production caller.
    uint8_t           test_deleg_custody_n(uint8_t custody) const {
        uint8_t n = 0;
        for (const auto& e : _deleg_acks) if (static_cast<uint8_t>(e.custody_state) == custody) ++n;
        return n;
    }
    // ★★ §B278 S3 white-box seams, and the reason they are HERE rather than on `DualLayerTestAccess`: the home-side
    //    correlation cases belong beside §CUSTODY-G's receiver cases in `test/test_custody_receive_g.cpp`, which is
    //    not that friend. ⛔ Each forwards VERBATIM to the ONE production authority and adds no logic; the private
    //    enums are flattened to integers so a case never has to name them, exactly as `test_deleg_custody_n` does.
    bool              test_deleg_ack_put(uint32_t mobile_hash, uint16_t ctr_h, uint16_t ctr_m,
                                         uint8_t target_kind, uint32_t target,
                                         uint8_t return_kind, uint32_t return_peer,
                                         uint8_t outward_type, uint8_t custody) {
        return deleg_ack_put(mobile_hash, ctr_h, ctr_m, static_cast<DelegAckPeer>(target_kind), target,
                             static_cast<DelegAckPeer>(return_kind), return_peer, active_layer_id(),
                             outward_type, static_cast<DelegAckCustody>(custody));
    }
    bool              test_deleg_ack_translate(uint32_t mobile_hash, uint16_t acked_ctr, uint8_t return_kind,
                                               uint32_t return_peer, uint16_t& out_mobile_ctr) {
        return deleg_ack_translate(mobile_hash, acked_ctr, static_cast<DelegAckPeer>(return_kind),
                                   return_peer, active_layer_id(), out_mobile_ctr);
    }
    // ⛔⛔ THE INVARIANT-VIOLATION SEAM, AND IT IS LABELLED AS ONE. §4.4's `ambiguous` disposition reports an
    //    INVARIANT FAILURE — two live rows sharing the wire-visible return key — and §B278 S1b's activation
    //    uniqueness makes that state structurally UNREACHABLE through every production path (`deleg_ack_put`
    //    and `deleg_ack_activate` both refuse the second row; the S3 battery proves that refusal beside the
    //    use of this seam). A diagnostic whose only input is an impossible state would otherwise be a claim no
    //    test could redden. ⛔ This writes the row the ring would refuse and has EXACTLY ONE user: the S3
    //    ambiguity case. Nothing in production calls it and it exists only under `MESHROUTE_NATIVE`.
    void              test_deleg_force_row(uint8_t slot, uint32_t mobile_hash, uint16_t ctr_h, uint16_t ctr_m,
                                           uint8_t target_kind, uint32_t target,
                                           uint8_t return_kind, uint32_t return_peer,
                                           uint8_t outward_type, uint8_t custody) {
        DelegAck& e = _deleg_acks[slot];
        e = DelegAck{};
        e.ts_ms = _hal.now(); e.mobile_hash = mobile_hash; e.ctr_h = ctr_h; e.ctr_m = ctr_m;
        e.target_kind = static_cast<DelegAckPeer>(target_kind); e.target = target;
        e.return_kind = static_cast<DelegAckPeer>(return_kind); e.return_peer = return_peer;
        e.layer = active_layer_id(); e.outward_type = outward_type;
        e.state = DelegAckState::active; e.custody_state = static_cast<DelegAckCustody>(custody);
    }
    // One row, flattened. The S3 identity assertions need every field (a count cannot say WHICH row moved), and
    // `DelegAck` itself stays private — nothing here weakens access.
    struct TestDelegRow { uint64_t ts_ms; uint32_t mobile_hash, target, return_peer; uint16_t ctr_h, ctr_m;
                          uint8_t layer, outward_type, target_kind, return_kind, state, custody_state; };
    TestDelegRow      test_deleg_row(uint8_t slot) const {
        const auto& e = _deleg_acks[slot];
        return TestDelegRow{e.ts_ms, e.mobile_hash, e.target, e.return_peer, e.ctr_h, e.ctr_m, e.layer,
                            e.outward_type, static_cast<uint8_t>(e.target_kind),
                            static_cast<uint8_t>(e.return_kind), static_cast<uint8_t>(e.state),
                            static_cast<uint8_t>(e.custody_state)};
    }
    uint8_t           test_deleg_ack_cap() const { return kDelegAckCap; }
    // §remote-admin v2 SLICE 5 — the TOP ALLOCATED timer id, exposed so a case can assert that its OWN mechanism
    // took none. The ids are private (they are not an API), and a test that re-typed the number would stop being
    // a guard the moment the number moved. ⛔ Not a flag, not runtime state: one constexpr read of a constant.
    static constexpr uint32_t test_last_allocated_timer_id() { return kRadminExpiryTimerId; }
    uint8_t           test_parked_sends_n() const { return _parked_sends_n; }
    void              test_drain_parked_sends(uint32_t key_hash32, uint8_t resolved_id) { drain_parked_sends(key_hash32, resolved_id); }
    void              test_mark_mobile_peer(uint8_t id) { _active->_mobile_peer[id >> 3] |= static_cast<uint8_t>(1u << (id & 7)); }   // simulate an is_mobile beacon setting the SET-only bit
    bool              test_id_bind_set(uint8_t id, uint32_t key_hash32, bool authoritative) { return id_bind_set(id, key_hash32, IdBindSource::bcn, authoritative ? IdBindConf::authoritative : IdBindConf::claimed); }
    // §CUSTODY-B: `type` APPENDED with a default, so every existing caller is byte-identical and the new cases can
    // drive the SAME terminal arm with an internal carrier (the §6.2(5) suppression is a per-type verdict, so a
    // seam that can only build type-0 items cannot reach the behaviour under test). U1 — extended, not forked.
    void              test_defer_send(uint8_t dst, uint16_t ctr, uint8_t redrain_count, uint8_t type = 0) { TxItem it{}; it.dst = dst; it.ctr = ctr; it.redrain_count = redrain_count; it.type = type; defer_send(it); }   // drive the defer-loop giveup directly
    uint8_t           test_deferred_count() const { return _active->_deferred_n; }
    // §S3 part2 white-box: suspend the become_free tx-drain so an enqueued frame STAYS in the queue for a wire-golden read
    // (else the MAC immediately drains it into an RTS/CTS flight and the DATA never sits in the queue). Sets the same
    // half-duplex guard become_free honors. Reset to false to resume normal draining.
    void              test_suspend_tx_drain(bool on) { if (on) _active->_pending_tx.emplace(); else _active->_pending_tx.reset(); }
    // §S3 part2 white-box: inspect the tx queue (a last-mile forward stays queued while the drain is suspended — the wire golden reads it here).
    uint8_t           test_tx_queue_n() const { return _active->_tx_queue_n; }
    uint8_t           test_tx_type(uint8_t i)     const { return _active->_tx_queue[i].type; }
    uint8_t           test_tx_flags(uint8_t i)    const { return _active->_tx_queue[i].flags; }
    uint8_t           test_tx_dst(uint8_t i)      const { return _active->_tx_queue[i].dst; }
    uint8_t           test_tx_origin(uint8_t i)   const { return _active->_tx_queue[i].origin; }   // §team-parity T6 white-box: the id stamp_origin chose for this flight (the whole subject of Part A)
    uint8_t           test_tx_addr_len(uint8_t i) const { return _active->_tx_queue[i].addr_len; }
    const uint8_t*    test_tx_inner(uint8_t i, uint8_t& len) const { len = _active->_tx_queue[i].inner_len; return _active->_tx_queue[i].inner; }
    // §team-ch-key T-K3 white-box: the two STRUCTURAL sealed-only guards live on private origination seams whose only
    // reachable caller (team_key_grant_send) forces CryptIntent::on — i.e. exactly the "future caller" the guards exist
    // to stop. Without these seams the guards would be algebra-only, which is the coverage claim this arc refuses to
    // make. They forward VERBATIM, add no logic, and each test also runs the type-0 control through the same seam so a
    // pass cannot come from the path being broken.
    uint16_t          test_do_send_typed(uint8_t dst, const uint8_t* body, uint8_t body_len, CryptIntent crypt,
                                         uint32_t override_dst_hash, uint8_t type) {
        return do_send(dst, body, body_len, /*flags=*/0, crypt, override_dst_hash, type);
    }
    bool              test_enqueue_cross_layer_typed(uint8_t gw_node, uint32_t dst_hash, const uint8_t* layer_ids,
                                                     uint8_t n_layers, const uint8_t* body, uint8_t body_len,
                                                     uint16_t* out_ctr, uint8_t type) {
        return enqueue_cross_layer(gw_node, dst_hash, layer_ids, n_layers, /*cur=*/0, body, body_len, /*flags=*/0, out_ctr, type);
    }
    // §S3 part2 white-box: seed a live hosted-mobile entry (has_pubkey) without driving the full CLAIM+probe path (that's covered by s22).
    void              test_add_host_mobile(uint32_t key_hash32, uint8_t local_id, const uint8_t ed_pub[32]) {
        if (_active->_mobile_reg_n >= protocol::cap_host_mobiles) return;
        auto& e = _active->_mobile_reg[_active->_mobile_reg_n];
        e = { key_hash32, local_id, /*epoch=*/1, _hal.now() };
        for (int i = 0; i < 32; ++i) e.ed_pub[i] = ed_pub[i];
        e.has_pubkey = true;
        _active->_mobile_reg_n++;
    }
    // §S7 T-B white-box: mark THIS node as a registered mobile (mobile-side) without driving the full DISCOVER/CLAIM (s22 covers that).
    void              test_set_my_mobile_reg(uint8_t home_id, uint8_t local_id) {
        _my_mobile_reg = { /*active=*/true, home_id, local_id, /*home_key_hash32=*/0u, _cfg.leaf_id, /*epoch=*/1, _hal.now() };
    }
    // ★ §hybrid-rts S2b white-box: the home-liveness clock, so a test can prove an UNBOUND terminal CTS does NOT
    // refresh it (the ordering defect S2 shipped). Read-only; adds no state.
    uint64_t          test_last_heard_home_ms() const { return _my_mobile_reg.last_heard_home_ms; }
    // ★★★ §MH-S5 §9.4 STEP 8 — drive the HOST LAST-MILE DECISION for a DM that arrived addressed to us and carries
    // an inner DST_HASH. This is the decision the spec requires to be **hash-anchored, never local-id-anchored**:
    // after a 25-minute row expiry the departed mobile's local id may belong to a DIFFERENT mobile, so a DM for the
    // OLD hash must reach nobody rather than reach the new holder of that id.
    // ⓘ THE INNER LAYOUT IS THE PRODUCTION ONE, not an approximation: `[dst_hash 4B LE][origin][body…]` behind
    //   `DATA_FLAG_DST_HASH`, which is what `parse_unicast_inner` reads.
    // ⓘ U1 — `test_dual_layer.cpp`'s `DualLayerTestAccess::drive_post_ack_deliver` now DELEGATES here instead of
    //   keeping its own copy of this scaffold, so the two cannot drift apart.
    void              test_drive_deliver_for_hash(uint8_t origin, uint32_t dst_hash) {
        auto& pa = _active->_post_ack; pa = PostAck{};
        pa.pending = true; pa.is_forward = false; pa.origin = origin; pa.dst = _node_id;
        pa.ctr = 0x1234; pa.ctr_lo = 4; pa.flags = DATA_FLAG_DST_HASH; pa.type = 0;
        pa.inner[0] = static_cast<uint8_t>(dst_hash);       pa.inner[1] = static_cast<uint8_t>(dst_hash >> 8);
        pa.inner[2] = static_cast<uint8_t>(dst_hash >> 16); pa.inner[3] = static_cast<uint8_t>(dst_hash >> 24);
        pa.inner[4] = origin; pa.inner[5] = 0xAA; pa.inner_len = 6;
        do_post_ack();
    }
    // ★★★ §MH-S5 §9.2 / gate 14 — drive the REAL `DATA_TYPE_MOBILE_BREADCRUMB` handler (a moved mobile's new home
    // telling us we are stale), so the redirect conversion AND its lifetime stamp are exercised by the production
    // code rather than by a white-box poke into `redirect_home_id` — which would bypass the one line under test.
    // ⓘ Inner layout for SOURCE_HASH without DST_HASH, read off `parse_unicast_inner` (V1, frame_codec.cpp:1030-1036):
    //   `[origin][source_hash 4B LE][body…]`, body = `[new_home_id][new_epoch][new_home_layer]` (§S6.4-D's packer).
    void              test_drive_breadcrumb(uint8_t origin, uint32_t mobile_hash,
                                            uint8_t new_home_id, uint8_t new_epoch, uint8_t new_home_layer) {
        auto& pa = _active->_post_ack; pa = PostAck{};
        pa.pending = true; pa.is_forward = false; pa.origin = origin; pa.dst = _node_id;
        pa.ctr = 0x1235; pa.ctr_lo = 5; pa.flags = DATA_FLAG_SOURCE_HASH; pa.type = DATA_TYPE_MOBILE_BREADCRUMB;
        uint8_t o = 0;
        pa.inner[o++] = origin;
        pa.inner[o++] = static_cast<uint8_t>(mobile_hash);       pa.inner[o++] = static_cast<uint8_t>(mobile_hash >> 8);
        pa.inner[o++] = static_cast<uint8_t>(mobile_hash >> 16); pa.inner[o++] = static_cast<uint8_t>(mobile_hash >> 24);
        pa.inner[o++] = new_home_id; pa.inner[o++] = new_epoch; pa.inner[o++] = new_home_layer;
        pa.inner_len = o;
        do_post_ack();
    }
#endif
    // A heard 1-hop gateway's stored window schedule (nullptr if none known) + the ms to defer an RTS to its window.
    // For the `routes` console dump: surface a gateway route's unique state (period / per-leaf windows / heard-age).
    const GatewaySchedule* rt_gateway_schedule(uint8_t gw_node_id) const { return find_gw_schedule(gw_node_id); }
    uint32_t          rt_gateway_defer_ms(uint8_t gw_node_id) const       { return gateway_schedule_base_defer_ms(gw_node_id, nullptr); }  // base (no jitter) — stable display
    void              rt_resort_for_pick(uint8_t dest) { refresh_route_order(dest, "test_pick"); }   // test: force the pick-time re-sort (freshness/penalty applied)
    void              test_set_link_one_way(uint8_t next_hop) {                    // §bidi test: drive a one_way transition + its fan-out (mirrors the real Slice-3 detection)
        _active->_link_bidi[next_hop] = static_cast<uint8_t>(LinkBidi::one_way);
        resort_routes_for_neighbor_penalty(next_hop, "test_one_way", /*local_only=*/true);
    }
    void    test_learn_route(uint8_t dest, uint8_t via, uint8_t hops, int16_t snr_q4, bool team_plane) { learn_route_via(dest, via, hops, snr_q4, team_plane); }  // §S7 test seam: install a 1-hop route into _rt (team_plane=false) or _rt_team (true) without beacon setup
    void    note_link_confirmed(uint8_t next_hop, bool team_plane = false);   // local bidi confirm (real CTS / complete-heard-set hit): set confirmed + stamp + fan out. §T5: team_plane -> _team_liveness[].team_bidi_* + team_resort (NEVER _link_bidi)
    void    decay_link_bidi(uint8_t next_hop, bool team_plane = false);   // confirmed + stale past bidi_confirm_ttl_ms -> unknown (MF6: NEVER -> one_way). §T5: team_plane -> the team slot
    void    set_link_bidi_for_test(uint8_t next_hop, LinkBidi v) { _active->_link_bidi[next_hop] = static_cast<uint8_t>(v); }  // test seam: seed a bidi state directly
#if MR_FEAT_TEAM
    // §team-parity T5 test seam: seed a TEAM bidi state directly (creates the slot, like the real one_way/confirm path).
    void    set_team_link_bidi_for_test(uint8_t team_local_id, LinkBidi v) {
        PeerLiveness* s = team_liveness_slot(team_local_id, /*create=*/true);
        if (s) s->team_bidi_state = static_cast<uint8_t>(v);
    }
#endif
    bool    candidate_degraded(const RtCandidate& c, bool team_plane = false) const;   // LIVE: c.degraded_from_wire || bidi(c.next_hop)==one_way on the GIVEN plane (never a sticky cache, MF5/OI1). §T5: team_plane reads the team bidi slot (was wire-only)
    int16_t bidi_penalty_q4(uint8_t next_hop, bool team_plane = false) const;          // §bidi: one_way next-hop -> bidi_penalty_one_way_q4, unknown/confirmed -> 0 (PURE; composed into effective_score at node_routing.cpp:100, SORT-only — never a next_hop_selectable gate). §T5: team_plane -> the team bidi slot
    size_t            test_build_suspect_ext(uint8_t* out, size_t cap) { return build_suspect_ext(out, cap); }                 // §P4 test: drive the gossip encoder
    void              test_apply_suspect_gossip(const SuspectEntry* e, uint8_t n, uint8_t src) { apply_suspect_gossip(e, n, src); }   // §P4 test: drive the gossip apply
    void              test_emit_beacon(const char* kind) { emit_beacon(kind); }   // §5 census/advertise tests: drive a deterministic beacon (bypasses the throttle)
    bool              has_pending_tx() const { return _active->_pending_tx.has_value(); }
#ifdef MESHROUTE_NATIVE
    // ★★★ §CUSTODY-F TEST SEAM — **THE ONE WAY §10.1's NEGATIVE MATRIX CAN BE DRIVEN OFF A REAL CARRIER.**
    //
    // ⛔⛔ WHY IT EXISTS, stated because [[B268]]'s lesson ("a fabricated carrier proves the assertion, not the
    //     code") argues the other way and is RIGHT: §18.4.9 demands a negative arm for crypted, raw-inner,
    //     team, mobile, XL, gateway-reinject, channel-M and the two excluded types — carrier shapes a static
    //     3-node chain cannot install through its MAC at all. The alternative to this seam is fabricating a
    //     `PendingTx` from nothing, which is strictly weaker. ⇒ the tests take the LIVE, PRODUCTION-INSTALLED
    //     transit carrier through `test_live_pending_tx()`, copy it, change EXACTLY ONE field, and ask the
    //     PRODUCTION predicate — a one-variable experiment against a real baseline, not an invention.
    // ⛔ ZERO DEVICE SURFACE and zero behaviour: both are `MESHROUTE_NATIVE`-only const accessors onto the
    //    existing private path. No state, no member, `sizeof(Node)` unmoved.
    const PendingTx*  test_live_pending_tx() const { return _active->_pending_tx ? &*_active->_pending_tx : nullptr; }
    CustodyNoticeSnapshot test_custody_notice_snapshot(const PendingTx& pt, const TerminalCustodyContext& ctx) const {
        return custody_notice_snapshot(pt, ctx);
    }
    // ⓘ THE STEP-(7) HALF, exposed for ONE reason: `custody_notice_enqueue`'s C2 fail-loud arm (a snapshot that
    //   is eligible yet UNPACKABLE) is unreachable from the production cascade, because the only way to build
    //   one is a `CustodyRootStage::invalid` context and E's seam guarantees that cannot happen. A refusal that
    //   nothing can drive is a refusal no mutation can redden — measured: the battery arm that deletes its emit
    //   SURVIVED until this seam existed.
    void test_custody_notice_enqueue(const CustodyNoticeSnapshot& snap) { custody_notice_enqueue(snap); }
    // ★★★ §CUSTODY-G TEST SEAM — **THE SAME ARGUMENT, ON THE RECEIVE SIDE.** §13's eighteen validations need one
    //     independent falsifier EACH, and several of the contexts they judge (a TEAM-plane arrival; an inner that
    //     parses at the MAC but not as a unicast inner) cannot be installed by a static 3-node chain's MAC.
    // ⛔ THE PAIR IS DELIBERATE AND SO IS THE ORDER OF USE: `test_pending_post_ack()` hands back the LIVE,
    //    PRODUCTION-INSTALLED `PostAck` that a REAL received DATA left behind (it is `pending` between `on_recv`
    //    and the post-ACK timer), and `test_custody_failure_receive` runs the PRODUCTION validator over a COPY of
    //    it with EXACTLY ONE field changed. ⇒ every arm is a one-variable experiment against a real baseline,
    //    never a fabricated frame ([[B268]]'s lesson, honoured rather than argued around).
    // ⛔ IT IS NOT A SHORTCUT PAST THE MAC: the arms that CAN be driven as real frames (every record-byte break,
    //    the CRYPTED flag, a foreign `failed_origin`, a wrong `reporter_layer`, the domain overruns) ARE driven
    //    that way in `test/test_custody_receive_g.cpp`, and the seam covers only what the chain cannot install.
    // ⛔ ZERO DEVICE SURFACE and zero behaviour: `MESHROUTE_NATIVE`-only, no state, `sizeof(Node)` unmoved.
    const PostAck* test_pending_post_ack() const {
        return _active->_post_ack.pending ? &_active->_post_ack : nullptr;
    }
    void test_custody_failure_receive(const PostAck& pa, const data_unicast_inner* ui) {
        custody_failure_receive(pa, ui);
    }
#endif
    bool              tx_queue_full()  const { return _active->_tx_queue_n >= kTxQueueCap; }   // enqueue_data SILENTLY drops when full -> callers (firmware scheduled-send) gate on this before originating
    uint64_t          nav_until_ms()   const { return _nav_until_ms; }  // NAV reservation deadline (0 = clear); test/status accessor
    uint32_t          test_nav_duration_rts(uint8_t sf, uint8_t payload_len, uint8_t data_cr) const { return nav_duration_rts(sf, payload_len, data_cr); }  // M6: white-box the payload_len clamp · §rts-cr-overhear: white-box the peer-CR term
    uint32_t          test_nav_duration_cts(uint8_t sf, uint8_t payload_len, uint8_t data_cr) const { return nav_duration_cts(sf, payload_len, data_cr); }  // §rts-cr-overhear: white-box the peer-CR term + the payload_len=0 max-frame fallback
    // ---- channel-plane inspection (public, like rt_count) + the two seams tests drive directly ----
    uint16_t          channel_buffer_count() const { return _active->_channel_buffer_n; }
    bool              channel_has(uint32_t id) const { return channel_buffer_find(id) >= 0; }
    // ---- id_bind (hash-locate substrate) inspection: tests + the H resolver drive these.
    uint16_t          id_bind_count() const { return _active->_id_bind_n; }
    bool              joined()        const { return _joined; }        // DAD: adopted a node_id (test/app accessor)
    bool              in_discovery()  const { return _active && _active->_discovery_mode; } // per-active-leaf; _active-guard for pre-init safety
    uint32_t          steady_beacon_period_ms() const {   // §team-multihop (spec 2026-07-15 Change A): a TEAM member's steady cadence = team_beacon_period_ms (more responsive than static's 15 min, for a roaming team); a static node (team_id==0) keeps beacon_period_ms -> s18-inert
        return (_cfg.is_mobile && _cfg.team_id != 0) ? _cfg.team_beacon_period_ms : _cfg.beacon_period_ms; }
    // §team-parity T0 (spec 2026-07-27 §3/T0): the hop ceiling FOR A PLANE — the DV combined-hops cap, the F RREQ
    // TTL and the RREQ/RREP hop-cap backstops all key off it. Same shape as steady_beacon_period_ms above (U3), and
    // deliberately NOT MR_FEAT_TEAM-gated so it compiles identically on the three gateway_* envs (MR_FEAT_TEAM 0):
    // a `{}`/stub form would be invisible to the byte-identity corpus, which is exactly how the 2026-07-27ze gateway
    // channel-wipe near-miss happened.
    // ★★ DONE vs MISSING after T1 (spec §3/T1). DONE — four of the six consumers now pass the real plane, so the
    // TEAM discovery plane runs on team_hop_cap (8) end to end: node_cascade.cpp:145 (team cascade-exhaustion RREQ
    // TTL) · node_cascade.cpp:317 (deferred-drain requery TTL, `team_rreq`) · node_route_discovery.cpp:224, which
    // feeds BOTH the RREQ `f.hops >= cap` guard and the RREP `f.hops > 2*cap` backstop. The cap and the TTL therefore
    // stay in the relationship the static plane has always had.
    // MISSING — two consumers still hardcode `false`, each for its own reason, neither an oversight:
    //   · node_beacon.cpp:884 (DV combined-hops cap) — ★ T3 ATTEMPTED THE FLIP, MEASURED IT AND BACKED IT OUT
    //     (2026-07-28). It is NOT the "halves the team DV radius across 9 scenarios" change T0/T1 predicted: measured,
    //     **0 of those 9 move** (their team paths are <= 3 hops, so 8 and 16 decide identically). Its one real effect
    //     is to disarm s35a/s38, and NO value of team_hop_cap restores them, for a structural reason recorded in full
    //     at that site. Re-attempting it needs s35a re-authored FIRST. The config prerequisite is landed (T3 gave
    //     team_hop_cap a `cfg set` + readouts + a sim dispatch row), so the flip itself is one token.
    //   · node_cascade.cpp:164 (§P3 dead-primary rediscovery) — STATIC-ONLY BY CONSTRUCTION and nothing flips it
    //     later; the team branch above it returns early to avoid the static _peer_liveness array it reads.
    uint8_t           hop_cap_for(bool team_plane) const { return team_plane ? _cfg.team_hop_cap : _cfg.dv_hop_cap; }
    // Duty-cycle consumption readout (console `duty` + companion). 0..100% of the rolling-window budget (100 = the node
    // must stay silent); avail_ms = ms until SOME airtime ages back in (0 when there's headroom); enabled=false = no
    // limit. Pure accessor — surfaces what duty_over_budget already computes; no state change.
    struct DutyStatus { uint8_t pct; uint32_t avail_ms; bool enabled; };
    DutyStatus        duty_status() const;
    // Anti-spam v2 (MF1/MF8): the channel-cap duty basis D = duty_cycle * originator_window_ms — a 5-MINUTE budget
    // (1% -> 3000 ms). Deliberately NOT _duty_cycle_budget_ms (a 1-HOUR budget, 12x too big for the 5-min cap window).
    // Returns 0 when duty is disabled (duty_cycle <= 0) — the sentinel the legacy-flat-cap fallback (MF2) keys on.
    uint32_t          channel_duty_budget_ms() const {
        return (_cfg.duty_cycle > 0.0)
            ? static_cast<uint32_t>(_cfg.duty_cycle * protocol::originator_window_ms)
            : 0u;
    }
    // Anti-spam v2 (2026-06-30): the SF/mesh/duty-aware per-origin CHANNEL cap (distinct floods/origin/window). Pure,
    // const, draw-free. MF2: duty disabled (channel_duty_budget_ms()==0) -> the legacy flat cap. Else MF1/MF3:
    // T_ch = airtime_routing_ms(43) + airtime_ms(max_data_sf(),...); C = max(1, D/T_ch); shared C/N_active among origins.
    uint16_t          channel_cap_origin() const;
    // `limits` query snapshot (companion anti-spam/headroom screen). Live-computed on demand: counters +
    // the channel_capacity_C()/channel_cap_origin() formula (cheap, idempotent, no state change). *_next_ms = the
    // true "when can I send next" = max(burst-floor remaining, channel window cap-wait, duty recovery).
    struct LimitsSnapshot {
        uint32_t win_ms, win_left_ms, n, ch_sf, ch_cap, ch_used,
                 ch_min_ms, ch_next_ms, ch_ceiling, dm_min_ms, dm_next_ms, duty_ms, duty_used_ms;
    };
    LimitsSnapshot    limits_snapshot() const;
    // id_bind reverse lookup. ★ §id-hash S3: the AUTHORITATIVE-only rule is now a PARAMETER, not a hard filter, and
    // the default reproduces the old behaviour exactly (`false` = unknown, expired, or below the floor ⇒ DST_HASH
    // omitted). The floor is the twin of team_key_of_id's above — one policy, one spelling, both planes (U1).
    // ⚠ WHY IT HAD TO BECOME A PARAMETER (spec §3-D1, "load-bearing"): the hard filter made a `claimed` binding
    //   invisible to EVERY reader, so S4a would have landed a mechanism nothing could observe or display.
    bool              key_hash_of_id(uint8_t id, uint32_t& out, IdBindConf min = IdBindConf::authoritative, IdBindConf* actual = nullptr) const;  // Public for the send-path test.
    int               mobile_home_find(uint32_t mobile_hash, uint8_t* home_layer_out = nullptr) const;   // §mobile 3c/5b: cached mobile_hash -> home_id (+layer out-param), or -1 (TTL-checked). Public for the send-path test.
    void              mobile_home_set(uint32_t mobile_hash, uint8_t home_id, uint8_t epoch = 0, uint8_t home_layer = 0);  // §mobile 3c/4a/5b: insert/refresh (evict oldest if full); freshest-epoch wins. SILENT.
    void              mobile_home_age_out();                            // §mobile 3c: TTL drop (alongside id_bind_age_out)
    int               mobile_home_on_leaf(uint8_t leaf, uint32_t mobile_hash) const;    // §5b: mobile_home_cache lookup on a SPECIFIC leaf (the cross-layer bridge, not _active)
    void              on_mobile_hash_bind_response(const uint8_t* inner, uint8_t inner_len);  // §mobile 4a: a MOBILE_H_ANSWER -> cache M->home (epoch), NO id_bind. public = deliver seam + test
    void              on_mobile_hash_bind_pubkey_response(const uint8_t* inner, uint8_t inner_len);  // §mobile Part 2 Fix 8: a MOBILE_H_ANSWER_PUBKEY -> cache peer_key(M) + M->home, NO id_bind. public = deliver seam + test
    void              on_mobile_key_forward(const uint8_t* body, uint8_t len);   // §S3 part2 (mobile side): cache the home-forwarded requester key (self-consistency-checked) + push peer_key_cached; closes the recipient-side decrypt gap. public = deliver seam + test
    uint8_t           claim_epoch()   const { return _claim_epoch; }
    void              restore_join_state(uint8_t claim_epoch, bool joined) { _claim_epoch = claim_epoch; _joined = joined; }  // boot: reload persisted DAD state (NV)
    // Channel send-ctr persistence (metal reboot id-reuse fix): the self-keyed _peer_send_counter entry = the LAST
    // channel ctr this node minted. channel_ctr() reads it (0 if none); restore_channel_ctr seeds it at boot so the
    // first post-boot next_ctr(_node_id) CONTINUES (no re-mint of an already-used channel_msg_id). Call after on_init
    // (when _active + _node_id are valid). Host-testable.
    uint16_t          channel_ctr() const { auto it = _active->_peer_send_counter.find(_node_id); return it != _active->_peer_send_counter.end() ? it->second : 0; }
    void              restore_channel_ctr(uint16_t v) { _active->_peer_send_counter[_node_id] = v; }
    // D7 (companion-contract): generalize the channel_ctr lease to a per-peer high-water FLOOR — the DM dedup identity
    // (sender_hash, ctr) must not collide after a reboot re-mints ctrs. peer_ctr_high() = the MAX ctr across ALL
    // _peer_send_counter entries (the self/channel counter is just one of them); the lease persists THIS + margin.
    // restore_peer_ctr_floor seeds the boot floor so every per-peer next_ctr resumes ABOVE the pre-reboot high-water.
    uint16_t          peer_ctr_high() const { uint16_t m = 0; for (const auto& kv : _active->_peer_send_counter) if (kv.second > m) m = kv.second; return m; }
    void              restore_peer_ctr_floor(uint16_t v) { _active->_peer_ctr_floor = v; }
    uint16_t          test_next_ctr(uint8_t dst) { return next_ctr(dst); }   // D7 test seam: drive the (floor-applied) per-peer counter
    // §6 DAD tiebreak (pure): higher claim_epoch wins; tie -> lower key_hash32 wins. Public for the convergence test.
    static bool       join_tiebreak_wins(uint8_t my_epoch, uint32_t my_key, uint8_t their_epoch, uint32_t their_key);
    // -> node_id, or -1 (skips expired); opt. out: the binding's confidence (soft/hard resolve).
    // §AB3: made `const` (it only reads _id_bind + writes *conf_out) so the const address-book view can reuse it
    // instead of forking a fourth _id_bind scan (U1). Pure widening — no call site changes, no behaviour changes.
    int               id_bind_find_by_hash(uint32_t key_hash32, IdBindConf* conf_out = nullptr) const;
    // E2E peer-pubkey cache (Phase 1 §6). Public for the seal/open paths + tests. hash-verified (ed_pub[:4]==hash),
    // authoritative-never-downgraded, evict-oldest at cap_peer_keys, TTL-aged. Per the ACTIVE layer.
    bool              peer_key_set(uint32_t key_hash32, const uint8_t ed_pub[32], PeerKeyConf conf, const char* name = nullptr, uint8_t name_len = 0);   // false: ed_pub[:4]!=hash. §1.3: name (if given) is REFRESHED on every call (mutable), the key never downgrades.
    uint8_t           peer_name_find(uint32_t key_hash32, char* out, uint8_t cap) const;   // §1.3: the cached name for a peer hash (0 = unknown/none); for `nameof`
    // ★ §AB2 (spec 2026-07-29 §2.3) — the write twin of peer_name_find, and THE ONE name writer: peer_key_set now
    // delegates its two name-copy sites here rather than keeping a third clamp-and-copy (U1).
    // false = no row holds this hash ⇒ the `peername` verb refuses loud (C2); it NEVER creates a keyless placeholder row
    // (spec §2.3), which would fight peer_key_set's ed_pub[:4]==hash invariant.
    // ★★ DELIBERATELY NOT ROUTED THROUGH peer_key_set, and this is the one design call in AB2 worth reading:
    //   (a) peer_key_set REQUIRES an ed_pub that hash-verifies, so a rename would have to read the key back out and
    //       hand it straight in — via peer_key_find, which AGES, so renaming a peer whose TTL had lapsed would refuse
    //       while `nameof` still answered with its name: two verbs disagreeing about one row (spec §2.5's defect class);
    //   (b) it refreshes last_seen_ms — a rename is not a sighting, and silently extending a key's TTL lease is a
    //       behaviour nobody asked for;
    //   (c) its `existing_pinned && conf != pinned` early return would have to be defeated by passing `pinned` back in,
    //       i.e. the console ASSERTING a confidence it never verified — exactly what AB1's "never silently promoted"
    //       ruling exists to stop.
    // ⇒ a user-initiated rename SUCCEEDS on a pinned peer (the key is IMMUTABLE, the name is MUTABLE — PeerKey's own
    // contract) and touches neither ed_pub nor confidence nor last_seen_ms.
    bool              peer_name_set(uint32_t key_hash32, const char* name, uint8_t name_len);
    bool              peer_key_find(uint32_t key_hash32, uint8_t ed_pub_out[32], PeerKeyConf* conf_out = nullptr);  // false: absent/aged
    bool              peer_confirmed(uint32_t key_hash32) const;   // §S2: have we OPENED a sealed frame from this peer? (no entry -> false -> INTRO attaches on first contact)
    // §remote-mgmt: node_id -> its learned key_hash32 (from the _id_bind beacon table), 0 if we've heard no beacon for it.
    // Lets the admin-issue path resolve a target id -> hash -> ed_pub (peer_key_find) to seal a command to it.
    // ✔ FIXED 2026-07-31 (§idbind-loop) — the loop below was wrong in TWO ways, both closed by its ONE bound. Kept on
    //    record because the shape is an easy one to reintroduce, and because the second defect is invisible by reading:
    //    (1) ★★ IT NEVER RETURNED ON A MISS. The counter was `uint8_t` against `protocol::cap_id_bind` (256), so
    //        `i < 256` was ALWAYS true — `i` wrapped 255->0 and `return 0` was unreachable. Being a `const`,
    //        side-effect-free function, that was UB, not merely a hang: elide/garbage/hang all legal, per -O level and
    //        target. ⇒ on a device, resolving an id we hold no binding for HUNG (watchdog reset) at BOTH call sites,
    //        both behind `unlock`: src/firmware_remote.cpp (`rcmd <unknown-id> <gated-verb>`) and src/fw_main.cpp (a
    //        sealed rcmd RESPONSE from a node whose beacon we never heard). ⓘ The proof it was never intended:
    //        firmware_remote.cpp's very next line is `if (!th) { … "unknown id (no beacon heard from it yet)" … }` —
    //        a miss-handler written for a function that could not report a miss. That branch is LIVE again.
    //    (2) it scanned the whole 256-slot ARRAY instead of the live `_id_bind_n` prefix, and the compacting removers
    //        (id_bind_age_out / id_bind_evict_other_hash_holders / node_join.cpp's prior-id drop) leave STALE COPIES
    //        in the tail, so it could hand back the hash of an EVICTED/AGED binding. `_id_bind_n` fixes this too.
    //    Bound + index copied from the sibling key_hash_of_id (node_hashlocate.cpp) — `uint16_t i < _id_bind_n`, and
    //    `_id_bind_n` is itself `uint16_t`, so the comparison is warning-clean (U1). Both directions are now pinned in
    //    test/test_node_hashlocate.cpp: the miss returns 0 (defect 1) and an id evicted by the rehome self-heal no
    //    longer resolves out of the tail (defect 2).
    // ⚠ STILL DIVERGENT FROM key_hash_of_id, deliberately and out of this slice's scope (C1): that sibling is also
    //   AUTHORITATIVE-gated and TTL-gated; this one is neither, so it can answer from a `claimed` or lapsed row. The
    //   residual is narrow (the hash only feeds peer_key_find, which ages independently, and id_bind_set maintains the
    //   id<->hash bijection) — but it is a real difference, not an oversight in the reading.
    uint32_t          key_hash_for_id(uint8_t id) const {
        if (!_active || id == 0) return 0;
        for (uint16_t i = 0; i < _active->_id_bind_n; ++i)
            if (_active->_id_bind[i].node_id == id && _active->_id_bind[i].key_hash32) return _active->_id_bind[i].key_hash32;
        return 0;
    }
    void              peer_key_age_out();                                                              // drop entries past peer_key_ttl_ms
    uint16_t          peer_key_count() const { return _active->_peer_keys_n; }

    // ==================== ★★★ §AB4 — RETAINED PEER LOCATION (spec 2026-07-29 §2.7) ====================
    // See the _peer_loc ring's own note (down with the Node-global members) for RAM-only, for why neither PeerKey nor
    // _team_keys is the home, and for the trust bound. These two are the whole public surface.
    //
    // ★ THE ONE SETTER, for BOTH sources (U1/U2 — one conversion path, as seed_blob_from_live is for the carriers).
    // The live caller is node_mac_rx.cpp's DELIVER path, inside the `if (loc_present)` block that ALREADY parses the
    // position, ALREADY distinguishes sealed from plaintext and ALREADY emits `peer_location` — only RETENTION was
    // missing, so nothing is re-extracted here (U1). Refreshes an existing hash in place; appends while there is room;
    // evicts the STALEST slot when full. Returns false only on key_hash32 == 0 (C2: 0 is the "no hash" sentinel that
    // peer_book_by_hash also refuses, never a queryable identity).
    // ⚠⚠ CALLER-ENFORCED, NOT ENFORCED HERE: only an AUTHENTICATED position may be stored. The receive site tests
    // `crypted_ok && sender_hash` and emits `peer_location_unauth` instead of calling this when it fails (owner ruling
    // O6). The check lives THERE because that is where the evidence is — `crypted_ok` is the seal result, and this
    // function cannot re-derive it from four scalars. ★ A plaintext DATA_FLAG_LOCATION is still parsed and still pushed
    // to the app exactly as before; it is only never RETAINED. Rationale: an unauthenticated position is spoofable by
    // anyone in range, and a spoofed position in an address book is WORSE than an absent one, because the UI presents it
    // as fact.
    // ★ TWO CALLERS NOW, one per source, and each does its OWN evidence test before calling — for the same reason:
    //   · node_mac_rx.cpp's DELIVER path -> PeerLocSrc::peer (tests `crypted_ok && sender_hash`);
    //   · node_channel.cpp's ingest_channel_m -> PeerLocSrc::team (§chan-crypt CL2b; the seal under the shared team
    //     content key IS the trust anchor per owner ruling O5, and the test there is ATTRIBUTION — §chan-crypt CL2c:
    //     the sender's full key_hash32 READ OFF THE SEALED INNER (bit2, required beside a position), non-zero, and
    //     cross-checked against the msg-id's 16 hash bits. It no longer resolves through `_team_keys`).
    bool              peer_loc_set(uint32_t key_hash32, int32_t lat_e7, int32_t lon_e7, PeerLocSrc src);
    // The read twin. `age_s` is derived from the stored second-stamp against `_hal.now()` — see PeerLoc::t_s for the
    // rollover reasoning and for why a backwards clock reports MAXIMALLY STALE rather than 0. false = no position held
    // for that hash (the NORMAL case, not an error), and the out-params are then untouched.
    bool              peer_loc_find(uint32_t key_hash32, int32_t& lat_e7, int32_t& lon_e7,
                                    uint32_t& age_s, PeerLocSrc& src) const;
    uint8_t           peer_loc_count() const { return _peer_loc_n; }   // live slots (test/diagnostic; mirrors peer_key_count)

    // ==================== ★★ §AB3 — THE GENERATED ADDRESS BOOK (spec 2026-07-29 §2.1) ====================
    // A JOIN on key_hash32 over the THREE tables that already exist — _peer_keys (name/key/conf/confirmed),
    // _id_bind (static node_id) and _team_keys/_team_peer (team_local_id). **GENERATED, never stored:** there is no
    // fourth table, so the view costs ZERO RAM and cannot go stale. A stored copy would need syncing on every
    // peer_key_set / id_bind_set / team_key_set and every eviction, which is precisely how the ledgers this arc spent
    // itself un-drifting drifted.
    // ★ WHY IT EXISTS AT ALL (spec §2.5, bench-proven 2026-07-30): `reqpubkey <id>` reads _team_keys and `hashof <id>`
    // read _id_bind, so `reqpubkey 228` cached 0x6C297145 and `hashof 228` still answered `unknown`. Each verb was
    // right about ITS table and neither answered the question. ⇒ every id/hash-shaped console query now reads THIS
    // view, so they cannot disagree again.
    // ⚠⚠ THE FORBIDDEN REPAIR, recorded so nobody re-takes it: do NOT make `hashof` work by writing the team hash into
    // _id_bind. That is the plane-blind ingest closed on 2026-07-31 (§id-bind-plane) — a team-scoped answer writing the
    // static map is an I2 breach. A team id belongs in _team_keys; the VIEW is what joins it to the hash for display.
    struct PeerBookRow {
        uint32_t    hash;               // 0 = an ID-ONLY row (we hold an id but no hash for it)
        char        name[protocol::peer_name_max];
        uint8_t     name_len;           // 0 = no name cached (normal — most rows have neither name nor key)
        uint8_t     static_id;          // 0 = none — the STATIC node_id plane (_id_bind)
        uint8_t     team_id;            // 0 = none — the TEAM local-id plane (_team_keys/_team_peer). §18: BOTH may be set.
        PeerKeyConf conf;               // meaningful ONLY when has_key; see console::peerkeyconf_name (the ONE spelling)
        // ★ has_key = we hold a USABLE pubkey (peer_key_find would succeed) ⇒ conf/peer_confirmed meaningful and a seal
        // is possible at conf >= authoritative. An AGED non-pinned row still contributes its NAME and its ids but
        // reports has_key=false + conf=overheard, so the app can never offer an encryption that would fail (§0.1).
        bool        has_key;
        bool        peer_confirmed;     // §S2: they hold OUR key (a sealed reply can come back)
        bool        static_authoritative;   // the _id_bind binding is AUTHORITATIVE (what key_hash_of_id vouches for); false = claimed/second-hand
        // ★★ §id-hash S3 (spec §3-D1): the TEAM plane's twin, and D6's "display a claim LABELLED as a claim" is
        // unimplementable without it — a renderer that cannot see the tier will print a claim as a fact. Meaningful
        // only when `team_id != 0` AND the row carries a hash (an id-only team row asserts no binding at all, exactly
        // like `static_authoritative` on the `_rt` id-only rows pass 2b emits).
        // ⓘ TRUE ON EVERY ROW S3 CAN PRODUCE, and that is not the §2.4 "tier with no producer" smell: the underlying
        //   `TeamKey::confidence` HAS a producer here (the heard beacon writes `authoritative`), so this field is a
        //   faithful readout of live state, not an enumerator nothing writes. S4a's on-air ingest makes it false.
        bool        team_authoritative;
        uint8_t     team_alias_dropped; // ⚠ >0: that many OTHER _team_keys rows carry this hash and LOST the freshest-wins
                                        // race. The emit MUST say so (spec §2.1) — never silently pick a winner.
        // ★★ §AB4 — the joined _peer_loc row (spec §2.7). ADDITIVE: every pre-AB4 caller compiles and reads unchanged.
        // ⚠ ABSENCE IS NORMAL, NOT AN ERROR — most rows will never carry a position, so a renderer must handle
        // has_location == false as the ordinary case (the contract says so too).
        bool        has_location;       // false ⇒ lat_e7/lon_e7/loc_age_s/loc_src are ALL meaningless, do not render them
        int32_t     lat_e7;
        int32_t     lon_e7;
        // ★★ MANDATORY ALONGSIDE THE POSITION, never optional: a position shown without its age gets read as CURRENT,
        // which is exactly the misleading-stale-fix failure the RAM-only ruling exists to prevent.
        uint32_t    loc_age_s;
        PeerLocSrc  loc_src;            // the TRUST ANCHOR — pairwise (`peer`) vs group (`team`). See PeerLocSrc.
    };
    using PeerBookVisit = void (*)(const PeerBookRow& row, void* ctx);   // a plain fn-ptr: lib/core carries no std::function
    // Walk the book, ONE row on the stack at a time (never an array — cardinality is driven by _id_bind's 256, and a
    // 256-row buffer is ~12 KB on the loop-task stack: the do_post_ack overflow lesson).
    // include_id_rows=false ⇒ ★ the §2.6(a) BOUND: only rows backed by _peer_keys (≤ cap_peer_keys = 16), enriched with
    //   static_id/team_id. That is the JSON address book, bounded BY CONSTRUCTION rather than by a paging protocol.
    // include_id_rows=true  ⇒ the full up-to-256 diagnostic list (`peers all`, TEXT console only). Emitting that over
    //   BLE walks straight back into the self-inflicted-console-flood WEDGE this project already fixed once (mrcon).
    // Returns the row count. fn may be nullptr (count only).
    uint16_t          peer_book_walk(bool include_id_rows, PeerBookVisit fn, void* ctx) const;
    // The hash-shaped query: the joined row for one hash. false = no table holds it. (`nameof` reads this.)
    bool              peer_book_by_hash(uint32_t key_hash32, PeerBookRow& out) const;
    // ★ The ID-shaped query — spec §2.5's actual fix. Searches BOTH namespaces and reports WHICH matched; when one
    // number matches in both (the §18 dual-identity space) it fills BOTH rows so nothing is silently picked.
    // Returns a bitmask: bit0 = `static_out` valid, bit1 = `team_out` valid; 0 = the id is unknown in both planes.
    // ⚠ It resolves through key_hash_of_id and team_key_of_id — the SAME two functions the send path and
    // `reqpubkey <team-id>` (node.cpp CmdKind::reqpubkey) already use, not a fourth hand-rolled scan (U1).
    uint8_t           peer_book_by_id(uint8_t id, PeerBookRow& static_out, PeerBookRow& team_out) const;
    static constexpr uint8_t kPeerBookStatic = 0x1, kPeerBookTeam = 0x2;

    // E2E seal/open (Phase 1 §4/§5). Public for the send/receive paths + tests. SAME-LAYER DMs only in v1
    // (cross-layer CRYPTED out of scope). Recipient/sender pubkey resolved from the peer-key cache; ECDH+KDF+nonce
    // via _x_secret. e2e_seal_inner builds [dst_hash 4][ciphertext][tag 16] + the 8-B nonce-seed (§1c: pt = origin‖…); returns
    // inner_len, or 0 with `outcome` set to WHY (no_identity / no_pubkey / too_large / bad_rng / cross_layer) so the
    // caller FAILS LOUD distinctly, never cleartext. Only no_pubkey warrants a WANT_PUBKEY flood.
    size_t e2e_seal_inner(uint8_t* inner, size_t cap, uint8_t seed8[8], uint8_t flags, uint32_t dst_key_hash32,
                          uint8_t origin, uint16_t ctr, uint32_t source_hash, int32_t lat_e7, int32_t lon_e7,
                          const uint8_t* body, uint8_t body_len, SealOutcome& outcome);
    // e2e_open_inner: open under ONE candidate `sender_hash`; VERIFY the sealed source_hash == sender_hash. false = no
    // key / tag fail. `origin_out` = the DM's origin (1a: read from the cleartext AAD; 1c: recovered from the seal).
    bool   e2e_open_inner(const uint8_t* inner, size_t inner_len, const uint8_t seed8[8], uint8_t flags, uint16_t ctr,
                          uint32_t sender_hash, uint32_t& origin_out, uint32_t& source_hash_out, bool& has_location_out,
                          int32_t& lat_out, int32_t& lon_out, uint8_t* body_out, uint8_t& body_len_out);
    // §1a sealed-sender: TRIAL DECRYPTION — try each AUTHORITATIVE/PINNED cached peer key; the Poly1305 tag is the
    // oracle. First verifying key → decrypt + that key's owner IS the sender (sender_hash_out) + recover origin. false =
    // NO cached key opens it (caller DROPS silently — option a: no push/ack/inbox). No cleartext sender hint on the wire.
    bool   e2e_open_trial(const uint8_t* inner, size_t inner_len, const uint8_t seed8[8], uint8_t flags, uint16_t ctr,
                          uint32_t& sender_hash_out, uint32_t& origin_out, uint32_t& source_hash_out,
                          bool& has_location_out, int32_t& lat_out, int32_t& lon_out, uint8_t* body_out, uint8_t& body_len_out);
    // §S4 SEALED_RELAY (DATA_TYPE_SEALED_RELAY): build the relay BODY [seal_ctr 2 LE][seed8 8][ct‖tag] — seal `body`
    // to `target_hash` under OUR identity (source_hash = _key_hash32), SAME-LAYER-shaped (aad = target_hash, nonce =
    // dm_nonce(seed8, seal_ctr, target_hash)); seal_ctr = ++_relay_seal_ctr (CARRIED, not the frame ctr, so a
    // delegating home re-originates under its OWN frame ctr for MAC dedup while the recipient still derives the nonce
    // WE used). Returns the body length, or 0 with `outcome` set (no_identity/no_pubkey/too_large) -> caller FAILS LOUD.
    uint8_t build_sealed_relay_body(uint32_t target_hash, const uint8_t* body, uint8_t body_len,
                                    uint8_t* out, uint8_t out_cap, SealOutcome& outcome);
    // §S4: open a SEALED_RELAY body whose CLEAR sender is `source_hash` (directed, no trial). Verifies the SEALED
    // source_hash == source_hash (anti-spoof) and IGNORES the sealed origin byte (§1c layer-local garbage). false = no
    // key / tag fail / short / spoof -> caller DROPS (never delivers ciphertext).
    bool   e2e_open_relay(const uint8_t* relay_body, size_t len, uint32_t source_hash,
                          uint8_t* body_out, uint8_t& body_len_out);
    // ★ §hashbind-plane: `team_plane` is REQUIRED, not defaulted (C2) — it is the §18 plane split, and a caller that
    // forgets it must fail to compile rather than silently re-open the I2 breach. true => the answer rode the TEAM
    // plane, so its node_id is a TEAM LOCAL id and the static _id_bind write is SKIPPED (PostAck::team_plane).
    void              on_hash_bind_response(const uint8_t* inner, uint8_t inner_len, bool authoritative, bool team_plane);   // C.1: the origin consumed an H_ANSWER DATA -> cache (h_query) + drain. authoritative from the frame TYPE. public = the deliver seam + test driver
    void              on_hash_bind_snoop(const uint8_t* inner, uint8_t inner_len, bool authoritative, bool team_plane);      // C.2: a forwarder snooped an H_ANSWER in transit -> cache-on-pass (h_relay). authoritative from the frame TYPE. public = the relay seam + test driver
    void              on_hash_bind_pubkey(const uint8_t* inner, uint8_t inner_len);   // E2E §6: a DATA_TYPE_AUTHORITATIVE_H_ANSWER_PUBKEY (delivered OR relayed-through) -> cache the ed_pub authoritative (verify ed_pub[:4]==hash)
    bool              channel_entry_dirty(uint32_t id) const { const int i = channel_buffer_find(id); return i >= 0 && _active->_channel_buffer[i].dirty; }
    bool              channel_payload_eq(uint32_t id, const uint8_t* p, uint16_t len) const {
        const int i = channel_buffer_find(id);
        if (i < 0 || _active->_channel_buffer[i].payload_len != len) return false;
        for (uint16_t k = 0; k < len; ++k) if (_active->_channel_buffer[i].payload[k] != p[k]) return false;
        return true;
    }
    static uint32_t   channel_msg_id_mint(uint8_t origin, uint32_t key_hash32, uint8_t ctr);   // origin<<24|(kh&0xffff)<<8|ctr (dv:2239)
    void    ingest_channel_m(const m_out& m, uint8_t from);  // M-frame merge (dv:10942); public for tests
    // Origin-level DATA dedup (loop/retransmit detection): record (origin,dst,ctr)->expiry + the prev-hop.
    // Prunes expired, then ROLLS (evicts the oldest = min-expiry) at the 256 cap instead of refusing. Public for tests.
    void    record_seen_origin(uint64_t sokey, uint8_t from, uint64_t now_ms);
    size_t  seen_origin_count() const { return _active->_seen_origins.size(); }
    bool    seen_origin_live(uint64_t sokey, uint64_t now_ms) const {
        auto it = _active->_seen_origins.find(sokey); return it != _active->_seen_origins.end() && it->second > now_ms; }
    // ★★★ §hybrid-rts S2 — the COMPLETED-FLIGHT cache (design §4.3). The match is the FULL tuple
    // `immediate sender | dst | team/static plane | domain | full identity` and nothing else; `_find` returns the
    // live entry or nullptr. `_store` prunes expired, refreshes an existing key in place, then inserts — evicting
    // the min-expiry entry only when every slot is live. Public for tests (like record_seen_origin above).
    // ⛔ `from` must be the ON-AIR immediate sender (`PendingRx::from` = the RTS's `src`), NEVER `meta.src_hint`.
    const CompletedFlight* completed_flight_find(uint8_t from, uint8_t dst, bool team_plane,
                                                 const RtsFlightIdentity& id, uint64_t now_ms) const;
    void    completed_flight_store(uint8_t from, uint8_t dst, bool team_plane,
                                   const RtsFlightIdentity& id, uint64_t now_ms);
    size_t  completed_flight_live_count(uint64_t now_ms) const;   // live (unexpired) occupancy — for tests/instrumentation

    // ---- Peer-liveness + freshness plane (routing-liveness port). Public for tests + the hooks. PHASE 1 = STATE
    // ONLY: tracked + emitted, NOT yet applied to scoring/selection/cascade (that is Phase 2/3). ----
    void    record_peer_rts_timeout(uint8_t node_id, uint8_t ctr_lo, bool team_plane = false);   // a same-hop RTS/ACK giveup -> count + tier (suspect@1/silent@3/dead@6). §2c: team_plane -> _team_liveness
    void    clear_peer_suspect(uint8_t node_id, const char* source, bool team_plane = false);   // a frame heard FROM node_id -> alive -> clear its tiers. §2c: team_plane -> _team_liveness (recovery-on-heard)
    void    mark_dest_seen(uint8_t node_id);                           // stamp last-seen-as-transmitter (freshness input)
    uint8_t peer_suspect_level(uint8_t node_id);                       // 0 healthy / 1 suspect / 2 silent / 3 dead (clears expired tiers lazily)
    bool    is_next_hop_fresh(uint8_t node_id) const;                  // now - dest_seen <= next_hop_live_ttl_ms (self = always fresh); DEFINED, not consulted in P1

private:
    // Node-owned timer-id namespace (Hal::after re-arm-by-id, cap 64). Reserve
    // 4+ for the R3 RTS/CTS/ACK timers.
    static constexpr uint32_t kBeaconTimerId           = 1;
    static constexpr uint32_t kAgingTimerId            = 2;
    static constexpr uint32_t kTriggeredBeaconTimerId  = 3;
    // R3 data-plane (MAC) timers — single-flight per node, so one live instance each.
    static constexpr uint32_t kRtsTimeoutTimerId       = 4;   // sender: CTS-wait
    static constexpr uint32_t kAckTimeoutTimerId       = 5;   // sender: ACK-wait
    static constexpr uint32_t kPendingRxExpiryTimerId  = 6;   // receiver: DATA-wait
    static constexpr uint32_t kCtsToDataGapTimerId     = 7;   // sender: CTS-rx -> DATA-tx gap
    static constexpr uint32_t kQueueWakeupTimerId      = 8;   // become_free: not-ready re-arm
    static constexpr uint32_t kPostAckTimerId          = 9;   // receiver: ACK-air -> deliver/forward
    static constexpr uint32_t kRetryBackoffTimerId     = 10;  // sender: jittered RTS retry
    // Cascade-to-alt / no-route defer plane.
    static constexpr uint32_t kDeferredDrainTimerId    = 11;  // periodic 1s drain of _deferred (TTL giveup)
    static constexpr uint32_t kCascadeRequeueTimerId   = 12;  // backoff before re-draining a requeued flight
    static constexpr uint32_t kNackWaitTimerId         = 13;  // NACK BUSY_RX wait-same-hop one-shot
    static constexpr uint32_t kReqSyncTimerId          = 14;  // REQ_SYNC boot loop: re-arm every req_sync_retry_ms while discovery+route-starved (dv:9167)
    static constexpr uint32_t kBeaconJitterTimerId     = 27;  // R4.3 silence-jitter deferred periodic beacon; BASE of a 4-slot ring [27..30] (cleanup #D: two defers in one jitter window must BOTH fire, dv per-closure)
    static constexpr uint8_t  kBeaconJitterSlots       = 4;
    static constexpr uint32_t kRtsDutyDeferTimerId     = 31;  // cleanup #A redo: over-budget RTS duty-defer re-check/hand
    static constexpr uint32_t kLbtDeferTimerId         = 15;  // R4.5 LBT deferred-TX re-fire; BASE of a 4-slot range [15..18]
    static constexpr uint32_t kRadioBusyRetryTimerId   = 19;  // R4.5b on_radio_busy stash re-issue; BASE of a 4-slot range [19..22]
    static constexpr uint32_t kDutyDeferTimerId        = 23;  // tx_with_retry duty-cycle pre-check defer; BASE of a 4-slot range [23..26]
    static constexpr uint32_t kSyncResponseTimerId     = 32;  // REQ_SYNC jittered response fire; BASE of a kSyncRespSlots ring [32..47] (one slot per pending requester)
    static constexpr uint8_t  kSyncRespSlots           = protocol::cap_sync_response_pending;
    static constexpr uint32_t kChannelPullTimerId      = 48;  // channel CHANNEL_PULL jittered fire; BASE of a kChannelPullSlots ring [48..55]
    static constexpr uint8_t  kChannelPullSlots        = protocol::cap_channel_pull_pending;
    static constexpr uint32_t kMBcastClearTimerId      = 56;  // M-broadcast fire-and-forget: clear pending_tx after the DATA-M airtime (no ACK)
    static constexpr uint32_t kOverhearRetuneTimerId   = 57;  // overhear ARM: retune RX back to routing_sf after the DATA-M window
    static constexpr uint32_t kJoinClaimGuardTimerId   = 58;  // node_id DAD: claim guard window -> adopt-or-deny
    static constexpr uint32_t kJoinRetryTimerId        = 59;  // node_id DAD: jittered re-claim after a lost claim/heal
    static constexpr uint32_t kJoinListenTimerId       = 60;  // node_id DAD: listen window before the FIRST claim (L1: hear the leaf, then pick)
    static constexpr uint32_t kFloodRebcastTimerId     = 61;  // channel flood rebroadcast fire; BASE of a ring [61..63] (slot = id - base); LAST of the dense 1..63 block
    // ---- Slice 3 dual-layer gateway scheduler band [64..79] (kCap raised 64->80 in 3b). PER-LAYER timers: slot = layer
    // index (0..1). Inert on a single-layer node (n_layers==1 never arms them). The window open/close + per-leaf beacon
    // are the only PERSISTENT per-layer timers; the MAC exchange timers (RTS/ACK/retry rings) are active-layer-shared.
    static constexpr uint32_t kLayerWindowTimerId      = 64;  // per-layer window-OPEN / leaf-switch fire; BASE of [64..65]
    static constexpr uint32_t kLayerWindowCloseTimerId = 66;  // per-layer window-CLOSE / return fire;      BASE of [66..67]
    static constexpr uint32_t kLayerBeaconTimerId      = 68;  // per-leaf beacon cadence (gateway);         BASE of [68..69]
    // The gateway band [64..69] and the channel re-offer ring [70..73] are ROLE-EXCLUSIVE: a gateway (n_layers==2)
    // is out of the channel provider plane (§7 — never originates a flood, so never arms re-offer), and a normal node
    // (n_layers==1) never arms the gateway timers. So they coexist within kCap=80 with no overlap; the after() id<kCap
    // bound stays intact (the canary era: the wheel is exonerated only because it bounds).
    static constexpr uint32_t kChannelReofferTimerId   = 70;  // channel ORIGIN re-offer jittered fire; BASE of a ring [70..73] (slot = id - base)
    static constexpr uint8_t  kChannelReofferSlots     = protocol::cap_channel_reoffer_pending;
    static constexpr uint32_t kMobileDiscoverTimerId   = 74;  // §mobile 2b: registration FSM — DISCOVER kick / periodic re-CLAIM
    static constexpr uint32_t kMobileClaimGuardTimerId = 75;  // §mobile 2b: collect-OFFERs window close -> pick strongest + CLAIM
    static constexpr uint32_t kMobileLayerQueryTimerId = 76;  // §mobile 5a: pull the layer directory from a gateway (periodic while registered)
    static constexpr uint32_t kTeamDadGuardTimerId     = 77;  // §mobile 6.4: team-DAD claim guard window close -> confirm _team_local_id
    static constexpr uint32_t kPresenceProbeTimerId    = 78;  // §S6: mobile presence check period T (dynamic) + probe retry re-arm
    static constexpr uint32_t kPresenceRosterTimerId   = 79;  // §S6: home roster-coalesce window close -> emit ONE roster
    static constexpr uint32_t kMobileOfferBackoffTimerId = 80;// §S6/QA-3b: host OFFER de-storm — jitter the OFFER so two hosts don't answer a DISCOVER at the SAME ms (the same-ms collision that made a mobile adopt the WEAK home)
    static constexpr uint32_t kHForwardTimerId         = 81;  // §F-XL-1: jittered h_forward de-storm — BASE of a kHForwardSlots ring [81..84] (slot = id - base)
    static constexpr uint32_t kRreqForwardTimerId      = 85;  // §F-XL-2: jittered rreq_forward de-storm — BASE of a kRreqForwardSlots ring [85..88] (slot = id - base)
    static constexpr uint32_t kParkRefloodTimerId      = 89;  // §F-SL-1: parked-send H re-flood scan (single one-shot, re-armed to the earliest pending re-flood)
    static constexpr uint32_t kE2eAckDeadlineTimerId   = 90;  // shelf item (i): E2E-ack deadline scan (single one-shot, re-armed to the earliest pending -a send's deadline — park_reflood idiom)
    // ★★★ §remote-admin v2 SLICE 5 (R-RA-22, design §15) — **THE ONE remote-admin expiry id, and the ONLY reason
    //   `TimerWheel::kCap` grows 91 -> 92 (+8 B on all three ABIs).** ⛔ NO per-record-class id: the ingress
    //   reservations and the open/bootstrap staging rows share ONE earliest-deadline scan, exactly as
    //   `kParkRefloodTimerId` and `kE2eAckDeadlineTimerId` do for their rings. Slice 7b's transcript, deferred-
    //   action and rollover deadlines JOIN THIS SAME SCAN — they do not each take a new id.
    // Both owned endpoints use this same scan; no per-record or second profile timer is allocated.
    // Historically only ACCEPT had expiring state; 8a adds the CLIENT deadlines.
    // The id, like every id above, is a compile-time constant on every profile.
    static constexpr uint32_t kRadminExpiryTimerId     = 91;  // §radmin-5: the ONE remote-admin ingress/staging earliest-deadline scan
    // [78..80] = the presence plane + OFFER de-storm; [81..84] = the h_forward de-storm ring; [85..88] = the rreq_forward de-storm ring; [89] = the parked-send re-flood scan; [90] = the E2E-ack deadline scan; [91] = the remote-admin expiry scan; the timer wheel cap is 92 (kCap in timer_wheel.h).

    // ---- beacon emit / ingest ----------------------------------------------
    void emit_beacon(const char* kind);                            // "periodic" | "triggered"
    void periodic_beacon_fire();                                   // R4.3 throttle body (dv:7695-7851)
    void deferred_beacon_jitter_fire(uint8_t slot);                // R4.3 post-silence-jitter re-check (dv:7801-7849); #D ring slot
    bool _beacon_jitter_pending[kBeaconJitterSlots] = {};          // #D: which ring slots have a deferred periodic beacon armed
    bool beacon_max_idle_force(uint64_t now, bool emit_events);    // R4.3 max-idle B+C override (dv:7734-7784)
    void ingest_beacon(const uint8_t* bytes, size_t len, const RxMeta& meta);
    uint16_t cfg_config_hash() const;                             // R6.1: leaf_config_hash over THIS node's active cfg (u16)
    // R6.1 §6.4 join-participation gate: a node may originate F/DATA only once its leaf config is "synced" — UNMANAGED
    // (lineage 0, backward-compat, always allowed) OR managed-and-adopted (config_epoch > 0; leaf-create/CONFIG_PULL set it).
    // An un-synced managed joiner must listen + CONFIG_PULL only (no F/DATA pollution before it's a member).
    bool     leaf_config_synced() const { return _cfg.lineage_id == 0 || _cfg.config_epoch > 0; }
    int16_t route_score_from_snr(int16_t snr_q4) const;            // dv_dual_sf.lua:3053
    static void emit_rt_update(Hal& hal, uint8_t dest, uint8_t next, int16_t score_q4, uint8_t hops, const char* slot);   // rt_update telemetry (dest/next/score/hops/slot) — shared by the beacon merge sites + the hop_budget-NACK bump (node_mac_rx)
    // Direct (hops=1) neighbour learning from a received frame's immediate sender — the C++
    // learn_rx_source / learn_direct_from_frame. Returns true on a real change (new/promote/
    // refresh) so the caller can fire the triggered beacon. sender must be a real id (0..254);
    // 0xFF (unknown/reserved) and self are no-ops. C++ has no id-bind/dest-seen/liveness plane,
    // so (unlike the Lua) those sub-actions are absent.
    bool    learn_direct_neighbor(uint8_t sender, int16_t snr_q4, bool is_gw, bool team_plane = false);   // §6.2: team_plane -> learn into _rt_team
    void    learn_route_via(uint8_t dest, uint8_t via, uint8_t hops, int16_t snr_q4, bool team_plane = false);  // multi-hop install (F path); §team-multihop: team_plane -> _rt_team + _team_peer bit
    // F route discovery (AODV RREQ/RREP) — node_route_discovery.cpp. §team-multihop (spec 2026-07-15 Plane 2): team_plane forks
    // the whole family onto the TEAM plane (team_scoped F, origin/dst = team_local_id, _rt_team, team-private _rreq state).
    void    handle_f(const uint8_t* bytes, size_t len, const RxMeta& meta);
    void    handle_f_common(const struct f_out& f, const RxMeta& meta, bool team, uint8_t me);   // §P2-2: shared F RREQ/RREP body; static/team entry wrappers apply the plane-only gates then hand off
    void    emit_route_request(uint8_t dst, uint8_t ttl, bool team_plane = false);
    void    send_route_reply(uint8_t origin, uint8_t dst, uint8_t hops_to_dst, bool team_plane = false);
    bool    rreq_seen_recently(uint8_t origin, uint8_t dst, bool team_plane = false);
    void    mark_rreq_seen(uint8_t origin, uint8_t dst, bool team_plane = false);
    bool    rreq_rate_ok(uint8_t dst, uint8_t ttl, bool team_plane = false);
    void    age_out_rreq_last();                                  // periodic (kAgingTimerId): drop spent rate-limit entries — BOTH planes
#if MR_FEAT_TEAM
    void    handle_f_team(const struct f_out& f, const RxMeta& meta);   // §team-multihop: same-team-only F handler (gated on team_id, on _rt_team) — full static/other-team separation
#endif
    // Hash-locate (H) plane — node_hashlocate.cpp. id_bind = the key_hash32->node_id binding table, the
    // substrate the H resolver answers from (Lua dv:4677+). Populated by beacons (every BCN carries the
    // sender's key_hash32) + self + hash-bind responses.
    bool    id_bind_set(uint8_t node_id, uint32_t key_hash32, IdBindSource source, IdBindConf confidence); // insert/update; dedup-by-hash; authoritative overwrites a conflict, claimed refuses
    uint8_t id_bind_evict_other_hash_holders(uint32_t key_hash32, uint8_t keep_node_id);   // rejoin self-heal: one hash -> one node_id
    // ★ §id-hash S2b-fix (QA P1a): the CONFIDENCE guard on that self-heal — the node_id (>= 0) that holds this hash
    // AUTHORITATIVELY and is not `except_node_id`, else -1. Gates are key_hash_of_id's verbatim (U1).
    int     id_bind_auth_holder_other(uint32_t key_hash32, uint8_t except_node_id) const;
    void    id_bind_age_out();                                    // drop expired (TTL); emit id_bind_aged
    // ★ §AB3 view internals (node_hashlocate.cpp). peer_book_fill_from_peer_key does the reverse (hash -> id) JOINS.
    int     peer_key_slot_of(uint32_t key_hash32) const;                         // _peer_keys index, or -1 (NOT age-gated)
    void    peer_book_fill_from_peer_key(uint16_t slot, PeerBookRow& r) const;   // _peer_keys[slot] + both reverse id joins
    void    peer_book_join_ids(PeerBookRow& r) const;                            // hash -> static_id (+conf) and hash -> team_id (+alias count) + the §AB4 location
    // ★ §AB4: hash -> _peer_loc. ONE implementation, called from peer_book_join_ids (which covers the ENTIRE app-facing
    // surface — the bounded JSON book, `nameof` and `hashof` all reach the view through it) and additionally from
    // peer_book_walk's unkeyed passes (2)/(3), which resolve their ids directly and so never call join_ids. Those two
    // extra call sites are what makes `peers all` complete and what stops CL2 — whose channel-sourced positions land on
    // hashes with NO _peer_keys row by design (O5) — having to hunt for a missed join.
    void    peer_book_join_loc(PeerBookRow& r) const;
#if MR_FEAT_TEAM
    // ⚠ THE AMBIGUOUS REVERSE LOOKUP, and it is real on THIS table only. _id_bind maintains one-hash-one-id
    // (id_bind_set calls id_bind_evict_other_hash_holders on BOTH its accept paths) so hash -> static_id cannot alias.
    // _team_keys has NO such dedup — team_key_set upserts BY ID only — so a teammate that re-ran team-DAD leaves its
    // OLD (id, hash) row live until the 48 h TTL or the LRU reclaims it, and TWO team ids then carry one hash.
    // ⇒ resolve by FRESHEST last_seen_ms among rows at the caller's confidence floor and report how many qualifying
    // rows lost. This is the ONE reverse-resolution policy shared by display and send paths: the address-book view
    // passes `claimed` (show a claim, LABELLED as one), while live sends retain their default `authoritative` floor.
    // The winner's tier is returned through `conf_out`; the floor filters candidates but never re-ranks them by trust.
    // ⚠⚠ THE TWO DEFAULTS POINT IN OPPOSITE DIRECTIONS, ON PURPOSE — and that makes this the easier one to misuse.
    // This raw resolver defaults to the PERMISSIVE `claimed` (it exists for the VIEW); the `team_id_of_key` wrapper
    // defaults to the STRICT `authoritative` (it exists for the SEND). ⇒ **a send-path caller reaching for THIS
    // function — the more capable API, since it also returns `alias_dropped` and the winner's tier — would silently
    // get the permissive floor and route on a claim, which spec §3-D7 forbids.** All four callers are correct today
    // (three views pass or default to `claimed`; the wrapper threads its caller's floor). If you add a fifth from a
    // send/mutation path, PASS `IdBindConf::authoritative` EXPLICITLY. Flagged by the §B30 QA review, 2026-08-02.
    uint8_t team_id_of_key_freshest(uint32_t key_hash32, uint8_t& alias_dropped,
                                    IdBindConf min = IdBindConf::claimed, IdBindConf* conf_out = nullptr) const;
#else
    uint8_t team_id_of_key_freshest(uint32_t, uint8_t& alias_dropped,
                                    IdBindConf = IdBindConf::claimed, IdBindConf* conf_out = nullptr) const { alias_dropped = 0; if (conf_out) *conf_out = IdBindConf::claimed; return 0; }
#endif
    void    handle_h(const uint8_t* bytes, size_t len, const RxMeta& meta);   // H flood: resolve (own-hash OR id_bind) + suppress, else forward TTL-1
    void    h_forward_fire(uint8_t slot);                                     // §F-XL-1: fire the jittered (de-stormed) h_forward stashed in ring slot
    void    rreq_forward_stash(const uint8_t* buf, size_t n);                 // §F-XL-2: stash a built RREQ-forward frame + arm a jittered fire (shared by static + team relays)
    void    rreq_forward_fire(uint8_t slot);                                  // §F-XL-2: fire the jittered (de-stormed) rreq_forward stashed in ring slot
    bool    hash_query_seen_recently(uint8_t origin, uint32_t query_key32, bool hard, bool want_pubkey, bool team_scoped, bool by_id);   // per-(PLANE,origin,KEY,VARIANT) dedup; VARIANT = hard + want_pubkey (§2: a WANT_PUBKEY isn't suppressed by a prior plain HARD); §T6/B: team_scoped = the plane; §S4a: by_id = the KEY SPACE
    void    mark_hash_query_seen(uint8_t origin, uint32_t query_key32, bool hard, bool want_pubkey, bool team_scoped, bool by_id);
    // §id-hash S4a / spec §3-D4: the last bool is `binding_verifiable`, NOT "we answered". It selects the plain vs
    // AUTHORITATIVE answer TYPE, i.e. whether the id->hash assertion in this frame is one the receiver can check.
    // An owner's BY_ID answer passes FALSE: it owns the key, but an id is an address, not a commitment.
    bool    pack_typed_answer_inner(TxItem& item, Plane plane, uint8_t dst,
                                    const uint8_t* body, uint8_t body_len);  // B161: stamp a plane-correct origin and wrap a bounded internal-answer BODY in the canonical plaintext-unicast envelope
    void    send_hash_bind_response(uint8_t to_origin, uint8_t target_layer, uint8_t node_id, uint32_t key_hash32, bool binding_verifiable, bool mobile_proxy = false, uint8_t epoch = 0, bool team_scoped = false); // B: routed DATA(H_ANSWER body) home; §mobile 4a: mobile_proxy -> MOBILE_H_ANSWER TYPE + epoch; §F-TR-2: team_scoped -> route the answer on the TEAM plane (_rt_team + team RREQ), not AUTO (which falls to the static plane when the origin isn't yet a known team peer)
    void    send_hash_bind_pubkey_response(uint8_t to_origin, uint8_t target_layer, uint8_t node_id, const uint8_t ed_pub[32], uint32_t dst_hash = 0, bool team_scoped = false);  // E2E §6: routed DATA_TYPE_AUTHORITATIVE_H_ANSWER_PUBKEY (the owner's ed_pub). Wave 2: dst_hash!=0 (mobile requester) -> DST_HASH so the home last-miles it; §F-TR-2: team_scoped -> TEAM plane
    const uint8_t* host_mobile_ed_pub(uint32_t key_hash32) const;  // §mobile Part 2 Fix 7: the cached ed_pub for a hosted mobile (live direct proxy + has_pubkey), else nullptr
    void    send_mobile_pubkey_answer(uint8_t to_origin, uint8_t target_layer, uint8_t home_id, uint32_t key_hash32, uint8_t epoch, const uint8_t ed_pub[32], bool team_scoped);  // §mobile Part 2 Fix 7 / B161: canonical DATA_TYPE_MOBILE_H_ANSWER_PUBKEY BODY (home routing ‖ the mobile's ed_pub ‖ name) on the originating H-query's plane
    uint32_t cache_want_pubkey_requester(const h_out& h);          // §S3 part2/3: validate + cache a WANT_PUBKEY H's appended requester key (self-consistency + non-zero + the mobile/team id_bind gate), fire peer_key_cached. Returns the requester hash (0 = rejected). Used by the home proxy-answer branch + the mobile TX-free overhear cache.
    void    forward_requester_key_to_mobile(uint32_t mobile_hash, const uint8_t requester_ed_pub[32], const char* name, uint8_t name_len);   // §S3 part2: 1-hop last-mile DATA_TYPE_MOBILE_KEY_FORWARD to a hosted mobile (dedup same-requester via _mobile_reg[].last_key_fwd_hash32)
    // D — send-by-hash trigger (the deferred "address by key_hash32") + verify-on-use.
    uint16_t send_by_hash(uint32_t key_hash32, const uint8_t* body, uint8_t body_len, uint8_t flags, CryptIntent crypt = CryptIntent::def, uint32_t reply_to_hash = 0, uint16_t mobile_ctr = 0, Plane plane = Plane::AUTO, uint8_t type = 0, bool suppress_intro = false, SendDispatch* out_dispatch = nullptr); // §UI-16 N6b: out_dispatch (nullptr = every pre-existing caller) carries the arm's OWN admission fact + the SEND-TIME resolved dst — the return value is still "the ctr if sent immediately, else 0" and is unchanged. // authoritative binding -> send now; soft/unknown -> park + flood (soft binding -> HARD verify). §mobile: reply_to_hash!=0 = the HOME re-originating for its mobile (stamps SOURCE_HASH=mobile hash); reply_to_hash==0 + is_mobile+registered = the mobile ITSELF -> delegate to its home (DATA_TYPE_MOBILE_SEND). mobile_ctr = the mobile's original ctr (ctr_M) -> the ctr_H->ctr_M reverse-ack map (0 = not delegated). §S2: type=0 lets INTRO auto-attach at origination (reply_to_hash==0); type=DATA_TYPE_INTRO = the HOME re-originating an already-prefixed delegated INTRO (no re-attach, threaded to the wire TYPE)
    // §S2: decide + build the INTRO first-contact prefix [ed_pub 32][name_len 1][name] for a plaintext hash-addressed send to dst_hash. Returns the prefix length (33 + name_len), or 0 = no attach (send plain: no identity / sealed intent / already peer_confirmed / cfg off / would overflow the DM body cap — message delivery beats key bootstrap).
    uint8_t  intro_attach_prefix(uint32_t dst_hash, CryptIntent crypt, uint8_t body_len, uint8_t* pfx, uint8_t pfx_cap);
    // §id-hash S4a: `by_id` flips the query KEY SPACE — `query_key32` is then a node/team id ("who owns id N?"),
    // canonical per frame_codec.h. The default keeps the three best-effort callers byte-identical (C1).
    HQueryOutcome emit_hash_query(uint32_t query_key32, bool hard, bool want_pubkey = false, Plane plane = Plane::AUTO, bool by_id = false);   // H flood for query_key32 (hard = verify-on-use; want_pubkey = E2E §6, ask the owner's ed_pub). Wave 2: TEAM => team_scoped + origin=team_local_id (answer routes via _rt_team); GLOBAL => not team-scoped
    // ★ §UI-16 N6b: it RETURNS ITS DISPOSITION now (true = the ParkedSend was STORED; false = the ring was FULL and the
    // send was dropped) — the `emit_hash_query` idiom below, for the same reason: this function had a silent early-out
    // and its callers were reporting it to the app as a parked send. Every pre-existing caller ignores the value.
    bool    park_send(uint32_t key_hash32, const uint8_t* body, uint8_t body_len, uint8_t flags, CryptIntent crypt = CryptIntent::def, uint32_t reply_to_hash = 0, uint16_t mobile_ctr = 0, uint8_t type = 0, bool reflood = false, bool reflood_hard = false, Plane reflood_plane = Plane::AUTO);   // M3: crypt stamped at park so a parked CRYPTED send flies sealed on drain. §mobile: reply_to_hash carried so a parked delegated send keeps the mobile's reply address; mobile_ctr -> the ctr_H->ctr_M reverse-ack map on drain. §S2: type (DATA_TYPE_INTRO) preserved so a parked INTRO re-originates with its TYPE + prefix intact on drain. §F-SL-1: reflood => re-emit the H (hard/plane preserved) on a jittered bounded retry while parked
    void    park_reflood_arm();                                  // §F-SL-1: (re)arm kParkRefloodTimerId to the earliest pending re-flood (cancel if none)
    void    park_reflood_fire();                                 // §F-SL-1: scan parked sends -> re-emit the H for those due (bounded); re-arm
    void    park_send_layer(uint32_t key_hash32, const uint8_t* body, uint8_t body_len, uint8_t flags);   // Slice 4d: a cross-layer-capable park (resolves layer + gateway on the H-answer); flags carry the app's E2E_ACK_REQ etc.
    void    drain_parked_sends(uint32_t key_hash32, uint8_t resolved_id, uint8_t target_layer = 0xFF);   // a binding arrived -> fly the parked DMs to it (target_layer from the H-answer, 0xFF = beacon re-drain / unknown)
    // Slice 4d: cross-layer origination — select a bridging gateway (schedule-verified) + build the CROSS_LAYER DM.
    uint8_t select_gateway_for_leaf(uint8_t target_leaf);        // a gateway (1-hop schedule OR multi-hop _bridged_layers) bridging to target_leaf; 0 = none. Two-pass: routed-preferred, then unrouted fallback (non-const: prunes aged rows)
    // ★ §xl-crypt-intent (2026-07-29): `crypt` is MANDATORY (no default) BY DESIGN — this signature used to end at
    // `type`, so both call sites structurally DISCARDED the per-message crypt intent and a `-e` DM to a mobile whose
    // home sits on another layer went out IN THE CLEAR with no refusal (C2's exact failure class). Making the parameter
    // required means a future caller cannot re-open the hole by omission: it must state on/off/def and the seal-or-refuse
    // decision below is then unavoidable. Param ORDER mirrors do_send (…, flags, crypt, …, type) per U3.
    // ★★ §xl-deleg-ack (BUG FIX 2026-07-30): `override_source_hash` is likewise MANDATORY (no default) and the return
    // type went `void` -> the DM ctr, for the SAME reason applied to a delivery guarantee instead of a confidentiality
    // one. This signature used to end at `type`, so the mobile_home_find arm structurally dropped BOTH halves of the
    // delegation contract its same-layer sibling honours — the mobile's SOURCE_HASH and the ctr_H->ctr_M map entry —
    // and a home re-originating for its hosted mobile toward a target homed on a THIRD layer aired SOURCE_HASH = its
    // OWN key. Consequence on a plaintext DM: the reversed 4e ack addresses the home, is consumed there, and the
    // mobile never sees it. On a DELEGATED SEALED DM it is worse — the mobile sealed under its own hash, so the
    // recipient's directed open runs the ECDH against the WRONG identity, the Poly1305 tag fails, and the DM is
    // dropped with no trace on metal (MR telemetry is sim-only). 0 = nothing flew (next_ctr never mints 0), so a
    // caller can guard its deleg_ack_put on the return exactly as the do_send sites do.
    uint16_t send_cross_layer(uint8_t dst_node, uint32_t dst_hash, uint8_t target_layer, const uint8_t* body, uint8_t body_len, uint8_t flags, CryptIntent crypt, uint8_t type, uint32_t override_source_hash);  // pick G + enqueue, else err_no_gateway (4d.2: park+ROUTE_QUERY); flags honored on the DM. §S2: type (e.g. INTRO) threads to the cross-layer DM's TYPE. want_crypt => the body is SEALED into a DATA_TYPE_SEALED_RELAY (never a cleartext downgrade); a seal failure or an already-TYPED send fails LOUD. §GapB: override_source_hash (!=0) = the delegating MOBILE's hash -> the inner SOURCE_HASH. Returns the DM ctr, 0 = not sent
    // Explicit-path origination (console/companion send_layer, §5): route a cross-layer DM along the user-supplied
    // layer path [our_layer, hops...] cur=1, NO H-query. Returns SYNCHRONOUSLY (no orphan push): CmdCode::queued (+
    // out_ctr = the MAC ctr the app correlates async pushes by), err_no_gateway (no gateway serves hops[0]'s leaf),
    // or err_too_large (the inner overflows). The handler validates the path before calling (hop_count, layer!=0, hops[0]!=ours).
    CmdCode originate_layer_path(uint32_t dst_hash, const uint8_t* hops, uint8_t hop_count, const uint8_t* body, uint8_t body_len, uint8_t flags, uint16_t& out_ctr, uint8_t type = 0, uint32_t override_source_hash = 0);   // §GapB: type (E2E_ACK for a re-originated ack) + override_source_hash (the delegating mobile's hash) thread through to enqueue_cross_layer
    bool    enqueue_cross_layer(uint8_t gw_node, uint32_t dst_hash, const uint8_t* layer_ids, uint8_t n_layers, uint8_t cur, const uint8_t* body, uint8_t body_len, uint8_t flags, uint16_t* out_ctr = nullptr, uint8_t type = 0, uint32_t override_source_hash = 0);  // build the layer-path inner -> next-hop G; honors flags & E2E_ACK_REQ; *out_ctr=ctr on success; false = fit/queue fail. §GapB: type stamps the frame TYPE; override_source_hash (!=0) sets the inner SOURCE_HASH (the delegating mobile) instead of _key_hash32
    void     send_xl_ack(const data_unicast_inner& dm, uint16_t acked_ctr);   // §GapB: a cross-layer E2E-ack = a NORMAL send to (reversed path, dm.source_hash) type=E2E_ACK. STATIC recipient -> enqueue_cross_layer; MOBILE recipient -> delegate_send_layer (never self-originate an XL frame).
#if MR_FEAT_MOBILE
    uint16_t delegate_send_layer(uint32_t dst_hash, const uint8_t* hops, uint8_t hop_count, uint8_t enclosed_type, const uint8_t* body, uint8_t body_len, uint8_t flags);   // §S1: a REGISTERED mobile WRAPS a cross-layer send to its HOME (DATA_TYPE_MOBILE_SEND + CROSS_LAYER path, body prefixed by enclosed_type). Returns the wrapper ctr (0 = no home / invalid). The home unwraps + re-originates via originate_layer_path.
#endif
    void    drain_resolved_parked_sends();                       // beacon-tick re-drain: any parked hash now authoritatively bound
    void    age_out_parked_sends();                              // give up on parked sends past send_defer_ttl_ms
    // Diagnostic `resolve` (CmdKind::resolve): locate a hash WITHOUT sending a DM. Authoritative cache hit (or
    // own hash) -> answer now; else park a notify-only request + flood H. The answer/timeout rides hash_resolved.
    void    request_resolve(uint32_t key_hash32, bool hard);     // the resolve entrypoint (called by on_command)
    void    park_resolve_request(uint32_t key_hash32);           // park a notify-only resolve (de-dups by hash)
    void    push_hash_resolved(uint32_t key_hash32, uint8_t node_id, bool authoritative);  // enqueue the push (node_id 0 = timeout)
    // ★★★ §id-hash S4b (spec §5): the two-stage by-id `reqpubkey`. See the `PendingIdPubkey` ring for the state and
    // node_hashlocate.cpp for each function's reasoning — including why the stage-2 escalation is NOT the auto-resolve
    // `§no-auto-reqpubkey` forbids.
    bool    id_pubkey_intent_arm(uint8_t id, uint8_t plane);     // refresh-or-insert; FALSE = ring full -> the caller refuses BEFORE airtime
    void    id_pubkey_intent_clear(uint8_t id, uint8_t plane);   // undo an arm whose stage-1 frame the TX path then rejected
    void    id_pubkey_intent_consume(uint8_t id, bool team_plane, uint32_t key_hash32);   // an id->hash answer landed: fire stage 2 (spec §5 step 3)
    void    age_out_pending_id_pubkey();                         // periodic (kAgingTimerId, beside age_out_parked_sends): bounded timeout -> loud giveup
    // L2c verify-on-delivery: a DM whose DST_HASH != our key was misdelivered by an id collision —
    // FORWARD it (identity-preserving, not re-originated) toward the real owner of want_hash. The HEAL
    // (renumber) is confirmation-gated: deferred to the HARD-H resolution, fired only when want_hash resolves
    // back to OUR own id (a proven same-id collision) — see design §7.1.
    void    l2c_handle_misdelivery(const PostAck& pa, uint32_t want_hash);
    // ★★★★ §CUSTODY-G (2026-08-31) — **THE RECEIVER FOR `DATA_TYPE_CUSTODY_FAILURE` (0x81)**: design §13's
    //   EIGHTEEN validations, then §7.3's five-step record-BEFORE-push order. Called from `do_post_ack`
    //   (node_mac_rx.cpp) at the position §13 fixes — after EVERY forwarding role, before ordinary DM delivery.
    // ⛔ IT ALWAYS CONSUMES. A valid report is stored + pushed; an invalid one is dropped with the ruled bounded
    //   scalar `custody_failure_reject{type,origin,dst,ctr}` — ⛔ NOT `unsupported_internal`, which would now be
    //   FALSE (0x81 is supported). Either way the frame never reaches `record_dm`, `msg_recv` or an E2E ack.
    // `ui` is `nullptr` iff the standard unicast parse failed (§13.2); the caller owns `become_free()`.
    void    custody_failure_receive(const PostAck& pa, const data_unicast_inner* ui);
    // ★★★★ §remote-admin v2 SLICE 1b (2026-09-06) — **THE TWO CAPABILITY-OWNED PRE-TAIL REMOTE ENTRY POINTS.**
    //   R-RA-8/R-RA-27 item 1, STRICTLY: `REMOTE_CMD` is owned by ACCEPT and `REMOTE_RESP` by CLIENT, and
    //   ⛔ `MR_FEAT_REMOTE_MGMT` WIDENS NEITHER. Each declaration, definition AND consuming call site is compiled
    //   only under its own capability, so a static/gateway image carries no response consumer and a mobile image
    //   carries no command consumer; the un-owned type takes no arm and reaches the fail-closed internal guard.
    // ACCEPT consumes through the target session; CLIENT consumes through the controller pending table.
    // Slice 9 removes the remaining legacy sender, preserving this direction ownership boundary.
    // `ui` is `nullptr` iff the standard unicast parse failed; the CALLER owns `become_free()` (custody's convention).
#if MR_FEAT_RADMIN_ACCEPT
    void    rx_remote_cmd_accept (const PostAck& pa, const data_unicast_inner* ui);   // accept-owned: a REMOTE_CMD for us
    // §remote-admin v2 SLICE 5 — the three private halves of the accept arm. `radmin_build_carriers` derives the
    // REAL request leg and the reversed REPLY leg from the parsed inner (no guessed shape); `radmin_send_reply`
    // is the ONLY transmitter Slice 5 owns (R-RA-31: a bootstrap response and nothing else);
    // `radmin_expiry_arm`/`_fire` are the ONE shared earliest-deadline scan on `kRadminExpiryTimerId`.
    void    radmin_build_carriers(const PostAck& pa, const data_unicast_inner& ui, RemoteRxInput& in) const;
    void    radmin_send_reply    (RemoteRxResult& res);
    void    radmin_report_counters(const RadminCounters& before) const;
    SendDispatch radmin_send_response(uint32_t source_hash, const ReplyRoute& route,
                                      const uint8_t* body, uint8_t len, uint8_t slot, bool bootstrap);
#endif
#if MR_FEAT_RADMIN_ACCEPT || MR_FEAT_RADMIN_CLIENT
    void    radmin_expiry_arm    ();
    void    radmin_expiry_fire   ();
#endif
#if MR_FEAT_RADMIN_CLIENT
    void    rx_remote_resp_client(const PostAck& pa, const data_unicast_inner* ui);   // client-owned: a REMOTE_RESP to our cmd
#endif

    void    l2c_park_redirect(uint32_t want_hash, const PostAck& pa);                 // hold a misdelivered DM for forward-on-resolution
    bool    l2c_enqueue_forward(uint8_t to_id, uint8_t origin, uint16_t ctr, uint8_t ctr_lo, uint8_t flags,
                                uint8_t type, const uint8_t* inner, uint8_t inner_len, const uint8_t nonce_seed[8]);   // fresh ORIGINATOR-budget leg; type/nonce_seed threaded (S1: a typed/CRYPTED redirect keeps them); false = dropped (queue full)
    void    l2c_confirmed_collision(uint32_t want_hash);                              // HARD-H resolved want_hash->our id => key-only heal (called AFTER the drain loop)
    bool    l2c_redirected_recently(uint32_t want_hash);         // one redirect action per hash per window (anti-flood)
    void    l2c_mark_redirected(uint32_t want_hash);
    // node_id auto-assignment (DAD + heal) — node_join.cpp.
    int     join_choose_candidate_id();                          // prefer previous id, else a random free slot (-1 = leaf full)
    uint8_t find_free_mobile_id(uint32_t key_hash32);            // §mobile 2a: host-assign a free LOCAL id, TOP-DOWN 254..17 (0 = pool full; idempotent for a known key); §S0 excludes id_bind/_rt statics; §MH-S2 [[B137]] also excludes LIVE PENDING RESERVATIONS
    void    evict_aliased_hosted_mobile(uint8_t node_id, uint32_t static_key_hash32);   // §S0(b): an authoritative static binding lands for a hosted mobile's local id -> evict the mobile (it re-registers)
    // ★★ §MH-S2 — the keyed pending-OFFER ring's own verbs (node_join.cpp, beside the DISCOVER handler that feeds it).
    // `mobile_offer_admit` PACKS NOTHING: the caller owns the frame (that is where `pack_j_offer`'s inputs live) and
    // hands it the already-packed bytes plus the id it drew, so the ring stays a scheduler and not a second codec.
    MobileOfferAdmit mobile_offer_admit(uint32_t target_key_hash32, const uint8_t* frame, size_t n, uint8_t proposed_id);
    void    mobile_offer_arm_timer();                            // §5.3.3: (re)arm kMobileOfferBackoffTimerId to the EARLIEST pending deadline — armed OFFER or reservation bound (cancel if none). park_reflood_arm / e2e_ack_deadline_arm_timer idiom (U1)
    void    mobile_offer_fire();                                 // §5.3.3: expire elapsed reservations, transmit AT MOST ONE due OFFER, re-arm
    void    mobile_offer_release(uint32_t target_key_hash32);    // [[B137]]: the matching CLAIM arrived (or was refused) -> free the slot + its reservation, re-arm
    int     mobile_offer_slot_of(uint32_t target_key_hash32) const;   // the IN-USE slot keyed by hash, or -1. ⛔ hash, never index (§5.3.2 item 2)
    bool    join_start_claim(const char* reason);                // pick a candidate, bump epoch, broadcast J_CLAIM, arm the guard
    void    join_claim_guard_fire();                             // kJoinClaimGuardTimerId: adopt (no objection) or deny+retry
    void    join_adopt(uint8_t node_id);                         // set_identity + joined + self-bind + beacon
    void    handle_j(const uint8_t* bytes, size_t len, const RxMeta& meta);   // J RX dispatch (CLAIM/DENY; DISCOVER/OFFER later)
    void    addr_conflict_send_deny(uint8_t node_id, uint32_t owner_key, uint32_t claimant_key, uint8_t reason,
                                    bool team_scoped = false, uint32_t team_id = 0);  // owner defends its id; §W2c: team_scoped -> a 19-B team-mediated DENY (team_id-gated at the loser)
    void    forced_rejoin(const char* reason);                   // lost the heal tiebreak -> yield id + re-claim
    // §mobile 2b: the mobile-side registration FSM (node_mobile.cpp). Armed only for _cfg.is_mobile (static never enters).
    // §featuresplit: dropped (with the whole registration FSM) on a static/gateway build; the timer-dispatch cases are gated too.
#if MR_FEAT_MOBILE
    void    mobile_discover_fire();                             // DISCOVER + open the collect-OFFERs window
    void    mobile_claim_guard_fire();                         // window close: pick strongest OFFER -> CLAIM + adopt; else backoff
    // §S6 presence plane (mobile side) — node_presence.cpp. REPLACES the periodic re-CLAIM + layer poll.
    void    presence_probe_fire();                             // kPresenceProbeTimerId: send a probe (jittered/suppressed) or retry; k_miss -> HOME LOST
    void    presence_arm_check(uint32_t delay_ms);             // (re)arm the check timer at now+delay (dynamic T)
    void    presence_ingest_roster(const uint8_t* frame, size_t len, const RxMeta& meta);   // mobile: a roster heard -> refresh/re-register/re-home eval
    void    presence_note_candidate(uint8_t home_id, uint8_t home_layer, int16_t snr_q4);   // §S6.4-C: overheard beacon/roster -> candidate home
    void    presence_mark_incompatible(uint8_t home_id, uint8_t home_layer);   // §D16: mark a candidate home INCOMPATIBLE (wrong wire_version roster) -> FSM B/C skips its DISCOVER
    uint8_t presence_cand_alloc_slot();   // §P2-6: append while room, else evict the STALEST (min last_seen_ms) — never clobber the best candidate (was evict-slot-0)
    void    presence_maybe_rehome();                           // §S6.4-C: sustained-better candidate + dwell -> voluntary re-DISCOVER
    void    presence_on_adopt();                               // called from the mobile adopt path: seed clocks + arm the first check probe
    // ★★★ §MH-S5b-ii §8.3 — **IS THE ALREADY-SCHEDULED STEADY CHECK PROBE ALLOWED TO BE A *SEARCHING* ONE?**
    // §8.3's permitted triggers are a CLOSED LIST OF THREE and this predicate carries **exactly ONE of them today**:
    // trigger 2 (the home missed a check, on the way to `lost`).
    // ⛔⛔ **TRIGGER 1 (the current home's quality is weak or critical) IS IMPLEMENTED-THEN-DEFERRED UNDER [[B178]]**,
    //    measured at −6 unique deliveries (all in `s07`) from the fleet-wide roster storm §8.3 itself predicts.
    //    ★★ **THE LIMITATION THAT LEAVES: a weak but CONSISTENTLY RESPONDING home is never canvassed, so the mobile
    //    changes home only AFTER connectivity begins failing** — a CONSERVATIVE INTERIM POLICY, ⛔ **NOT completed
    //    proactive roaming, and §8.3 is NOT satisfied** (§S6.4-C's *leave a weak home BEFORE loss* is unmet). The
    //    refined trigger that returns, and the [[B177]] fix that must precede it, are spelled out at the definition.
    // ⛔ Trigger 3 (an attributable home-path failure) is NOT here either: it needs a latch, i.e. `Node` state
    // and therefore D2, and it is a separate slice.
    // ⛔⛔ IT IS A *KIND* DECISION, NEVER A *CADENCE* ONE. Nothing here schedules, re-arms or adds a probe: the
    //    caller is `presence_probe_fire`, already on its own deadline, and the frame it packs is the same 8 B
    //    either way (`selected_home_id` is present in every probe; only its VALUE changes). That is what keeps
    //    §8.3's airtime hole shut on the mobile's own transmissions — gate 27.
    // ⓘ DERIVED, not stored: `sizeof(Node)` is unmoved by this slice (gate 5 / D2).
    bool    presence_searching_probe_due() const;
#endif
    // §S6 presence plane (home side) — always compiled (a home is a static); host-gated (dormant on a non-host).
    void    presence_ingest_probe(const uint8_t* frame, size_t len, const RxMeta& meta);   // home: a probe heard -> refresh registry + SNR EWMA + custody; schedule a coalesced roster
    void    mobile_reg_touch(uint8_t slot, int16_t snr_q4);    // §3-D: refresh a hosted mobile's last_heard_ms + step its per-mobile SNR EWMA. ★ §B177-FIX (ledger §1.16) — CORRECTED IN PLACE: this used to read "ONE path shared by the probe (node_join) + beacon (node_beacon) sites"; the BEACON caller is REMOVED, so the ONE remaining caller is `presence_refresh_hosted_row` (both P-probe arms, each gated on host_row_probe_refreshable). NOT used by CLAIM (which SEEDS a fresh slot, not EWMA-updates).
    // ★★★ §MH-S5b — **ONE "A PROBE FROM THIS HOSTED MOBILE ARRIVED" REFRESH, read by BOTH probe arms.** It is
    // `mobile_reg_touch` (last_heard_ms + the SNR EWMA) PLUS §S6 A.4 key custody, which is exactly what the
    // selected-check arm already did inline. §MH-S5b needs the identical refresh on the SEARCHING arm (item 2), and
    // U1 says extend the one path rather than fork a second copy — a forked custody check is precisely the
    // field-drop rot U1 names. ⛔ The extraction is BYTE-INERT for the pre-existing caller (same two effects, same
    // order); only the new call site changes behaviour.
    void    presence_refresh_hosted_row(uint8_t slot, const p_probe_out& p, int16_t snr_q4);
    // ★★★ §MH-S5-FIX [[B172]]/[[B173]] + §MH-S5-FIX2 (owner-ruled) — **THE ONE "LIVE DIRECT HOSTED ROW" PREDICATE.**
    // A registry row's identity is the whole tuple `(hash, local_id, direct-vs-redirect, live-vs-expired)`, and matching
    // `hash` alone is the defect both slices closed. `redirect_home_id != 0` means the mobile lives at ANOTHER home and
    // this row is only a breadcrumb, so spec §9.2's *"redirect rows never reserve last-mile service or advertise as
    // directly hosted"* and §9.1's *"an expired row is absent from rosters and coverage accounting"* are the SAME
    // question — asked here, and nowhere else. §9.3: *"do not duplicate age predicates at each consumer"*, which is why
    // the arithmetic is spelled ONCE and `mobile_reg_age_out()` tests the same helper.
    //
    // ★ THE TEN CONSUMERS, and exactly what each one excludes (both kinds — redirect AND expired — at every one).
    //   §MH-S5-FIX landed the first four; §MH-S5-FIX2 added the rest on the owner's *"consistently to every service
    //   path"* ruling, so a locally-originated send, a forwarded send and a delegation now agree about one boundary:
    //   · `presence_emit_roster`            (node_join)       — an excluded row is not ADVERTISED as directly hosted;
    //   · the host last-mile FORWARD        (node_mac_rx)     — no re-addressed 1-hop delivery of a routed DM;
    //   · `flood_set_my_coverage`           (node_channel)    — contributes NO coverage bit;
    //   · `flood_any_unmarked`              (node_channel)    — never DEMANDS a re-flood;
    //   · the `DATA_TYPE_MOBILE_SEND` OWNERSHIP scan (node_mac_rx) — no upstream DELEGATION on its behalf;
    //   · the `send_by_hash` direct last mile (node_hashlocate) — the LOCALLY-originated twin of the forward above;
    //   · `forward_requester_key_to_mobile` (node_hashlocate) — no last-mile key push;
    //   · `host_mobile_ed_pub`              (node_hashlocate) — no *"here is my hosted mobile's key"* answer;
    //   · the team-key-grant pre-check      (node.cpp)        — its whole job is to PREDICT the send path above;
    //   · `presence_mark_deleg_fail`        (node_join)       — refuses a one-shot no roster could ever carry.
    //
    // ⓘ **NON-MUTATING BY DESIGN, and that is the [[B173]] answer.** The alternative was to de-const the two coverage
    //   readers so they could run the compaction sweep; a flood-coverage predicate that silently deletes registry rows
    //   is a worse contract than a pure test. Physical compaction stays with `mobile_reg_age_out()` (the aging timer +
    //   §9.3's two decision points); what changes here is that a row PAST the boundary is refused IMMEDIATELY by every
    //   consumer instead of up to one 60-second sweep later.
    // ★★★ §MH-S5-FIX2 — **CORRECTED IN PLACE 2026-08-10 (owner-ruled; ledger §1.14). THE INSTRUCTION THAT STOOD HERE
    //   IS WITHDRAWN.** It read: ⛔ *"NOT the same question as the bare `redirect_home_id == 0` tests in
    //   `node_hashlocate.cpp` (`host_mobile_ed_pub`, `forward_requester_key_to_mobile`, the send_by_hash last-mile) and
    //   `node.cpp`'s grant pre-check … ⇒ Do not mechanically fold them in here."* (kept as the audit trail, per the
    //   owner-rulings ledger §3 rule 3 — ⛔ a WITHDRAWN quote, never a live claim).
    //   **It was wrong twice.** (a) The owner ruled the boundary applies to EVERY hosted/last-mile SERVICE path, so it
    //   IS the same question at all four of those sites, and all four now read this predicate (see the list above).
    //   (b) *"paths this slice never measured"* was a reason to measure them, not a reason to diverge; the
    //   half-and-half state it produced is what §MH-S5-FIX was corrected for.
    // ⛔⛔ WHAT IS **NOT** FOLDED IN, and must never be: the **hash-location REDIRECT ANSWER**
    //   (`node_hashlocate.cpp` `handle_h`, the `redirect_home_id != 0` fork). The ruling is about SERVICE; a redirect
    //   row's whole remaining job is to be followable, so that fork is deliberately **not** liveness-gated. A positive
    //   control (`test_node_join.cpp`) turns RED if a filter ever leaks into it — over-fixing is the live risk here.
    // ⓘ The DIRECT proxy arm beside it keeps its own inline `now - last_heard_ms < mobile_liveness_ms` (the exact
    //   complement of `host_row_expired`), which is what makes the WANT_PUBKEY caller of `host_mobile_ed_pub`
    //   structurally already-gated; the gate there is redundancy, not a new exclusion.
    // ⓘ Bounds are CALLER-checked (the `mobile_reg_touch` idiom): every consumer loops `i < _mobile_reg_n`.
    bool    host_row_live_direct(uint8_t i) const {
        return _active->_mobile_reg[i].redirect_home_id == 0 && !host_row_expired(i, _hal.now());
    }
    // ★★★★ §B177-FIX (owner-ruled 2026-08-11, ledger §1.16) — **THE ONE "MAY A P PROBE REFRESH THIS HOSTED ROW?"
    // PREDICATE, READ BY *BOTH* PROBE ARMS.** With the beacon touch removed (`node_beacon.cpp`) the P probe is the SOLE
    // ongoing authority over `last_heard_ms` and the per-mobile SNR EWMA, so the two arms must agree about which row
    // they are allowed to refresh — and before this they did not: §MH-S5b's SEARCHING arm carried `host_row_live_direct`
    // + the low-byte epoch match, while the older SELECTED arm found the row by **hash alone** and refreshed it with
    // neither term. `sel_me` proves only that the probe names *us* as home; it says nothing about row kind, freshness or
    // generation. ⇒ the tuple is asked ONCE, here, and never re-spelled at a call site (the [[B147]]/[[B172]]/[[B174]]/
    // beacon-touch lesson: a predicate copied is a predicate that drifts).
    // · `host_row_live_direct` — a REDIRECT row's clock belongs to the BREADCRUMB (§9.2) and an EXPIRED row gets no
    //   service before compaction (ledger §1.14); refreshing either RESURRECTS a row this arc made mortal.
    // · the **epoch** — the low byte, deliberately: that is the width the P wire carries (`frame_codec.h` P-probe byte 7,
    //   present on EVERY probe — check and searching alike) and the same arithmetic `presence_ingest_roster` uses at the
    //   mobile end. The mobile bumps `_my_mobile_reg.epoch` on every fresh CLAIM (`node_mobile.cpp`) and the home
    //   overwrites the row's epoch from the CLAIM it accepts (`node_join.cpp`), so a row from BEFORE a re-home cannot
    //   match, and a matching pair is the same registration generation on both sides.
    // ⓘ Bounds are CALLER-checked, the `mobile_reg_touch` idiom (every consumer loops `i < _mobile_reg_n`).
    bool    host_row_probe_refreshable(uint8_t i, uint8_t probe_reg_epoch) const {
        return host_row_live_direct(i)
            && static_cast<uint8_t>(_active->_mobile_reg[i].epoch) == probe_reg_epoch;
    }
    // The AGE half alone. `mobile_reg_age_out()` expires BOTH kinds at this boundary, so it cannot use the predicate
    // above (which excludes redirects) — it uses THIS, so the two can never disagree about where the boundary is.
    bool    host_row_expired(uint8_t i, uint64_t now) const {
        return (now - _active->_mobile_reg[i].last_heard_ms) >= protocol::mobile_liveness_ms;
    }
    // ★★★ §MH-S5 §9.3 — the ONE removal primitive (row + EVERY parallel array) and the 25-minute deadline scan
    // that drives it. Contract + the declined-alternative record live at the definitions in `node_join.cpp`.
    // ⛔ `mobile_reg_age_out()` allocates NO timer id — `TimerWheel::kCap` stays 91 (asserted, gate 16).
    void    mobile_reg_remove(uint8_t slot, const char* reason);   // compact `_mobile_reg` + `_mobile_snr_q4`; the caller owns any roster consequence
    void    mobile_reg_age_out();                              // §9.1/§9.2: physically expire direct AND redirect rows at `mobile_liveness_ms`
    void    presence_roster_fire();                            // kPresenceRosterTimerId: emit ONE coalesced roster
    void    presence_schedule_roster();                        // arm the coalesce timer (rate-limit floored)
    void    presence_mark_deleg_fail(uint32_t mobile_hash);    // §B2: a delegated send for this hosted mobile failed loud -> set the roster deleg_fail bit + schedule a roster
    void    presence_emit_roster();                            // build + LBT-broadcast the roster from _mobile_reg + tiers + has_key + dir_epoch
    // ★ §MH-S1 §6.2: the host's staged OFFER reached its jitter deadline and the TRANSMITTER refused it
    // (full defer ring / HAL refusal). ⚠ NOT `#if MR_FEAT_MOBILE`-gated, deliberately: a HOME IS A STATIC
    // NODE, so this path is compiled on every build that can host (the timer-80 arm beside it is likewise
    // outside that guard). Spec §6.2 offers two fates for a definitively-rejected entry — reschedule with
    // a bounded new deadline, or REPORT AN EXPLICIT DROP so the source mobile's own retry is the backstop.
    // ⛔ S1 takes the SECOND, because the first needs a fresh bounded-jitter draw and **S3 is the only
    // planned RNG re-anchor in this arc**; a draw here would destroy that attribution. The reschedule is
    // therefore owed to S2/S3, which own the keyed ring the new deadline would live in.
    // ★★ §MH-S3: NOT OWED AFTER ALL — the two fates are ALTERNATIVES in §6.2's own wording, and the drop
    // branch is now taken in full (event + [[B146]] counter + [[B137]] reservation retained). S3 declined
    // to spend a draw here; the ruling and its reasoning are at the function in `node_join.cpp`.
    void    mobile_offer_admission_rejected(TxAdmission why);
    void    mobile_host_pending_clear();                       // ★★ §B132b: drop EVERY leaf's PENDING mobile-host transmission (the staged J OFFER + the roster coalesce/echo state) and cancel their timers. Shared by on_init's gateway force-off (hygiene) and by the OFFER timer's own eligibility re-check (the guarantee), so the two can never disagree.
    void    presence_notify_old_home(uint32_t mobile_hash, uint8_t new_local_id, uint16_t new_epoch);  // §S6.4-D: NEW home originates the redirect breadcrumb to the stashed last_home
    uint8_t presence_compute_dir_epoch() const;               // §S6/D6: XOR aggregate of known gateway dir_epochs (a gateway derives its own layer-set epoch)
    // §mobile 6.4: team-DAD — a team member self-assigns a persistent _team_local_id on the team plane (no static host).
#if MR_FEAT_TEAM
    int     team_dad_choose_candidate_id();                    // a free team id (not a _team_peer / _rt_team dest / our current), 17..254; -1 if full
    void    team_dad_guard_fire();                            // guard-window close -> confirm _team_local_id (team_dad_adopted)
#else
    int     team_dad_choose_candidate_id() { return -1; }
    void    team_dad_guard_fire() {}
#endif
public:
#if MR_FEAT_TEAM
    void    team_dad_fire();                                  // (re-)pick + tentatively claim a _team_local_id + arm the guard (public: handle_team / tests)
#else
    void    team_dad_fire() {}
#endif
private:
#if MR_FEAT_MOBILE
    // §autoregister ruling (2026-07-21): the SINGLE gate on the DISCOVER/registration half of the FSM. autoregister ON =
    // autonomous. OFF = the app drives attachment via `mobile register`; absent a request the mobile NEVER
    // DISCOVERs/registers — after a home-loss it stays off-grid-quiet (the team plane still works per F-PS-1, and
    // team-DAD runs regardless as it rides the FSM tick BEFORE this gate).
    // ★★ §MH-S4 §4.2 — `registration_armed()` AND `mobile_service_desired()` ARE THE SAME PREDICATE, and they
    // are two names on purpose, because they read two different sentences at their call sites:
    //   · `registration_armed()`      — "may the DISCOVER/registration half run at all?" (the one FSM entry gate)
    //   · `mobile_service_desired()`  — "does this node want a home service AT ALL?", the §4.2 rule that
    //     confirmation, presence checks, candidate monitoring, proactive re-home and home-loss recovery
    //     continue INDEPENDENTLY OF THE INITIAL-AUTO FLAG once a session was explicitly started. Every site
    //     that used to arm a follow-up timer on `_cfg.mobile_autoregister` ALONE now asks this instead —
    //     otherwise a manually-attached mobile got no presence plane at all, and gate 10 ("presence monitoring
    //     and weak-home candidate canvass run after a manual attach with auto OFF") could not pass.
    // ⛔ NOT consumed, unlike the retired `_mobile_arm_once`: a durable request is the whole point (§4.2).
    // ★★★★ §MH-S4b — **`_mobile_home_desired` IS THE EFFECTIVE SESSION STATE, AND IT IS THE WHOLE PREDICATE.**
    // §MH-S4 wrote these two as `_cfg.mobile_autoregister || _mobile_home_desired`, which made `mobile unregister`
    // INTERNALLY CONTRADICTORY on the only kind of device most fleets ship: with `mobile_autoregister` ON the verb
    // set the attachment plane to `dormant` while BOTH predicates stayed TRUE, so §4.3's stated post-condition
    // ("end the current volatile attachment session and return to `dormant`") was true of one member and false of
    // the machine. Nothing scheduled a replacement DISCOVER either, so the device was neither dormant nor seeking —
    // it was inert until something else happened to arm a timer, and §MH-S4's own test had to INJECT the timer the
    // verb had just cancelled in order to observe autonomy resume. ⚠ A test that injects the very timer production
    // would have to schedule is a harness modelling something that does not exist ([[B145]]'s hand-pumped callbacks,
    // [[B143]]'s call-history-as-state).
    // ⇒ ONE state answers "is a home-service session live?", it is INITIALISED FROM `mobile_autoregister` at
    //   `on_init` (§4.2: "`true`: boot enters `seeking` automatically"), and both predicates read it DIRECTLY.
    //   `mobile unregister` therefore suppresses attachment until a manual `mobile register` or a reboot — which is
    //   §4.2's sentence, now expressible.
    // ⓘ `mobile_autoregister` keeps its field, its JSON key and its meaning (§4.2 compatibility): it is the BOOT
    //   POLICY, read once. ⛔ It is deliberately NOT re-read afterwards — §4.2: "once an attachment session was
    //   explicitly started, … continue INDEPENDENTLY of this initial-auto flag." Turning the flag OFF at runtime
    //   must not end a live session; only `mobile unregister` does. (Turning it ON at runtime is an explicit
    //   request for home service and `cfg set` routes it through `mobile_register_current()` — src-side, so the
    //   corpus cannot reach it.)
    // ⓘ CORPUS-INERT BY CONSTRUCTION, and the reason CHANGED with the shape, so it is restated rather than
    //   inherited: `_mobile_home_desired` is now seeded from `_cfg.mobile_autoregister` at `on_init` and is
    //   written afterwards ONLY by the `mobile register`/`unregister` console entries, which the simulation
    //   harness cannot drive (s29's own `_desc` records this) ⇒ in every corpus scenario this predicate holds
    //   `_cfg.mobile_autoregister`'s value from `on_init` to the end of the run, bit for bit.
    bool    registration_armed()     const { return _mobile_home_desired; }
    bool    mobile_service_desired() const { return _mobile_home_desired; }
    void    mobile_request_home_service();                     // §4.2/§4.3: set home-service desired + enter `seeking` (idempotent while already seeking/claiming)
    void    mobile_reset_registration(const char* reason);     // drop registration -> re-enter discovery
    // ★★★ §MH-S4 §7.1 steps 5-6 — THE SAME-EPOCH RE-CLAIM. `presence_claim_max_retries` had ZERO consumers
    // before this slice (measured by grep, and by the §S0-4 characterization case observing that no second
    // CLAIM ever reached the air). These two functions are its consumers:
    //   · `mobile_reclaim_send()`      re-sends THE SAME CLAIM — same chosen host, same local id, SAME EPOCH —
    //     rebuilt from the retained `_mobile_offers[0]` stage (U2: one carrier, no second copy of the offer).
    //   · `presence_claim_unconfirmed()` is the ONE decision point for both §7.1 triggers, because §7.1 step 6
    //     says silence follows THE SAME BOUNDED COUNT as a roster that omits us: spend a retry if the budget
    //     allows, else RESET AND RETURN TO `seeking` rather than remaining falsely registered.
    // ★★★★ §MH-S4b — IT RETURNS **WHETHER THE FRAME WAS ADMITTED BY OUR OWN TRANSMITTER**, and that return value
    // is the only thing allowed to spend a re-CLAIM. §MH-S4 incremented `_mobile_claim_retries` on the line BEFORE
    // this call, so a mobile whose radio refused all three retries reported `claim_unconfirmed` with NOT ONE
    // re-CLAIM ever on the air — the fifth appearance in this arc of one rule: ★ **A BUDGET IS SPENT BY THE
    // PHYSICAL ACT, NEVER BY THE REQUEST** ([[B84]]'s `_tries`, [[B145]]/[[B146]]'s OFFER counters, [[B139]]'s
    // `_presence_miss`, now this).
    // ⛔ THE BOUNDARY, AND IT IS THE SAME ONE [[B139]] HAD TO GET RIGHT: `tx_initiating` answers **true** for a
    //    frame merely ACCEPTED INTO the LBT defer ring (`node_mac.cpp` sets `*out = deferred` and returns queued).
    //    A deferred re-CLAIM legitimately IS in flight and MUST be counted. Only a DEFINITIVE refusal — a full
    //    defer ring or a HAL rejection, i.e. `false` here — is excluded. The one remaining case is a frame that was
    //    deferred (counted) and then refused by the HAL when the defer fired: it never reached the air, so it is
    //    REFUNDED, by `mobile_reclaim_deferred_rejected()` below and nowhere else.
    bool    mobile_reclaim_send();
    void    presence_claim_unconfirmed(const char* why);
    // ★★★ §MH-S4b — the DEFERRED half of the rule above. Called from node.cpp's `tx_deferred_lost` arm for
    // `LbtKind::mobile_claim`. Answers TRUE iff the dead frame was a RE-CLAIM, in which case it refunds the
    // retry and the caller must NOT fall into `mobile_admission_rejected` (that is the PRE-attachment FSM's
    // backoff, and a `claiming` mobile is past it). ⓘ It identifies the transaction BEFORE acting on it
    // ([[B147]]): a FIRST CLAIM still holds `_mobile_claim_pending` — only `mobile_claim_adopt` clears it and
    // this frame never reached it — while a re-CLAIM is sent with the flag deliberately FALSE from an already
    // provisionally-attached, `claiming` node.
    bool    mobile_reclaim_deferred_rejected();
    // ★★ §MH-S1 §6.1/§6.3/§6.4 — the ONE handler for "OUR transmitter refused an attachment frame",
    // shared by the DISCOVER and the CLAIM site (U1: one discipline, not two). It does exactly three
    // things and deliberately no more:
    //   1. records `why` as the last attempt result (§10) — ⛔ NEVER `mobile_no_host`, which would blame
    //      a home that was never asked, and ⛔ never a home-link state (gate 20: `_my_mobile_reg` and
    //      `_presence_*` are not touched here, by construction);
    //   2. ⚠ §MH-S4 §4.2 — STEP 2 IS GONE, and its DISAPPEARANCE is the fix, not a regression. It used to
    //      re-arm `_mobile_arm_once` "because the attempt never happened", i.e. it patched up a one-shot the
    //      FSM had already eaten. `_mobile_home_desired` is DURABLE, so there is nothing to restore: the
    //      retry in 3 is authorised for as long as the operator's request stands. The old restore is also why
    //      the retry below had to be documented as "unconditional on mobile_autoregister"; it now simply
    //      services `mobile_service_desired()`, which is the honest condition;
    //   3. arms a BOUNDED retry (gate 6) on kMobileDiscoverTimerId.
    // ★★ §MH-S3 §5.2 — STEP 3 NOW DRAWS, and this note is the record of S1's marker being HONOURED rather
    //    than left to rot. S1 wrote here "⛔ DRAW-FREE BY CONSTRUCTION: the retry delay is the existing
    //    `mobile_offer_window_ms` constant, not `rand_range` … jittering this retry is S3's, and is marked
    //    so at the call site." S3 is that slice: the delay is now `mobile_equal_jitter(mobile_offer_window_ms)`
    //    = rand(1000, 2001). ★ IT IS THE SAME FAILURE MODE §5.2 NAMES: a fleet whose transmitters all refuse
    //    on one busy channel used to retry in lockstep at exactly 2000 ms and storm the channel again.
    void    mobile_admission_rejected(TxAdmission why, const char* site);
    // ★★ §MH-S3 §5.2 — THE ONE MOBILE-SIDE EQUAL-JITTER DRAW SITE (U1: three callers, one discipline, one
    // place to read the contract). Consumes EXACTLY ONE `rand_range` and returns a delay in
    // [window/2, window]. The bounds themselves are the pure `protocol::equal_jitter_*` pair, so they are
    // unit-testable without a Hal. ⛔ Every caller must be a MOBILE-plane path — this is the draw whose
    // absence keeps the static plane byte-identical (C3), and it is why s18 is S3's inertness proof.
    uint32_t mobile_equal_jitter(uint32_t window);
    // ★★ §MH-S1b §6.3 — THE ADOPT HALF OF THE CLAIM ADMISSION BOUNDARY. Split out of
    // `mobile_claim_guard_fire` verbatim so it can be called from `lbt_complete` at the accepted handoff
    // instead of at the request. On a clear channel that is the SAME instant (lbt_complete is entered
    // synchronously from tx_initiating, and the adopt used to run on the statement after it returned), so
    // the immediate path's Hal-call sequence is unchanged; on an LBT defer it is seconds later, which is
    // exactly the "success that isn't" being closed — the mobile no longer registers at a home whose CLAIM
    // is still sitting in the defer ring and may yet be refused by the HAL.
    // ⚠ It reads `_mobile_offers[0]` and is a NO-OP unless `_mobile_claim_pending` — a fresh DISCOVER
    //   clears both, which abandons a stale deferred CLAIM rather than adopting from a clobbered slot.
    // ★★★ [[B142]] 2026-08-07 — AND THAT BOOL IS NO LONGER THE CORRELATOR, because it never could be: it is
    //   GLOBAL and carries no attempt identity, so once a fresh DISCOVER had RE-staged slot 0 the flag was
    //   true again and a stale deferred CLAIM adopted the NEW candidate. The reach here is now gated one
    //   level up, in `lbt_complete`, by `completion_gen != _mobile_attach_gen` — i.e. by transaction identity.
    //   The bool remains as the "is anything staged at all" test it always honestly was.
    void    mobile_claim_adopt();
    // §mobile 5a: the scan-set = [the mobile's own/bootstrap PHY] ∪ [the LEARNED layer directory]. On boot (nothing learned)
    // that's just layers[0] -> single-PHY = 2b-identical; neighbours appear only after a successful directory pull.
    uint8_t scan_set_count() const { return static_cast<uint8_t>(1 + _learned_layers_n); }
    LayerConfig scan_phy(uint8_t idx) const {                  // BY VALUE (a learned record is synthesized into a LayerConfig); idx 0 = own layer, 1..n = learned
        if (idx == 0 || _learned_layers_n == 0) return _cfg.layers[0];
        const LayerRecord& r = _learned_layers[(idx - 1) % _learned_layers_n];
        LayerConfig c{}; c.layer_id = r.layer_id; c.routing_sf = r.sf;
        c.freq_mhz = static_cast<double>(r.freq_khz) / 1000.0; c.bw_hz = r.bw_hz;
        c.allowed_sf_bitmap = static_cast<uint16_t>(1u << r.sf);   // the learned control SF as the DATA-SF set
        return c;
    }
    void    adopt_mobile_phy(const LayerConfig& phy, bool retune_radio = true);   // §mobile 5a: adopt the host's PHY (config scalars leaf/sf_list ALWAYS; radio retune only when retune_radio — single-PHY is already tuned)
    void    mobile_layer_query_fire();                         // §mobile 5a: pull the layer directory from a gateway (armed while registered)
    int     nearest_bridging_gateway();                        // §mobile 5a: a bridging gateway we can route to (learned type-4 TLV), or -1
    void    learned_layers_ingest(const uint8_t* body, size_t len);   // §mobile 5a: parse [count][record…] -> upsert _learned_layers (dedup, TTL, evict-oldest)
#endif
    // §mobile 3b/4: stamp a fresh outbound TxItem's origin + self-mark. A REGISTERED MOBILE bills its home_node (an
    // accountable GLOBAL id; the mobile's E2E identity still rides sender_hash) and self-marks (mobile_src -> the host
    // keeps our local-id out of the global rt, Fix 2). A static/host node = _node_id, unmarked (byte-identical).
    // ★★ §team-parity T6 (spec §3/T6, OWNER-RULED §11 2026-07-28): ONE ORIGIN NAMESPACE PER PLANE. A TEAM-plane flight
    // stamps our team_local_id(); a static/global flight keeps the pre-T6 home_id-or-node_id rule verbatim. Before T6 the
    // namespace depended on how the SENDER happened to be attached — an OFF-GRID member stamped its team id only because
    // node_id == team_local_id there, while a HOMED member stamped its HOME's STATIC id (measured live: s28 node 3 and s29
    // node 3 both aired origin=101 on a `-t` DM). Consequences that were MEASURED on 2026-07-28, not reasoned:
    //   • the acking teammate takes `origin` as its ack destination, so a homed member's team `-a` addressed the HOME on
    //     the STATIC plane — 1.77 s and correct WHEN static infrastructure was reachable (a plane crossing that violates
    //     R3, "team-internal routing only"), and FOUR static-plane RREQ floods for the home's id then
    //     send_failed{e2e_ack_timeout} when it was not — the bench's own leaf-4-vs-leaf-7 shape;
    //   • T2's DATA-origin learn had to be fenced by is_team_peer(origin) (node_mac_rx.cpp:694) because "is this origin a
    //     team id?" was undecidable. T6 makes it decidable; relaxing that fence was NOT folded in here (C1).
    //     ✔ 2026-07-28: §team-parity T7 has since REMOVED that fence, re-measuring this function's effect first — over
    //     all 36 scenarios every plain-DM team-plane origin is now inside the team id space, so the ✖ MISSING half of
    //     that site's note (the §0 bench case) is closed. This block is T7's premise; do not weaken it without re-reading
    //     the soundness note at that site.
    // Anti-spam accountability on the team plane moves from the home to the member, DELIBERATELY (the §11 ruling).
    // ⚠ `team_local_id() != 0` is a hard precondition, not caution: a member whose team-DAD is still pending has
    // _team_peer bits set (node_beacon.cpp:776 does not require our own id) while team_local_id() is still 0, and
    // stamping origin 0 would air the reserved sentinel. It falls back to the pre-T6 expression there. `send -t` is
    // already refused loud in that window (node.cpp:1138); an AUTO send to a team peer is not — MISSING, deferred,
    // because refusing it is a new loud failure on a path that works today (C1/C2 both point away from folding it in).
    // Static reduction: flight_is_team_plane() is false for every static node (is_team_peer stubs/reads false when
    // team_id==0) and for every GLOBAL send, so the expression reduces to the pre-T6
    // `mob ? _my_mobile_reg.home_id : _node_id` VERBATIM. Build profiles: the team arm is MR_FEAT_TEAM-gated and
    // flight_is_team_plane() itself returns a compile-time false on the three gateway_* envs (MR_FEAT_TEAM 0).
    // `dst` is passed rather than read from item.dst because every caller assigns item.dst AFTER this call — passing it
    // keeps that order untouched (no reorder risk across the five call sites) and makes the plane decision explicit.
    void    stamp_origin(TxItem& item, Plane plane, uint8_t dst) const {
#if MR_FEAT_MOBILE
        const bool mob = _cfg.is_mobile && _my_mobile_reg.active;
#if MR_FEAT_TEAM
        if (flight_is_team_plane(plane, dst) && team_local_id() != 0) {
            item.origin     = team_local_id();   // the id EVERY teammate can route (node_mac.cpp:70's invariant, now true)
            item.mobile_src = mob;               // unchanged: the wire mark is `pt.mobile_src || team_next` (node_mac.cpp:817)
            return;
        }
#else
        (void)plane; (void)dst;
#endif
        item.origin = mob ? _my_mobile_reg.home_id : _node_id;
        item.mobile_src = mob;
#else
        (void)plane; (void)dst;
        item.origin = _node_id;   // §featuresplit: a static/gateway node never bills a home — always self-origin, unmarked
        item.mobile_src = false;
#endif
    }
    void    join_deny_id(uint8_t id);                            // add to the denied list (1-day TTL)
    bool    join_id_denied(uint8_t id) const;                    // is this id currently denied (not expired)?
    void    age_out_denied_ids();                                // drop denied entries past dad_denied_id_ttl_ms
    bool    mediated_recently(uint8_t node_id, uint32_t loser_hash) const;  // L2a: did we already DENY this (id,loser) this window?
    void    mark_mediated(uint8_t node_id, uint32_t loser_hash);            // L2a: record a sent mediated DENY
    void    age_out_mediated();                                             // drop mediation records past the suppress window
    // Q REQ_SYNC plane (boot route-bootstrap) — node_query.cpp.
    void    req_sync_loop_fire();                                  // kReqSyncTimerId: send + re-arm while discovery+starved (dv:9167)
    void    send_req_sync_q(const char* reason, bool force = false, bool team_plane = false);  // broadcast a REQ_SYNC Q (no draw; dv:8032). force=bypass boot-flag+route-rich guards (reactive route-miss pull). §team-parity T0: team_plane is INERT — no caller passes true until T4
    void    send_config_pull(uint8_t to, uint16_t lineage, uint16_t epoch);  // R6.2: 1-hop CONFIG_PULL to a heard member
    void    send_c_config(uint8_t to);                            // C frame (cmd 0xB): control-plane answer to a CONFIG_PULL carrying OUR leaf config (an empty-sf_list joiner CAN receive it)
    void    handle_c(const uint8_t* bytes, size_t len, const RxMeta& meta);   // C RX dispatch (cmd 0xB) -> adopt if addressed to us on our leaf
    void    adopt_c_config(const uint8_t* body, size_t len);      // adopt a pulled config (cfg + recompute + persist Push); lineage from the last-heard beacon
public:
    bool    leaf_config_write();                                   // R6.3 §4.1: operator config write -> epoch=max_seen+1 + re-advertise (managed only)
private:
    void    handle_q(const uint8_t* bytes, size_t len, const RxMeta& meta);   // Q RX dispatch (dv:11767)
    void    schedule_sync_response(uint8_t requester, bool requester_mobile, bool team_plane); // jittered full-table reply (the backoff DRAW; dv:8064)
    void    sync_response_fire(uint8_t slot);                      // kSyncResponseTimerId+slot: emit_beacon("sync") unless suppressed
    bool    q_responded_recently(uint8_t opcode, uint8_t src, uint8_t dest);  // q_responded_to dedup (ttl q_respond_ttl_ms)
    void    mark_q_responded(uint8_t opcode, uint8_t src, uint8_t dest);      // refresh/append (evict-oldest; dv:11778)
    // Channel-message gossip plane (ROADMAP §3) — node_channel.cpp. Phase 1: buffer + origination + DATA-M ingest.
    // Single-layer; gateways skip (Principle 11). seen_by is a 256-bit bitmap (neighbour id -> bit) so the
    // safe-eviction cover-check is O(neighbours). Struct defs here so they precede both the decls + the state.
    struct ChannelEntry {
        uint32_t id;                 // channel_msg_id: origin<<24 | (key_hash32&0xffff)<<8 | ctr
        uint8_t  channel_id;
        uint8_t  flavor;
        uint8_t  origin;             // == (id >> 24): the minting node
        bool     dirty;              // advertise in the BCN digest until bcn_ad_count hits K (Phase 2)
        uint8_t  bcn_ad_count;
        uint64_t received_at;
        uint8_t  seen_by[32];        // 256-bit set of neighbours known to hold this msg (eviction safety)
        uint16_t payload_len;
        uint8_t  payload[protocol::channel_msg_max_payload_bytes];
        uint32_t team_id = 0;        // §mobile 6.3: 0 = a normal leaf channel message; !=0 = a team-scoped message (flavor has channel_flavor_team). Re-emitted on gossip/re-broadcast.
    };
public:
    // Public so native tests can inspect the per-origin channel ledger directly (like channel_buffer_count()).
    struct ChannelOriginEvent  { uint32_t id; uint64_t t_ms; };
    struct ChannelOriginLedger {
        ChannelOriginEvent ev[protocol::cap_channel_origin_events];   // MF7: sized by the new const
        uint8_t  n = 0;
        uint64_t last_flood_ms = 0;   // Slice 2: per-origin last admitted flood — the channel_min_interval_ms burst floor
    };
private:
    // Channel FLOOD in-progress state (2026-06-08 redesign). One slot per concurrent flood mid-backoff;
    // slot i owns rebroadcast timer kFloodRebcastTimerId+i. active while awaiting_data (overhear) OR while
    // its rebroadcast timer is armed; freed on fire / coverage-cancel / no-unmarked / anti-spam drop.
    struct FloodState {
        bool     active = false;
        bool     awaiting_data = false;   // RTS-M seen, DATA-M not yet (fast-self-pull candidate)
        bool     team_flood = false;      // §mobile 6.3: the RTS-M was mobile_src (a TEAM channel flood). The RTS carries no team_id (only the DATA-M does), so we CANNOT know if it is OUR team until the DATA-M -> do NOT fast-self-pull (would emit a CHANNEL_PULL for a possibly-FOREIGN team). ingest_channel_m team-gates the DATA-M + frees a foreign state.
        uint32_t id = 0;                  // channel_msg_id
        uint8_t  src = 0;                 // who relayed it to us (pull target / neighbour-learn)
        int16_t  rx_snr_q4 = 0;           // SNR of the winning RTS-M (drives the backoff)
        uint8_t  bitmap[32] = {};         // working coverage (OR'd from every heard RTS-M for this id)
        uint8_t  body[protocol::channel_msg_max_payload_bytes] = {};  // cached for the re-flood DATA-M
        uint8_t  body_len = 0, channel_id = 0, flavor = 0, hop_left = 0;
    };
    struct ChannelPullPending  { bool active; uint32_t id; uint8_t target; uint64_t requested_at; uint64_t fire_at; };
    struct ChannelPullRecent   { uint32_t id; uint64_t t_ms;       // re-pull dedup (Lua channel_pull_recent)
                                 bool same_key(const ChannelPullRecent& o) const { return id == o.id; } };
    // Part 2: per-origin re-offer (timer kChannelReofferTimerId+slot). team = a TEAM flood: a single relay does NOT confirm coverage on a mixed multi-hop chain, so it re-offers all its retries (P-BUDGET s28 class). holder (§F-CH-RELAY) = a RELAY (not the origin) re-offering to cover its own still-unmarked downstream team neighbours — coverage-driven (seen_by), deterministic jitter, team-only.
    // ★★ §b38-b40 FIELD ORDER IS LOAD-BEARING — the four bools lead, then the 4-aligned `id`, then `ctr`+`retries_left`
    // in the 2 bytes that follow it. MEASURED: 12 B before this slice (active/pad3/id/retries_left/team/holder/pad1) and
    // 12 B after, i.e. `relay_seen` (+1 B) and `ctr` (+2 B) BOTH cost zero — they land in the 3-byte hole that sat after
    // `active` and the 1-byte tail pad. x cap_channel_reoffer_pending(4) x MR_N_LAYERS, so a grown record would move
    // sizeof(Node) (the D2 trigger); the static_assert below is the tripwire, and it is per-ABI, not native-only.
    struct ChannelReofferPending {
        bool     active;
        bool     team;
        bool     holder;
        bool     relay_seen;     // §b38: a relay of THIS origination was overheard at least once. Remembered rather than discarded, so a TEAM post can report the truth (see channel_reoffer_confirm) AND keep re-offering for its far members. Also the once-only latch: the outcome push is emitted exactly once per origination and exhaustion must never contradict a `true` already sent.
        uint32_t id;
        uint16_t ctr;            // §b40: the FULL 16-bit originating ctr (next_ctr), so channel_sent can be correlated past 255 posts. ⚠ A LOCAL CORRELATION HANDLE ONLY — the wire carries just `ctr & 0xff` (the channel msg-id's low byte, channel_msg_id_mint), so no peer can echo more than 8 bits and this must never be matched against a received id. 0 on a holder slot (a relay owns no origination).
        uint8_t  retries_left;
    };
    // ★★ §T3 (2026-08-14): `id`, `ctr` and `holder` are now ALSO READ by `Node::push_send_aired_if_owned` — the
    //    channel row of the `send_aired` ownership rule matches an ACTIVE, NON-holder slot on `id` and pushes its
    //    16-bit `ctr`. ⛔ THAT PATH ADDED NO FIELD AND MUST NEVER ADD ONE: the three it needs already existed, and
    //    the assert below is why — a grown record costs bytes x cap x MR_N_LAYERS and moves `sizeof(Node)`.
    static_assert(sizeof(ChannelReofferPending) == 12 && offsetof(ChannelReofferPending, id) == 4
                      && offsetof(ChannelReofferPending, ctr) == 8,
                  "node.h: ChannelReofferPending grew — §b38's relay_seen / §b40's ctr left the padding they were "
                  "placed in, so the record now costs real bytes x cap_channel_reoffer_pending x MR_N_LAYERS and "
                  "sizeof(Node) has moved (see the layout tripwire at the end of this header)");
    void    channel_reoffer_register(uint32_t id, bool team, uint16_t ctr);   // Part 2: arm a re-offer slot on flood origination (retries_left = team ? channel_reoffer_team_max_retries : channel_reoffer_max_retries). §b40: `ctr` is the origination's full 16-bit next_ctr, remembered for the channel_sent push.
    void    channel_holder_reoffer_register(uint32_t id);          // §F-CH-RELAY: a team-flood HOLDER arms a coverage-driven re-offer after it re-broadcasts, iff it still has unmarked hops-1 team neighbours (deterministic jitter, no RNG draw)
    void    channel_reoffer_fire(uint8_t slot);                    // Part 2: timer fire — re-flood if not yet confirmed + retries remain, else free (holder slot: re-check seen_by coverage instead of the confirm flag). §b38: the exhaustion give-up emits channel_sent{relayed:false} ONLY when no relay was ever seen.
    void    channel_reoffer_confirm(uint32_t id);                  // Part 2: a relay of OUR message was overheard -> report the outcome (channel_sent{relayed:true}, once) and, on the NON-team plane, cancel the pending re-offer (dedicated signal, NOT seen_by). §b38: a TEAM origin reports AND keeps re-offering; a HOLDER slot reports nothing.
    int     channel_buffer_find(uint32_t id) const;                // index of the entry, or -1 (dv:3426)
    bool    channel_mark_seen_by(uint32_t id, uint8_t neighbour);  // set seen_by bit; true if newly set (dv:3434)
public:
    bool    channel_origin_admit(uint8_t origin, uint32_t msg_id, bool team_plane = false); // per-(PLANE,origin) distinct-count anti-spam (dv:3456). Public: the receiver-HOOK test seam (drives the cap + 10s burst floor directly). §T6/B: team_plane keys the ledger; the default keeps every existing static/leaf caller (incl. the native hook tests) on the STATIC key verbatim.
    // Slice 6: the send-outcome feedback pushes. Public so native tests can drive them (the reoffer-exhaustion path
    // enqueues channel_sent{relayed:false}); called internally from do_send_channel / become_free / channel_reoffer_*.
    void    emit_send_blocked(bool channel, SendFailReason reason, uint32_t next_ms);   // Slice 6a: the send_blocked push (self-gate)
    void    emit_channel_sent(bool relayed, uint16_t ctr);                              // Slice 6c: OWN channel post re-offer outcome
    // ★★★ §T3: the `aired` arm's ONE app consumer — enqueue `PushKind::send_aired` iff this completion belongs to a
    // LOCALLY ORIGINATED flight. Public for the same reason `emit_channel_sent` is: native cases drive it through
    // `on_tx_complete`, and the ownership rows need to be reachable per-carrier. ⛔ It is NOT telemetry — see the
    // definition's [[B169]] note; wrapping it in `MR_TELEMETRY` would delete the whole B164 fix on every board env.
    void    push_send_aired_if_owned(const TxOutcome& info);
private:
    int     channel_buffer_pick_eviction(bool* safe) const;        // oldest-all-seen else oldest; index (dv:3485)
    bool    channel_entry_fully_seen(const ChannelEntry& e) const; // 2026-06-23: every live 1-hop neighbour holds e (or none to serve) -> retire-OK (holder-aware retirement; NOT shared with pick_eviction — opposite nn==0 meaning)
    void    channel_buffer_add(const ChannelEntry& e);             // insert; evict if full (dv:3511)
    void    cancel_channel_pull(uint32_t id, uint8_t overheard_from, bool peer_q = false); // pull cancel: peer_q=true -> a peer's Q pulled it (dv:11831); else we received it (dv:11006)
    uint16_t do_send_channel(uint8_t channel_id, const uint8_t* body, uint8_t body_len, bool crypt = false, bool with_location = false);  // send_channel origination (dv:12126). §chan-crypt CL2a: crypt=true SEALS the body under the team content key (+ channel_flavor_crypted). §chan-crypt CL2b: with_location=true also packs THIS node's pack_loc6 position into the sealed inner (bit1) — it REQUIRES crypt (Node::on_command refuses `-l` on any post that would not be sealed, ruling O6) and is ignored without it, so a position can never reach a plaintext body. BOTH defaulted false so the two OTHER callers — the home's delegated re-originate (handle_channel_post) and src/fw_main.cpp's `testch` workload — stay plaintext AND position-free by construction.
#if MR_FEAT_MOBILE
    bool    do_send_channel_delegated(uint8_t channel_id, const uint8_t* body, uint8_t body_len);  // §S7 T-B: a registered mobile delegates a GLOBAL/leaf channel post to its home (MOBILE_SEND wrapper, enclosed DATA_TYPE_CHANNEL_POST). false = no home (off-grid) -> caller fails loud.
#endif
    // Phase 2: digest emit/ingest + the jittered pull (THE draw). SELECT/COMMIT split (B, 2026-06-23): build is side-effect-free
    // (fills `picked`); the per-ad ad_count++/retire is COMMITTED separately.
    // ★★ §tx-admission TX3 (owner ruling 2026-08-02) — WHERE THE COMMIT HAPPENS AND WHAT "SENT" MEANS. It is NOT
    // `emit_beacon`, and it is NOT literal airtime; both halves of the old wording here were wrong after TX3.
    // "Sent" = **ACCEPTED BY THE TRANSMITTER/DeviceHal** — the owner-ruled digest-commit boundary —
    // and the commit lives at the two sites that reach it: the IMMEDIATE path (`tx_flood` after `_hal.tx` answers
    // ok, node_mac.cpp) and the DEFERRED path (the LBT timer's `lbt_complete`, node.cpp — the selected ids ride the
    // `DeferredLbt` slot so a late rejection leaves both `bcn_ad_count` and `dirty` untouched).
    // ⚠ WHAT THE BOUNDARY IS NOT: a later `DeviceHal::pump_tx` radio-start error drops the frame AFTER admission and
    //   is OUTSIDE the guarantee. §T2 makes that attempt observable as `tx_failed`; moving the digest boundary is a
    //   separate decision. Nothing here claims the beacon reached the air.
    size_t  build_channel_digest_ext(uint8_t* out, size_t cap, uint32_t* picked, uint8_t& npicked);  // SELECT: dirty ids -> BCN ext-TLV; NO side effects (dv:1426)
    void    commit_channel_digest_advertised(const uint32_t* ids, uint8_t n);  // COMMIT (transmitter-admitted, see above): ad_count++ + holder-aware retire
    void    process_channel_digest(uint8_t src, const uint32_t* ids, uint8_t count);  // diff -> mark/schedule pull (dv:3546)
    void    channel_pull_fire(uint8_t slot);                       // kChannelPullTimerId+slot: re-check overhear -> tx the pull
    bool    channel_pull_recently(uint32_t id) const;             // re-pull dedup window (dv:3567)
    void    channel_pull_mark(uint32_t id);                        // record a fired pull (channel_pull_recent)
    // Phase 2c: the CHANNEL_PULL responder + M-broadcast tx.
    void    handle_channel_pull(uint8_t src, uint8_t dest, const uint32_t* ids, uint8_t count);  // dv:11821
    void    enqueue_channel_m(uint8_t target, const ChannelEntry& e);  // M-inner DATA -> tx_queue (dv:11875)
    bool    channel_m_in_flight(uint32_t id) const;              // an M-payload for `id` already pending/queued (dv:11850 dedup)
    bool    channel_have_id_lo16(uint16_t lo) const;             // do we hold a channel msg whose id low-16 == lo? (overhear skip, dv:2081)
    // M-broadcast fire-and-forget tx (no CTS/ACK; chosen_data_sf = max allowed; dv:6997/7044).
    void    issue_m_broadcast();                                  // set up the m_broadcast flight from _pending_tx + fire the RTS
    void    tx_m_broadcast_rts();                                 // pack+tx the M_BROADCAST (or FLOOD) RTS + arm the RTS->DATA gap (no CTS wait)
    // ---- §chan-crypt CL2a — the SEALED team channel post (T-K2 §2.2; node_channel.cpp) --------------
    // ★★ THE KEYING MODEL, and it is NOT the DM's: a channel post is a BROADCAST TO A GROUP, and every member holds
    // the same `team_ch_priv`. So the AEAD key is SYMMETRIC — derived from the team content key alone — NOT a per-pair
    // ECDH like e2e_seal_inner. Consequences, both deliberate:
    //   ✔ EVERY keyholder opens EVERY post, with no prior pairwise key exchange. That is the requirement T-K2 states
    //     in its own words ("Everyone holding team_ch_priv opens"); a per-sender ECDH could not meet it (a keyholder
    //     lacking the SENDER's pubkey would hold the team key and still see nothing), and it would cost one X25519
    //     per cached peer key per received post on the RX path.
    //   ✖ NO in-team sender AUTHENTICATION — sealing proves MEMBERSHIP, not identity. That bound is already ruled and
    //     recorded at PeerLocSrc above ("ANY KEYHOLDER CAN FORGE ANOTHER MEMBER'S source_hash"); this is the code that
    //     bound describes. An OUTSIDER still cannot forge or read a post.
    bool    channel_content_key(uint8_t key[32]) const;   // BLAKE2b("MR-TEAM-CH-v1" | team_ch_priv)[:32]. false = keyless (key untouched) — the ONE derivation, shared by seal and open (U2)
    uint8_t channel_seal_body(uint32_t msg_id, uint8_t channel_id, const uint8_t* pt, uint8_t pt_len,
                              uint8_t* out, uint8_t out_cap, SealOutcome& outcome);   // -> [seal_ctr 2 LE][seed8 8][ct‖tag]; 0 = refused (outcome says why). Mirrors build_sealed_relay_body's body shape exactly (U1)
    bool    channel_open_body(uint32_t msg_id, uint8_t channel_id, const uint8_t* body, uint16_t body_len,
                              uint8_t* out, uint8_t& out_len);   // false = no key / malformed / TAG FAIL -> the caller drops the CONTENT (it still relays the frame)
    // ---- channel FLOOD plane (2026-06-08 redesign; node_channel.cpp) -------------------------------
    int     flood_state_find(uint32_t id);                        // active slot for id, or -1
    int     flood_state_alloc(uint32_t id);                       // free slot, or -1 (all active -> DROP to repair; never evict, §6)
    void    flood_state_free(uint8_t slot);                       // clear active + cancel its rebroadcast timer (the ACTIVE leaf)
    void    flood_state_free(uint8_t layer, uint8_t slot);        // ...on an EXPLICIT leaf; the 1-arg form delegates here (purge_tx_carriers's reprovision axis sweeps every leaf)
    void    flood_set_my_coverage(uint8_t* bm, bool team = false) const;   // §S7 T-A plane-keyed: team=false -> my static id + _rt hops==1 + HOSTED MOBILES (§S7 T-B: a home covers its registered mobiles); team=true -> my team_local_id + _rt_team hops==1. Idempotent (originate-seed AND rebroadcast cover). The bitmap indexes ONE id-space per flood (§18: team ids never mix with static ids).
    bool    flood_any_unmarked(const uint8_t* bm, bool team = false) const; // §S7 T-A: any coverage target unmarked? team-plane consults _rt_team (+ its own team id-space); static consults _rt + hosted mobiles
    void    enqueue_flood_m(uint8_t channel_id, uint8_t flavor, uint32_t id, const uint8_t* body, uint8_t body_len,
                            const uint8_t* bitmap32, uint8_t hop_left);   // build+enqueue a FLOOD m-broadcast (no target)
    bool    handle_flood_rts(const rts_out& r, const uint8_t* in_bitmap, int16_t snr_q4);  // §4.2 RX of a FLOOD RTS-M; true = fresh state -> retune to catch DATA-M
    void    flood_forward_decision(uint8_t slot);                // §4.5 after DATA-M ingest: silent | arm backoff
    void    flood_rebroadcast_fire(uint8_t slot);                // kFloodRebcastTimerId+slot: re-flood {unmarked+me}, hop_left--
    // void    flood_log_coverage(const char* tag, uint32_t id, const uint8_t* bm) const;  // FLOOD-DBG disabled 2026-06-23 (def #if 0'd in node_channel.cpp; re-enable for bench diag)
    void    flood_fast_self_pull(uint8_t slot);                  // §4.4: caught RTS-M, missed DATA-M -> pull from src
    uint8_t max_data_sf_index() const;                            // its index in the ascending allowed set (the RTS sf_index)
    static uint32_t m_inner_id(const uint8_t* inner);             // channel_msg_id (BE) from an M-inner buffer [id4|ch|fl|body]

    // ---- route table (DV merge) --------------------------------------------
    enum class MergeAction : uint8_t { none, new_dest, primary_refresh, promote, alt_install };
    RtEntry*    rt_find(uint8_t dest, Plane plane = Plane::AUTO);   // Wave 2: plane-aware dispatch (AUTO=is_team_peer, TEAM=_rt_team, GLOBAL=_rt)
    RtEntry*    rt_insert(uint8_t dest);                           // sorted insert; nullptr if full
    void        rt_remove(uint8_t idx);                            // R2: drop _rt[idx], keep sort
    MergeAction rt_merge(uint8_t dest, const RtCandidate& cand);   // dv_dual_sf.lua:4484
    // §mobile 6.2: the SAME DV core, over an arbitrary (table,count) — default via the wrappers above = `_active->_rt`
    // (static plane, byte-identical). The §6.2 team plane passes `_rt_team`/`_rt_team_count`. team_plane skips the
    // route_uses_mobile_as_transit block (a same-team peer IS a legal transit in its own table).
    RtEntry*    rt_find(uint8_t dest, RtEntry* rt, uint8_t rt_count);
    RtEntry*    rt_insert(uint8_t dest, RtEntry* rt, uint8_t& rt_count);
    void        rt_remove(uint8_t idx, RtEntry* rt, uint8_t& rt_count);
    MergeAction rt_merge(uint8_t dest, const RtCandidate& cand, RtEntry* rt, uint8_t& rt_count, bool team_plane);
    void        sort_candidates(RtEntry& e, bool team_plane = false);   // §2c: team_plane threads to route_strictly_better/effective_score (team liveness + skip freshness + wire-only degraded)
    // route_strictly_better/effective_score take the candidate LIST (cands,n) as context so the
    // R4.2 budget penalty can count viable alternatives (Lua signature (a,b,viab,candidates)). The
    // penalty is 0 for every HEALTHY-tier next_hop, so effective_score == score until a tier is marked.
    bool        route_strictly_better(const RtCandidate& a, const RtCandidate& b,
                                      const RtCandidate* cands, uint8_t n, bool gw_dest = false, bool team_plane = false) const;  // :4227 (gw_dest: cross-layer freshness-exempt). §2c: team_plane -> team liveness in effective_score + SKIP the is_next_hop_fresh viability gate (no team freshness array)
    bool        is_gateway_dest(uint8_t dest) const;          // §cross-layer: dest is a gateway egress (freshness-exempt)
    int16_t     effective_score(const RtCandidate& c, const RtCandidate* cands, uint8_t n, bool team_plane = false) const; // :4050. §2c: team_plane -> liveness_penalty_q4(team) + NO static bidi_penalty_q4
    int16_t     budget_penalty_q4(const RtCandidate& c, const RtCandidate* cands, uint8_t n) const; // :3887
    int16_t     liveness_penalty_q4(uint8_t next_hop, bool team_plane = false) const;   // §P2: suspect 192 / silent 640 / dead 1280 Q4 (const read). §2c: team_plane -> scans _team_liveness
    // Slice 3: the bidirectionality DETECTION scan. For advertiser P's beacon heard-set (its hops==1 entries),
    // a [dest==self] entry proves P hears us -> confirmed (note_link_confirmed); an ABSENT self in a COMPLETE
    // page proves P does NOT hear us -> one_way; an absent self in a TRUNCATED page is unconfirmed (no change).
    void        update_link_bidi_from_beacon(uint8_t advertiser, const beacon_entry* entries, uint8_t n, bool complete, bool team_plane = false);   // §T5: team_plane -> "self" is team_local_id() and the verdict lands in the team bidi slot
    int         resort_routes_for_neighbor_penalty(uint8_t node_id, const char* source, bool local_only);      // :4255
#if MR_FEAT_TEAM
    void        team_resort_routes_through(uint8_t team_local_id, const char* reason = "team_liveness");   // §2c: re-sort _rt_team routes through a demoted/recovered team next-hop (proactive candidates[0] update). §T5: `reason` so the bidi confirm/recover is distinguishable from the liveness tier in rt_penalty_rerank (default = the pre-T5 literal ⇒ both existing call sites byte-identical)
#endif
    RtEntry*    refresh_route_order(uint8_t dst, const char* reason, Plane plane = Plane::AUTO);   // re-sort ONE dest's candidates (catch a tier change since the last sort), dv:4455
    void        maybe_emit_rt_full();

    // ---- R2 route-plane hardening ------------------------------------------
    void     age_out_stale_routes();                               // dv_dual_sf.lua:5249 — ages BOTH planes
    void     age_out_stale_routes(RtEntry* rt, uint8_t& rt_count, bool team_plane);   // §6.2: over an arbitrary table; team_plane clears the _team_peer bit on a full eviction
    uint32_t ttl_for_hops(uint8_t hops) const;                     // hops<=1 neighbor else remote
    void     rt_prune_cycle(uint8_t dest, uint8_t sender);         // 3-cycle prune  :5193
    void     rt_prune_cycle(uint8_t dest, uint8_t sender, RtEntry* rt, uint8_t& rt_count);   // §6.2: over an arbitrary table
    // ---- Peer-liveness internals (routing-liveness port) -------------------
    struct PeerLiveness;                                              // fwd decl (full def below, near the LayerRuntime member structs)
    PeerLiveness* peer_liveness_slot(uint8_t node_id, bool create);   // find (or LRU-create) the per-node slot; nullptr if absent + !create
    PeerLiveness* peer_liveness_slot(uint8_t node_id, bool create, PeerLiveness* tbl, uint8_t& n, uint8_t cap);   // §P2-4: shared table-ref core (static _peer_liveness / team _team_liveness)
    uint8_t       apply_timeout_tier(PeerLiveness& s, uint16_t count, uint64_t now);   // §P2-4: shared rts-timeout tier cascade -> level 0-3 (mutates first_timeout_ms; sets NO until fields)
    bool          clear_liveness_tiers(PeerLiveness& s);              // §P2-4: shared recovery clear-core -> true if anything was live (the emit-only-if-had gate)
#if MR_FEAT_TEAM
    PeerLiveness* team_liveness_slot(uint8_t team_local_id, bool create);   // §2c: self-slotted mirror over _team_liveness (team_local_id-keyed, own LRU); NEVER _peer_liveness / _team_keys
    // §team-parity T5: the CONST twin of team_liveness_slot(id, create=false) — the team bidi READS (bidi_penalty_q4,
    // candidate_degraded) are const and cannot take the non-const slot accessor. nullptr = no slot = LinkBidi::unknown.
    // ⚠ MISSING (deliberate, C1): liveness_penalty_q4 (node_routing.cpp:94) still carries this identical linear scan
    // INLINE. It is provably the same loop, but folding it onto this helper is a pure refactor and T5 is a feature
    // slice — the same C1 split T6 made for `rt_find` vs flight_is_team_plane and T2 made for its learn_direct_neighbor
    // hoist. A cleanup slice owns both. There is exactly ONE scan to fold, not a family.
    const PeerLiveness* team_liveness_find(uint8_t team_local_id) const;
#endif
    bool          e2e_ack_spoofer_flagged(uint8_t src);               // anti-spoof: has `src` been caught faking RTS_FLAG_E2E_ACK within the penalty window? (its exemption is then revoked). Non-const: peer_liveness_slot is non-const.
    void          mark_peer_suspect(uint8_t node_id, uint8_t level, const char* source, uint8_t remote_src = 0);   // set the tier expiry + resort (§P4: remote_src!=0 => gossip-learned: local_only resort + NO advertise-table write; remote_src is also echoed in the event)
    size_t        build_suspect_ext(uint8_t* out, size_t cap);    // §P4: locally-observed suspect/dead peers -> a type-1 or type-2 BCN ext-TLV; 0 = none (dv:1373 build_suspect_nodes_ext)
    void          apply_suspect_gossip(const SuspectEntry* e, uint8_t n, uint8_t bcn_src);   // §P4: a received suspect-TLV -> mark_peer_suspect(remote); skip self + the gossiper (dv:9627)
    void     maybe_exit_discovery(const char* reason);            // :7517

    // ---- R3 data plane (MAC: RTS-CTS-DATA-ACK) -----------------------------
    // override_dst_hash (§mobile 3c): when non-zero, the DM's DST_HASH is stamped with THIS hash (the queried mobile hash M)
    // instead of key_hash_of_id(dst) — so a mobile's home_node sees dst_hash != its key and last-mile-forwards (not consumes).
    uint16_t do_send(uint8_t dst, const uint8_t* body, uint8_t body_len, uint8_t flags, CryptIntent crypt = CryptIntent::def,
                     uint32_t override_dst_hash = 0, uint8_t type = 0, uint32_t override_source_hash = 0, Plane plane = Plane::AUTO,
                     SendDispatch* out_dispatch = nullptr);  // returns the ctr. §mobile delegate: type=MOBILE_SEND + override_source_hash=the mobile's hash (home re-originating on its behalf). §UI-16 N6b: out_dispatch (nullptr = every pre-existing caller) receives enqueue_data's OWN admission fact
    uint16_t enqueue_data(uint8_t dst, const uint8_t* body, uint8_t body_len, uint8_t flags, const char* tx_event,
                          bool app_dm = false, uint8_t type = 0, CryptIntent crypt = CryptIntent::def, uint32_t override_dst_hash = 0, uint32_t override_source_hash = 0,
                          uint8_t addr_len = 0, Plane plane = Plane::AUTO, SendDispatch* out_dispatch = nullptr);   // §mobile: addr_len=1 ORIGINATES a last-mile DM to a hosted mobile's LOCAL id (E2E-ack back to a mobile); 0 = normal global-id send (byte-identical). §UI-16 N6b: out_dispatch reports whether the TxItem was really STORED — the `ctr` alone never did
    void     send_e2e_ack(uint8_t to_origin, uint16_t acked_ctr, uint32_t sender_hash = 0);   // E2E ACK reply (TYPE=E2E_ACK; e2e_ack_tx). §mobile: sender_hash a hosted mobile -> last-mile the ack to it (origin was home-stamped == a self-send)
    // §GapB (2026-07-18): send_e2e_ack_cross_layer RETIRED — the reversed-path XL ack is now a normal send via send_xl_ack (declared above).
    // §mobile reverse-ack (delegated): a home re-originates a hosted mobile's send under its OWN ctr (ctr_H). When the
    // target's E2E-ack (for ctr_H) comes home, translate ctr_H -> the mobile's original ctr (ctr_M) so the last-miled ack
    // matches what the mobile is waiting on. A DIRECT send (home only forwarded) has NO entry -> out stays acked_ctr.
    enum class DelegAckPeer : uint8_t { node_id = 0, key_hash = 1 };
    enum class DelegAckState : uint8_t { free = 0, reserved = 1, active = 2 };
    struct DelegAck;                       // defined with the ring below; forward-declared for the prune helper
    // §B278 §4.5 — the custody lifecycle of the ONE correlation row, carried UNDER that row's single 300 s TTL.
    // ⛔ NOT a second clock and NOT a second row (spec §10.1).
    // ★ §B278 S1b MOVES IT: `none -> candidate` at reservation (the §5 terms knowable BEFORE the mobile hop ACK),
    //   then `candidate -> eligible | none` at activation (the arm's own final verdict). `candidate` is valid ONLY
    //   while RESERVED; an ACTIVE row is `eligible` or `none`.
    // ⚠ CORRECTED 2026-09-02 BY §B278 S3. THIS LINE READ: *"`forwarded` is S3's and remains UNREACHABLE — nothing
    //   writes it (the S3 translated-report origination is the only future writer)"*. That was true through S2 and
    //   is now FALSE: `deleg_custody_mark_forwarded` (node_hashlocate.cpp) writes it, and ONLY it, when a
    //   translated report for that exact row was `queued` or `parked`. ⛔ WHAT DID **NOT** CHANGE: the state is
    //   still reachable from `eligible` ALONE, still never from `candidate`/`none`, still never at reservation or
    //   activation (D12/D15/D16 remain RED), and it is still cleared by the SAME single 300 s row prune — a
    //   `forwarded` row expires at exactly the edge an `eligible` one does, reporting `custody_state = 3`.
    enum class DelegAckCustody : uint8_t { none = 0, candidate = 1, eligible = 2, forwarded = 3 };
    // ★★ §B278 S1b F6 — the NON-WIRE release-cause authority. It exists so ONE `deleg_ack_released` emit can live
    //    inside `deleg_ack_release` instead of being copied to its seventeen call sites, and so the cause is the
    //    CALLER'S STATED DECISION rather than something inferred from the row: the row cannot know why it is being
    //    dropped, and two causes (a cached-home XL no-route vs a spoofed source) leave byte-identical rows.
    //    ⛔ Never serialized, never persisted, never compared — it is a telemetry field and nothing else.
    enum class DelegAckReleaseCause : uint8_t {
        activation_conflict = 0,   // the wire-visible return key cannot activate (§4.3 uniqueness / ambiguity)
        commit_invariant    = 1,   // the PRE-CHECKED direct-transit commit unexpectedly failed after the hop ACK
        carrier_ineligible  = 2,   // the reserved wrapper became a carrier which does not use this map (channel post)
        invalid_path        = 3,   // malformed cross-layer path in the wrapper
        source_not_owned    = 4,   // stale/spoofed wrapper source: no live direct row owns that hash
        dispatch_refused    = 5,   // enqueue / park / resolution / cross-layer dispatch did not admit
        park_giveup         = 6,   // the retained send aged out without ever resolving
    };
    // ★★★ §B278 S1b §5 — THE ONE CUSTODY-ELIGIBILITY AUTHORITY, in the two phases §5 rules. ⛔ THERE IS NO SECOND
    //     TYPE LIST: `deleg_custody_type_reportable` is §5(7) and BOTH phases call it. The remaining seven §5 terms
    //     are structural at each site (see the reservation/activation call-site notes) and reach these functions as
    //     the single boolean each phase can honestly answer.
    // §5(7): a carrier that IS the ACK, or IS a custody notice, can never itself be the subject of one.
    static constexpr bool deleg_custody_type_reportable(uint8_t type) {
        return type != DATA_TYPE_E2E_ACK && type != DATA_TYPE_CUSTODY_FAILURE;
    }
    // PHASE 1 (reservation, BEFORE the mobile hop ACK). Can only ever produce `none` or a PROVISIONAL `candidate`.
    // `outward_type_known` is what records WHY a row is only provisional: the MOBILE_SEND wrapper's enclosed type is
    // not parsed at this boundary, so §5(7) is deferred to activation — which owns the final type in every case.
    static constexpr DelegAckCustody deleg_custody_reserve_verdict(bool carrier_prospectively_eligible,
                                                                   bool outward_type_known,
                                                                   uint8_t outward_type) {
        return !carrier_prospectively_eligible                                     ? DelegAckCustody::none
             : (outward_type_known && !deleg_custody_type_reportable(outward_type)) ? DelegAckCustody::none
                                                                                    : DelegAckCustody::candidate;
    }
    // PHASE 2 (activation, AFTER the outward arm is chosen). `arm_carries_custody` is the ARM's own structural
    // decision — §4.3's four ACK-only arms (direct last-mile, cached-home XL, the wrapper XL branch and the
    // cross-layer park-fire) answer FALSE and keep only the ACK obligation. Produces `none` or `eligible`, never
    // `candidate`: a provisional state may not survive activation.
    static constexpr DelegAckCustody deleg_custody_activate_verdict(bool arm_carries_custody,
                                                                    uint8_t outward_type) {
        return (arm_carries_custody && deleg_custody_type_reportable(outward_type)) ? DelegAckCustody::eligible
                                                                                    : DelegAckCustody::none;
    }
    static constexpr uint8_t kDelegAckNoSlot = 0xFF;
    bool     deleg_ack_reserve(uint32_t mobile_hash, uint16_t ctr_m, DelegAckPeer target_kind,
                              uint32_t target, uint8_t layer, DelegAckCustody custody,
                              uint8_t& out_slot, uint32_t& retry_ms);
    bool     deleg_ack_activation_available(uint8_t slot, uint16_t ctr_h, DelegAckPeer return_kind,
                                            uint32_t return_peer, uint8_t layer, uint32_t& retry_ms) const;
    // §B278 S1a: `outward_type` is the DataType of the carrier this activation actually dispatched, taken from the
    // value ALREADY in scope at each call site (d.type / itype / etype / p.type) — no parameter is threaded merely
    // to discover it.
    // §B278 S1b: `custody` is the ARM'S OWN phase-2 verdict, from `deleg_custody_activate_verdict`. It is a
    // REQUIRED argument and never inferred inside the ring: `commit_deleg_ack`'s four callers cannot be told apart
    // by `{return_kind, return_peer}` (direct last-mile and cached-home same-layer both pass a node id), so an
    // inference here would silently give the last mile a custody obligation §4.3 forbids.
    bool     deleg_ack_activate(uint8_t slot, uint16_t ctr_h, DelegAckPeer return_kind,
                               uint32_t return_peer, uint8_t layer, uint8_t outward_type,
                               DelegAckCustody custody);
    bool     deleg_ack_put(uint32_t mobile_hash, uint16_t ctr_h, uint16_t ctr_m,
                          DelegAckPeer target_kind, uint32_t target,
                          DelegAckPeer return_kind, uint32_t return_peer, uint8_t layer,
                          uint8_t outward_type, DelegAckCustody custody);
    void     emit_deleg_originated(uint32_t mobile_hash, uint16_t ctr_h, uint16_t ctr_m);
    // §B278 S1b F6: `cause` is telemetry-ONLY — the one `deleg_ack_released` emit lives inside the helper, right
    // before the matching RESERVED row is cleared, so a no-match release stays silent by construction.
    void     deleg_ack_release(uint32_t mobile_hash, uint16_t ctr_m, DelegAckPeer target_kind,
                              uint32_t target, uint8_t layer, DelegAckReleaseCause cause);
    // §B278 S1b F6: the ONE expiry authority for the three prune sites (reserve / put / translate). It owns the
    // `age >= delegated_custody_ttl_ms` comparison AND the `deleg_ack_expired` emit that must precede the clear.
    void     deleg_ack_prune_expired(DelegAck& e, uint64_t now);
    bool     deleg_ack_translate(uint32_t mobile_hash, uint16_t acked_ctr, DelegAckPeer return_kind,
                                uint32_t return_peer, uint8_t layer, uint16_t& out_mobile_ctr);
    // ★★★★ §B278 S3 (2026-09-02) — THE CUSTODY-CORRELATION LOOKUP AND THE ONE `eligible -> forwarded` WRITER.
    //   Both live in `node_hashlocate.cpp` BESIDE `deleg_ack_translate`, and that placement is the contract, not a
    //   preference: `_deleg_acks` has exactly one scanning authority per question, and a receiver that walked the
    //   ring itself would be a second one (spec §4.4 / brief S3-1).
    // ⛔ THE DISPOSITION IS EXPLICIT AND NOT A NULLABLE ROW, because the four outcomes take four DIFFERENT product
    //   actions: `no_live_rows` is the NORMAL v1-only state of a node that never delegated anything and is SILENT;
    //   `no_match` is a live population that this report does not belong to and is one bounded diagnostic;
    //   `ambiguous` is an invariant failure; only `exact` may originate. Collapsing the first two into "nullptr"
    //   would put a `deleg_custody_no_map` line behind every ordinary custody receipt in the corpus.
    enum class DelegCustodyLookup : uint8_t {
        no_live_rows = 0,   // after the prune, this node holds NO ACTIVE `eligible` row at all -> silent
        no_match     = 1,   // >=1 live eligible row, none matching §4.4's return key -> one bounded diagnostic
        ambiguous    = 2,   // >1 exact match: wire-indistinguishable, so nothing is forwarded and nothing guessed
        exact        = 3,   // exactly one -> `out_action` is materialized
    };
    // The BOUNDED, STACK-ONLY translation action (spec §7). ⛔ It holds NO `PostAck`, NO `PendingTx`, NO 241-byte
    // payload buffer, NO ring reference and NO pointer into mutable row storage: the record is the 24-byte semantic
    // prefix as a VALUE, the tail is §6.2's eight bytes as a VALUE, and everything else is a scalar. The row
    // identity is carried IN FULL because the post-send commit re-selects the row by all of it — a slot index
    // would be authority over whatever happens to sit there afterwards, which is the [[B172]] "identity is the
    // whole tuple" defect.
    struct DelegCustodyAction {
        CustodyFailureRecord  record{};        // the ORIGINAL parsed record, COPIED, with `record_len` normalized to 24
        CustodyTranslatedTail tail{};          // §6.2: original_reporter / target_kind / mobile_ctr / target_value
        uint32_t mobile_hash = 0;              // the row's mobile — the `send_by_hash` destination
        uint32_t target      = 0;              // ---- the COMPLETE row identity, for the post-send recheck ----
        uint32_t return_peer = 0;
        uint16_t ctr_h       = 0;
        uint16_t ctr_m       = 0;
        uint8_t  layer       = 0;
        uint8_t  outward_type = 0;
        DelegAckPeer target_kind = DelegAckPeer::node_id;
        DelegAckPeer return_kind = DelegAckPeer::node_id;
    };
    // ★ THE BOUND, PINNED ON EVERY ABI THAT COMPILES THIS HEADER — not on the host alone, because the whole claim
    //   is that this action is a small STACK object and stack is what the two board builds pay for. ARITHMETIC, and
    //   it closes exactly: `CustodyFailureRecord` **28** (its `dst_hash32` forces 4-alignment, so the 24 WIRE bytes
    //   occupy 0..25 with two bytes of tail pad) + `CustodyTranslatedTail` **8** + `mobile_hash`/`target`/
    //   `return_peer` **12** + `ctr_h`/`ctr_m` **4** + four bytes of `layer`/`outward_type`/`target_kind`/
    //   `return_kind` = **56**, alignof **4**, with NO padding anywhere between them.
    // ⛔ IT IS NOT A `Node` MEMBER AND MUST NEVER BECOME ONE: every instance is a local in
    //   `custody_failure_receive`, so `sizeof(Node)` and both ruled board RAM figures move by ZERO.
    static_assert(sizeof(DelegCustodyAction) == 56,
                  "B278 S3: the bounded translation action grew — re-measure the RX stack before accepting it");
    static_assert(alignof(DelegCustodyAction) == 4, "B278 S3: the bounded action's alignment moved");
    // PRUNE FIRST, exactly as `deleg_ack_reserve` / `deleg_ack_put` / `deleg_ack_translate` do — so a report that
    // arrives at or after the 300 s edge cannot match a row the scan would otherwise still see. `out_matches` is
    // the exact-match count (the `ambiguous` diagnostic's one scalar); `reporter_origin` is `pa.origin`, the outer
    // reporting relay, and becomes the tail's `original_reporter`.
    // §4.4's five key terms plus the OPTIONAL hash cross-check, as one predicate with one line per term
    // (node_hashlocate.cpp). Static: it reads a row and a record and nothing else about this node.
    static bool custody_row_matches_report(const DelegAck& e, const CustodyFailureRecord& rec);
    DelegCustodyLookup deleg_custody_lookup(const CustodyFailureRecord& rec, uint8_t reporter_origin,
                                            DelegCustodyAction& out_action, uint8_t& out_matches);
    // The ONE `eligible -> forwarded` writer. Returns true IFF the complete materialized identity still selects
    // EXACTLY ONE ACTIVE `eligible` row and that row was marked. ⛔ It never marks a replacement row, never
    // creates, refreshes, evicts or clears one, and never touches a row in any other state.
    bool     deleg_custody_mark_forwarded(const DelegCustodyAction& action);
#ifdef MESHROUTE_NATIVE
public:
    // ★★ §B278 S3 white-box probe seams. They live HERE, immediately after the two authorities and their action
    //    type, because `TestCustodyProbe` has a MEMBER of that type — a nested struct's member declarations are
    //    not in complete-class context, so it cannot be declared beside the other `test_*` seams above.
    // ★★ THE STALE-ACTION PROBE, and it is labelled a PROBE because that is what it is. Inside
    //    `custody_failure_receive` nothing can mutate `_deleg_acks` between `deleg_custody_lookup` and
    //    `deleg_custody_mark_forwarded` (the send path in between reserves, activates and releases nothing —
    //    `reply_to_hash == 0` and `mobile_ctr == 0` keep `send_by_hash` out of the ring entirely), so the
    //    commit's complete-identity recheck is DEFENCE IN DEPTH. ⛔ Defence in depth that no test can reach is
    //    a claim rather than a guard, so these two seams let a case materialize an action, change the ring
    //    underneath it, and then ask the commit what it does. `DelegCustodyAction` itself stays PRIVATE — the
    //    case carries the opaque probe value and never names the type.
    struct TestCustodyProbe { DelegCustodyAction action; uint8_t disposition; uint8_t matches; };
    TestCustodyProbe  test_custody_lookup(const CustodyFailureRecord& rec, uint8_t reporter_origin) {
        TestCustodyProbe p{};
        uint8_t m = 0;
        const DelegCustodyLookup d = deleg_custody_lookup(rec, reporter_origin, p.action, m);
        p.disposition = static_cast<uint8_t>(d);
        p.matches     = m;
        return p;
    }
    bool              test_custody_mark_forwarded(const TestCustodyProbe& p) { return deleg_custody_mark_forwarded(p.action); }
    static constexpr size_t test_custody_action_size()  { return sizeof(DelegCustodyAction); }
    static constexpr size_t test_custody_action_align() { return alignof(DelegCustodyAction); }
    // The four §4.4 dispositions, flattened, so a case never hard-codes an integer whose meaning could drift.
    static uint8_t    test_custody_disposition_no_live_rows() { return static_cast<uint8_t>(DelegCustodyLookup::no_live_rows); }
    static uint8_t    test_custody_disposition_no_match()     { return static_cast<uint8_t>(DelegCustodyLookup::no_match); }
    static uint8_t    test_custody_disposition_ambiguous()    { return static_cast<uint8_t>(DelegCustodyLookup::ambiguous); }
    static uint8_t    test_custody_disposition_exact()        { return static_cast<uint8_t>(DelegCustodyLookup::exact); }
    // The four §4.5 custody states, likewise flattened (the `DualLayerTestAccess` idiom, for G's non-friend file).
    static uint8_t    test_custody_state_none()      { return static_cast<uint8_t>(DelegAckCustody::none); }
    static uint8_t    test_custody_state_candidate() { return static_cast<uint8_t>(DelegAckCustody::candidate); }
    static uint8_t    test_custody_state_eligible()  { return static_cast<uint8_t>(DelegAckCustody::eligible); }
    static uint8_t    test_custody_state_forwarded() { return static_cast<uint8_t>(DelegAckCustody::forwarded); }
private:
#endif
    // ★ E2E-ack DEADLINE (shelf item (i), 2026-07-24) — node_mac.cpp. Arm/clear are emit-free (byte-neutral when acks arrive).
    void     e2e_ack_arm(uint32_t key, bool is_xl, uint8_t dst, uint16_t ctr, uint32_t budget_ms);   // silent: a -a send minted its ctr -> track until send_e2e_acked or the deadline. Full ring -> skip + telemetry (the command path pre-refuses).
    void     e2e_ack_clear(uint8_t acker_origin, uint16_t acked_ctr, uint32_t sender_hash);          // silent: a send_e2e_acked arrived -> drop the matching pending entry (a late/unknown ack is a harmless no-op)
    bool     e2e_ack_ring_full() const;                                    // ring-full pre-check for on_command (refuse a new -a send loudly)
    void     e2e_ack_deadline_arm_timer();                                 // re-arm the ONE one-shot to the earliest pending deadline (park_reflood_arm idiom)
    void     e2e_ack_deadline_fire();                                      // timer body: expire elapsed entries -> send_failed{e2e_ack_timeout}, then re-arm
    void     enqueue_push(const Push& p);                                  // append to the bounded ring
    // §3-B.2: THE one send-failure push. Every `send_failed` the companion app sees goes through here, so the
    // {kind,reason,dst,ctr} field set can never be filled short at a new site (the S1/L9 field-drop class). dst/ctr
    // are REQUIRED, not defaulted: several callers legitimately mean 0 ("no addressable dst yet") and that must read
    // as a decision, not an omission. The reason is the CONTRACT string the app keys on (console_json.cpp
    // sendfailreason_name) — pass the site's own; this helper never invents one.
    // ★★★ §CUSTODY-B / [[B268]] blocker-1 — THE ONE POST-ADMISSION TERMINAL OUTCOME (definition in node.cpp,
    //     where the full contract is written). Every site where an ADMITTED carrier DIES calls this: it applies
    //     the DATA-type trait once, and emits either the generic `send_failed` or the grant's own
    //     `team_key_grant_failed`. ⛔ `generic_owed` is the CALLER'S site-specific answer, passed in and never
    //     recomputed. §CUSTODY-E added the THIRD term `own_origination` to the central gate, which is [[B263]]
    //     closed: a TRANSIT carrier's death no longer mints a generic completion under a foreign `{dst, ctr}`.
    void     terminal_carrier_outcome(uint8_t type, bool own_origination, bool generic_owed,
                                      SendFailReason reason, uint8_t dst, uint16_t ctr);
    void     push_send_failed(SendFailReason reason, uint8_t dst, uint16_t ctr);
    // §3-B.9: THE one wire_version join-refusal — the windowed Push+emit ritual shared by the BEACON pre-parse
    // version wall (node_beacon.cpp handle_beacon) and the P-plane roster wall (node_mobile.cpp §D16). Takes the
    // peer's advertised version; fills OUR version as `dst` itself so a caller can't report the mismatch one-sided.
    // NOT extended to the other three join_refused flavours (phy_mismatch / sf_list_mismatch / leaf_full): they carry
    // different payload fields and emit no telemetry, so one helper would need a parameter per difference.
    void     push_join_refused_wire(uint8_t their_ver);
    void     push_peer_key_cached(uint32_t key_hash32);                    // §S6: peer_key_cached push carrying the cached name (copied at cache time; body empty when unknown)
    void     become_free();                                       // dv_dual_sf.lua:7433 (FIFO single-drain)
    void     issue_send(const TxItem& item);                      // :7018 pending_tx + RTS
    void     clear_nack_wait() { _hal.cancel(kNackWaitTimerId); _nack_wait_pending = false; }   // drop a stale BUSY_RX wait
    // ★★★ §hybrid-rts S2 — THE ONE PRODUCER OF THE WIRE ADDRESSING MARKS a unicast RTS carries for a pending
    // flight. Extracted from `tx_rts_retry` because S2 gained a SECOND consumer: the sender-side terminal-CTS echo
    // must compare the plane it DECLARED, and re-deriving `team_next` at that site would fork the §team-parity T8
    // predicate in two (U1). `pack` uses these verbatim; `rts_wire_team_plane(addr_len, mobile_src)` turns them
    // into the plane. ⛔ Do not add a third derivation of `team_next`.
    struct RtsWireMarks { uint8_t addr_len = 0; bool mobile_src = false; bool team_src = false; };
    RtsWireMarks rts_wire_marks(const PendingTx& pt) const;
    // ★★★ §hybrid-rts S2 — THE ONE derivation of a pending flight's identity (node_mac.cpp). Two consumers:
    // `tx_rts_retry` (what goes on the wire) and `handle_cts` (what a terminal echo must equal). ⛔ Do not inline
    // it at either: the first draft did, they diverged on `pt.origin` vs the DATA-exposed origin, and the corpus
    // answered with 40 terminal-CTS refusals and a retry deadlock.
    RtsFlightIdentity flight_identity(const PendingTx& pt) const;
    void     handle_rts (const uint8_t* b, size_t n, const RxMeta& m);   // on_recv 'R' -> CTS
    void     handle_cts (const uint8_t* b, size_t n, const RxMeta& m);   // on_recv 'C' -> DATA
    void     handle_data(const uint8_t* b, size_t n, const RxMeta& m);   // on_recv 'D' -> deliver/forward + ACK
    void     handle_channel_data(const uint8_t* b, size_t n, const RxMeta& m);  // on_recv 'M' (cmd 0xA) -> leaf gate + ingest
    void     handle_ack (const uint8_t* b, size_t n, const RxMeta& m);   // on_recv 'K' -> done
    void     handle_nack(const uint8_t* b, size_t n, const RxMeta& m);   // on_recv 'N' -> blind+wait / cascade
    void     do_data_tx();                                        // kCtsToDataGapTimerId fire
    void     do_post_ack();                                       // kPostAckTimerId fire (deliver|forward)
    // ---- Slice 3 dual-layer gateway: leaf activation (3d's window scheduler drives activate_layer on timers,
    // gated by layer_swap_blocked). Retunes SF + per-leaf identity + the active-layer scalars/SNR-floor/LBT timing;
    // migrates the per-leaf sync-response ring (shared timer ids) off the LEAVING leaf so a stale fire can't hit it.
    void     activate_layer(uint8_t i);
    bool     layer_swap_blocked() const;                          // §4 busy-guard: never switch mid-exchange
    int16_t  routing_snr_floor_for(uint8_t routing_sf) const;     // SF_DEMOD_THRESHOLD[sf] + sf_margin (per-leaf)
    void     window_switch_fire();                                // Slice 3d: gateway window scheduler (kLayerWindowTimerId) — alternate the active leaf
    void     maybe_emit_gateway_beacon();                         // Slice 3d: per-leaf beacon at window-activation (if the active leaf is due)
    bool     gateway_announce_has_headroom() const;               // rolling airtime < gw_announce_duty_pct % of the duty budget
    void     set_window_anchors(uint8_t active_leaf);             // Slice 3e: refresh each leaf's _next_open_ms (the countdown anchor)
    void     window_grid_now(uint8_t* active_leaf, uint32_t* ms_to_boundary) const;  // Slice 3d GRID: which leaf is active now + ms to its close
    void     store_gateway_schedule(const GatewaySchedule& gs);   // Slice 3e.2: remember a heard gateway's schedule (evict-oldest)
    const GatewaySchedule* find_gw_schedule(uint8_t gw_node_id) const;
    uint32_t gateway_schedule_base_defer_ms(uint8_t gw_node_id, uint32_t* out_jmax) const;  // PURE: base defer + jitter range (no RNG draw)
    uint32_t gateway_schedule_defer_ms(uint8_t gw_node_id);       // Slice 3e.2 SEND path: base + herd-jitter draw (NON-const: draws RNG)
    uint32_t gateway_window_align_beacon(uint32_t nominal_ms);    // gw-window broadcast sync: bias the PERIODIC beacon to a gw-neighbour window-open (NON-const: herd-jitter draw)
    uint8_t  count_direct_neighbors() const;                     // §3e herd sizing: rt entries whose primary candidate is 1-hop
    uint8_t  gateway_spread_nibble() const;                      // §3e: this gateway's 0..15 herd-spread hint (Lua dv:1692)
    uint32_t exchange_airtime_ms() const;                        // §3e: RTS+CTS+gap+DATA+ACK airtime (DATA len = rolling mean)
    // Gateway-doorstep hold (Lua gateway_doorstep_hold@6351): an RTS/ACK timeout to a known gateway —
    // patient window-aware requeue instead of the generic cascade. Returns true if consumed.
    bool     gateway_doorstep_hold();
    // [[B159]]: the gateway give-up deadline predicate — true (and emits the existing send_giveup shape) when an
    // attempt starting at `start_ms` would begin at/after `enqueue + gateway_send_giveup_ms`. The bound is
    // EXCLUSIVE (a start exactly AT it is already expired), because the DATA it would carry lands one MAC exchange
    // later and the receiver's `seen_origin_ttl_ms` is sized from precisely this instant.
    // ⚠ WITHDRAWN CLAIM (this line read "ENFORCED AT ONE SITE: `issue_send`'s start boundary, against the ACTUAL
    //   start"): that check was REMOVED, and `Hal::tx()` was never the air start anyway — on a device it only
    //   ENQUEUES. ⇒ THE ENFORCEMENT IS LAYERED: this predicate and `rts_handoff_deadline_cancel` are EARLY
    //   ADMISSION/CANCELLATION guards; the TERMINAL PHYSICAL-START AUTHORITY is `DeviceHal::pump_tx()`, immediately
    //   before `start_transmit()`. The entry test inside `gateway_doorstep_hold` is pre-existing behaviour.
    // ⛔ It does NOT itself drop the flight — the caller runs its own give-up ritual (giveup_flight / push_send_failed)
    // because the two call contexts hold different state (a live PendingTx vs a queued TxItem).
    bool     gateway_deadline_expired(uint64_t enqueue_time_ms, uint64_t start_ms,
                                      uint8_t origin, uint8_t dst, uint16_t ctr);
    // [[B159]] blocker-1: the RTS HAL-handoff guard. Called immediately before each of the TWO places an RTS
    // frame reaches the HAL (lbt_complete's RTS branch, rts_duty_defer_fire), so an LBT or duty deferral cannot
    // carry a frame across the bound. true => the flight was given up LOUDLY and the caller must not transmit.
    bool     rts_handoff_deadline_cancel(uint32_t flight_gen);
    // [[B159]]: the absolute air deadline to stamp on an RTS TxParams, or 0 when the flight is not
    // gateway-bound. The HAL enforces it at the physical start; this is the only producer of a non-zero one.
    uint64_t rts_air_deadline_ms() const;
    // ---- Multi-hop gateway discovery (2026-06-14, type-4 BCN TLV): the originator's gateway SELECTION half ------
    void     ingest_bridged_layer(uint8_t gw_id, uint8_t dest_leaf);   // last-write-wins (one row per gw_id)
    void     prune_aged_bridged_layers(uint64_t now);                  // invalidate rows older than bridged_layers_ttl_ms
    size_t   build_gateway_layer_ext(uint8_t* out, size_t cap);        // our beacon's type-4 TLV (self-advert + re-gossip); 0 = none (s18-inert)
    // ---- Slice 4c.1: cross-layer DM bridge (the keystone) ------------------------------------------------------
    void     bridge_cross_layer(const PostAck& pa, const data_unicast_inner& ui);  // re-inject a transit cross-layer DM onto the far leaf
    int      id_on_leaf_by_hash(uint8_t leaf, uint32_t key_hash32) const;          // resolve key_hash32 -> node_id on a SPECIFIC leaf's id_bind (-1 = unknown); NEVER via _active->
    void     seed_seen_origin_on_leaf(uint8_t leaf, uint8_t origin, uint8_t dst, uint16_t ctr);  // loop-suppress the re-inject on the far leaf
    bool     push_xl_handoff(const XlHandoff& h);                 // buffer a handoff; false = full (refuse loud)
    void     drain_xl_handoffs_for_leaf(uint8_t leaf);           // on activate_layer(leaf): move matching handoffs into the leaf's tx_queue
    // Slice 4a': active_layer_id() (the FULL 8-bit layer_id of the ACTIVE leaf, stamped on every delivered DM/channel
    // record + Push so the app knows which layer a message arrived on) is now PUBLIC (device-console diagnostics block).
    void     start_rts_timeout();
    void     start_ack_timeout();
    void     start_pending_rx_expiry(uint8_t payload_len);
    void     rts_timeout_fire();                                  // :6326
    void     ack_timeout_fire();                                  // :6546
    void     pending_rx_expiry_fire();                            // :6699
    void     tx_rts_retry();                                      // re-pack SAME-ctr_lo RTS
    // R4.5 listen-before-talk. tx_initiating wraps an INITIATING TX (RTS/handle_rts NACK) — LBT pre-check,
    // defer at busy_until + rand(0,lbt_backoff+1) (dv:3680); tx_flood wraps a beacon (LBT + max-defer DROP +
    // duty pre-check, dv:3765); lbt_complete runs the deferred TX (+ the RTS staleness check + start_rts_timeout).
    // ★★ §MH-S1 §6.1 — `mobile_discover` IS THE COMPLETION TOKEN, and it exists because the obvious
    // alternative was MEASURED NOT TO WORK. The spec's §2.3 framing ("mobile_discover_fire ignores
    // tx_initiating's return value") UNDERSTATES the defect: checking the bool would NOT have helped,
    // because `tx_initiating` returns `schedule_lbt_defer(...)` on the defer path (node_mac.cpp) — i.e.
    // TRUE for a frame that is merely queued. §S0's M3 mutation gated the claim-guard arm on
    // `!tx_initiating(...)`, matched its anchor exactly once, and reddened NOTHING.
    // ⇒ the response window needs a signal raised WHERE THE HANDOFF HAPPENS, not where it was requested.
    // ★ U1 — THIS IS THE RTS DISCIPLINE, NOT A SECOND ONE. `LbtKind::rts` already names an initiating
    // frame whose response timeout (`start_rts_timeout`, the Lua `on_handed`) is armed by `lbt_complete`
    // AFTER `tx_with_retry`, on BOTH the immediate and the LBT-deferred entry (and by
    // `rts_duty_defer_fire` on the third). `mobile_discover` reuses that exact seam for the
    // collect-OFFERs window; see the arm in `lbt_complete`.
    // ⓘ It maps to `FrameTag::beacon` in `lbt_complete`'s tag ternary, exactly as `flood` does — so a
    //   DISCOVER's stash/retry/labelling behaviour is unchanged; the kind carries nothing but the arm.
    // ★★ §MH-S1b (QA round 2) — `mobile_claim` and `mobile_offer` EXIST FOR THE SAME REASON, AND THE REASON
    // IS THAT THE FIRST ROUND FIXED ONE OF THREE SIBLINGS. A frame accepted into the LBT defer ring reports
    // `true` upward; if the HAL later refuses it at defer-fire time, `node.cpp`'s deferred-loss arm is the
    // ONLY place that can attribute the loss — and it can only attribute what the kind names. With only
    // `mobile_discover` named there, a deferred CLAIM died anonymously while the mobile had ALREADY adopted
    // on the strength of that `true` (the fourth "success that isn't"), and a deferred OFFER died with only
    // the generic `tx_deferred_lost` line. ⇒ all three attachment frames now carry their own kind:
    //   · `mobile_discover` arms the collect-OFFERs window at the handoff (§6.1);
    //   · `mobile_claim`    ADOPTS at the handoff — never before it (§6.3);
    //   · `mobile_offer`    emits the honest `mobile_offer_tx` at the handoff (§6.2/§10).
    // All three map to `FrameTag::beacon` below, exactly as `flood` did, so stash/retry/labelling is
    // unchanged and a clear-channel path is byte-identical to the pre-slice ordering.
    // ★★★ §B186a 2026-08-12 — `mobile_reclaim` IS A FOURTH KIND, AND IT IS THE WHOLE OF "CAPTURE IT BEFORE THE
    // HAND-OFF". A re-CLAIM used to travel as `mobile_claim`, so the four mobile attachment frames reached the
    // transmitter under THREE identities and the two CLAIMs were indistinguishable downstream. The only place that
    // knows which one it is, is the site that DECIDED to send it (`mobile_claim_guard_fire` vs
    // `mobile_reclaim_send`) — so the fact is established THERE, by the act, and carried in the carriers that
    // already exist (`DeferredLbt::kind` for a deferred frame; `TxParams::tag`'s high byte for the radio).
    // ⛔ IT MUST NOT BE RECONSTRUCTED FROM FSM STATE AT REFUSAL TIME: by the time an asynchronous refusal arrives
    //    the attachment FSM may have moved on, and a reconstructed answer would be a false attribution wearing a
    //    diagnostic's name. (`mobile_reclaim_deferred_rejected()` still derives its REFUND decision that way —
    //    unchanged by this slice, deliberately, because changing a decision is not observability; see its note.)
    // ⓘ `mobile_reclaim` is BEHAVIOURALLY `mobile_claim` everywhere the two are tested: the stale-attachment
    //    cancel, the adopt-at-handoff line and node.cpp's deferred-loss arm all name BOTH, so nothing about a
    //    re-CLAIM's handling changed. Only its NAME downstream did.
    enum class LbtKind : uint8_t { rts = 0, nack = 1, flood = 2, mobile_discover = 3, mobile_claim = 4, mobile_offer = 5,
                                  mobile_reclaim = 6 };
    // R4.5b frame-type tag (echoed by the sim in on_radio_busy; identifies a blocked TX heap-free).
    enum class FrameTag : uint16_t { rts = 0, cts = 1, data = 2, ack = 3, nack = 4, beacon = 5 };
    // ★ §id-hash S1c/S1d: returns FALSE iff the frame was DROPPED — a full LBT defer ring, or a HAL rejection. A
    // successful DEFER is TRUE: it was ACCEPTED, which is the boundary the owner ruled (2026-08-01); it is NOT a
    // promise that it flew, and a deferred frame that dies later is reported by node.cpp's defer arm.
    // NOT `[[nodiscard]]` — the ~22
    // best-effort callers legitimately ignore it; only `emit_hash_query` reads it, because only it feeds a contract
    // event that ASSERTS a frame left. See the definition for why lbt_complete's RTS-only bails are excluded.
    // §MH-S1: `out` (optional) discriminates the two `false` outcomes and the two `true` ones; see TxAdmission.
    // ★★★ [[B142]] 2026-08-07 — THE `completion_gen` CONTRACT (renamed from `rts_flight_gen`; read this before
    // passing anything but 0). It is the identity of the TRANSACTION a deferred completion belongs to, and it
    // has exactly TWO named producers. A completion whose stored token differs from the producer's CURRENT
    // token is STALE and must do nothing at all:
    //   · `LbtKind::rts`                             ⇒ `PendingTx::flight_gen` (`_flight_gen`, bumped per flight
    //     in `issue_send`). The original use; `lbt_complete` cancels a deferred RTS whose flight was replaced.
    //   · `LbtKind::mobile_discover` / `mobile_claim` ⇒ `_mobile_attach_gen`, the mobile ATTACHMENT-transaction
    //     generation (bumped in `mobile_discover_fire`; the CLAIM INHERITS its DISCOVER's value, it does not
    //     bump). This is [[B142]]: without it the deferred ring correlated a completion by `LbtKind` ALONE, so a
    //     stale DISCOVER/CLAIM slot firing after the operator re-registered would transmit the OLD frame while
    //     consuming the NEW transaction's staged candidate — and on the REJECTED path would clear that
    //     candidate and arm a retry for an attempt that no longer existed.
    //   · every other kind (`nack` / `flood` / `mobile_offer`) passes 0 = NO transaction identity, and is never
    //     tested for staleness. ⚠ `mobile_offer` is deliberately excluded: it is the HOST side, whose staging is
    //     a single slot owned by [[B137]]/S2 — giving it an identity is that slice's, not this one's.
    // ⛔ RENAMED, NOT SILENTLY WIDENED: a carrier called `rts_*` that also carries attachment identity is the
    //    drifted-name defect class this codebase keeps paying for. If a third producer appears, add it HERE.
    bool     tx_initiating(const uint8_t* bytes, size_t len, int16_t sf, LbtKind kind, uint32_t completion_gen,
                           TxAdmission* out = nullptr);
    // §3-B.5 de-storm fire, shared by ALL THREE jittered_tx_stash.h members (§F-XL-1 H-forward ring,
    // §F-XL-2 RREQ-forward ring, §S6/QA-3b mobile-OFFER slot): tx the stashed frame at routing_sf as a
    // flood, then clear the slot so a re-entry can't double-send. The tx itself cannot live in the header
    // (it needs tx_initiating + _cfg), so this is the one Node-side half of the discipline.
    // §MH-S1 §6.2: it now RETURNS the transmitter admission (it used to discard it), because "the generic
    // jitter fire path must return/propagate transmitter admission and the admission result decides the
    // entry's fate". TRUE = handed to the radio OR accepted into the defer ring — i.e. another structure
    // now owns the frame, so releasing the slot is correct. FALSE = a DEFINITIVE rejection: nothing owns
    // it and nothing will retry it. ⚠ The slot is cleared either way (a re-entrant fire must not double-
    // send); the OFFER caller turns a `false` into an explicit, counted DROP report so the drop is not
    // silent — see `mobile_offer_admission_rejected`. The two §F-XL ring callers ignore the value: their
    // frames are best-effort flood FORWARDS whose originator re-floods, which is the same backstop.
    // §MH-S1b: `kind` defaults to `flood`, so the two §F-XL ring callers are byte-identical; the mobile-OFFER
    // slot passes `LbtKind::mobile_offer` so (a) the honest `mobile_offer_tx` is emitted at the HANDOFF, and
    // (b) a DEFERRED OFFER's later HAL refusal is attributable in node.cpp's deferred-loss arm instead of
    // dying as a generic `tx_deferred_lost`.
    bool     jtx_fire(uint8_t* buf, uint8_t& len, LbtKind kind = LbtKind::flood, TxAdmission* out = nullptr);
    void     rts_duty_defer_fire();                                // cleanup #A redo: re-check duty + hand the deferred RTS (or re-defer / drop-if-stale)
    // ★ §tx-admission TX2: false = the frame was DROPPED or SKIPPED — duty pre-check, busy-too-long, a FULL LBT
    // defer ring, or a HAL rejection. TRUE = ADMITTED (handed to the radio, or accepted into the defer ring and
    // scheduled) — the same acceptance boundary the owner ruled for `reqpubkey_sent`.
    // ⚠ LOAD-BEARING BEYOND TELEMETRY: `emit_beacon` gates `commit_channel_digest_advertised` on this, so a `true`
    // for a dropped beacon burns an advertisement horizon and can retire a digest nobody received.
    // ★ §tx-admission TX3: `digest_ids`/`n` are the channel-digest entries this beacon advertised. tx_flood now OWNS
    // the commit, because only it knows WHERE admission happened: immediate `_hal.tx` == ok -> commit here; accepted
    // into the defer ring -> the ids ride the slot and node.cpp's defer arm commits iff DeviceHal later answers ok;
    // dropped (duty / busy-too-long / ring full / HAL reject) -> NO commit, the entry stays dirty.
    bool     tx_flood(const uint8_t* bytes, size_t len, int16_t sf,
                      const uint32_t* digest_ids = nullptr, uint8_t digest_n = 0);
    // §tx-admission TX1: FALSE iff the HAL REJECTED the frame (a definitive drop). THREE early-outs return true —
    // the two RTS-only ones (a stale-flight CANCEL abandons a flight that is already gone; the duty defer re-arms
    // kRtsDutyDeferTimerId) and, since [[B142]], the STALE-ATTACHMENT cancel (a `mobile_discover`/`mobile_claim`
    // whose `completion_gen` no longer matches `_mobile_attach_gen`). None is a loss to report: in every one the
    // transaction that owned the frame is already gone, so reporting a loss would make the deferred-loss arm
    // destroy the CURRENT transaction's state — which is the [[B142]] defect itself, not its fix.
    // Unreachable from the one reader anyway: emit_hash_query always passes LbtKind::flood.
    bool     lbt_complete(const uint8_t* bytes, size_t len, int16_t sf, LbtKind kind, uint32_t completion_gen);
    bool     schedule_lbt_defer(const uint8_t* bytes, size_t len, int16_t sf, LbtKind kind,   // free-slot stash
                                uint32_t completion_gen, uint32_t delay,
                                const uint32_t* digest_ids = nullptr, uint8_t digest_n = 0);   // false = ring full (dropped)
    // NAV (virtual carrier sense, nav_enabled): an overheard unicast RTS/CTS reserves the medium for the rest
    // of that exchange; the node defers its own unsolicited TX (tx_initiating/tx_flood) until it clears. The
    // duration helpers are PURE (native-testable); nav_arm extends _nav_until_ms (max). Conservative SF/size.
    // §rts-cr-overhear: `data_cr` is the CR of the PEER that will send the reserved DATA — the whole frame we
    // are reserving for is somebody else's, so it is NOT active_cr(). No default: every caller must state
    // where its CR came from (C2 fail loud), because the two overheard-CTS callers CANNOT know it (see below).
    uint32_t nav_duration_rts(uint8_t data_sf, uint8_t payload_len, uint8_t data_cr) const;  // overheard RTS -> CTS+DATA+ACK+gaps
    uint32_t nav_duration_cts(uint8_t data_sf, uint8_t payload_len, uint8_t data_cr) const;  // overheard CTS -> DATA(exact, or max if payload_len=0)+ACK+gaps
    void     nav_arm(uint32_t duration_ms);                                 // _nav_until_ms = max(_nav_until_ms, now+dur)
    bool     reserve_yield(uint32_t reserve_ms);                            // spec 2026-06-28: push the pending CTS/ACK timeout past an overheard reserve involving our next-hop, NO retry burned; lifetime-bounded (no starvation). Returns true if yielded.
    // ★★★ §tx-admission TX1 (2026-08-01): tx_with_retry's disposition. It used to be a `bool handed` that was TRUE
    // whenever the frame reached `_hal.tx`, **whatever the HAL answered** — and `DeviceHal::tx` returns `busy` on a
    // full 8-entry ring, bumps `txq_drops` and DOES NOT RETAIN the frame. So a definitive hardware drop read as
    // "handed" all the way up to the app.
    // ⚠⚠ THE THREE-WAY SPLIT IS LOAD-BEARING, and a two-way `false-on-rejection` would have caused a REGRESSION —
    // this is the finding that shaped the slice. `tx_with_retry` has THREE readers (duty_defer_fire, and both
    // do_data_tx arms) and every one of them uses the answer to decide *"arm the post-TX state?"*. Their existing
    // `false` means **"not sent, but a re-send timer IS armed"** (the duty defer). A HAL rejection arms NOTHING, so
    // folding it into that same `false` would suppress `start_ack_timeout()` on a dropped DATA and leave the flight
    // with **no recovery at all** — strictly worse than the reporting defect being fixed. For a retry-eligible frame
    // the MAC timeout IS the recovery (`device_hal.h`'s "MAC timeouts recover the frame"), so those readers must keep
    // arming it. They therefore branch on `!= deferred_retry_armed`, which is EXACTLY their old `true`.
    // ⇒ only `slot < 0` frames (RTS / beacon-flood) have no stash and no MAC timeout, and among those only the H
    //   query reports a disposition to an app — which is why S1d reads this and nothing else does.
    enum class TxHandOff : uint8_t {
        handed = 0,             // the HAL accepted it (queued for the radio)
        deferred_retry_armed,   // NOT sent — the duty pre-check deferred it and kDutyDeferTimerId+slot will re-run
        rejected                // the HAL REFUSED it (busy / too_long / radio_error): dropped, nothing will retry
    };
    // R4.5b: the central TX helper (Lua tx_with_retry dv:3599) — stash the retry-eligible frame + set the
    // frame-type tag + duty pre-check + _hal.tx. Every TX except the beacon routes through it.
    // §B186a: `op` is the MOBILE TX-OPERATION IDENTITY, defaulting to `none` so all ~30 non-mobile callers are
    // untouched. It ONLY colours `TxParams::tag`'s high byte — it changes no branch, no stash slot and no label.
    TxHandOff tx_with_retry(const uint8_t* bytes, size_t len, int16_t sf, FrameTag tag,
                            MobileTxOp op = MobileTxOp::none);   // §tx-admission TX1: handed / deferred_retry_armed / rejected
    void     retry_stashed(uint8_t slot);                          // re-issue a stashed frame (kRadioBusyRetryTimerId+slot)
    void     duty_defer_fire(uint8_t slot);                        // re-run tx_with_retry from the stash after a duty defer (kDutyDeferTimerId+slot)
    bool     duty_over_budget(size_t len, int16_t sf, uint32_t* wait_ms);   // check_duty_cycle dv:3573; *wait_ms = defer time when over budget
    static int retry_slot_of(FrameTag tag);                        // FrameTag -> stash slot (0..3) or -1 (not eligible)
    static const char* label_of_frame(FrameTag tag);              // FrameTag -> "RTS"/"CTS"/...
    // ★★★ §T1 2026-08-14 — THE ONE `TxParams` BUILDER. Every `_hal.tx()` hand-off in lib/core builds its params
    // here (four sites), so a fifth site cannot silently omit a field — the S1/L9 field-drop shape (U2).
    // ⛔⛔ `flight_seq` IS AN ARGUMENT AND THIS FUNCTION DERIVES NOTHING. It must never read `_pending_tx` (it is
    //    `static` so that it cannot): `retry_stashed` transmits with NO pre-transmit flight guard, so its frame may
    //    belong to a SUPERSEDED flight, and a derived identity would confirm the WRONG one. See hal.h's TxParams::seq.
    static TxParams tx_params_of(uint16_t tag, int16_t sf, uint32_t flight_seq,
                                uint64_t deadline_ms = 0);   // [[B159]]: 0 = the no-deadline sentinel
    // §B186a decoders/derivations. `frame_tag_of` is the ONE place the mobile-op high byte is masked off, so the
    // retry/label/giveup paths keep seeing the pre-slice values; `mobile_op_of_kind` derives the op from the kind
    // the SENDING SITE chose, which is what makes the identity captured-at-the-act rather than reconstructed.
    static uint16_t    tx_tag_of(FrameTag t, MobileTxOp op);       // THE one encoder: (op << 8) | FrameTag
    static FrameTag    frame_tag_of(uint16_t tag);                 // tag's low byte -> FrameTag (verbatim pre-slice values)
    static MobileTxOp  mobile_op_of_kind(LbtKind kind);            // LbtKind -> MobileTxOp (non-mobile kinds -> none)
    static const char* busy_reason_name(BusyReason r);             // BusyReason -> "channel_busy"/... (telemetry only)
    // ---- cascade-to-alt walk + no-route defer+Q ----------------------------
    uint8_t  pick_next_cascade_hop(const PendingTx& pt);          // two-pass walk :5430; 0 = none (NON-const: refreshes the route order first)
    bool     next_hop_selectable(const RtCandidate& c, const PendingTx& pt,
                                 bool allow_uphill) const;        // minimal filter :3990
    // ★ §CUSTODY-E: the ROOT STAGE travels as a TYPED argument from the timer that fired, alongside — never
    //   inside — the give-up EVENT NAME. The string stays because telemetry names two distinct events per stage
    //   ("rts_giveup"/"rts_silent_cascade"), which no 2-value enum can carry; ⛔ but it is no longer parsed.
    void     cascade_to_alt(CustodyRootStage stage, const char* trigger);        // on giveup: switch hop or requeue :6456
    void     try_cascade_requeue(const PendingTx& pt, CustodyRootStage stage, const char* giveup_event,
                                 bool repair_attempted);                          // exhaustion -> requeue/giveup :6190
    // §3-B.2: the TERMINAL giveup of the live flight — tell the app, drop the flight, re-service the queue. Deliberately
    // does NOT absorb the caller's `return`: the 6 sites return differently (bare `return`, `return true`, or fall out of
    // an if/else to a shared `return`), and hiding control flow inside a helper is worse than the duplication it saves.
    void     giveup_flight(SendFailReason reason, uint8_t dst, uint16_t ctr);   // push_send_failed + _pending_tx.reset() + become_free(), in that order
    // ★★★ §CUSTODY-E — THE SELECTED CUSTODY-ELIGIBLE CASCADE TERMINAL: the §11 seven-step order, steps 1-6, with
    //     step 7's insertion point named at the end. ⛔ ONLY the three §9.4-representable branches call it; every
    //     other carrier death (gateway timeout, no-route, NACK, purge, pack-fail, LBT stash) keeps plain
    //     `giveup_flight`/`terminal_carrier_outcome` and stays OUTSIDE the typed custody seam (design §9.4/§10.2).
    void     cascade_terminal_giveup(const PendingTx& pt, CustodyRootStage stage,
                                     CustodyFailureReason cause, bool repair_attempted);
    // ★★★★ §CUSTODY-F — **STEP 7, IN TWO HALVES, AND THE SPLIT IS THE LIFETIME RULE** (design §11).
    //   `custody_notice_snapshot` runs at step (1), while the carrier is ALIVE: it answers §10.1's twelve
    //   eligibility conditions and materializes the bounded §9.2 record. ⛔ It is `const` and takes `pt` by
    //   const reference — it reads the authoritative carrier once and copies out 24 bytes' worth of VALUES,
    //   never the ~352-B `PendingTx`.
    //   `custody_notice_enqueue` runs at step (7), AFTER `become_free()` has had its chance to install the next
    //   queued flight: it originates ONE `DATA_TYPE_CUSTODY_FAILURE` through the existing typed-DATA enqueue
    //   path. ⛔ An ineligible snapshot is a silent no-op — eligibility was decided upstream, at the only moment
    //   the evidence existed.
    // ⛔ THEY MUST NOT BE MERGED: a single function called at step 7 could not see the carrier, and one called
    //   at step 1 would queue the notice BEFORE the failed flight was closed (§12's first bullet) and could
    //   preempt the flight `become_free()` installs.
    CustodyNoticeSnapshot custody_notice_snapshot(const PendingTx& pt, const TerminalCustodyContext& ctx) const;
    void                  custody_notice_enqueue(const CustodyNoticeSnapshot& snap);
    // §CUSTODY-E test observation (native/simulator builds only; a no-op inline on every board). See node_cascade.cpp.
#ifdef MESHROUTE_NATIVE
    static void custody_terminal_observe(const TerminalCustodyContext& c);
#else
    static void custody_terminal_observe(const TerminalCustodyContext&) {}
#endif
public:
    // ④ load-adaptive cascade budget (Lua cascade_load_skip dv:6275): the effective requeue budget at a given TX-queue
    // depth = cascade_requeue_max − max(0, depth − threshold), clamped ≥0. Pure (depth + constants); static for tests.
    static int cascade_effective_max(uint8_t queue_depth);
    // ★★★★ §CUSTODY-E — **THE ONE CASCADE-TERMINAL CAUSE AUTHORITY** (design §9.4), and it is `try_cascade_requeue`'s
    //      BRANCH PREDICATE as well as its diagnostic label. That dual role is the design, not an economy:
    //      a wrong answer here does not merely mislabel a future notice, it sends the carrier down the wrong arm
    //      (or requeues a flight that must die), so the wiring is behaviourally load-bearing instead of decorative.
    // ⛔ PRECEDENCE IS `cascade_count` -> `cascade_age` -> `queue_full` -> `load_shed`, which reproduces the
    //    pre-slice condition's own evaluation order EXACTLY (`count_done || age_done || queue >= cap`, then the
    //    load-shed test) — the diagnostic is deterministic when several are simultaneously true, and the terminal
    //    DECISION is byte-identical to what it replaced.
    // ⛔ `invalid` means **NOT TERMINAL** — the flight is requeued. It is the same value §9.4 reserves as "never
    //    transmitted", which is exactly right: no notice can be built from a carrier that did not die.
    // ⓘ Pure (its three inputs + protocol constants + `cascade_effective_max`); static so §18.4.7's per-cause
    //   cases can drive it directly rather than through a fixture that can only reach some of its arms.
    static CustodyFailureReason cascade_terminal_cause(uint8_t requeue_count, uint64_t age_ms,
                                                       uint8_t queue_depth);
    // §CUSTODY-E: the ROOT STAGE -> `SendFailReason` mapping, replacing `giveup_fail_reason`'s prefix match on
    // "rts_*"/"data_ack_*". Same two answers, from the timer identity instead of a string (design §11).
    static SendFailReason custody_stage_fail_reason(CustodyRootStage stage);
#ifdef MESHROUTE_NATIVE
    // §CUSTODY-E test observation — see `custody_terminal_observe` in node_cascade.cpp for the full contract and
    // for why it is native-only.
    // ⓘ CORRECTED 2026-08-31 (§CUSTODY-F): this note read *"⚠ Slice F retires it: once a real 0x81 notice is
    //   enqueued, the context is observable as traffic and an out-of-band recorder stops earning its place."*
    //   **F DID NOT RETIRE IT, AND THE REASON IS A MEASUREMENT RATHER THAN A PREFERENCE:** only an §10.1-ELIGIBLE
    //   terminal becomes traffic. The LOCAL-ORIGINATION terminals (§CUSTODY-E/2, /3, /4a-e, /5) and every
    //   INELIGIBLE transit terminal deliberately emit no notice at all, so for them the typed context is still
    //   the ONLY observable — and those are exactly the cases §18.4.7's per-cause bar is proved on.
    static const TerminalCustodyContext& test_last_terminal_custody_ctx();
    static void                          test_reset_terminal_custody_ctx();
#endif
private:
    uint32_t requeue_backoff_ms(uint8_t requeue_count) const;     // pure base*2^(n-1) capped :6209
    uint8_t  effective_rts_max_retries(uint8_t requeue_count) const;  // max(0, max-requeue_count) :3119
    void     defer_send(const TxItem& item);                      // no route yet -> hold (originator) :5545
    void     try_drain_deferred();                                // TTL-first, route-exists drain :6765
    bool     alt_tried(const PendingTx& pt, uint8_t hop) const;
    void     mark_tried(PendingTx& pt, uint8_t hop);
    uint16_t peek_next_ctr(uint8_t dst) const;                    // B251: read the next destination-scoped value without allocating it (single-threaded pre-ACK admission)
    uint16_t next_ctr(uint8_t dst);                               // per-(self,dst) counter (NOT rand)
    uint8_t  select_data_sf(uint8_t rts_sf_index, int16_t rx_snr_q4) const;  // adaptive DATA SF, Lua :3043+:3027
    uint32_t airtime_routing_ms(uint16_t len) const;             // floor-exact, for timeout sizing
    // Anti-spam v2 (MF3/MF8): the channel-capacity C = max(1, D/T_ch) with T_ch = RTS-M + DATA-M airtime. THE single
    // source of C — BOTH channel_cap_origin() (the enforced cap) and limits_snapshot() (the ch_ceiling shown to the
    // user) call it, so the displayed ceiling can never drift from the enforced math. Returns 0 when duty is disabled.
    uint32_t channel_capacity_C() const;
    // retry_jitter_ms() is declared in the public section (R3.x golden test).

    // ============================ Node-global state (cleanup 2026-07-15: by-concern sections; behavior-preserving) ============================
    Hal&     _hal;                // injected platform (radio/clock/timers) — ctor init-list [1]

    // ---- IDENTITY (Node-global) ----
    uint8_t  _node_id;            // ctor init-list [2]; reassignable via _hal.set_protocol_id (join/lease)
    // TEAM-plane id — DELIBERATELY kept HERE (between _node_id & _key_hash32): on 4B-pointer targets these two bytes
    // fill the pre-_key_hash32 padding, so relocating them costs +8 B on the team/mobile builds (measured via the
    // per-board .bss diff — native's 8B alignment hides it). Layout-invariance wins over grouping; do NOT move this pair.
    // (The rest of the team/mobile-member plane groups in a later increment; this stays put.)
#if MR_FEAT_TEAM
    uint8_t  _team_local_id = 0;  // §mobile 6.4: the member's id on the TEAM plane (self-assigned by team-DAD, no host; persistent). 0 = not team-DAD'd (a non-team node, or a team member mid-DAD). The 6.2 team plane (_team_peer/_rt_team, team beacon src, team frames) keys on THIS; the static plane keys on _node_id. §18: _rt_team keeps the two id-spaces from colliding.
    bool     _team_dad_pending = false;  // §mobile 6.4: true during the team-DAD guard window (tentative _team_local_id) -> a same-team src collision RE-PICKS; after (confirmed) -> DEFEND (DENY).
    // §team-ch-key (T-K1): 1 = _team_ch_pub/_team_ch_priv (E2E CRYPTO section below) hold a real keypair.
    // ★ DELIBERATELY SPLIT from the keys it describes, for the SAME measured reason the pair above sits here:
    // byte 19 is pure alignment padding ahead of the 4-aligned _key_hash32, so this flag costs ZERO bytes at
    // this offset and EIGHT beside the keys (the 65 B of new state would round the +64 up to +72 — measured,
    // see the sizeof(Node) ledger at the end of this header). Layout-invariance over grouping, as above.
    bool     _team_ch_key_present = false;
#endif
    uint32_t _key_hash32;         // ctor init-list [3]; stable long identity
    char     _name[32] = {};      // §1.3: human label (the /mrid IdBlob.name, <=32 B); empty -> effective_name() defaults to "MeshRoute node: 0x<hash>"
    uint8_t  _name_len = 0;

    // ---- E2E CRYPTO (Node-global) ----
    uint8_t  _x_secret[32] = {};  // DP1: X25519 ECDH secret (Phase-1 E2E DM crypto)
    uint8_t  _ed_pub[32]   = {};  // DP1: our Ed25519 pubkey (advertised so peers can ECDH to us)
#if MR_FEAT_TEAM
    // §team-ch-key (T-K1, spec 2026-07-26 §2.1): the TEAM CHANNEL content keypair. X25519, dedicated — NOT
    // derived from the identity seed above, NOT a team_id input. Stored in CANONICAL (clamped) form; see
    // team_channel_key_derive in identity.h for why that matters. The has-key flag lives in the IDENTITY
    // block above (it is free there and costs 8 B here — see the note at it).
    // ⚠ MARK OF WHAT IS *NOT* DONE:
    //   · DONE — T-K3 reads them: team_key_grant_send seals _team_ch_priv into a DATA_TYPE_TEAM_KEY_GRANT, and
    //     team_key_grant_receive adopts one. So the pair has a producer AND a consumer.
    //   · ✅ RULED AND BUILT (§o3-key-lifetime, owner ruling 2026-07-31): set_team_id() DOES clear them now —
    //     the first of the two candidate fixes this note used to leave open (clear on switch), chosen over
    //     storing an owning team_id beside the pair. A `team <other-id>` switch and `team 0` both leave the
    //     node KEYLESS; the recovery is a teammate's re-grant or a QR, never a local regeneration.
    //     ⓘ The one exception lives at the console caller, not here: handle_team carries a pair minted/adopted
    //     FOR THE TEAM BEING JOINED across the switch (see its §o3-key-lifetime note).
    //   · STILL MISSING — the SEAL. The encrypted channel flavour + seal/open and the un-keyed-receiver drop
    //     push (T-K2, now slice CL2a) are the reason the clear above had to land FIRST: until something seals,
    //     the clear is inert, which is exactly what made it attributable as its own slice.
    uint8_t  _team_ch_pub[32]  = {};
    uint8_t  _team_ch_priv[32] = {};
#endif
    bool     _crypto_ready = false;
    uint16_t _relay_seal_ctr = 0; // §S4 SEALED_RELAY: a dedicated per-node nonce ctr, CARRIED in the relay body (NOT the MAC frame ctr — that stays the delegating home's for dedup). Uniqueness rides the random seed8; this ctr is defense-in-depth (matches the same-layer seal's ctr role). Pre-incremented per relay seal.

    // ---- REMOTE-MGMT (Node-global) ----
#if MR_FEAT_REMOTE_MGMT
    uint8_t  _admin_pubkey[32] = {};   // §remote-mgmt: pinned admin Ed25519 pubkey (trust anchor)
    uint32_t _admin_counter_floor = 0; // §remote-mgmt: replay floor (persisted, write-coalesced)
    bool     _admin_provisioned = false;
#endif

    // ★★ §chan-crypt CL2a: the sealed-channel-post nonce ctr — the SAME shape as `_relay_seal_ctr` above, a dedicated
    // per-node counter CARRIED in the body `[seal_ctr 2][seed8 8][ct‖tag]` (the M frame has no ctr field at all;
    // enqueue_channel_m DERIVES its MAC ctr from the msg id, so there is nothing on the frame to reuse).
    // ⚠⚠ AND HERE THE CTR IS EVEN LESS LOAD-BEARING THAN THE RELAY ONE, deliberately: every member seals under the
    // SAME team content key, so two members trivially hold the same counter value. Cross-member nonce separation
    // rides (a) the FRESH 8-B random seed and (b) the channel_msg_id bound into the nonce — which carries the origin
    // id AND 16 bits of the sender's key_hash32, so two members differ even on an identical (seed, ctr). This ctr is
    // defence in depth for the SELF-collision case only. Pre-incremented per seal.
    // ★ PLACEMENT — MEASURED, not chosen for tidiness, and it is worth the two lines: this belongs semantically next
    // to `_relay_seal_ctr` (native offset 186) and putting it there costs EIGHT bytes, not two. Measured by offsetof:
    // Historically, at 188 it pushed `_admin_pubkey` 188->190, which pushes the 4-aligned `_admin_counter_floor` 220->224 (2 new pad
    // bytes) and the 8-aligned `_cfg` 472->480 (6 more) => sizeof(Node) +8. HERE it lands at 470, in the 2-byte
    // historical alignment pad before `_cfg`. In 8a the legacy slot is removed and the CLIENT block
    // follows this counter; the measured R-RA-45 credit is 240 native /248 mobile bytes.
    // EIGHTH application of the radio_freq_mhz / team_hop_cap / HashQuerySeen.team_scoped / T5-PeerLiveness /
    // T-K1-_team_ch_key_present / AB4-_peer_loc_n / CL2a-team_channel_crypt padding-placement rule.
    uint16_t _channel_seal_ctr = 0;
#if MR_FEAT_RADMIN_CLIENT
    // R-RA-45: pointer-free controller block, 4512/8. Replaces the legacy 245/1 slot.
    RemoteClientState _remote_client{};
#endif
#if MR_FEAT_RADMIN_ACCEPT
    // ★★★ §remote-admin v2 SLICE 5 — **THE ONE ACCEPT-ONLY REMOTE-ADMIN STATE BLOCK.** 2 064 bytes, alignof 8, and
    //   every byte of it is attributed at the `static_assert` in `remote_session.cpp`: pair 64 + ACL 340 +
    //   status 4 + epochs 80 + seen 896 + headers 80 + bodies 472 + staging 128.
    // ★ PLACEMENT, MEASURED not chosen for tidiness — and it is the SIXTEENTH application of the radio_freq_mhz /
    //   team_hop_cap / T-K1 padding-placement rule. This historical Slice-5 placement is followed by
    //   the measured 7b growth and R-RA-45 CLIENT replacement; the current ABI pins cover all padding.
    // ⚠ IT IS ROLE-GATED, so the movement is ⛔ NOT uniform across ABIs — the opposite of §B278 S1a's ring:
    //   native (R-RA-17 `{1,1}`) and gateway pay it, `heltec_mobile` (CLIENT) pays ZERO and is the UNMOVED
    //   CONTROL for the R-RA-31 re-pin. See the `sizeof(Node)` ledger at the end of this header.
    // ⛔ `TimerWheel::kCap` DOES move for this slice (91 -> 92) and exactly ONE id is allocated
    //   (`kRadminExpiryTimerId`) — but the wheel lives in `DeviceHal`, ⛔ NOT in `Node`, so that +8 is HAL RAM on
    //   EVERY build including `heltec_mobile` and is ⛔ not part of this member's cost.
    RemoteSessionState _radmin_session{};
#endif

    // ---- CONFIG ----
    NodeConfig _cfg;             // borrowed copy from on_init

    // ---- INBOX ----
    Inbox    _inbox;             // persistent inbox (disabled until a backend installs stores; see inbox())

    // ======== ROUTING witnesses (Node-global) ========
    int16_t  _routing_snr_floor_q4 = 0;   // SF_DEMOD_THRESHOLD[routing_sf] + sf_margin_q4
    bool     _rt_full_emitted = false;

    // ======== BEACON / R2 discovery (Node-global) ========
    uint8_t  _beacon_offset = 0;             // sliding stable-page rotation cursor
    bool     _pending_rediscover = false;     // reprovision verb -> restart discovery at the next join_adopt (id stable)
    bool     _triggered_beacon_pending = false;  // coalesce: gates BEFORE the rand draw
    uint64_t _last_beacon_tx_ms = 0;

    // ======== DUTY / airtime (Node-global) ========
    uint64_t _duty_cycle_budget_ms = 0;          // R4.0: floor(duty_cycle*window), derived in on_init; 0 = disabled
    uint16_t _dm_payload_mean = 0;               // §3e: EWMA (alpha 5/16) of DATA payloads we pass; 0 = no sample (use assumption)
    // (_window_epoch_ms relocated to the GATEWAY / CROSS-LAYER scheduler section below — it was orphaned here among the duty/R4.3 witnesses; cleanup 2026-07-15.)
    // ---- R4.3 CHANNEL-BUSY witnesses (adaptive throttle; pure timestamps, no rand) ----
    // R4.3 adaptive-throttle witnesses (channel-busy detector). Pure timestamps, no rand.
    uint64_t _last_rx_routing_sf_ms = 0;         // any successful decode OR preamble-detect (dv:9164/12231); 0 = never
    uint64_t _last_rx_bcn_ms        = 0;         // last beacon ingest (the max-idle B+C filter; dv:9559)

    // ======== MAC / FLIGHT witnesses (Node-global): LBT ring · duty-defer · tx-stash · flight_gen ========
    // R4.5 LBT: derived delays (on_init) + a small RING of deferred-TX slots. The Lua uses independent
    // per-defer closures (dv:3704/3808), so two concurrent busy-channel defers BOTH fire — a single stash
    // would drop the first + desync the rand stream. Each slot has its own timer id (kLbtDeferTimerId+slot).
    // buf holds a full beacon (beacon_max_bytes=151) — a smaller buf would TRUNCATE a deferred page (review #04).
    uint32_t _lbt_backoff_ms        = 0;
    uint32_t _flood_lbt_max_defer_ms = 0;
    uint64_t _nav_until_ms          = 0;         // NAV: medium reserved (by an overheard unicast RTS/CTS) until this ms; 0 = clear
    static constexpr uint8_t kLbtSlots = 4;
    // ★★★ §tx-admission TX3 (OWNER RULING 2026-08-02): a deferred BEACON carries the digest ids it advertised, so the
    // channel-digest commit can happen at the TRANSMITTER-ADMISSION boundary instead of at ring entry.
    // ⚠ THE RULING REVERSED THE EARLIER CALL, and the reason is worth keeping: the `reqpubkey_sent` ruling settled an
    // APP EVENT; digest retirement is an INDEPENDENTLY load-bearing state machine (`++bcn_ad_count`, and on horizon
    // `dirty = false`), so extending the app-event boundary to it was a design decision, not an implementation
    // detail. It now has its own ruling: **"sent" = accepted by the transmitter/DeviceHal** — the digest commit
    // boundary, even though §T2 separately observes hardware completion.
    // ★ WHAT THIS BOUNDARY IS NOT: a later `DeviceHal::pump_tx` radio-start error (`start_transmit` -> radio_error)
    //   drops the frame AFTER admission and is **outside** the guarantee. It is now reported as `tx_failed`, but
    //   moving the boundary is a separate decision; do not describe it as covered.
    // ⓘ `digest_ids[0] == 0` terminates: a live channel id can never be 0 (`channel_msg_id_mint` packs origin >= 1
    //   into the high byte), and `channel_buffer_find(0)` therefore misses — so no count byte is needed.
    static constexpr uint8_t kDeferDigestIds = 3;   // == the digest select cap (emit_beacon picks <= 3)
    struct DeferredLbt { bool pending = false; uint8_t kind = 0; uint8_t len = 0; int16_t sf = 0;
                         // ★★★ [[B142]] 2026-08-07 — RENAMED FROM `rts_flight_gen`, BECAUSE IT NO LONGER CARRIES
                         // ONLY AN RTS FLIGHT, AND A SILENT OVERLOAD IS EXACTLY THE DRIFT THIS PROJECT KEEPS
                         // FIXING. ONE FIELD, ONE CONTRACT, TWO NAMED PRODUCERS — see the `completion_gen`
                         // contract block above `tx_initiating`. The staleness TEST is identical for both
                         // (`stored != current` ⇒ the transaction this completion belongs to is gone), which is
                         // why generalising the carrier is U1 and not a second mechanism.
                         uint32_t completion_gen = 0;   // 0 = no transaction identity (flood/nack/mobile_offer: never stale)
                         uint32_t digest_ids[kDeferDigestIds] = {};   // §TX3: beacon only; 0 = unused
                         uint8_t buf[protocol::beacon_max_bytes] = {}; };
    DeferredLbt _deferred_lbt[kLbtSlots];
    // Cleanup #A redo: an over-budget RTS is duty-deferred in a DEDICATED slot (NOT the shared LBT ring — that reuse
    // was net-worse, review wgvbtirmu). One slot: there is only ever one pending_tx/flight. flight_gen staleness makes
    // the long (~1h) duty wait safe. kRtsDutyDeferTimerId fires rts_duty_defer_fire (re-check duty / hand / re-defer).
    uint32_t _flight_gen = 0;     // monotonic; bumped per new pending_tx (issue_send)
    struct RtsDutyDefer { bool pending = false; uint16_t len = 0; int16_t sf = 0; uint32_t flight_gen = 0;
                          uint8_t buf[16] = {}; };   // RTS pack is <=9 B (RTS_LEN 8 + M-broadcast 2)
    RtsDutyDefer _rts_duty_defer;
    // R4.5b on_radio_busy retry: a per-frame-type tag (echoed by the sim) lets on_radio_busy identify a blocked
    // TX (heap-free, no string label). The retry-eligible frames (CTS/DATA/ACK/NACK; RTS/beacon are NOT) are
    // STASHED so a busy-channel block re-issues them up to TX_DEFER_MAX_RETRIES. tx_stash keyed by the retry slot.
    static constexpr uint8_t kRetrySlots = 4;   // cts, data, ack, nack
    struct TxStashSlot { bool valid = false; uint16_t len = 0; int16_t sf = 0; uint8_t retries_left = 0;
                         uint32_t flight_gen = 0;   // L9: DATA slot — the EXACT pending_tx flight this DATA belongs to (re-arm guard). Was the 4-bit ctr_lo (dv:10271) whose 1/16 aliasing let a re-arm fire against a since-replaced flight; flight_gen is the monotonic per-flight identity (issue_send) so the match is exact.
                         // reissue_pending: a busy/duty re-issue timer is ARMED for this slot (vs. a stale clean-sent
                         // buffer that is `valid` but already on the air). layer_swap_blocked() gates on THIS, not
                         // `valid` — else a gateway's first cleanly-sent ACK leaves `valid` set forever + the layer
                         // swap never fires (the bridged DM on the other leaf never transmits). See node.cpp swap guard.
                         bool reissue_pending = false;
                         uint8_t buf[protocol::lora_max_frame_bytes] = {}; };
    TxStashSlot _tx_stash[kRetrySlots];
    // R3 data-plane state (single flight per node) — the pipeline arrays MOVED into LayerRuntime (Slice 2a).
    // kTxQueueCap stays a Node-level static constexpr (compile-time array dim, identical for every layer;
    // visible by unqualified name inside the nested LayerRuntime + in Node member fns — no per-layer state).
    static constexpr uint8_t kTxQueueCap = 8;

    // ======== LayerRuntime member TYPE defs — defined here for def-before-use; the INSTANCES live in LayerRuntime, ========
    //          NOT in Node (0 Node-layout impact). Struct-extraction to a private header is a later, separate slice.
    // F route-discovery dedup state (Lua route_request_seen / route_request_last). Members in LayerRuntime.
    // recent_ring.h contract: `t_ms` + `same_key` (the dedup key, defined ONCE for both the query and the mark).
    struct RReqSeen { uint8_t origin; uint8_t dst; uint64_t t_ms;       // relay flood-dedup
                      bool same_key(const RReqSeen& o) const { return origin == o.origin && dst == o.dst; } };
    struct RReqLast { uint8_t dst; uint8_t ttl; uint64_t t_ms; };      // per-dst origination rate-limit
    // Hash-locate id_bind table (Lua dv:4677): key_hash32 -> node_id, beacon-populated. Bounded array
    // (array sized at the protocol max; _cfg.cap_id_bind gates additions). One timestamp: id_bind_set
    // always carries the key, so last_seen == last_key_seen (the plain-refresh split lands with C.2). Member in LayerRuntime.
    struct IdBind { uint32_t key_hash32; uint64_t last_seen_ms; uint8_t node_id; uint8_t source; uint8_t confidence; };
    // §mobile 3c: a mobile's stable hash -> its home_node id (sender-side proxy cache; id_bind can't hold it). No bijection.
    struct MobileHomeBinding { uint32_t mobile_hash; uint64_t last_seen_ms; uint8_t home_id; uint8_t epoch = 0; uint8_t home_layer = 0; };  // §mobile 4a epoch (freshest-proxy wins) + §5b home_layer (the home's full layer_id, for cross-layer routing)
    // E2E peer-pubkey cache (Phase 1 §6): key_hash32 -> ed_pub. Immutable + hash-verifiable (ed_pub[:4]==key_hash32),
    // so an AUTHORITATIVE_H_ANSWER_PUBKEY owner answer is cached AUTHORITATIVE even relayed/cached-on-pass (can't decay). Member in LayerRuntime.
    struct PeerKey { uint32_t key_hash32; uint64_t last_seen_ms; uint8_t ed_pub[32]; uint8_t confidence; char name[32]; uint8_t name_len; bool peer_confirmed; };   // §1.3: name rides with the key — IMMUTABLE key, MUTABLE name (refreshed on every pubkey message). §S2: peer_confirmed = we've OPENED a SEALED frame from this peer (they hold our key) -> stop attaching INTRO to plaintext sends toward them. Set on e2e_open_trial success ONLY (never on a plaintext receipt).
    // §AB2: peer_name_set / peer_key_set / push_peer_key_cached / on_command's peername refusal all size the name by
    // protocol::peer_name_max instead of the bare literal `32` they used to repeat. Pin the two together so widening
    // `name[]` without widening the constant (or vice versa) fails the build rather than truncating silently.
    static_assert(sizeof(PeerKey::name) == protocol::peer_name_max, "node.h: PeerKey::name and protocol::peer_name_max disagree");
    // H hash-locate flood dedup (Lua hash_query_seen): per-(origin,key_hash32), hash_query_seen_ttl_ms window. Member in LayerRuntime.
    struct HashQuerySeen { uint8_t origin; uint32_t key_hash32; uint64_t t_ms; bool hard; bool want_pubkey;   // §2: WANT_PUBKEY is its own variant
                           bool team_scoped;   // ★ §team-parity T6/B: the PLANE discriminator (see below)
                           // §2: `hard` and `want_pubkey` are part of the KEY — a HARD (verify-on-use) or a
                           // WANT_PUBKEY query must NOT be suppressed by a prior plain/SOFT one's seen-entry.
                           // ★★ §team-parity T6/B (spec §3/T6 Part B, closing §10.3/§9-Q4): `team_scoped` is part of the
                           // KEY. Before T6 this ring was documented (LayerRuntime, "§P2-7 AUDIT") as safe *only by an
                           // UNWRITTEN role-exclusion invariant* — "no node today processes BOTH the static and the team
                           // H-flood plane". VERIFIED AT SOURCE, and the invariant is DEFEATABLE BY LIVE CONFIG, not
                           // merely fragile: handle_h returns before any mark for a static H iff `_cfg.is_mobile`
                           // (node_hashlocate.cpp:584) and for a team H iff `!same_team` (:603) — so a node with
                           // `team_id != 0 && !is_mobile` marks BOTH.
                           // ★★ UPDATED 2026-07-31 (§role-model / B28/R2): that config is now OUTLAWED, so this alias is
                           // UNREACHABLE BY CONFIG rather than merely keyed around — `set_team_id` DOES set is_mobile
                           // when the new team is non-zero (role_enforce, node_role.h), the NV boot restore normalises
                           // the same implication, and `cfg set mobile 0` REFUSES while in a team. (`cfg set team_id`,
                           // the other spelling this note used to name, was removed entirely — B27.) The `team_scoped`
                           // key below STAYS: it is the correct plane discriminator regardless, it costs zero bytes,
                           // and belt-and-braces beats resting a suppress-direction failure on a config invariant.
                           // The alias is not hypothetical either: `key_hash32` is a node's key, IDENTICAL on both planes
                           // (a dual member has one key, a static id and a team_local_id), so a team H and a static H for
                           // the SAME target collide as soon as the two queriers' 8-bit origins collide (§18) — and the
                           // failure direction is SUPPRESS: hash_query_seen_recently returns true and the H is never
                           // forwarded, so a locate dies silently instead of reaching the owner.
                           // Cost: ZERO bytes — `hard`/`want_pubkey`/`team_scoped` share the same 8-byte tail slot
                           // (1+3pad+4+8 then 3 bools + 5 pad = 24 B, unchanged), so sizeof(Node) does not move.
                           bool by_id;   // ★ §id-hash S4a: the KEY-SPACE discriminator (see below)
                           // ★★ §id-hash S4a (spec §4): `by_id` joins the key for the SAME reason `team_scoped` did,
                           // and the collision is arithmetic rather than hypothetical: `key_hash32` here holds the H
                           // frame's raw bytes 2-5, so a BY_ID query for **id 114** and a by-hash query for
                           // **0x00000072** are the same 32-bit value from the same origin. Without this bit one
                           // suppresses the other's FORWARD and a locate dies silently — the same failure DIRECTION
                           // team_scoped guards against. The canonical encoding (frame_codec.h
                           // `h_by_id_key_canonical`) is what makes the value itself unambiguous; this bit is what
                           // keeps the two key SPACES apart.
                           // Cost: still ZERO bytes — a FOURTH bool in the same 5-byte tail pad. MEASURED by the
                           // sizeof(Node) assert below (221024, unmoved) + offsetof, not inferred.
                           bool same_key(const HashQuerySeen& o) const {
                               return origin == o.origin && key_hash32 == o.key_hash32 && hard == o.hard
                                   && want_pubkey == o.want_pubkey && team_scoped == o.team_scoped
                                   && by_id == o.by_id; } };
    // ★ §id-hash S4a — THE ZERO-COST PLACEMENT, MEASURED HERE RATHER THAN INFERRED (and native-only: the board proof
    // is the per-env RAM diff in the slice report, which reads +0/+0/+0). Layout: origin@0, pad@1-3, key_hash32@4,
    // t_ms@8, then hard@16 / want_pubkey@17 / team_scoped@18 and FIVE bytes of tail pad. `by_id` takes @19, the first
    // of those five (⚠ I first WROTE 18 from inference and the assert below failed the build — which is the assert
    // earning its place, and the reason this line quotes a measurement). The record stays 24 B, so the
    // `[cap_hash_query_seen=64] x MR_N_LAYERS` array does not grow. NINTH application of the radio_freq_mhz /
    // team_hop_cap / HashQuerySeen.team_scoped / T5-PeerLiveness / T-K1 padding-placement rule.
    // ⓘ NOT vacuous: change `24` to `32` here, or move `by_id` above `key_hash32`, and the build fails.
    static_assert(sizeof(HashQuerySeen) == 24, "node.h: HashQuerySeen grew — the §S4a by_id bool must fit the existing tail pad");
    static_assert(offsetof(HashQuerySeen, by_id) == 19, "node.h: HashQuerySeen::by_id moved out of the tail pad");
    // Peer-liveness + freshness plane (routing-liveness port, Lua dv:3986-4545): per-next-hop RTS/ACK-timeout
    // accounting -> suspect/silent/dead tiers (each with an expiry), + dest_seen for next-hop freshness. Bounded
    // LRU table per LayerRuntime (the direct-neighbour set). node_id 0 = empty slot.
    // §P4 gossip: suspect_advertise_until_ms / dead_advertise_until_ms hold the GOSSIP window (what to put in our BCN
    // suspect-TLV), set ONLY by LOCAL rts_timeout evidence (mark_peer_suspect remote_src==0). REMOTE-learned tiers write
    // the *_until_ms routing fields but NOT these -> a node never re-gossips a suspicion it heard (anti-storm, dv:1388).
    // ★★★ §team-parity T5 (spec §3/T5) — team_bidi_state / team_bidi_confirmed_s ARE the TEAM-plane bidirectionality
    // plane: the team mirror of the STATIC _link_bidi[256] + _link_bidi_confirmed_ms[256] (below, 2304 B), which a
    // 256-entry team copy could never be on an nRF52840. They are MEANINGFUL ONLY in _team_liveness (keyed by
    // team_local_id); in _peer_liveness they are dead space — exactly as suspect_advertise_until_ms /
    // dead_advertise_until_ms are dead in _team_liveness ("A team slot NEVER carries advertise fields",
    // node_routing.cpp:644). Same precedent, in this same struct. The `team_` prefix is deliberate and load-bearing as
    // documentation: a reader who finds `_peer_liveness[i].team_bidi_state` has found a bug, because the static plane's
    // answer is _link_bidi[node_id]. ⇒ invariant I8 ("team bidi state is plane-private and never indexes _link_bidi")
    // is enforced STRUCTURALLY here — the team state is not an index into anything node_id-shaped.
    // ★★ PLACEMENT IS THE WHOLE COST OF T5's STATE, AND IT IS ZERO — measured, not argued. node_id occupies byte 0 and
    // rts_timeouts needs 2-alignment, so byte 1 was pure padding; first_timeout_ms needs 8-alignment, so bytes 4..7 were
    // pure padding. The two new members take exactly those five holes ⇒ sizeof(PeerLiveness) is 72 BEFORE and 72 AFTER,
    // so neither _peer_liveness[cap_peer_liveness=64] nor _team_liveness[cap_team_liveness=16] grows a byte on any
    // layer and sizeof(Node) does NOT move. Fourth application of the radio_freq_mhz / team_hop_cap /
    // HashQuerySeen.team_scoped placement rule.
    // ⚠ THE SPEC'S §3/T5 SHAPE WAS MEASURED AND DECLINED, with its arithmetic CONFIRMED: a dedicated
    // `_team_bidi[16]` of {uint8_t id; uint8_t state; uint32_t confirmed_s} is 8 B/entry × 16 = 128 B per layer (the
    // u64-ms form is 16 B × 16 = 256 B — alignment does NOT collapse the two, so the spec's "u32 halves it" is right).
    // Declined because (a) 128 B × MR_N_LAYERS of nRF52840 RAM buys nothing this fit does not, and (b) it would be a
    // SECOND 16-entry team_local_id-keyed table sitting beside _team_liveness with the identical cap, identical
    // self-slotted LRU and identical lifetime — the U1 field-drop fork (add a teammate to one, forget the other).
    // SECONDS, not ms: bidi_confirm_ttl_ms is 1200000 (protocol_constants.h:207) so second granularity is ample, and
    // u32 seconds is what the 4-byte hole holds. 0 = never confirmed (same sentinel as _link_bidi_confirmed_ms).
    // ⚠ NOT cleared by clear_liveness_tiers, DELIBERATELY: hearing a frame from a teammate proves it is ALIVE, which is
    // liveness; it does not prove it hears US, which is bidi. MF6 also forbids one_way decaying on mere staleness. The
    // ONLY reset is a fresh slot (peer_liveness_slot's `tbl[best] = PeerLiveness{}` on create/LRU-evict), which is
    // correct — a re-used slot is a different peer.
    struct PeerLiveness { uint8_t node_id; uint8_t team_bidi_state; uint16_t rts_timeouts; uint32_t team_bidi_confirmed_s;
                          uint64_t first_timeout_ms;
                          uint64_t suspect_until_ms; uint64_t silent_until_ms; uint64_t dead_until_ms; uint64_t dest_seen_ms;
                          uint64_t suspect_advertise_until_ms; uint64_t dead_advertise_until_ms;
                          uint64_t e2e_ack_spoof_until_ms = 0; };   // anti-spoof: while now < this, the peer's RTS_FLAG_E2E_ACK is IGNORED (backstop re-applies)
    // ★★ §team-parity T5 PLACEMENT TRIPWIRE — deliberately NOT `#ifdef MESHROUTE_NATIVE`. The 0-byte claim is an
    // ALIGNMENT claim, so it has to be proven on every ABI that compiles this header (ARM/AAPCS and Xtensa both align
    // uint64_t to 8, which is what makes the two holes exist there too), not just on the host. If a future member add or
    // reorder spills out of the holes this fails the BOARD build loudly instead of silently costing
    // 8 B × (cap_peer_liveness 64 + cap_team_liveness 16) × MR_N_LAYERS of RAM. If a reorder is intentional, re-measure
    // and update these three numbers together with the sizeof(Node) baseline below.
    static_assert(sizeof(PeerLiveness) == 72, "PeerLiveness grew: the T5 team-bidi fields no longer fit its padding holes — re-measure the RAM cost before updating this");
    static_assert(offsetof(PeerLiveness, team_bidi_state)       == 1, "T5: team_bidi_state left byte 1 (the hole after node_id)");
    static_assert(offsetof(PeerLiveness, team_bidi_confirmed_s) == 4, "T5: team_bidi_confirmed_s left bytes 4..7 (the hole before the 8-aligned first_timeout_ms)");

    // ======== PARKED-SEND / hash-resolve + L2c redirect + deleg-ack (Node-global) ========
    // send-by-hash DMs parked awaiting a hash-bind resolution (D); drained by on_hash_bind_response, aged on the timer.
    // is_redirect=true => an L2c misdelivered DM held for FORWARD (not re-send): `body`=the full inner (incl.
    // DST_HASH), and origin/ctr/ctr_lo are preserved so the resolution forwards it identity-intact. The redirect
    // leg is re-budgeted as a fresh route (originator-style), so no hop fields are carried. resolved_id==our id
    // at drain = a CONFIRMED collision (the heal trigger, design §7.1).
    struct ParkedSend { uint32_t key_hash32; uint64_t parked_at_ms; uint8_t flags; uint8_t body_len;
                        uint32_t reply_to_hash = 0;   // §mobile delegate: the HOME re-originating for its mobile parks with the mobile's hash -> SOURCE_HASH on drain, so the target's reply routes back to the mobile (0 = our own hash)
                        bool is_redirect = false; bool is_resolve = false; bool cross_layer = false; uint8_t origin = 0; uint16_t ctr = 0; uint8_t ctr_lo = 0;
                        uint8_t type = 0;   // S1/M7a: a redirect's DataType (E2E_ACK/H_ANSWER); preserved across park+heal so the forwarded frame keeps its type (only meaningful when is_redirect)
                        CryptIntent crypt = CryptIntent::def;   // M3 (2026-07-04): the per-message crypt intent stamped at park time so a `sendhashx`(crypt=on) parked awaiting a binding still flies CRYPTED on drain (never silently downgrades to cleartext, node.h invariant); threaded into both drains' do_send
                        uint8_t nonce_seed[8] = {};   // §1c: a CRYPTED redirect's originator seed (preserved across the park+heal); zero for a plain send (re-sealed on drain)
                        uint16_t mobile_ctr = 0;      // §mobile reverse-ack: a delegated re-origination carries the MOBILE's original ctr (ctr_M) so the drain records ctr_H->ctr_M (0 = not a delegated send)
                        // §F-SL-1: bounded jittered H re-flood while parked (send_by_hash origination path only). reflood=false =>
                        // this entry never re-floods (a redirect / resolve / cross-layer park keeps today's single-flood behaviour).
                        bool     reflood = false; bool reflood_hard = false; Plane reflood_plane = Plane::AUTO;
                        uint8_t  reflood_count = 0; uint64_t reflood_at_ms = 0;   // next scheduled re-flood (wall clock); the scan re-arms the shared timer to the earliest
                        uint8_t body[protocol::max_payload_bytes_hard_cap]; };   // is_resolve: notify-only diag (a `resolve`), no body. cross_layer (Slice 4d): a send_layer awaiting (node_id,target_layer)
    ParkedSend _parked_sends[protocol::cap_parked_sends] = {};
    // B251 strengthened the delegated reverse-ACK ring without growing a row: ONE `peer` field carried the requested
    // target while RESERVED and the returning ACK's discriminator once ACTIVE. §B278 S1a GENERALIZES that one ring
    // into the delegated-flight correlation row and SPLITS that field, because a custody report names the FAILED
    // static leg while the mobile's pending operation is named by the ORIGINAL target — the old row could hold only
    // one of the two (spec §4.1/§4.3).
    //   · `target` / `target_kind` are written ONCE at reservation and NEVER overwritten (the mobile-visible target:
    //     a hash-addressed wrapper's `dst_key_hash32`, or a direct transit's node id).
    //   · `return_peer` / `return_kind` are written at activation (same-layer origin id or cross-layer SOURCE_HASH).
    // ⛔ THE SPLIT IS DECISION-NEUTRAL BY CONSTRUCTION, which is what makes S1a a refactor: every RESERVED-phase
    //    comparison (reserve match, release) reads the target pair and every ACTIVE-phase comparison (activation
    //    uniqueness, put refresh, translate) reads the return pair — exactly what the single `peer` field meant in
    //    each phase. No key, refusal, eviction or release decision moves.
    // `layer` separates node-local ids across a dual-layer gateway. No live row is ever evicted.
    // `outward_type` is the DataType of the carrier the activation dispatched. ⛔ S1a STORES IT AND READS IT NOWHERE:
    //    it is not part of the reserve key, the activation-uniqueness key, the put key, the release key or the
    //    translate key. §4.4's custody-lookup cross-check is a later slice's.
    // `custody_state` is §4.5's lifecycle under this row's ONE 300 s TTL (`protocol::delegated_custody_ttl_ms`).
    //    ⛔ NOT a second clock. §B278 S1b writes it: `candidate` at RESERVE (provisional — §5's pre-hop-ACK terms),
    //    then `eligible`/`none` at ACTIVATION from the arm's own verdict. `candidate` NEVER survives activation and
    //    `forwarded` is UNREACHABLE until S3 originates a translated report.
    // ⓘ R1=A (spec §1.1(4)): a row exists only for a flight carrying DATA_FLAG_E2E_ACK_REQ, so every row is an
    //    E2E-ACK row BY CONSTRUCTION and there is no separate ACK-obligation bit to store.
    // Field order is deliberate and MEASURED, not reasoned: the 8-byte stamp, then the 4-byte run, then the 2-byte
    // run, then the byte run — 32 B / alignof 8 on host, ARM and Xtensa alike, with the two trailing pad bytes the
    // 24-byte B251 row also had. `tools/probe_b278_row_abi.py` compiles the assert below on all three toolchains
    // beside a namespace-scope mirror that prints the offsets.
    struct DelegAck {
        uint64_t ts_ms = 0;
        uint32_t mobile_hash = 0;
        uint32_t target = 0;              // RESERVE-phase identity, never overwritten
        uint32_t return_peer = 0;         // ACTIVE-phase identity, written at activation
        uint16_t ctr_h = 0;
        uint16_t ctr_m = 0;
        uint8_t layer = 0;
        uint8_t outward_type = 0;         // stored-only in S1a — no lookup reads it
        DelegAckPeer target_kind = DelegAckPeer::node_id;
        DelegAckPeer return_kind = DelegAckPeer::node_id;
        DelegAckState state = DelegAckState::free;
        DelegAckCustody custody_state = DelegAckCustody::none;
    };
    static_assert(sizeof(DelegAck) == 32, "B278 S1a: the delegated-flight correlation row is 32 B on host/ARM/Xtensa (was 24 B under B251); re-pack the bounded x8 ring before accepting further RAM cost");
    static constexpr uint8_t kDelegAckCap = 8;
    DelegAck _deleg_acks[kDelegAckCap] = {};
    // ★ E2E-ack DEADLINE ring (shelf item (i), 2026-07-24): sends awaiting their DATA_TYPE_E2E_ACK. ARMED (emit-free) when an
    // app DM with DATA_FLAG_E2E_ACK_REQ mints its ctr; CLEARED (emit-free) on the matching send_e2e_acked; EXPIRED ->
    // send_failed{e2e_ack_timeout}. NOT mobile/team-gated (a static -a send arms too). The MATCH mirrors what send_e2e_acked
    // carries {dst=acker origin, ctr=acked, sender_hash}: an XL send's ack is CROSS_LAYER (sender_hash set) -> key==sender_hash;
    // a same-layer id send's ack is same-layer (sender_hash==0) -> dst==acker origin; a delegated/wildcard entry (key==0)
    // matches on ctr alone (the delegated reverse-ack can arrive either same-layer or XL — see node_mac.cpp e2e_ack_arm).
    struct PendingE2eAck {
        uint32_t key    = 0;      // XL: the far-target key_hash32 (== send_e2e_acked.sender_hash). Same-layer id send: the dst id. 0 = wildcard (delegated) -> match by ctr only.
        uint16_t ctr    = 0;      // the minted ctr the app correlates on (== the acked ctr in the returning DATA_TYPE_E2E_ACK)
        uint8_t  dst    = 0;      // same-layer id send: the dst id, echoed on the send_failed{e2e_ack_timeout} push (0 for hash/XL/delegated)
        bool     is_xl  = false;  // the ack returns CROSS_LAYER (sender_hash carried) -> match by key==sender_hash; else same-layer (sender_hash==0)
        bool     used   = false;
        uint64_t deadline_ms = 0;
    };
    static constexpr uint8_t cap_pending_e2e_acks = protocol::cap_pending_e2e_acks;
    PendingE2eAck _pending_e2e_acks[cap_pending_e2e_acks] = {};
    // ★★★ §id-hash S4b (spec §5) — THE `resolve-id-for-pubkey` INTENT RING. The state that makes `reqpubkey <id>` ONE
    // command again when the id has no binding: stage 1 asks "who owns id N?", this remembers that we asked and WHY,
    // and the answer's arrival fires the ordinary HARD WANT_PUBKEY query by the returned hash (spec §5 steps 1-3).
    // Node-GLOBAL, like its `_pending_e2e_acks` neighbour and for the same reason: the answer can arrive on any layer.
    //
    // ★★ THIS IS NOT THE AUTO-RESOLUTION `§no-auto-reqpubkey` FORBIDS — the reasoning lives at the escalation site
    // (node_hashlocate.cpp, id_pubkey_intent_consume) so a reader meets it where the second query is actually emitted.
    //
    // ⓘ `id != 0` IS THE USED SENTINEL, deliberately instead of the `bool used` its neighbour carries. A by-id query
    // key is canonical-gated (`h_by_id_key_canonical`: never 0, never 255), so 0 is structurally impossible for a live
    // intent — and one field that cannot disagree with another beats two that can. `PendingE2eAck` needs its flag only
    // because its key 0 is a legal wildcard.
    struct PendingIdPubkey {
        uint64_t deadline_ms = 0;   // armed at now + protocol::id_pubkey_intent_ttl_ms; swept by age_out_pending_id_pubkey
        uint8_t  id          = 0;   // the queried id IN ITS OWN PLANE'S SPACE (static node_id / team local id) — 0 = slot free
        uint8_t  plane       = 0;   // Plane::TEAM(1) / Plane::GLOBAL(2), never AUTO: the plane is resolved before arming
    };
    // ⚠ MEASURED, NOT INFERRED (D2). 16 B/slot: the 8-aligned `deadline_ms` first, then the two bytes in the 6-byte
    // tail pad it already forces — so the ring costs exactly 4 x 16 = 64 B and, being a multiple of 8, opens NO hole
    // at its insertion point (immediately after the 8-aligned end of `_pending_e2e_acks`, `_peer_loc`'s own precedent).
    // Reversing the field order — the two bytes FIRST — measures 16 as well, so the placement is not load-bearing here;
    // it is written this way because `deadline_ms` is the field the sweep reads.
    static_assert(sizeof(PendingIdPubkey) == 16, "node.h: PendingIdPubkey grew — x cap_pending_id_pubkey, and sizeof(Node) has moved");
    static_assert(offsetof(PendingIdPubkey, id) == 8, "node.h: PendingIdPubkey::id left the tail pad after deadline_ms");
    static constexpr uint8_t cap_pending_id_pubkey = protocol::cap_pending_id_pubkey;
    PendingIdPubkey _pending_id_pubkey[cap_pending_id_pubkey] = {};
    // ★★★ §MH-S2 §5.3.2/§5.3.3 — THE KEYED PENDING-OFFER RING, and the [[B137]] PENDING-ID RESERVATION IT CARRIES.
    // It REPLACES `LayerRuntime::_pending_offer`, the single 13-byte slot whose "last DISCOVER wins" overwrite §S0-1
    // reproduced: a second mobile's DISCOVER arriving inside the host's 100..1000 ms OFFER jitter destroyed the first
    // mobile's targeted OFFER outright, and that mobile was never answered at all.
    //
    // ★ NODE-GLOBAL, NOT PER-LAYER, AND THE REASON IS A SEMANTIC ONE, NOT A RAM ONE. `can_host_mobiles()` is
    // `host_mobiles && !is_mobile && !is_gateway && n_layers == 1`, so **a legal home is necessarily a single-layer
    // non-gateway node**. Sizing the ring `x MR_N_LAYERS` would buy no capacity whatsoever — it would only double the
    // RAM on a node that can never reach the second dimension. (Its predecessor lived in LayerRuntime, which is why
    // `mobile_host_pending_clear` had to loop over both leaves; that loop is now unnecessary FOR THE OFFER and the
    // function says so at its site.)
    //
    // TWO INDEPENDENT LIFETIMES PER SLOT, and confusing them is the mistake this comment exists to prevent:
    //   • ARMED   — `len != 0`: a packed OFFER waiting for `due_ms`. Cleared by `jtx_fire` at the transmission.
    //   • RESERVED — `reserve_until_ms != 0`: [[B137]]'s promise that `proposed_id` belongs to `target_key_hash32`.
    //     It OUTLIVES the transmission (that is the whole point — the CLAIM has not arrived yet) and is released by
    //     the matching CLAIM or by `mobile_offer_fire`'s deadline scan at `mobile_offer_reservation_ms`.
    // ⇒ the slot is IN USE while EITHER holds. `reserve_until_ms` is the occupancy flag, because every armed entry
    //   also holds a reservation but not every reservation is still armed.
    //
    // ★★★ §MH-S2b — AND THE ONE CONSEQUENCE THE DOCS KEPT BLURRING, WRITTEN OUT HERE ONCE. "A duplicate DISCOVER
    // coalesces" and "a re-DISCOVER retains its reserved id" are TWO DIFFERENT BEHAVIOURS on the SAME slot, and
    // which one you get is decided by `len`, i.e. by whether the OFFER has flown yet:
    //   • DUPLICATE, entry still ARMED (`len != 0`) -> **COALESCE**. An answer is already on its way inside the
    //     100..1000 ms jitter window. Nothing is scheduled, no slot is consumed, **no RNG draw is made, and the
    //     deadline is NOT moved** (moving it would let a retry-happy mobile postpone its own OFFER forever).
    //     `mobile_offer_admit` returns `duplicate`; the caller emits `mobile_offer_coalesced`, which deliberately is
    //     NOT `mobile_offer_scheduled` — nothing was scheduled.
    //   • RE-DISCOVER, entry already TRANSMITTED (`len == 0`, reservation still live) -> **RE-ARM THE SAME SLOT,
    //     KEEPING THE SAME RESERVED ID.** The mobile did not hear the OFFER, so the correct answer is a NEW OFFER —
    //     a fresh frame, a fresh deadline and therefore a fresh draw, into the slot it already owns. The id is
    //     unchanged because `find_free_mobile_id` returns a live reservation's own id to its own key, so the caller
    //     has already handed us the same `proposed_id`. `mobile_offer_admit` returns `armed`.
    // ⛔ Reading the second case as a "duplicate" would answer every re-DISCOVER with SILENCE for the whole 10 s
    //    reservation; reading the first as a re-arm reintroduces the deadline-shifting the coalesce exists to stop.
    //    ⓘ Both are exercised natively (`§MH-S2 (spec §5.3.3)`), and both are corpus-inert — `mobile_offer_coalesced`
    //    occurs 0 times in all 36 streams, so the native gate is the ONLY thing standing over this distinction.
    struct PendingMobileOffer {
        uint64_t due_ms            = 0;   // §5.3.3: this entry's OWN jitter deadline (valid while len != 0)
        uint64_t reserve_until_ms  = 0;   // [[B137]]: reservation bound; 0 = slot FREE
        uint32_t target_key_hash32 = 0;   // §5.3.2 item 1: THE KEY. Coalescing is by hash — ⛔ never by slot index
        uint8_t  buf[13]           = {};  // the packed j_offer (pack_j_offer emits exactly 13 B)
        uint8_t  len               = 0;   // jtx "armed" flag: 0 = nothing to transmit (fired, or reservation-only)
        uint8_t  proposed_id       = 0;   // the RESERVED local id this OFFER proposes
    };
    // ⚠ MEASURED, NOT INFERRED (D2), on native + all four board toolchains: 40 B/slot, alignof 8 — the two 8-aligned
    // deadlines first, the u32 key, then buf+len+proposed_id (15 B) in the 4+16 that follows, 5 B of tail pad. The
    // ring is therefore 8 x 40 = 320 B and, being a multiple of 8, opens NO hole at its insertion point (immediately
    // after the 8-aligned end of `_pending_id_pubkey` — `_peer_loc`'s own precedent at the same seam).
    static_assert(sizeof(PendingMobileOffer) == 40 && alignof(PendingMobileOffer) == 8,
                  "node.h: PendingMobileOffer moved — x cap_pending_mobile_offers, and sizeof(Node) has moved");
    static_assert(offsetof(PendingMobileOffer, buf) == 20 && offsetof(PendingMobileOffer, proposed_id) == 34,
                  "node.h: PendingMobileOffer's tail left the pad the two u64 deadlines already force");
    static constexpr uint8_t cap_pending_mobile_offers = protocol::cap_pending_mobile_offers;
    PendingMobileOffer _pending_mobile_offers[cap_pending_mobile_offers] = {};
    // §5.3.2 item 8 — the two counters §10 asks for beside the ring. MEASURED to cost ZERO: both land in the padding
    // that already sat between the 8-aligned ring end and the members after it (probed by removal — sizeof(Node)
    // identical with and without them). Monotonic, never reset; a uint16 wraps at 65535 on a host that refused that
    // many OFFERs, which is a diagnostic, not a ledger.
    uint16_t _mobile_offer_ring_full_n = 0;   // admissions refused because every slot was in use (§5.3.2 item 5 `full`)
    uint16_t _mobile_offer_reject_n    = 0;   // armed OFFERs our OWN transmitter definitively refused at the fire (§6.2)
    // ★★★ §AB4 — RETAINED PEER LOCATION (address-book spec 2026-07-29 §2.7/§2.7.1, owner-ruled 2026-07-31).
    // key_hash32 -> that peer's last known position, so `peers` / `nameof` can show it. Node-GLOBAL (not LayerRuntime,
    // unlike its _peer_keys/_id_bind/_team_keys neighbours): a key_hash32 is a layer-INDEPENDENT identity, so a
    // position learned on one leaf is equally true on the other — per-leaf copies would cost 2x the RAM to hold two
    // answers to a question that has one. Nothing here is #if MR_FEAT_TEAM: the live source is a SEALED DM, which a
    // static-only build (gateway) receives exactly as a team member does.
    //
    // ★★★ RAM ONLY — DELIBERATELY VOLATILE. NO NV RECORD, AND THE REASONS ARE HERE SO NO LATER SLICE "COMPLETES" IT:
    //   (1) A STALE POSITION IS WORSE THAN NONE. An app that renders a three-hour-old fix as current is actively
    //       misleading — and a reboot-restored position has no upper bound on its staleness at all.
    //   (2) A CAPTURED OR STOLEN NODE MUST NOT YIELD EVERY TEAMMATE'S LAST KNOWN POSITION. Keys in flash are a
    //       deliberate, bounded exposure; a movement history is not.
    // AB1 persists names and `authoritative` keys precisely because those are stable facts. Location is THE deliberate
    // exception, and §1.4's "one table, lossy backup" picture stays true. ⇒ src/device_nv.h's PeerRec gains NOTHING.
    //
    // ★★ AND IT IS NOT `PeerKey`, NOT `_team_keys` — both obvious homes are wrong, recorded so neither is re-taken:
    //   • NOT PeerKey: under owner ruling O5 a CHANNEL-sourced position must be storable with NO ed_pub for that hash,
    //     and peer_key_set *verifies* ed_pub[:4] == key_hash32, so a keyless row would fight a live invariant.
    //   • NOT _team_keys: the §id-bind-plane slice established three reasons — it has no confidence dimension, it FEEDS
    //     TEAM-DAD MEDIATION (seeding it from non-beacon traffic manufactures spurious DENYs), and it is a beacon-fed
    //     evict-oldest LRU whose last_seen_ms means "heard NOW", not "positioned then".
    // ⇒ a dedicated ring keyed by key_hash32 (§1.2: ids are addresses, the hash is the identity).
    //
    // ★ NOT recent_ring.h either, and this one is a REFUSED FORCED FIT rather than an oversight: that header's four
    // steps (scan / refresh / append / evict-oldest) are exactly right, but its ENTRY CONTRACT mandates `uint64_t t_ms`
    // and this record's whole size budget rests on a 4-byte stamp — measured, the u64 form is 32 B/slot vs 20 B, i.e.
    // +192 B of nRF52840 RAM to share ~10 lines of template. The MEANING differs too: recent_ring is a "have I seen
    // this recently" SUPPRESSION window with a TTL and an age-out sweep, whereas this is a retained VALUE whose stamp
    // is a DISPLAYED age and which must never expire behind the app's back. There is also no duplicated key predicate
    // to unify — that doubled `…_recently`/`mark_…` predicate is the entire reason that header exists.
    struct PeerLoc {
        uint32_t   key_hash32;   // the identity. 0 ⇒ unused slot (the _peer_loc_n prefix is the live region)
        int32_t    lat_e7;       // 1e-7 degrees, the same scale the wire and NodeConfig::lat_e7 use
        int32_t    lon_e7;
        // ★ SECONDS, not milliseconds — `_hal.now()` is ms and this is `now()/1000`. Two reasons: the 4-byte stamp is
        // what keeps the record at 20 B (a u64 ms stamp measures 32 B — see the recent_ring note above), and the only
        // consumer is `loc_age_s`, a human-facing age where sub-second precision is meaningless.
        // ★ ROLLOVER: uint32 seconds spans ~136 years of uptime, so on a monotonic since-boot clock the wrap is
        // UNREACHABLE and no wrap handling is warranted. peer_loc_find still clamps a now < t_s reading (a test that
        // rewinds TestHal, or a clock that ever moved backwards) to the MAXIMALLY STALE answer, never to 0 — 0 would
        // render a garbage position as current, which is failure mode (1) above.
        uint32_t   t_s;
        // ★★ THE TRUST ANCHOR (spec §2.7.2). It is stored, not derived, and it exists FROM THE START even though only
        // `peer` can occur today — so CL2 adds a SOURCE, never a schema change, and the weaker group-anchored claim can
        // never be silently rendered as the stronger pairwise one.
        PeerLocSrc src;
        // ★ NAMED, not implicit. sizeof(PeerLoc) is 20 either way (measured: 16 without `src`, 20 with, offsetof(src)==16),
        // but IMPLICIT tail padding is INDETERMINATE after `PeerLoc{}` — so any memcmp-style comparison over the record
        // would be unsound. Naming it makes those 3 bytes zero-initialised like every other member. (AB1's lesson: it
        // briefed a 70 B record and measured 72.) ⇒ 20 B x cap_peer_loc(16) = 320 B, NOT the 256 B §2.7.1 predicted —
        // that figure pre-dates the rescope that added `loc_src`, and the two cannot both hold.
        uint8_t    reserved[3];
    };
    // ★ PINNED AT THE DEFINITION, per-TARGET — the PeerLiveness == 72 precedent (node.h:1646), and better than a native
    // test could be: this fires on every board toolchain, not just native. 20 B x cap_peer_loc = the exact 320 B the
    // sizeof(Node) ledger accounts for, measured on all six flag-sets. `offsetof(src) == 16` is what proves `reserved`
    // occupies the REAL tail hole rather than adding a fifth word: widen any field, or drop `reserved`, and this fails
    // the build instead of silently costing (or indeterminately zeroing) 16 slots' worth of RAM.
    static_assert(sizeof(PeerLoc) == 20 && alignof(PeerLoc) == 4 && offsetof(PeerLoc, src) == 16,
                  "node.h: PeerLoc's layout moved — re-measure the ring's RAM cost (20 B x cap_peer_loc) and update "
                  "the sizeof(Node) ledger; and keep the tail padding a NAMED member, never implicit");
    static constexpr uint8_t cap_peer_loc = protocol::cap_peer_loc;
    PeerLoc    _peer_loc[cap_peer_loc] = {};
    uint8_t    _peer_loc_n = 0;
    uint8_t    _parked_sends_n = 0;
    // ★★★ §UI-16 N1 (spec 2026-08-22 §2.1) — THE NEARBY-TEAM OBSERVATION CACHE, WRITE SIDE + STORAGE.
    // Node-GLOBAL, not LayerRuntime, and `_peer_loc`'s reasoning is reused verbatim: a team_id is a
    // layer-INDEPENDENT identity, so a team heard on one leaf is equally audible-as-a-fact on the other
    // — per-leaf copies would cost 2x the RAM to hold two answers to a question that has one.
    // ★★ RAM ONLY, DELIBERATELY VOLATILE, NO NV RECORD — and unlike `_peer_loc` that needs no argument:
    // an observation is a statement about RIGHT NOW on THIS radio, so a reboot-restored one would be
    // meaningless by construction. `team_seen_retain_ms` is a 10-minute window; a boot outlives it.
    // ⛔ #if MR_FEAT_TEAM: the cache is team-plane-only by construction (a gateway can never act on it),
    // so the two members compile out on the gateway_* envs and the cost there is +0.
    // ★ THE COUNT BYTE IS DECLARED BEFORE THE ARRAY, AND THAT IS MEASURED, NOT ARGUED: here it lands in
    // the alignment pad that already sat between `_parked_sends_n` and the 8-aligned `_l2c_redirect`, so
    // it costs ZERO — sizeof(Node) is identical with and without it (probed by removal). Declared AFTER
    // the 8-aligned array it measures +8, because it would then open a fresh hole of its own.
#if MR_FEAT_TEAM
    uint8_t    _team_seen_n = 0;
    TeamSeen   _team_seen[protocol::cap_team_seen] = {};
    // The ONE write path. Called from exactly one site — `ingest_beacon`, immediately after the
    // leaf/team drop — and it touches ONLY `_team_seen`/`_team_seen_n`. ⛔ No route merge, no
    // `team_key_set`, no `id_bind_set`, no `peer_key_set`, no NV, no TX, no timer, no MR_EMIT.
    void team_seen_observe(uint32_t team_id, int16_t sample_q4, uint8_t src_id) {
        team_seen_ring_observe(_team_seen, _team_seen_n, team_id, sample_q4, src_id, _hal.now());
    }
#else
    void team_seen_observe(uint32_t, int16_t, uint8_t) {}   // §featuresplit: inert -> the one call site stays unchanged
#endif
    // L2c redirect-suppression ring: a misdelivered DM we've already redirected for this hash recently,
    // so a still-poisoned binding (collision unhealed) can't re-trigger an endless redirect→deliver→redirect.
    struct L2cRedirect { uint32_t key_hash32; uint64_t t_ms;
                         bool same_key(const L2cRedirect& o) const { return key_hash32 == o.key_hash32; } };
    L2cRedirect _l2c_redirect[protocol::cap_l2c_redirect] = {};
    uint8_t     _l2c_redirect_n = 0;

    // ======== JOIN / DAD id-assignment (Node-global — node_join.cpp; also _join_denied/_mediated_recent below, past the mobile block) ========
    // node_id auto-assignment (DAD + heal) — node_join.cpp; design 2026-06-05-node-id-auto-assignment-design.md.
    bool     _joined = false;                                    // adopted a node_id via DAD (vs cfg/NV-provisioned)
    bool     _join_listen_pending = false;                       // a join was requested; listening before the first claim (L1)
    uint8_t  _claim_epoch = 0;                                   // VESTIGIAL (key-only tiebreak): reserved on wire/NV, not consulted
    struct JoinClaim { bool active; uint8_t proposed; uint32_t key_hash32; uint8_t claim_epoch; uint8_t nonce; uint64_t started_ms; };
    JoinClaim _join_claim{};                                     // the single in-flight claim (active=false when none)

    // ======== MOBILE-MEMBER identity (Node-global, #if MR_FEAT_MOBILE — roaming-endpoint plane; compiles out on static/gateway) ========
    // §mobile 2b (mobile-side registration): a mobile has ONE attachment (identity-level, single-layer). DORMANT unless
    // _cfg.is_mobile — the FSM timer is armed only for a mobile, so a static node never touches any of this.
    // §featuresplit: the whole mobile-MEMBER (roaming endpoint) plane compiles out on a static/gateway build (MR_FEAT_MOBILE=0);
    // the header stubs the accessors + FSM to inert, so the static routing plane is untouched.
#if MR_FEAT_MOBILE
    struct MyMobileReg {
        bool     active = false;              // registered to a host?
        uint8_t  home_id = 0;                 // the host's node_id (our registrar / home)
        uint8_t  my_local_id = 0;             // our host-assigned local-id (== _node_id once adopted)
        uint32_t home_key_hash32 = 0;         // stable home identity (home-lost / redirect)
        uint8_t  home_leaf_id = 0;            // the leaf we registered on
        uint16_t epoch = 0;                   // §17 registration epoch (mobile-incremented per (re)register)
        uint64_t last_heard_home_ms = 0;      // last BCN from home_id (home-lost timeout)
    };
    MyMobileReg _my_mobile_reg{};
    struct OfferCand { uint8_t responder_id; uint32_t responder_hash; uint8_t proposed_local_id; float snr_db;
                       uint8_t leaf_id; uint8_t data_sf_bitmap; };   // §mobile: the HOST's leaf (from the OFFER) — adopted on registration. data_sf_bitmap is ADVISORY (F-SF-1): the mobile keeps its OWN configured sf_list; this byte only feeds the `mobile_sf_list_mismatch` diagnostic
    OfferCand _mobile_offers[protocol::cap_mobile_offers] = {};   // OFFERs collected during a DISCOVER window
    uint8_t   _mobile_offers_n = 0;
    // ★ §MH-S1b §6.3 — "a CLAIM is staged, awaiting the transmitter's answer", and `_mobile_offers[0]` holds
    // the chosen OFFER while it waits. `mobile_claim_guard_fire` sets it, `mobile_claim_adopt` (called from
    // `lbt_complete` at the accepted handoff) CONSUMES it, and a definitive refusal / a fresh DISCOVER clears
    // it. It is what makes "adopt only after successful handoff" possible across an LBT defer, which can put
    // seconds between the CLAIM being staged and the frame actually crossing to the radio.
    // ⛔ NOT a second copy of the offer: the chosen candidate is compacted into slot 0 rather than duplicated
    //    into a new 20-byte member (U2 — one carrier), which is also why sizeof(Node) does not move.
    // ★★★ [[B142]] 2026-08-07 — ⛔ THIS FLAG IS NOT AN ATTEMPT IDENTITY AND MUST NEVER BE USED AS ONE. It is
    //    global: after a fresh DISCOVER re-stages slot 0 it is true again, for a DIFFERENT candidate. Any
    //    deferred completion must be correlated by `_mobile_attach_gen` (the `completion_gen` token that rides
    //    `DeferredLbt`), never by this bool — reading it as "my CLAIM is still pending" is the ABA.
    // ⓘ PLACEMENT: `_mobile_offers_n` (u8) sits before the 4-aligned `_mobile_backoff_ms`, so THREE pad bytes
    //   were already being wasted here; this bool takes one of them. sizeof(Node) is therefore unchanged —
    //   ASSERTED by the tripwire at the end of this header, and MEASURED per-ABI, not inferred. Tenth
    //   application of the radio_freq_mhz / team_hop_cap / _channel_seal_ctr padding-placement rule.
    bool      _mobile_claim_pending = false;
    uint32_t  _mobile_backoff_ms = 0;                             // exp-backoff when no host answers (0 = first try)
    uint8_t   _mobile_scan_idx = 0;                              // §mobile 5a: which scan-set PHY the home-lost mobile is currently DISCOVERing on
    LayerRecord _learned_layers[protocol::cap_learned_layers] = {};   // §mobile 5a: neighbouring layers pulled from a gateway (candidate cross-layer PHYs, dedup by composite id)
    uint8_t   _learned_layers_n = 0;
    uint64_t  _learned_layers_ms = 0;                           // §mobile 5a: last directory refresh (TTL)
    uint64_t  _learned_layers_seen_ms[protocol::cap_learned_layers] = {};   // §3-A.6/P2-6: per-entry last-seen -> evict-STALEST when full (was evict-slot-0, which could clobber the freshest)
    // §S6 presence plane (mobile side): the probe/check FSM that REPLACES the periodic re-CLAIM + layer poll.
    uint8_t   _presence_miss     = 0;                           // consecutive unanswered probes (k_miss -> HOME LOST)
    uint32_t  _presence_T_ms     = protocol::presence_check_base_ms;   // current dynamic check period (quality-driven)
    uint8_t   _presence_my_tier  = protocol::presence_q_ok;     // my link tier from the last roster
    uint8_t   _presence_dir_epoch = 0;                          // last-seen layer-directory aggregate (pull on change)
    bool      _presence_dir_epoch_seen = false;                 // have we seen ANY roster dir_epoch yet
    // ★ §MH-S5b-ii — **STILL LOAD-BEARING, AND DELIBERATELY *NOT* READ BY `presence_searching_probe_due()`.** Two
    //   readers remain, both on the SWITCH-EVALUATION path: `presence_ingest_roster`'s
    //   `if (_presence_prescan) presence_maybe_rehome();` and `presence_maybe_rehome`'s own guard. ⛔ The third reader,
    //   §8.3's **trigger 1**, is **DEFERRED under [[B178]]**, and the flag is RETAINED for the refined trigger that
    //   returns with it: re-adding a member later would move `sizeof(Node)` twice and cost two ten-env sweeps.
    // ⛔ **AND THE TRAILING COMMENT BELOW USED TO SAY "collect candidate homes from beacons/rosters", WHICH THIS FLAG
    //   HAS NEVER GATED** — `presence_note_candidate` is unconditional on home quality. Corrected in place (V1).
    bool      _presence_prescan  = false;                       // weak/critical -> the re-home EVALUATION is unlocked (collection is unconditional)
    bool      _presence_key_confirmed = false;                  // §S6 A.4: home confirmed our key (roster has_key=1) -> stop attaching ed_pub to probes
    // ★★★ §MH-S4 §4.1 — NOW LOAD-BEARING. Before this slice it had TWO WRITES AND ZERO READS (measured by
    // grep across lib/core + src, and proven observably by the §S0-4 characterization case: no second CLAIM
    // ever reached the air). It answers exactly one question — *"has the chosen home ever shown our row in
    // ITS OWN roster?"* — and TWO decisions now read it:
    //   1. the ONCE-ONLY promotion in `presence_ingest_roster`: the `claiming` -> `attached` transition, the
    //      `mobile_reg{registered:true}` push and the confirmation stamp fire on the FIRST matching roster and
    //      never again for the same attachment (a home rosters every ~T; the app must not be re-notified);
    //   2. the roster-ABSENT fork: absent-and-never-confirmed means THE CLAIM WAS NEVER RECORDED (§7.1 step 5
    //      — re-send the same CLAIM), while absent-after-confirmed means THE HOME DROPPED US (reboot/eviction
    //      — the pre-existing staggered re-register). ★ The two arms are different actions on IDENTICAL wire
    //      evidence, so a flag that distinguishes them is not redundant with the FSM state; it is what makes
    //      the FSM state derivable at all.
    bool      _presence_reg_confirmed = false;                  // §MH-S4 §7.1: the chosen home confirmed our REGISTRATION (our hash+local id+epoch in ITS roster)
    // ★ §MH-S4 §4.2 — the VOLATILE home-service request. Replaces the consumed one-shot `_mobile_arm_once`
    // AT THE SAME BYTE (same type, same position in the bool run) so this member costs NOTHING; only its
    // LIFETIME changed, from "consumed by the first DISCOVER" to "held until `mobile unregister` or reboot".
    // ⛔ Deliberately NOT persisted to NV: §4.2 rules that a device with `mobile_autoregister` OFF is dormant
    //    again after reboot, and that a device needing attachment restored across reboots uses the flag ON.
    bool      _mobile_home_desired = false;
    // §MH-S1 §10: the last attachment-attempt outcome (see MobileAttemptResult). Placed at the END of the
    // bool run above and BEFORE the 8-aligned `_last_adopt_ms`: that run is `_presence_my_tier`(u8) +
    // `_presence_dir_epoch`(u8) + five bools = 7 bytes on an 8-byte boundary, so ONE pad byte was already
    // being wasted there and this member takes it. sizeof(Node) is therefore unchanged — ASSERTED by the
    // tripwire at the end of this header (221088), not inferred. Ninth application of the
    // radio_freq_mhz / team_hop_cap / _channel_seal_ctr padding-placement rule.
    MobileAttemptResult _mobile_last_result = MobileAttemptResult::none;
    uint64_t  _last_adopt_ms     = 0;                           // §S6.4-C dwell anchor (last (re)adopt)
    uint64_t  _presence_last_pull_ms = 0;                       // D6 safety-pull clock
    int16_t   _presence_home_rx_q4 = 0;                         // §S6/D14: my RX EWMA (Q4) of my HOME's frames (home->me direction; paired with _presence_my_tier = me->home)
    // ★★★★ §MH-S4b §7.1 step 3 — **THE SOLICITATION SUBSTATE, AND IT IS WHAT MAKES SILENCE DISTINGUISHABLE FROM
    // REFUSAL.** While `claiming`, one deadline id (`kPresenceProbeTimerId`) has to mean two different things in
    // alternation, and §7.1 describes them as two steps with a WAIT between:
    //   false ⇒ "we have not asked yet" — the next fire SENDS the short SEARCHING solicitation probe (step 3) and
    //           then waits `presence_claim_confirm_ms` for a roster. It spends NO budget.
    //   true  ⇒ "we asked and are waiting" — the next fire means the roster deadline EXPIRED with no answer
    //           (step 6's silence), which is the only event entitled to spend a re-CLAIM.
    // ⛔ §MH-S4 had no such distinction, so the probe and the verdict happened in ONE callback: the budget was
    //    spent before the answer could physically arrive, and a home that had missed the CLAIM was asked with a
    //    SELECTED probe it is required to IGNORE (`node_join.cpp` `presence_ingest_probe`: "a check probe for a
    //    hash we don't host -> ignore"). The one mechanism meant to detect the miss could not.
    // ⛔ NOT a sixth `MobileAttachState`: §4.1 fixes that enum's five values as the app-facing contract, and this
    //    is a substate OF `claiming`, not a peer of it. It is surfaced separately as `claim_solicited` (§10).
    // ⓘ PLACEMENT — MEASURED on the tripwire, not inferred: `_presence_home_rx_q4` (i16) is followed by SIX bytes
    //   of pure alignment pad before the 8-ALIGNED `PresenceCand[]` (this is the very hole the DECLINED u32
    //   confirmation-stamp variant would have used — see `_mobile_home_confirmed_ms` below), so this bool takes
    //   one of them and the hole shrinks to five. `sizeof(Node)` is UNCHANGED. FOURTEENTH application of the
    //   radio_freq_mhz / team_hop_cap / _channel_seal_ctr padding-placement rule.
    // ⚠ Its SEMANTIC home is beside `_mobile_claim_retries`; it lives here for the padding reason and no other.
    bool      _mobile_claim_solicited = false;
    // §S6.4-C candidate home. D14 bidirectional: snr_q4 = my RX of its roster/beacon (cand->me); echo_tier = its echo of MY probe (me->cand), 0xFF = unknown. Selection ranks by the WORSE of the two.
    struct PresenceCand { uint8_t home_id; uint8_t home_layer; int16_t snr_q4; uint8_t echo_tier; uint64_t first_seen_ms; uint64_t last_seen_ms; bool incompatible = false; };  // §D16: incompatible = heard a wrong-wire_version roster from this home -> never DISCOVER at it
    PresenceCand _presence_cand[protocol::cap_presence_candidates] = {};   // §S6.4-C overheard candidate homes (strongest-sustained wins)
    uint8_t   _presence_cand_n   = 0;
    // ★★★ [[B142]] 2026-08-07 — THE ATTACHMENT-TRANSACTION GENERATION. Monotonic, bumped by
    // `mobile_discover_fire` at the instant a new registration transaction supersedes everything before it
    // (the same statement group that clears `_mobile_offers_n` and `_mobile_claim_pending`). The CLAIM
    // INHERITS its DISCOVER's value — a CLAIM is the second half of one transaction, not a new one — and it
    // rides `tx_initiating` -> `DeferredLbt::completion_gen` so a completion can be matched to the
    // transaction that produced it. See the `completion_gen` contract block above `tx_initiating`.
    // ⛔ WHY A TOKEN AND NOT THE BOOL: `_mobile_claim_pending` is a single global flag with NO attempt
    //    identity, and `lbt_complete` correlated a deferred completion by `LbtKind` alone. An ABA followed:
    //    CLAIM A defers, the operator re-registers, DISCOVER B picks a different host and CLAIM B is staged,
    //    then slot A fires — transmitting A's bytes while adopting B's candidate, or (rejected) clearing B's
    //    stage and arming a retry for an attempt that no longer exists. The flag cannot distinguish them
    //    because it is the same flag; only a per-transaction identity can.
    // ⓘ PLACEMENT (measured, not inferred): `_presence_cand_n` (u8) is followed by the 8-ALIGNED
    //   `DeniedId _join_denied[]` (u8 + u64), so SEVEN pad bytes already sat here; this u32 takes four of
    //   them and the hole shrinks to three. sizeof(Node) is therefore unchanged — ASSERTED by the tripwire
    //   at the end of this header and MEASURED per-ABI on all five real toolchains, never inferred. Its
    //   SEMANTIC home is beside `_mobile_claim_pending`, where it costs 8 bytes (only 2 pad bytes are left
    //   before the 4-aligned `_mobile_backoff_ms`); it lives here for that reason and no other. Eleventh
    //   application of the radio_freq_mhz / team_hop_cap / _channel_seal_ctr padding-placement rule.
    // ★★★ §MH-S4 §4.1 — THE TWO INDEPENDENT PLANES + THE RE-CLAIM BUDGET, AND ALL THREE COST ZERO BYTES.
    // ⛔ THE TWO STATES ARE NEVER DERIVED FROM EACH OTHER. §4.1: "the two are orthogonal — a node can be
    //    `attached` with the link `checking`, and it must render as such." Any code that computes one from the
    //    other has re-created the single `registered` bit this slice exists to split.
    // ⓘ PLACEMENT — MEASURED BY BISECTION ON THE TRIPWIRE, AND THE FIRST PREMISE WAS WRONG. [[B142]]'s note
    //   below records that `_presence_cand_n` (u8) was followed by SEVEN bytes of pure alignment pad before the
    //   8-ALIGNED `DeniedId _join_denied[]`, that its own u32 took FOUR of them, and that "the hole shrinks to
    //   THREE". ★ THOSE THREE BYTES SIT **BEFORE** `_mobile_attach_gen`, NOT AFTER IT — the u32 needs 4-alignment,
    //   so it lands at the END of the run and closes the boundary exactly. Declaring this trio AFTER the u32
    //   therefore MEASURED +8 (221376 -> 221384 with the trio alone); moved HERE, ahead of the u32, it measures
    //   **+0**. That is the whole reason these three lines precede `_mobile_attach_gen` and it is why the note
    //   says "measured": the plausible-sounding version of the padding argument was off by one member.
    //   THIRTEENTH application of the radio_freq_mhz / team_hop_cap / _channel_seal_ctr padding-placement rule.
    // ⚠ Their SEMANTIC home is beside `_my_mobile_reg`; they live here for the padding reason and no other.
    MobileAttachState _mobile_attach_state = MobileAttachState::dormant;   // §4.1 attachment plane (authority: a matching chosen-home P roster)
    MobileHomeLink    _mobile_home_link    = MobileHomeLink::unknown;      // §4.1 home-link plane (authority: a recent correlated bidirectional exchange)
    uint8_t   _mobile_claim_retries = 0;                        // §7.1 steps 5-6: same-epoch re-CLAIMs spent on THIS attachment (cap = protocol::presence_claim_max_retries)
    uint32_t  _mobile_attach_gen = 0;
    // ★ §MH-S4 §4.1 — THE CONFIRMATION TIMESTAMP, so every surface can render the AGE rather than an
    // unconditional "Connected". 0 = never confirmed (distinguished from "confirmed at t=0" by
    // `mobile_home_confirmed_ever()`; `_hal.now()` is never 0 at a real confirmation because a roster must
    // have been received first).
    // ⓘ COST: 8 bytes, and it is a genuine cost, NOT a padding win — this is the 8-aligned u64 run
    //   (`_last_adopt_ms` / `_presence_last_pull_ms`), which has no hole. ⇒ THE WHOLE §MH-S4 STATE COST IS
    //   THIS ONE MEMBER: 221376 -> 221384, +8, native.
    // ⚠ A +0 ALTERNATIVE EXISTS, WAS MEASURED, AND WAS DECLINED — recorded here so the choice is visible rather
    //   than looking like an oversight. Narrowing this to `uint32_t` and placing it after `_presence_home_rx_q4`
    //   (an i16 followed by 6 bytes of pad before the 8-aligned `PresenceCand[]`) measures **221376, +0 exactly**.
    //   ⛔ DECLINED under M3's "pick the RIGHT shape, never contort a design to fit a spare bit": a u32 ms stamp
    //   costs a truncating cast, wrap-relative age arithmetic, a 49.7-day validity ceiling and a once-per-49.7-days
    //   collision between "confirmed at this instant" and the 0 sentinel — real reasoning debt, traded for 8 bytes
    //   on a node whose tightest board sits at 73.2 % RAM. The u64 is also the idiom of every stamp beside it
    //   (`_last_adopt_ms`, `_presence_last_pull_ms`, `last_heard_home_ms`) — U3.
    // ⛔ NOT folded into `_my_mobile_reg.last_heard_home_ms`, which was the other tempting zero-byte reuse and is
    //   WRONG on MEANING, not on cost: that field has FOUR writers (node_beacon.cpp:676, node_mac_rx.cpp:52 and
    //   :431, and the roster site), three of which are ONE-WAY hints — a heard beacon, a received frame. §7.2
    //   rules that inbound beacons alone are NOT bidirectional confirmation, so reusing that stamp would have made
    //   this age field claim a bidirectional confirmation on the strength of one-way evidence: the exact
    //   display-shaped-field defect. Gate 22 is the test that catches it.
    uint64_t  _mobile_home_confirmed_ms = 0;
#endif
    struct DeniedId { uint8_t id; uint64_t t_ms;                 // a slot that lost a claim/heal (§13: 1-day TTL)
                      bool same_key(const DeniedId& o) const { return id == o.id; } };
    DeniedId _join_denied[protocol::cap_join_denied] = {};
    uint8_t  _join_denied_n = 0;
    // §B251 — translated-mobile DATA refused before its hop ACK because queue/correlation admission was full.
    // Its semantic home is beside the reverse-ACK ring, but this placement is deliberate and measured: the u8 count
    // above was followed by seven bytes of native alignment padding before the 8-aligned MediatedRecent array. This
    // u16 consumes two of them. The native tripwire stays 222008; D2 still measures both board ABIs independently.
    uint16_t _mobile_ctr_admission_refused_n = 0;
    struct MediatedRecent { uint8_t node_id; uint32_t loser_hash; uint64_t t_ms;      // L2a: suppress per-(id,loser) re-DENY
                            bool same_key(const MediatedRecent& o) const { return node_id == o.node_id && loser_hash == o.loser_hash; } };
    MediatedRecent _mediated_recent[protocol::cap_mediated_recent] = {};
    uint8_t        _mediated_recent_n = 0;
    // Q REQ_SYNC plane state (node_query.cpp). _last_req_sync_tx_ms rate-limits the originator (dv:8035);
    // _q_responded is the responder dedup ring (key opcode|src|dest, ttl q_respond_ttl_ms) — Lua refuses on
    // cap-full, we evict-oldest (matches the F-dedup idiom; equivalent below cap, robust for a long-running
    // device). _sync_pending is the bounded jitter-response ring (Lua: an unbounded table of after()-closures;
    // one slot per requester, fired by kSyncResponseTimerId+slot). Both arrays MOVED into LayerRuntime (Slice 2b):
    // keyed by a REMOTE leaf-local id (q.src / requester), so a gateway's two leaves must NOT share them
    // (Principle 5 — else node-5@leafA aliases node-5@leafB and the gateway drops one leaf's sync reply).
    uint64_t _last_req_sync_tx_ms = 0;   // self-state (our own last REQ_SYNC tx) — stays Node-global, not per-layer
    uint64_t _last_config_pull_tx_ms = 0;   // R6.2: rate-limit our CONFIG_PULL tx
    uint16_t _max_seen_epoch = 0;           // R6.3 §4.1: highest config_epoch seen for OUR lineage (a write = max_seen+1)
    uint64_t _last_join_refused_ms = 0;     // R6.3 §7c: rate-limit the join_refused{wire_version} push
    struct QResponded { uint8_t opcode; uint8_t src; uint8_t dest; uint64_t t_ms;
                        bool same_key(const QResponded& o) const { return opcode == o.opcode && src == o.src && dest == o.dest; } };
    // §B4 `team_plane`: which plane's pull this slot answers (team_sync vs req_sync), carried from handle_q's opcode
    // dispatch so sync_response_fire's `rt_total` describes the SAME table the scheduler gated on. It must be STORED,
    // not re-derived at fire time — a homed member is team-active while answering a static REQ_SYNC (C3). Costs 0 B:
    // it lands in the alignment pad the three existing bools already share before the 8-aligned uint64_t pair, so
    // sizeof(SyncPending) stays 24 and sizeof(Node) is unchanged (the node.h assert is the tripwire).
    struct SyncPending { bool active; bool suppressed; uint8_t requester; bool requester_mobile;
                         bool team_plane; uint64_t requested_at; uint64_t fire_at; };
    // Channel-message gossip plane state + dedup maps + the originator ring — MOVED into LayerRuntime (Slice 2a;
    // struct defs ChannelEntry/FloodState/etc. are above the channel method decls; OrigEvent/OrigRing below).
    // R4.4 originator anti-spam: per-sender sliding-window ledger of overheard RTS/CTS. kind: 0=rts, 1=cts.
    // FIXED RING (not a std::vector) — the old map-of-vectors rebuilt a vector on every overheard frame
    // (alloc/free per frame), which fragments the nRF52 heap; this keeps the events in a fixed in-struct
    // array (no per-frame heap), evicting the oldest on overflow. Insertion-ordered so the dedup-FIRST
    // refresh still matches the Lua ipairs scan. The std::map (sender -> ring) stays — its node alloc is
    // once per NEW sender (bounded by neighbours), not per frame (the accepted determinism relaxation).
    struct OrigEvent { uint64_t t; uint8_t kind; uint8_t ctr_lo; uint32_t air; };
    struct OrigRing  { OrigEvent ev[protocol::cap_originator_events]; uint8_t count = 0; };
    // _per_sender_originator MOVED into LayerRuntime (Slice 2a).

    // ---- LayerRuntime (2026-06-12-gateway-dual-layer-design.md §2) -----------------------------------------
    // Per-layer (per-leaf) runtime state. A normal node has n_layers=1 and only _layers[0] is used; a gateway
    // (later slices) has 2 EQUAL layers and swaps _active at each window switch. Slice 2a is a PURE NO-OP hoist:
    // these members moved here VERBATIM (initializers preserved), every reader redirected through _active->.
    // The array dimension is MR_N_LAYERS (protocol_constants.h): 1 on a leaf build (the array is one element —
    // identical RAM to the pre-dual-layer firmware), 2 only on [env:gateway]. on_init REFUSES n_layers==2 when
    // MR_N_LAYERS<2, so _layers[1] is never reached on a 1-element build (audited: 405 reads all go via _active=&_layers[0]).
    // Nested struct so the in-class helper struct defs (RtEntry, TxItem, PendingTx, ..., IdBind, ChannelEntry,
    // FloodState, OrigRing, ...) stay visible by unqualified name. Node is never copied, so the raw _active
    // pointer + default member initializer is safe.
    struct LayerRuntime {
        // ============ PER-LEAF runtime state — one instance per _layers[i]; _active selects the current leaf (a leaf build ============
        // ============ has 1, a gateway 2, non-aliasing). By-concern sections (cleanup 2026-07-15); member TYPE defs are above. ============

        // ==== ROUTING — static DV plane ====
        // Routing table (DV).
        RtEntry  _rt[protocol::cap_routes];
        uint8_t  _rt_count = 0;       // distinct dests, kept sorted ascending by dest
        // §mobile 6.2: a SEPARATE team-plane DV table (a teammate's LOCAL id can collide with a static global id — §18 —
        // so the two planes MUST NOT share `_rt`). A team mobile (is_mobile+team_id) learns/advertises/routes here; a
        // static node / lone mobile leaves it empty (byte-identical). Same RtEntry + the same DV core (table-param).
        // ==== ROUTING — team DV plane (#if MR_FEAT_TEAM; a team local-id can collide a static global id → §18 keeps them SEPARATE) ====
#if MR_FEAT_TEAM   // §featuresplit: the team plane compiles out on a static-only build (gateway) -> frees ~45 KB (_rt_team ×2)
        RtEntry  _rt_team[protocol::cap_routes] = {};
        uint8_t  _rt_team_count = 0;
        uint8_t  _team_peer[32] = {};   // 256-bit set of KNOWN same-team peers (by beacon src) — mirror _mobile_peer; read by is_team_peer
        // §enc: a same-team peer's key_hash32 (its beacon carries it — we were DROPPING it for is_mobile beacons). A
        // team-SCOPED id->key map, NEVER _id_bind (the static plane, §18). Lets an ENCRYPTED send BY team_local_id derive
        // DST_HASH (the pubkey still arrives via the team-scoped WANT_PUBKEY, cached by this same hash). Empty for a
        // static/lone node (team_id==0) -> s18-inert.
        // ★★ §id-hash S3 (spec 2026-08-01 §3-D2): the CONFIDENCE LADDER _id_bind has always had and this table never
        // did. `IdBind` is {key_hash32, last_seen_ms, node_id, source, confidence} — mirrored here field for field, and
        // REUSING IdBindSource/IdBindConf rather than inventing a third enum (U1): the two tables answer the same shape
        // of question (an id is an ADDRESS, not a commitment — spec §2), so they must not carry different vocabularies.
        // ⓘ The zero defaults are `{IdBindSource::self, IdBindConf::claimed}` and the CLAIMED half is deliberate: an
        //   unwritten row must never read as first-hand. (`_team_keys_n` bounds validity, so this is belt-and-braces.)
        // ⚠ PLACEMENT IS THE WHOLE COST STORY and it is asserted below, not inferred: both bytes land in the 3-byte
        //   hole that already sat between `id` and the 4-aligned `key_hash32`, so sizeof(TeamKey) stays 16.
        struct TeamKey { uint8_t id = 0; uint8_t source = 0; uint8_t confidence = 0; uint32_t key_hash32 = 0; uint64_t last_seen_ms = 0; };
        // ★ MEASURED, not inferred (spec §3-D2's "⚠ MEASURE sizeof(TeamKey): offsetof, not inference"). The two
        // offsets are what prove the bytes went into the EXISTING hole; sizeof alone could not tell a free placement
        // from a lucky tail pad. If a future field pushes this to 24 the cost is 8 B x 16 slots x MR_N_LAYERS.
        static_assert(sizeof(TeamKey) == 16, "node.h: TeamKey grew — the §id-hash S3 ladder was supposed to be FREE (x16 slots x MR_N_LAYERS)");
        static_assert(offsetof(TeamKey, source) == 1 && offsetof(TeamKey, confidence) == 2,
                      "node.h: TeamKey's ladder bytes left the id-adjacent hole — re-measure the cost before accepting");
        static_assert(offsetof(TeamKey, key_hash32) == 4 && offsetof(TeamKey, last_seen_ms) == 8,
                      "node.h: TeamKey's hash/stamp moved — the ladder bytes opened a hole instead of filling one");
        TeamKey  _team_keys[16] = {};
        uint8_t  _team_keys_n = 0;
        // §team-multihop (spec 2026-07-15 Plane 2 / §5): TEAM-plane F route-discovery dedup + rate-limit — team-PRIVATE
        // copies of _rreq_seen/_rreq_last (keyed by a team_local_id origin/dst) so a team RREQ can NEVER alias a static one
        // (§18 the two id-spaces can collide). Right-sized to team scale (16), NOT the static caps. Empty for a static node.
        RReqSeen _rreq_seen_team[16] = {};
        uint8_t  _rreq_seen_team_n = 0;
        RReqLast _rreq_last_team[16] = {};
        uint8_t  _rreq_last_team_n = 0;
        // §team-multihop 2c (spec 2026-07-16): the TEAM-plane liveness table — a self-contained mirror of _peer_liveness,
        // keyed by team_local_id, with its OWN on-demand LRU (team_liveness_slot). NEVER _peer_liveness / _team_keys
        // (which evicts by crypto-key recency — a different lifetime). Proactive dead-relay demotion; empty for a static node.
        PeerLiveness _team_liveness[protocol::cap_team_liveness] = {};
        uint8_t      _team_liveness_n = 0;
#endif
        // ==== MAC / FLIGHT pipeline (single flight per node): tx-queue · pending-tx/rx · post-ack · no-route defer ====
        // R3 data-plane state (single flight per node).
        TxItem                   _tx_queue[kTxQueueCap];
        uint8_t                  _tx_queue_n = 0;          // FIFO depth
        std::optional<PendingTx> _pending_tx;
        std::optional<PendingRx> _pending_rx;
        PostAck                  _post_ack;
        // No-route defer queue (insertion-order array; drained TTL-first on a beacon
        // route-change or the 1s periodic timer). _drain_armed gates the periodic timer.
        DeferredSend             _deferred[protocol::cap_deferred_sends];
        uint8_t                  _deferred_n = 0;
        bool                     _drain_armed = false;
        // ==== ROUTE-DISCOVERY (F) dedup ====
        // F route-discovery dedup state (Lua route_request_seen / route_request_last).
        RReqSeen _rreq_seen[protocol::cap_route_request_seen] = {};
        uint8_t  _rreq_seen_n = 0;
        RReqLast _rreq_last[protocol::cap_route_request_last] = {};
        uint8_t  _rreq_last_n = 0;

        // ==== DAD / id-bind (hash-locate: key_hash32 → node_id) — STRADDLES crypto: also feeds key_hash_for_id + E2E DST_HASH ====
        // Hash-locate id_bind table (Lua dv:4677): key_hash32 -> node_id, beacon-populated.
        IdBind   _id_bind[protocol::cap_id_bind] = {};
        uint16_t _id_bind_n = 0;

        // ==== CRYPTO / PEERS (sender-side hash→home · E2E pubkey cache · H flood dedup) — _mobile_home_cache ships in the STATIC build (not #if MR_FEAT_MOBILE) ====
        // §mobile 3c: sender-side mobile_hash -> home_id cache. id_bind CAN'T hold this (one-hash-per-id, and the home
        // owns its own authoritative hash), so a mobile's stable hash -> its home_node lives here. NO bijection (many
        // mobiles -> one home). Populated by the proxy-answer signature; read by send_by_hash. SILENT (no telemetry).
        MobileHomeBinding _mobile_home_cache[protocol::cap_mobile_home_cache] = {};
        uint8_t           _mobile_home_cache_n = 0;
        // E2E peer-pubkey cache (Phase 1 §6): key_hash32 -> ed_pub (authoritative, hash-verified).
        PeerKey  _peer_keys[protocol::cap_peer_keys] = {};
        uint16_t _peer_keys_n = 0;
        // H hash-locate flood dedup (Lua hash_query_seen): per-(origin,key_hash32), hash_query_seen_ttl_ms window.
        HashQuerySeen _hash_query_seen[protocol::cap_hash_query_seen] = {};
        uint8_t       _hash_query_seen_n = 0;

        // ==== LIVENESS / freshness + CROSS-PLANE-SHARED substrate (node_id-indexed, NO plane discriminator) ====
        // ★ KNOWN LEAK SITE (tech-debt, fix deferred to the PlaneRuntime split — NOT this legibility pass): the node_id-indexed
        //   arrays below (_dest_seen_ms/_link_bidi/_link_bidi_confirmed_ms/_mobile_peer/_link_reprobe_last_ms) AND the maps
        //   _blind_until/_neighbor_budget_tier(_set_at)/_per_sender_originator (in the DEDUP-MAPS section) carry NO plane
        //   discriminator — a team/mobile LOCAL-id write (e.g. _blind_until[team_local_id]; note_link_confirmed → _link_bidi[next_hop])
        //   aliases the SAME slot a colliding static node_id uses. Correct today (planes rarely co-active on one link); do NOT read
        //   these as plane-clean. See [[meshroute-plane-separation]].
        // ★ §P2-7 AUDIT (2026-07-20) — five MORE plane-blind / dirty-blind ledgers, documented here (behavior fixes = Wave 2/3).
        // ★★ THE FIRST THREE ARE NOW PLANE-KEYED — §team-parity T6/B (2026-07-28, spec §3/T6 Part B), which closes §10.3 /
        //    §9-Q4 and the [[meshroute-plane-separation]] re-audit-by-plane item. The pre-T6 text of each is kept below as
        //    the record of what was fixed, because every "safe today" reason it gives is an assertion that the TEAM PLANE IS
        //    QUIET — and R1 (full team/static routing parity) is this arc deliberately ending that.
        //   • _per_origin_channel (DEDUP section below): ✅ FIXED — keyed `(plane<<8)|origin` (node_channel.cpp
        //     channel_origin_admit). Pre-T6: "keyed by the BARE origin id, NO plane bit — a team origin and a static origin
        //     that collide numerically share ONE windowed distinct-id cap slot (over-throttle risk). Safe today: the planes
        //     rarely co-relay the same origin id." ⚠ That reason was ALREADY FALSE: ingest_channel_m admits a plain leaf M
        //     (static origin) AND a team-scoped M (team origin) on the SAME node — "planes = BOTH" is written at its own
        //     :174 gate — so a team member co-relays both today.
        //   • _seen_origins (DEDUP section below): ✅ FIXED — bit 61 = the TEAM plane, on top of the pre-existing bit 62.
        //     ⚠ The pre-T6 text ("the PLAINTEXT flight key (origin<<24|dst<<16|ctr) has NO plane bit, so a team and a static
        //     PLAINTEXT DM alias iff origin+dst+ctr ALL collide") was DRIFTED, and this note is where it drifted: bit 62
        //     (`mobile_from`) had already separated team-or-mobile from static. What it did NOT separate was TEAM from
        //     MOBILE-STATIC, since a registered mobile's ordinary static DM sets mobile_from too. Bit 61 closes that.
        //     CRYPTED flights were always immune (disjoint 2^63 nonce-seed space — see the key comment there).
        //   • _hash_query_seen (above): ✅ FIXED — `team_scoped` is part of HashQuerySeen::same_key, at zero RAM cost.
        //     Pre-T6: "the H-flood dedup key has NO plane discriminator — safe ONLY by an UNWRITTEN role-exclusion
        //     invariant: no node today processes BOTH the static and the team H-flood plane." ⚠ That invariant is
        //     DEFEATABLE BY LIVE CONFIG: `cfg set team_id`/`team <id>` never sets is_mobile (node.cpp:413), and a
        //     `team_id!=0 && !is_mobile` node passes BOTH of handle_h's plane gates (node_hashlocate.cpp:584/:603).
        //   • _mediated_recent (below, Node-global): ★ DELIBERATELY **NOT** PLANE-KEYED — T6/B AUDITED IT AND REFUSED THE
        //     FIT, because it does not alias across planes at all. Its key is `(node_id, loser_hash)` and `loser_hash` is a
        //     32-bit KEY hash — a global node identity, not a per-plane id — so an alias would need ONE physical node to be
        //     the key-loser for the SAME numeric id on BOTH planes. That is impossible: the two writers' loser sets are
        //     disjoint on the single wire field `b.is_mobile`. The TEAM writer (node_beacon.cpp:788) requires
        //     `same_team_beacon`, which is `b.is_mobile && same_team(peer_team)` (:532). The STATIC writer
        //     (node_hashlocate.cpp:90, inside id_bind_set) requires `source == bcn && authoritative`, and the ONLY site
        //     that passes that pair is node_beacon.cpp:627 — guarded by `!b.is_mobile` (:626). (node_join.cpp:276/311 also
        //     pass `bcn` but with `claimed`, which the mediation gate rejects.) is_mobile is a static per-node config that
        //     never flips at runtime, so no key can be in both sets. Adding a plane byte would cost +256 B of nRF52840 RAM
        //     (MediatedRecent 16 B -> 24 B x cap_mediated_recent 32) and move sizeof(Node) for a provably empty set.
        //   • beacon_max_idle_force (node_beacon.cpp): its dirty-entry count scans the STATIC _rt only — a team member that
        //     advertises _rt_team can have its max-idle B+C beacons suppressed while dirty TEAM entries are still pending.
        //   • team_resort_routes_through (node_routing.cpp): a primary change reranks _rt_team AND dirty-marks the moved entry +
        //     schedules ONE triggered beacon (Wave-2 ruling 2.3 FIX), so the rerank IS advertised on the member's own cadence —
        //     emit_beacon's dirty pass selects from src_rt = _rt_team for a team member (team_emit). See that function's header.
        // Peer-liveness + freshness plane (routing-liveness port): per-next-hop timeout tiers. Bounded LRU.
        PeerLiveness  _peer_liveness[protocol::cap_peer_liveness] = {};
        uint8_t       _peer_liveness_n = 0;
        // dest_seen freshness map (Lua dest_seen_ms@1289): node_id -> last-seen ms, FULL 0..254 range, NO eviction
        // — decoupled from the bounded _peer_liveness table so seen-bitmap gossip can keep ANY peer fresh (the
        // create=false piggyback starved gossip-only peers). is_next_hop_fresh reads this. 0 = never seen.
        uint64_t      _dest_seen_ms[256] = {};
        // Bidirectionality plane (asymmetric-link routing, 2026-06-29). Index = node_id, value = a LinkBidi.
        // Zero-init => every link defaults to 'unknown' (selectable, unpenalized). FULL 0..254 range, NO eviction
        // (like _dest_seen_ms) so a gossip-only or quiet peer keeps its state. _link_bidi_confirmed_ms is the
        // DEDICATED decay source — last real-CTS / complete-heard-set confirmation time (do NOT overload _dest_seen_ms).
        uint8_t       _link_bidi[256] = {};
        uint64_t      _link_bidi_confirmed_ms[256] = {};
        // ① mobile-peer set (Lua mobile_peers@1325): 1 bit per node_id, SET-only (is_mobile is a static per-node config,
        // never flips at runtime — Lua dv:9603-9604 sets, never clears). Eviction-free (unlike _peer_liveness) so a
        // gossip-only mobile is still avoided. 256 bits = 32 B/layer. Read by is_mobile_peer.
        uint8_t       _mobile_peer[32] = {};
        // Slow-reprobe throttle (asymmetric-link slice 6): per-next-hop last single-probe time for a
        // _link_bidi==one_way sole route. FULL 0..254 range (index 255/0xFF is the reserved id, never written — matches the
        // sibling _dest_seen_ms/_link_bidi arrays; the "0..255" was a stale off-by-one comment), eviction-free (like _dest_seen_ms) so an
        // isolated next-hop is throttled even if its PeerLiveness slot was LRU-evicted. 0 = never reprobed
        // (clock-at-0 -> the FIRST giveup probes immediately, then once per link_reprobe_ttl_ms).
        uint64_t      _link_reprobe_last_ms[256] = {};

        // ==== CHANNEL / FLOOD (gossip plane: buffer · per-origin ledger · pull/re-offer rings · flood table) ====
        // Channel-message gossip plane state (node_channel.cpp).
        ChannelEntry _channel_buffer[protocol::cap_channel_buffer];
        uint16_t     _channel_buffer_n = 0;
        // ★ §team-parity T6/B: keyed `(plane<<8)|origin`, NOT the bare origin — see channel_origin_admit for the composer
        // and the LIVENESS-section note above for why the bare key was already aliasing (a team member ingests both a
        // plain leaf M and a team-scoped M, so it co-relays both planes today). std::map's own size does not depend on
        // the key type, so widening uint8_t -> uint16_t costs 0 bytes and does not move sizeof(Node).
        std::map<uint16_t, ChannelOriginLedger> _per_origin_channel;   // (plane<<8)|origin -> windowed distinct-id ledger
        ChannelPullPending _channel_pull_pending[protocol::cap_channel_pull_pending] = {};
        ChannelPullRecent  _channel_pull_recent[protocol::cap_channel_pull_recent] = {};
        uint8_t            _channel_pull_recent_n = 0;
        FloodState         _flood[protocol::cap_flood_pending] = {};   // channel-flood in-progress table (slot i -> timer kFloodRebcastTimerId+i)
        ChannelReofferPending _channel_reoffer_pending[protocol::cap_channel_reoffer_pending] = {};  // Part 2: per-origin re-offer table (slot i -> timer kChannelReofferTimerId+i)

        // ==== DEDUP / ctr maps (node_id- or flight-keyed). ★ _blind_until / _neighbor_budget_tier / _per_sender_originator are part of the no-plane-discriminator LEAK cluster (see the LIVENESS section header above) ====
        // dedup maps.
        std::map<uint8_t, uint16_t>  _peer_send_counter;   // next_ctr per dst
        uint16_t     _peer_ctr_floor = 0;                  // D7: per-peer next_ctr floor (persisted high-water; resumes DM ctrs above the pre-reboot value)
        // ⛔ §B153 (2026-08-08): `_last_acked_from` (the RTS-time `already_received` cache) is GONE, and with it
        // `struct LastAcked`. A 7-B RTS cannot prove message identity, so no terminal dedup answer may be built
        // from one — the DATA-level `_seen_origins` below is the sole authority. See frame_codec.h's
        // `already_received` note for the argument. ⛔ Do not reintroduce it.
        // ★★★ §hybrid-rts S2 (2026-08-08) — THE COMPLETED-FLIGHT CACHE, and it is NOT `_last_acked_from` restored:
        // it is keyed by the FULL identity the 10/11-B RTS now carries (see `CompletedFlight` in node_carriers.h for
        // the key and why `payload_len` is absent), it stores the WIRE-declared plane, and its TTL is DERIVED
        // (`completed_flight_cache_ttl_ms` = `gateway_send_giveup_ms`), not the retired 10 s.
        // ★ A FIXED PER-LAYER ARRAY, not a map: no heap, deterministic eviction, and bounded by construction —
        //   the plan's "smallest bounded deterministic cache; do not allocate an unbounded/per-peer dynamic
        //   structure". Empty slot == `expiry_ms == 0`. Full table: prune expired, then evict min-expiry (U1 —
        //   `record_seen_origin`'s policy verbatim).
        // ⚠ PER-LAYER IS NOT PLANE ISOLATION (design §4.3): a gateway's two leaves get separate tables, but the
        //   TEAM and STATIC planes COEXIST inside one layer, which is why `team_plane` is part of the key.
        CompletedFlight _completed_flights[protocol::cap_completed_flights] = {};
        std::map<uint64_t, uint64_t>  _seen_origins;       // §1b TYPE-NAMESPACED flight key -> expiry_ms. PLAINTEXT =
                                                           // (origin<<24|dst<<16|ctr) in [0,2^32); CRYPTED = the full
                                                           // 8-B nonce-seed | (1<<63) in [2^63,2^64) — disjoint, can't alias.
        std::map<uint64_t, uint8_t>   _seen_origin_from;   // same key -> the prev-hop (LOOP_DUP discriminator)
        std::map<uint8_t, uint64_t>   _blind_until;        // next_hop -> absolute_ms it's deaf-on-routing (F1)
        // R4.2 persistent neighbor budget tier (routing-grade demotion beyond the short blind window).
        // mutable: get_neighbor_tier lazy-prunes the TTL-expired entry on read, like the Lua (dv:3863-3868).
        mutable std::map<uint8_t, uint8_t>  _neighbor_budget_tier;       // next_hop -> tier (1..3); absent/0 = HEALTHY
        mutable std::map<uint8_t, uint64_t> _neighbor_budget_tier_set_at; // next_hop -> absolute_ms the mark was set
        // R4.4 originator anti-spam: per-sender sliding-window ledger of overheard RTS/CTS (fixed ring).
        std::map<uint8_t, OrigRing> _per_sender_originator;  // sender_id -> recent events (fixed ring)

        // ==== Q REQ_SYNC plane dedup ====
        // Q REQ_SYNC plane dedup (Slice 2b — moved from Node scope; keyed by a REMOTE leaf-local q.src/requester,
        // so per-layer: a gateway's two leaves must not alias the same 8-bit id across distinct physical nodes).
        QResponded  _q_responded[protocol::cap_q_responded_to] = {};            // responder dedup ring (opcode|src|dest)
        uint8_t     _q_responded_n = 0;
        SyncPending _sync_pending[protocol::cap_sync_response_pending] = {};    // jittered full-table reply ring (per requester)

        // ==== per-leaf BEACON · HOST-MOBILE registry (#if MR_FEAT_MOBILE host side) · DISCOVERY · WINDOW timing ====
        // Slice 3d per-leaf beacon: a gateway beacons each leaf on its OWN cadence at window-activation (the shared
        // kBeaconTimerId is disabled for gateways — its single deadline halves the per-leaf cadence). 0 = never beaconed.
        uint64_t _last_beacon_ms = 0;
        // §mobile 2a (host registration): mobiles this host has accepted. Populated on a mobile CLAIM (claim-stands, no
        // reply); mobile_local_id is host-assigned from 17..254 (may overlap a global id — the Slice-1 mark disambiguates).
        // Per-leaf (a host serves one leaf). DORMANT unless a mobile registers -> the static mesh is unaffected.
        // ★★ §MH-S5 §9.1/§9.2 — `last_heard_ms` IS **THE ROW'S LIFETIME CLOCK**, and its meaning is now wider than
        // its name: for a DIRECT row it is the last direct evidence of the mobile — **CLAIM (seed) or a P PROBE (via
        // `mobile_reg_touch`), and ⛔ NO LONGER A BEACON: §B177-FIX (ledger §1.16) removed the beacon writer, because a
        // beacon carries no `reg_epoch` and so cannot establish the row identity a refresh needs** (this list read
        // *"CLAIM / probe / beacon"* before; corrected in place). For a REDIRECT row it is re-stamped at BREADCRUMB
        // RECEIPT so §9.2's redirect gets its own full `mobile_liveness_ms` rather than inheriting the direct row's time.
        // `mobile_reg_age_out()` applies ONE predicate to both kinds. ⛔ A separate `redirect_stamp_ms` was measured
        // and DECLINED: 8 B × cap_host_mobiles(16) × MR_N_LAYERS of RAM to store a value that is definitionally the
        // last thing this home heard ABOUT this mobile (and it would have moved `sizeof(Node)` ⇒ D2).
        struct HostMobileEntry { uint32_t key_hash32; uint8_t mobile_local_id; uint16_t epoch; uint64_t last_heard_ms;
                                 uint8_t redirect_home_id = 0; uint8_t redirect_epoch = 0; uint8_t redirect_home_layer = 0;
                                 uint8_t ed_pub[32] = {}; bool has_pubkey = false;
                                 char name[32] = {}; uint8_t name_len = 0;
                                 uint32_t last_key_fwd_hash32 = 0; bool deleg_fail = false; };  // §mobile 4b redirect (0 home = none) + §5b the new home's LAYER + §Part 2 the mobile's E2E pubkey (Fix 5) + §1.3 the mobile's name (pushed w/ the key) + §S3 part2 last_key_fwd_hash32 (the last requester key we forwarded to this mobile — dedup a same-requester re-forward); at struct END for positional aggregate-inits
        HostMobileEntry _mobile_reg[protocol::cap_host_mobiles] = {};
        uint8_t         _mobile_reg_n = 0;
        // §S6 presence plane (home side): per-mobile SNR EWMA (Q4) PARALLEL to _mobile_reg (HostMobileEntry stays unchanged),
        // mapped to the roster's 2-bit quality tier; plus the roster coalesce/rate-limit clocks. All host-gated (dormant on
        // a non-host -> static-inert). INT16_MIN = no sample yet (seeds to the first probe SNR).
        int16_t         _mobile_snr_q4[protocol::cap_host_mobiles] = {};
        uint64_t        _last_roster_ms       = 0;    // rate-limit floor (presence_roster_min_interval_ms)
        bool            _roster_coalesce_pending = false;   // a probe opened a coalesce window; the timer will emit ONE roster
        // §S6.4-D new-home->old-home notify: on OFFERing a discovering mobile whose last_home != 0 != self, stash the
        // last-home so the CLAIM (adopt) can originate the breadcrumb (D10). Small ring; evict-oldest.
        struct PendingNotify { uint32_t mobile_hash; uint8_t last_home_id; uint8_t last_home_layer; uint32_t last_home_hash = 0; uint64_t stash_ms = 0; };  // §B4: last_home_hash addresses a CROSS-LAYER breadcrumb by hash (0 = same-layer / unknown). §3-A.6/P2-6: stash_ms -> evict-STALEST when full (was evict-slot-0)
        PendingNotify   _notify_pending[protocol::cap_host_mobiles] = {};
        uint8_t         _notify_pending_n = 0;
        uint8_t         _dir_epoch = 0;               // §S6/D6: gateway-derived layer-directory version this node advertises in the roster (XOR aggregate of known gw epochs; a gateway derives its own)
        // §S6 rev2 ECHO (D14/D15): the coalesce window's FIRST probe echo — echo_hash32 + its RX quality tier. Emitted in
        // the next roster iff pending (a searching-probe canvass answer). One echo per window (first wins).
        uint32_t        _roster_echo_hash = 0;
        uint8_t         _roster_echo_q = 0;
        bool            _roster_echo_pending = false;
        // ⓘ §MH-S2: the OFFER de-storm stash USED to live here — `uint8_t _pending_offer[13]` + `_pending_offer_len`,
        // ONE slot per leaf, "last DISCOVER wins". It is GONE, replaced by the node-global keyed ring
        // `Node::_pending_mobile_offers` (see its note above for why node-global is the SEMANTICALLY correct scope and
        // not merely the cheaper one). Recorded here rather than silently deleted so a reader of the per-leaf state
        // does not go looking for it.
        // §per-layer discovery (2026-07-05): a GATEWAY bootstraps each leaf INDEPENDENTLY — the boot leaf must not trip
        // the OTHER leaf out of fast-cadence discovery (node-global discovery starved leaf 1 -> the 3h heartbeat). A
        // single-layer node has ONE leaf, so _active is always &_layers[0] => per-leaf ≡ the old node-global state
        // (byte-identical, proven by s18). Gateway-only BY CONSTRUCTION (is_gateway ≡ n_layers==2), no is_gateway branch.
        bool     _discovery_mode = false;        // fast cadence + full pages until exit
        uint64_t _discovery_started_ms = 0;
        uint64_t _discovery_until_ms = 0;
        uint16_t _discovery_bcn_rx_count = 0;
        // Slice 3e: absolute ms this leaf's window NEXT opens — the anchor for the receiver-anchored countdown
        // (schedule_record.offset). Set by the scheduler on every switch + at boot. countdown = (next_open-now) % period.
        uint64_t _next_open_ms = 0;
    };
#ifdef MESHROUTE_NATIVE
    // White-box test seam (native test build only — #ifdef'd out of every device build, zero firmware surface):
    // test/test_dual_layer.cpp points _active at each leaf + reads the per-LayerRuntime dedup maps to ASSERT the
    // Slice-2b non-aliasing property (§8). The gateway's real leaf-swap (activate_layer) lands in Slice 3.
    friend struct DualLayerTestAccess;
    friend struct E2eAckTestAccess;   // shelf item (i): white-box access to the pending-e2e-ack ring + arm/clear/fire (test_node_e2e_ack.cpp)
#endif
    // ======== GATEWAY / CROSS-LAYER scheduler (Node-global — spans leaves; survives a window swap) ========
    LayerRuntime  _layers[MR_N_LAYERS];
    LayerRuntime* _active = &_layers[0];
    uint8_t       _n_layers = 1;
    // Slice 3e.2: learned schedules of nearby GATEWAYS (Node-global — a node's view of the gateways it can reach,
    // independent of its own layers). Keyed by the gateway's node_id; evict-oldest on overflow.
    GatewaySchedule _gw_schedules[protocol::cap_gateway_neighbor_schedules];
    BridgedLayer    _bridged_layers[protocol::cap_bridged_layers];   // multi-hop gw_id->dest_leaf (type-4 TLV; ~8×11 B)
    // Slice 4c.1: cross-layer re-inject HANDOFFS (node-global — they span leaves; survive a window swap, drained on the
    // TARGET leaf's activate). A SMALL bounded ring (refuse-when-full LOUD, never drop-oldest a transit DM silently).
    XlHandoff _xl_handoffs[protocol::cap_gateway_handoffs];
    uint64_t _window_epoch_ms = 0;  // Slice 3d GRID anchor (boot instant = leaf-0's first window open); switch times = grid epoch + k·period (+window0), a busy slip never ratchets it. Grouped here w/ the cross-layer scheduler (was orphaned among the duty/R4.3 witnesses — cleanup 2026-07-15).

    // ---- own-origin anti-spam floors (Node-global timestamps; duty/anti-spam concern) ----
    uint64_t _ack_warn_until = 0;   // DM Inc 3: park new DM originations until this ms (set by a warn'd ACK)
    uint64_t _last_channel_origin_ms = 0;   // Slice 2: self side of channel_min_interval_ms (own channel posts)
    uint64_t _last_dm_origin_ms = 0;   // Slice 3: own-DM burst floor (dm_min_interval_ms); relays/floods/e2e-ack/rcmd exempt
    // ★ §chan-crypt CL2a: the `team_channel_no_key` PUSH floor (protocol::team_channel_no_key_push_min_ms). NOT an
    // origination floor like the three above — it is a RECEIVE-side rate limit — but it is the same kind of quantity
    // (a Node-global ms stamp) and it is placed at the END of this 8-aligned u64 run so it costs exactly its own
    // 8 bytes and opens NO hole: the next member is the 4-aligned `_nack_wait_flight_gen`.
    // ⚠ It holds the NEXT-ALLOWED instant, not the LAST-PUSHED one, and that is a bug fix not a style choice: with a
    // last-pushed stamp, 0 has to double as "never pushed", and a node whose clock is still 0 (boot, and every native
    // test) writes 0 back — so the limiter never engages and every unreadable post prompts. Next-allowed needs no
    // sentinel: 0 means "allowed now" both before the first push and never again after it.
    // The TELEMETRY twin is deliberately un-limited (the bench wants every occurrence).
    uint64_t _team_ch_nokey_push_next_ms = 0;
    // NACK BUSY_RX wait-same-hop: the captured ctr_lo the kNackWaitTimerId re-RTSes for.
    uint32_t                     _nack_wait_flight_gen = 0;   // L9: the EXACT flight the BUSY_RX same-hop re-RTS wait belongs to (was the 4-bit ctr_lo proxy — 1/16 alias could re-RTS a since-replaced flight)
    bool                         _nack_wait_pending = false;
    // §F-XL-1 (2026-07-18): jittered h_forward de-storm. Sibling relays that heard the SAME H flood copy re-tx it
    // with ZERO jitter today -> a deterministic same-ms collision at any common/downstream receiver (s27 hello-m4:
    // T2+T3 forward at the identical ms every handoff retry, T4 behind T3 decodes neither). Stash the built frame,
    // fire after a small random delay (kHForwardTimerId+slot); the existing LBT then defers the later sibling. A
    // small RING (not single-slot): a dense mesh has concurrent floods for DIFFERENT hashes, which single-slot would
    // clobber. Node-global (the H frame is self-contained incl. its leaf_id; a gateway's two leaves share the radio).
    // jittered_tx_stash.h contract: `buf[N]` + `len` (0 = nothing armed / already fired); jtx_ring_arm
    // owns the fit guard, the cursor and the timer-id pairing, jtx_ring_armed + jtx_fire own the firing.
    static constexpr uint8_t kHForwardSlots = 4;
    struct HForwardStash { uint8_t buf[8 + 32 + 4 + 1 + 32]; uint8_t len = 0; };   // <=77 B H frame (matches pack_h)
    HForwardStash _h_forward_stash[kHForwardSlots];
    uint8_t       _h_forward_rr = 0;   // round-robin write cursor
    // §F-XL-2 (2026-07-19): jittered rreq_forward de-storm — the SAME machinery as F-XL-1 for the AODV RREQ relay
    // (node_route_discovery.cpp, static + team). Sibling relays that heard the same RREQ flood re-broadcast it at the
    // identical ms -> deterministic collision. Stash + jittered fire (kRreqForwardTimerId+slot). The packed F frame is
    // self-contained (leaf_id / team scope baked in by pack_f), so ONE Node-global ring serves both planes; the RING
    // (not single-slot) covers concurrent discoveries for DIFFERENT dsts. The 16-B buf matches pack_f's bound.
    // Same jittered_tx_stash.h contract as the F-XL-1 ring above.
    static constexpr uint8_t kRreqForwardSlots = 4;
    struct RreqForwardStash { uint8_t buf[16]; uint8_t len = 0; };   // <=16 B F frame (matches pack_f's buf[16])
    RreqForwardStash _rreq_forward_stash[kRreqForwardSlots];
    uint8_t          _rreq_forward_rr = 0;   // round-robin write cursor
    // async push ring (the app channel; drained via next_push, drop-oldest on overflow)
    Push     _push_ring[protocol::cap_push_ring];
    uint8_t  _push_head = 0, _push_count = 0;
    // _remote_inbound relocated to the REMOTE-MGMT section (identity block above) — cleanup 2026-07-15.
};

#ifdef MESHROUTE_NATIVE
// LAYOUT-INVARIANCE tripwire (native layout ONLY — NOT a RAM budget: native sizeof != nRF52 sizeof, different
// pointer/enum/alignment). Purpose: the node.h legibility reorder (2026-07-15 by-concern member reorder) must not
// change Node's layout. If this fires after a *deliberate* member add/remove/type change, update the baseline
// consciously — it is a tripwire, not a frozen contract. The real nRF52 RAM check is the firmware.map .bss/.data diff.
// 7b-1 rev-6 compiler reveal: 224136 -> 225920 (+1784 = pool 1776 + counters 6 + tail alignment 2).
// R-RA-34 authorizes this measured re-pin. The prior Slice 5 decomposition stays below as history.
// 8a R-RA-45: 230976 -> 235248 (+4272); CLIENT 4512 less legacy whole-Node credit 240.
// 7b-2 compiler reveal (native-first-build.log): 225920 -> 230896, +4976 R-RA-35 open state.
static_assert(sizeof(Node) == 235248, "node.h: Node native layout changed — if intentional, update the baseline");   // 222072 -> 224136 (+2064 §remote-admin v2 SLICE 5 — the target's authenticated-session/admission/bootstrap block, and the ABI re-pin is AUTHORIZED: R-RA-31, verbatim *"Agree - Slice 5 answers bootstrap on air, ABI re-pin authorized"*. BOTH halves of the number are MEASURED by a compile-only template reveal on each target's OWN `pio run -t idedata` flag set (`tools/probe_board_abi.py`'s flag authority), never inferred from the delta. ARITHMETIC, and it closes EXACTLY on all three ABIs — with three DIFFERENT answers, which is the whole point of the control. (a) THE BLOCK: `sizeof(RemoteSessionState)` = **2064**, alignof 8, itself asserted member-by-member in `remote_session.cpp` (pair 64 + ACL 340 + status 4 + epochs 80 + seen 896 + headers 80 + bodies 472 + staging 128, offsets 0/64/404/408/488/1384/1464/1936, ZERO tail padding). (b) THE CREDIT: `_remote_inbound` (`sizeof(Node::RemoteInbound)` = **245** on all three ABIs) becomes `#if MR_FEAT_RADMIN_CLIENT`. ★ THE TWO ARE INDEPENDENT AND WERE MEASURED SO: a variant tree carrying the CLIENT gate but NOT the block reproduces the BASE `sizeof` byte for byte on all three targets (222072 / 117912 / 148680), so neither half is inferred from the other. ⇒ PER TARGET, and NOT uniform — the OPPOSITE of §B278 S1a's ungated ring one entry below: · **native (R-RA-17 `{1,1}`, BOTH roles) 222072 -> 224136 = +2064 EXACTLY.** By offsetof: `_admin_provisioned`@224, `_remote_inbound`@225..469 (RETAINED — native compiles the client role, so the slot is ⛔ NOT subtracted here), `_channel_seal_ctr`@470..471 ending EXACTLY on the 8-byte boundary, so the 8-aligned block lands at 472 with ⛔ ZERO padding and `_cfg` moves 472 -> 2536 = 472+2064: every later member shifts by exactly 2064 and NO hole opens anywhere. SIXTEENTH application of the radio_freq_mhz / team_hop_cap / T-K1 padding-placement rule. · **heltec_mobile (Xtensa, MR_PROFILE_MOBILE, CLIENT-only) 117912 -> 117912 = +0, THE UNMOVED CONTROL R-RA-31 requires.** Every offset is identical too (`_remote_inbound`@180, `_channel_seal_ctr`@426, `_cfg`@432), because the block is `#if MR_FEAT_RADMIN_ACCEPT` and the slot it would have paid for is exactly the one that role keeps. ⚠⚠ AND AN UNMOVED `sizeof(Node)` IS ⛔ NOT UNMOVED BOARD RAM ([[B331]]): `TimerWheel::kCap` 91 -> 92 costs +8 B inside `DeviceHal::_wheel`, which is HAL storage on EVERY build, this one included. · **gateway (ARM Cortex-M4, MR_PROFILE_GATEWAY, MR_N_LAYERS=2, ACCEPT-only) 148680 -> 150504 = +1824**, and the three terms close exactly by offsetof: `_admin_provisioned` stays @152; dropping the 245-byte slot moves `_channel_seal_ctr` 398 -> 154, i.e. **-244** and not -245 because offset 153 is odd and the 2-aligned counter needs ONE new pad byte there; the 8-aligned block then needs **+4** more pad (156..159) and lands @160; **+2064** for the block itself; `_cfg` moves 400 -> 2224 and every later member shifts by exactly 1824. ⇒ -244 + 4 + 2064 = **+1824**. ⓘ The same decomposition read from `sizeof` alone agrees: the gate-only variant measures 148440 (= 148680 - 240, the -244 rounded by the struct's own 8-byte tail alignment) and the block adds 2064 on top. ⛔ `TimerWheel::kCap` DOES move for this slice, 91 -> 92, and EXACTLY ONE id is allocated (`kRadminExpiryTimerId` = 91, the ONE shared earliest-deadline scan, R-RA-22 / design §15) — but the wheel is `DeviceHal::_wheel`, ⛔ NOT a Node member, so that +8 is HAL RAM and is NOT part of any number on this line. ⛔ ZERO telemetry reaches an existing stream: every new `MR_EMIT` sits on the v2 accept path, which no corpus scenario airs (no scenario sends `0xA0`), so all 36 streams stay byte-identical and the delta stays attributable.). 222008 -> 222072 (+64 §B278 S1a — the ONE delegated-flight correlation row generalized, and BOTH halves of the number are MEASURED by a compile-only template reveal on each target's OWN `pio run -t idedata` flag set (`tools/probe_board_abi.py`'s flag authority, driven through `abi.measure`), never inferred from the delta. ARITHMETIC, and it closes exactly: `sizeof(Node::DelegAck)` **24 -> 32** — B251's single phase-dependent `peer` (u32) splits into `target` + `return_peer` (**+4**, the 4-byte run grows from 12..15 to 12..19), its single `peer_kind` splits into `target_kind` + `return_kind` (**+1**), and `outward_type` + `custody_state` (**+2**) land in the byte run — 7 new bytes against the **2** bytes of tail padding the 24-byte row already carried, so the row crosses ONE 8-byte quantum and grows by 8, NOT by 7. x `kDelegAckCap`(**8**) = **64**. ★ NO HOLE OPENS ANYWHERE, and that is a placement fact rather than a hope: `_deleg_acks` sits immediately after `_parked_sends` (whose `reflood_at_ms` makes ParkedSend 8-aligned, so the array ends 8-aligned) and immediately before the 8-aligned `_pending_e2e_acks`; 192 and 256 are both multiples of 8, so every later member shifts by EXACTLY 64. ⚠ **THIS +64 IS UNIFORM ON EVERY ABI AND EVERY PROFILE — the opposite of the §UI-16 N1 entry below it** — because the ring is NOT `MR_FEAT_*`-gated: a static-only gateway build carries it too (a home hosting no mobile simply never fills a row). MEASURED on all three: native **222008 -> 222072**, heltec_mobile (Xtensa, MR_PROFILE_MOBILE, 1 layer) **117848 -> 117912**, gateway (ARM Cortex-M4, MR_PROFILE_GATEWAY, MR_N_LAYERS=2) **148616 -> 148680** — +64 on all three, no cell disagreeing, and the three `tools/probe_board_abi.py` pins were re-pinned from exactly those measurements. ⛔ `TimerWheel::kCap` is UNCHANGED and NO timer id is allocated: the row still expires by the same single age comparison against the same value, now spelled `protocol::delegated_custody_ttl_ms`. ⛔ ZERO telemetry change — every existing `deleg_ack_*` event keeps its name, its fields and their order (the `deleg_ack_put` field stays named `peer` although the struct field became `return_peer`), which is what lets the 36-stream corpus stay byte-identical and therefore mean something.). 221880 -> 222008 (+128 §UI-16 N1 — the READ-ONLY nearby-team observation cache, and BOTH halves of the number are MEASURED by a compile-only template reveal on the native env's OWN flag set (`-DMESHROUTE_NATIVE=1 -DMR_N_LAYERS=2`), never inferred. ARITHMETIC, and it closes exactly: `sizeof(TeamSeen)` = **16** (alignof 8, `offsetof(team_id)` 8, `offsetof(src_id)` 14 — all four pinned beside the struct in team_seen_ring.h, on every board toolchain and not only native) x `cap_team_seen`(8) = **128**. The array is 8-aligned and 128 is a multiple of 8, so every later member shifts by exactly 128 and NO hole opens anywhere. ★ AND THE COUNT BYTE `_team_seen_n` COSTS ZERO — MEASURED BY REMOVAL, not by the padding argument: sizeof(Node) is 222008 with and without it on the same tree, because it takes one of the pad bytes that already sat between `_parked_sends_n` and the 8-aligned `_l2c_redirect`. ⚠ ITS DECLARATION ORDER IS LOAD-BEARING and that too was measured, not reasoned: declared AFTER the array instead of before it, the same byte measures **222016 (+136)** — it would then sit past the array's 8-aligned end and open a fresh hole. FOURTEENTH application of the radio_freq_mhz / team_hop_cap / T-K1 padding-placement rule. ⚠ this line is native-ONLY: both members are `#if MR_FEAT_TEAM`, so the two gateway_* envs (MR_FEAT_TEAM 0) pay **+0** and the per-board RAM diff is the gate's (native's 8-byte alignment structurally hides a 4-byte-align board padding shift — D2). ⛔ `TimerWheel::kCap` is UNCHANGED and NO timer id is allocated: retention is a cutoff comparison at READ time, never a sweep. ⛔ ZERO telemetry on the new path — an `MR_EMIT` here would re-anchor the team corpus streams in the same run as the behaviour change and make the delta unattributable.). 221288 -> 221880 (+592 §hybrid-rts S2 — the DATA-validation state and the completed-flight cache, and the number is MEASURED by a compile-only template reveal on the native env's OWN flag set (`-DMESHROUTE_NATIVE=1 -DMR_N_LAYERS=2`), not inferred — an ad-hoc flag set reads a DIFFERENT feature build and would be a false alarm. ARITHMETIC, and it closes exactly: (a) `PendingRx` 32 -> **40** — the 6-B `RtsFlightIdentity` POD plus the `wire_team_plane` bool need SEVEN bytes and only SIX of tail padding were free (the two existing bools sit at 24/25 before 6 pad bytes), so the struct crosses its 8-alignment quantum; `std::optional<PendingRx>` therefore goes 40 -> **48**, i.e. **+8 per layer**. ⛔ A +0 variant exists and was DECLINED under M3: dropping the separate `domain` field (it is 1:1 with `width` today) would fit the seven bytes into six — and would let a plaintext and a crypted identity compare equal by numeric accident, which is the one thing the domain field exists to prevent. (b) the cache `CompletedFlight[cap_completed_flights]` = **24 B x cap_completed_flights(12) = 288 per layer** (`CompletedFlight` measures 24: the 8-aligned `expiry_ms`, then the 6-B identity + `from`/`dst`/`team_plane` in the 8 bytes that follow, with 1 byte of tail pad). ⇒ (8 + 288) x MR_N_LAYERS(2) = **592**. ⓘ The capacity 12 is MEASURED, not chosen — see `cap_completed_flights` in protocol_constants.h: capacity 8 loses 5 of the 429 corpus cache hits and capacity 1 loses 105 of them. ⚠ BOTH HALVES ARE PER-LAYER, so the cost is per-ABI and NOT uniform: a SINGLE-layer board pays **296**, a 2-layer build **592** — the same shape as §B153's reclaim, and the reason this line is native-ONLY. ⛔ **THIS LINE READ "a 2-layer build 400" until §hybrid-rts S2b (2026-08-09) corrected it: 400 contradicted the very arithmetic three sentences earlier in this same entry — `(8 + 288) x MR_N_LAYERS(2) = 592` — and 592 is what the tripwire above actually measures (221288 -> 221880). The per-layer figure 296 was right; only the doubled one was wrong.** The per-target proof is the compile-only reveal recorded in `simulation/BASELINE.md` §HYBRID-RTS-S2. ⛔ `TimerWheel::kCap` is UNCHANGED at 91 and NO timer id is allocated — the cache is a deadline scan on absolute expiry, never a timer.). 221384 -> 221288 (★ **−96 §B153, and this is the first entry in this ledger that makes the node SMALLER for a behaviour fix rather than paying for one.** The whole of it is the DELETION of `LayerRuntime::_last_acked_from`, the per-hop `already_received` cache retired with the RTS-time dedup gate (see the argument at `already_received` in frame_codec.h: a 7-B RTS cannot prove message identity, so no terminal verdict may be built from one). ARITHMETIC, MEASURED by a template-reveal on the real native flag set (`-DMESHROUTE_NATIVE=1 -DMR_N_LAYERS=2`), not inferred: `sizeof(std::map<...>)` is **48** on this libstdc++ and the member is PER-LAYER, so 48 x MR_N_LAYERS(2) = 96. ⚠ THE RECLAIM IS THEREFORE PER-ABI AND NOT UNIFORM: a SINGLE-layer board reclaims **48**, a 2-layer build **96** — the mirror of §MH-S2's per-layer credit, and the reason this line is native-ONLY. `sizeof(PendingRx)` is **32, UNCHANGED** — the `flight_id`/`team_plane` members the refuted first attempt added there are gone with it. Per-board RAM deltas are the warning-census figures in `simulation/BASELINE.md` §B153.). 221376 -> 221384 (+8 §MH-S4 — the confirmed-attachment FSM, and the number is MEASURED BY BISECTION ON THIS TRIPWIRE, not inferred; the whole cost is ONE member. FOUR members were added and THREE of them cost ZERO: `_mobile_attach_state` (u8 enum), `_mobile_home_link` (u8 enum) and `_mobile_claim_retries` (u8) go into the THREE bytes of pure alignment pad that [[B142]]'s own note records as still sitting beside `_presence_cand_n` — ★ but BEFORE `_mobile_attach_gen`, not after it, because that u32 needs 4-alignment and therefore lands at the END of the run and closes the boundary. Declaring the trio AFTER the u32 MEASURED +8 for the trio alone (221376 -> 221384) and the full state at 221392; moved ahead of it, the trio measures +0 and the state lands at 221384. THIRTEENTH application of the padding-placement rule, and the first time the plausible reading of an existing note was off by one member. The remaining +8 is `_mobile_home_confirmed_ms` (u64), a GENUINE cost in the 8-aligned ms-stamp run (`_last_adopt_ms` / `_presence_last_pull_ms`), which has no hole. ⚠ A +0 VARIANT WAS MEASURED AND DECLINED: narrowing that stamp to u32 and placing it after `_presence_home_rx_q4` measures 221376 EXACTLY, i.e. the entire slice for free — declined under M3 ('pick the RIGHT shape, never contort a design to fit a spare bit') because a u32 ms stamp buys 8 bytes with a truncating cast, wrap-relative age arithmetic, a 49.7-day ceiling and a periodic collision with its own 0 sentinel. ⛔ `TimerWheel::kCap` is UNCHANGED at 91 and NO new timer id is allocated — the re-CLAIM and the confirmation deadline both ride the EXISTING kPresenceProbeTimerId. This line is native-ONLY; the per-ABI proof is the compile-only reveal recorded in §MH-S4.). 221088 -> 221376 (+288 §MH-S2 — the keyed pending-OFFER ring, and the number is a NET of two measured halves, neither inferred. (a) COST +320: `PendingMobileOffer` measures 40 B / alignof 8 (two u64 deadlines, a u32 key, then buf[13]+len+proposed_id in the 4+16 that follows, 5 B tail pad — asserted beside the struct by sizeof + TWO offsetofs, not by this line) x cap_pending_mobile_offers(8) = 320, inserted immediately after `_pending_id_pubkey` which ends 8-ALIGNED (`_peer_loc`'s own precedent at the same seam); 320 is a multiple of 8 so every later member shifts by exactly 320 and NO hole opens. ★ AND THE TWO uint16 COUNTERS COST ZERO — measured by REMOVAL, not by the padding argument: sizeof(Node) is 221408 with and without them on the same tree. TWELFTH application of the padding-placement rule. (b) CREDIT -32: `LayerRuntime::_pending_offer[13]` + `_pending_offer_len` are DELETED (the ring replaces them), and 14 B of members returned 16 B per LayerRuntime after re-alignment x MR_N_LAYERS(2 native) = 32. ⇒ 320 - 32 = 288. ⚠ THE CREDIT IS PER-LAYER AND THE COST IS NOT, so the net differs by ABI: a SINGLE-layer board pays 320 - 16 = +304 while native/gateway (2 layers) pay +288. This line is native-ONLY; the per-target proof is the compile-only reveal recorded in the §MH-S2 slice report, run on all five REAL toolchains. ⛔ `TimerWheel::kCap` is UNCHANGED at 91 — the ring runs on the EXISTING kMobileOfferBackoffTimerId as a deadline scan, and no timer id was allocated.). 221024 -> 221088 (+64 §id-hash S4b — the `resolve-id-for-pubkey` intent ring, MEASURED by offsetof + the assert pair beside the struct, not inferred: sizeof(PendingIdPubkey) = 16 (offsetof(id) = 8, i.e. both bytes sit in the tail pad the 8-aligned `deadline_ms` already forces) x cap_pending_id_pubkey(4) = 64. Inserted immediately after `_pending_e2e_acks`, which ends 8-ALIGNED (PendingE2eAck[8] x 24) — §AB4's `_peer_loc` precedent at the same seam — and 64 is a multiple of 8, so every later member shifts by exactly 64 and NO hole opens anywhere. ⚠ NOT team-gated and deliberately so: a by-id `reqpubkey` on the STATIC plane is the bench defect this arc opened with (spec §0), so a gateway build carries the ring too. Per-board RAM deltas in the slice report.). 220976 -> 221024 (+48 §tx-admission TX3 — the OWNER-RULED transmitter-admission boundary for the channel digest: DeferredLbt gains `uint32_t digest_ids[3]`, MEASURED by offsetof not inferred: sizeof(DeferredLbt) 164 -> 176 (+12), offsetof(digest_ids)=12 and offsetof(buf) 12 -> 24, i.e. it lands in the 4-aligned run before `buf` and opens NO new hole; x kLbtSlots(4) = +48. ⚠ The BRIEFED estimate was +64 (3 ids + a count byte); the count byte was removed by making `digest_ids[0] == 0` the terminator — a live channel id can never be 0 (channel_msg_id_mint packs origin >= 1 into the high byte) — which is what bought the 16 bytes back. Per-board RAM deltas in the slice report.). 220968 -> 220976 (+8 §chan-crypt CL2a, and BOTH new members are measured by offsetof + a template-reveal, not inferred. TWO members were added and only ONE of them costs anything. (a) `_team_ch_nokey_push_ms`, a uint64_t, is appended to the EXISTING 8-aligned run of own-origin ms stamps (_ack_warn_until / _last_channel_origin_ms / _last_dm_origin_ms) and the member after that run is the 4-aligned `_nack_wait_flight_gen`, so it opens NO hole anywhere and costs exactly its own 8 bytes. (b) `_channel_seal_ctr`, a uint16_t, costs ZERO — and where it sits is the whole reason. Its SEMANTIC home is beside `_relay_seal_ctr` (native offset 186), and MEASURED there it costs EIGHT: at 188 it pushes _admin_pubkey 188->190, which pushes the 4-aligned _admin_counter_floor 220->224 (two new pad bytes) and then the 8-aligned _cfg 472->480 (six more). Placed instead immediately after `_remote_inbound` it lands at 470, inside the 2-byte pad that already sat before the 8-aligned _cfg, and sizeof is unchanged by it. EIGHTH application of the padding-placement rule below. (c) NodeConfig::team_channel_crypt costs ZERO TOO and is NOT part of this +8: sizeof(NodeConfig) 256 -> 256, because the bool takes native byte 95 — the one pad byte still left in the dv_hop_cap@93 / team_hop_cap@94 / radio_freq_mhz@96 hole that team_hop_cap's own note describes. SEVENTH application. ⚠ this line is native-ONLY, so the per-target proof is the compile-only sizeof reveal on the REAL toolchains with the REAL per-env flag sets, recorded in the §chan-crypt CL2a slice report — and NOW INLINE, because omitting them left the newest per-target numbers in this ledger reading as AB4's and therefore STALE BY +8, which §b39 caught: xiao_sx1262 / xiao_esp32s3 117048 -> **117056**, gateway / gateway_esp32s3 147664 -> **147672**, both *_mobile 117016 -> **117024**.). 220648 -> 220968 (+320 §AB4 — the retained-peer-location ring, and BOTH halves of the number are measured, not inferred. THE RECORD: sizeof(PeerLoc) = 20, alignof 4, offsetof(src) = 16 — i.e. §2.7.1's briefed `{u32 hash; i32 lat; i32 lon; u32 t_s}` really is 16 B with no padding (that premise HELD, measured), but the RESCOPE that added `loc_src` pushed it to 20 with a 3-byte tail hole, so the spec's "16 B exactly, x16 = 256 B" and its own loc_src requirement cannot both be true — 320 B is the honest figure. Those 3 bytes are declared as a NAMED `reserved[3]` member: identical size, but IMPLICIT tail padding is INDETERMINATE after `PeerLoc{}`, which would make any memcmp-style comparison over the record unsound (AB1's lesson, which briefed 70 B and measured 72). THE PLACEMENT, by offsetof native and cross-checked on ARM: `_peer_loc[16]` is inserted immediately after `_pending_e2e_acks` and before `_parked_sends_n`. `_pending_e2e_acks` is PendingE2eAck[8] x 24 B ending on an 8-ALIGNED boundary (native 5208+192 = 5400; ARM 5192+192 = 5384), and PeerLoc needs only 4, so the array opens NO hole and its 320 B (= 8x40, itself a multiple of the 8-alignment downstream) shifts every later member by exactly 320: native `_l2c_redirect` 5408 -> 5728, ARM 5392 -> 5712. ★ AND THE COUNT BYTE `_peer_loc_n` COSTS ZERO: `_parked_sends_n` (a uint8_t) was already followed by SEVEN bytes of pure alignment pad before the 8-aligned `_l2c_redirect` (native 5401..5407, ARM 5385..5391); `_peer_loc_n` takes one of them and the hole shrinks to SIX (native 5722..5727, ARM 5706..5711). SIXTH application of the radio_freq_mhz / team_hop_cap / HashQuerySeen.team_scoped / T5-PeerLiveness / T-K1-_team_ch_key_present padding-placement rule. ⚠ this line is native-ONLY, so the per-target proof is a compile-only sizeof reveal on the REAL toolchains with the REAL per-env flag sets, whose PRE column reproduces this ledger's §loc-per-send figures EXACTLY (that is what calibrates it): xiao_sx1262 116728->117048, gateway 147344->147664, xiao_mobile 116696->117016, xiao_esp32s3 116728->117048, gateway_esp32s3 147344->147664, xiao_esp32s3_mobile 116696->117016 — ★ +320 UNIFORMLY ON ALL SIX ABI x member-set cells, no cell disagreeing and no hole opening anywhere, INCLUDING the two MR_FEAT_TEAM 0 gateways: the ring is deliberately NOT team-gated, because its live source is a sealed DM and a static-only build receives one exactly as a team member does. ⇒ the six-env LINK grid was NOT run and did not need to be: the grid exists to find a per-target padding difference, and the six-cell probe measured that there is none — so the RAM/flash figures come from the standard three envs (T-K1's recorded precedent).). 220656 -> 220648 (−8 §loc-per-send, and this one is worth reading because it is the FIRST entry in this ledger that REMOVES a member — a single `bool`, and it paid back EIGHT bytes, not one. Arithmetic, MEASURED by offsetof + a template-reveal on all six board flag-sets, not inferred: NodeConfig's tail ran lat_e7 @164, lon_e7 @168, then the four bools loc_in_dm @172 / loc_in_m @173 / e2e_dm @174 / intro_attach @175, then n_layers @176, SEVEN bytes of pure alignment pad (177..183), and the 8-ALIGNED `LayerConfig layers[2]` (40 B each) @184, ending at 264 with no trailing pad. Deleting `loc_in_dm` slides the three surviving bools and n_layers down one, so n_layers lands at 175 — the LAST byte before the 8-byte boundary — and `layers` moves back to 176, ending at 256. ⇒ sizeof(NodeConfig) 264 -> 256. The byte was therefore NOT sitting in a hole (the padding-placement rule's usual case, five prior applications below): it sat exactly ON the boundary, so it was costing a FULL 8-byte quantum and its removal reclaims all of it, while the 7-byte hole after n_layers shrinks to 0. Node embeds one 8-aligned `_cfg` (native offset 472, unchanged because everything before it is untouched), so Node loses exactly what NodeConfig loses: -8, uniformly. ⚠ this line is native-ONLY, so the per-target proof is the compile-only reveal recorded in the §loc-per-send slice report: sizeof(Node) -8 on ALL SIX flag-sets (xiao_sx1262 116736->116728, gateway 147352->147344, xiao_esp32s3 116736->116728, xiao_mobile 116704->116696, gateway_esp32s3 147352->147344, xiao_esp32s3_mobile 116704->116696) with sizeof(NodeConfig) 264->256 on every one — i.e. it moved on every ABI × member-set cell, which is what FORCED the six-env D2 grid for this slice rather than the usual three.). 220592 -> 220656 (+64, NOT +65 and NOT +72 — §team-ch-key T-K1 adds 65 B of state and pays for 64. Arithmetic, measured by template-reveal on all six board flag-sets, not inferred: (a) _team_ch_pub[32] + _team_ch_priv[32] are inserted immediately after _ed_pub, i.e. between _ed_pub and _crypto_ready. 64 is a multiple of 8, so EVERY downstream member keeps its alignment and NO new hole opens anywhere: native _crypto_ready 121->185 (still odd, so the 2-aligned _relay_seal_ctr still needs no pad), _admin_pubkey 124->188, the 4-aligned _admin_counter_floor 156->220 (still 4-aligned), _remote_inbound 161->225 ending 406->470, and the 8-aligned _cfg 408->472 with its pre-existing 2-byte pad UNCHANGED. The arrays therefore cost exactly their own 64 B. (b) the has-key flag `_team_ch_key_present` costs ZERO: it is placed at native offset 19, in the alignment pad that already sat between _team_dad_pending (18) and the 4-aligned _key_hash32 (20) — the SAME hole node.h:1242's note keeps _team_local_id/_team_dad_pending here to exploit. Placing it beside the keys instead would have made the insert 65 B, flipping _crypto_ready to an EVEN offset (186) so _relay_seal_ctr needs a pad byte, and pushing _admin_counter_floor off its 4-alignment for two more — measured +72, i.e. the flag would have cost 8. FIFTH application of the radio_freq_mhz / team_hop_cap / HashQuerySeen.team_scoped / T5-PeerLiveness padding-placement rule. ⚠ this line is native-ONLY and unverifiable on a board ABI, so the per-target proof is the compile-only sizeof probe recorded in the T-K1 slice report: +64 on ARM-full, Xtensa-full and both *_mobile (MR_FEAT_REMOTE_MGMT 0), and +0 on both gateway_* (MR_FEAT_TEAM 0 strips all three members)). 220592 -> 220592 (+0 §team-parity T6/B, and the SLICE BRIEF EXPECTED THIS TO MOVE — it does not, measured by template-reveal not by the assert alone. Arithmetic, per ledger: (1) HashQuerySeen gains `bool team_scoped` and stays 24 B — origin(1)+pad(3)+key_hash32(4)+t_ms(8) then hard+want_pubkey+team_scoped(3)+pad(5); the third bool lands in the 6 bytes of tail padding the previous two already shared, so the ×cap_hash_query_seen(64) ×MR_N_LAYERS array is unchanged. (2) _per_origin_channel's key widens uint8_t -> uint16_t, and sizeof(std::map) does not depend on its key type (the key lives in heap-allocated nodes), so 0 B. (3) _seen_origins takes a bit in an EXISTING uint64_t key — no member added. (4) _mediated_recent was AUDITED AND DELIBERATELY LEFT ALONE: its two writers' key sets are provably disjoint on b.is_mobile (see the §P2-7 note), and MediatedRecent measures 16 B, so a plane byte would have made it 24 B ×cap_mediated_recent(32) = +256 B of nRF52840 RAM for an empty set. THAT is the +256 this line does not carry). 220592 -> 220592 (+0 §team-parity T0: NodeConfig.team_hop_cap, a uint8_t placed immediately after dv_hop_cap. Arithmetic: dv_hop_cap sits at native offset 93 and the next member (the 8-byte-aligned `double radio_freq_mhz`) at 96, so bytes 94-95 were pure alignment pad; the new member takes byte 94 and the hole shrinks to one byte. sizeof(NodeConfig) 264 -> 264 and sizeof(Node) 264-worth-of-config unchanged => the member costs literally nothing. This is the radio_freq_mhz placement rule below applied a second time, and it is why the value on this line did NOT move). 220584 -> 220592 (+8 §layer-freq: NodeConfig.radio_freq_mhz, a `double` placed between dv_hop_cap and the existing `double duty_cycle` so it fills the 8-byte-alignment padding slot already there — measured sizeof(NodeConfig) 256 -> 264, i.e. the member costs its own 8 B and opens NO new hole; the same slot after `radio_cr` would have cost 16). 220392 -> 220584 (+192 shelf-item-(i): PendingE2eAck[cap_pending_e2e_acks=8], 24 B each = the E2E-ack deadline ring, Node-global). 220384 -> 220392 (+8 Wave-4: NodeConfig.gw_schedule_readvert_ms u32 + alignment; the gateway schedule re-advertisement cadence). …218872 (§S6) -> 219000 (§GapA) -> 219312 (+312 §F-XL-1: HForwardStash[4] = 4×(77+1) de-storm ring; _h_forward_rr fits existing padding) -> 219568 (+256 §S3 part2: HostMobileEntry.last_key_fwd_hash32 = 4 B + 4 B align, ×16 ×2 layers) -> 219760 (+192 batch B: §B2 HostMobileEntry.deleg_fail packs into existing tail padding; §B4 PendingNotify.last_home_hash 4 B ×16 ×2 layers = +128; §D16 PresenceCand.incompatible +8 align ×cap = +64) -> 219952 (+192 batch A: §F-XL-2 RreqForwardStash[4] = 4×(16+1) de-storm ring + _rreq_forward_rr; §F-SL-1 ParkedSend += reflood state (bool/bool/Plane/u8 + u64 reflood_at_ms, 8-align) ×cap_parked_sends=8) -> 220384 (+432 §3-A.6 evict-STALEST timestamps: _learned_layers_seen_ms u64×4 = +32; PendingNotify.stash_ms u64 -> 12->24 B ×16 ×2 layers = +384 (+16 align); MINUS the dead _presence_claim_retries u8 (absorbed by padding))
#endif

}  // namespace meshroute
