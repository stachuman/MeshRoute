from pathlib import Path
import hashlib, importlib.util, json, os, re, subprocess

q = Path(__file__).resolve().parent
r = q / 'snapshot'
os.environ['MESHROUTE_GIT_REV_OVERRIDE'] = 'b9d75aa'
spec = importlib.util.spec_from_file_location('abi', r / 'tools/probe_board_abi.py')
abi = importlib.util.module_from_spec(spec)
spec.loader.exec_module(abi)

def emit(name, data):
    (q / name).write_text(json.dumps(data, indent=2) + '\n')

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

h = (r / 'lib/core/remote_session.h').read_text()
header = re.search(r'struct TranscriptHeader \{.*?\n\};', h, re.S).group()
header = header.replace('TranscriptHeader', 'CandidateTranscriptHeader').replace('\n};', '\n    uint32_t activation_ms;\n};')
state = re.search(r'struct RemoteSessionState \{.*?\n\};', h, re.S).group()
state = state.replace('RemoteSessionState', 'CandidateEffectOnlyState').replace('TranscriptHeader', 'CandidateTranscriptHeader')
state = state.replace('\n};', '\n    CandidateEffectOnlyAction action;\n    uint8_t last_activation_kind;\n    uint8_t last_activation_outcome;\n};')
source = '''// PRIVATE TYPE PRICING ONLY. Not an allocation or implementation proposal for all 48 rows.
#include <cstddef>
#include <cstdint>
#include "node.h"
#include "device_nv.h"
#include "firmware_join_service.h"
#include "firmware_provisioning_service.h"
#include "firmware_config_parse.h"
namespace meshroute {
// CONDITIONAL SMALL-SCOPE COMPARISON: only existing no-argument reboot/prep wrappers and OTA entry.
// Four policy rows, not complete 48-row coverage. All other families still require preparation analysis.
struct CandidateEffectOnlyAction {
    uint64_t request_id, admin_epoch, activate_at_ms;
    uint32_t source_hash, activation_ms;
    uint8_t controller_slot, authority, kind, phase;
    uint8_t backend, trigger;
};
'''+header+'\n'+state+'\n}\n'
types = ['meshroute::LayerConfig','meshroute::GatewayProvision','meshroute::Identity',
         'mrfw::PhyArgs','mrfw::JoinRequest','mrfw::TeamRequest','mrfw::TeamProjection',
         'mrfw::TeamPlan','mrfw::ProvSnapshot','mrfw::ProvPhy','mrfw::CfgValues',
         'mrnv::Blob','mrnv::IdBlob','mrnv::TeamKeyBlob',
         'meshroute::TranscriptHeader','meshroute::RemoteSessionState','meshroute::Node',
         'meshroute::CandidateEffectOnlyAction','meshroute::CandidateTranscriptHeader',
         'meshroute::CandidateEffectOnlyState']
for t in types:
    ident=t.replace('::','_')
    source+=f'char mr_abi_size__{ident}[sizeof({t})];\nchar mr_abi_align__{ident}[alignof({t})];\n'
source+='''#if MR_FEAT_RADMIN_ACCEPT
char mr_abi_included__candidate_effect_only_state[1];
#endif
'''
(q / 'candidate-layout.cpp').write_text(source)
results={}
for target in ('native','gateway','heltec_mobile'):
    data=abi.idedata(target)
    emit(target+'-idedata.json',data)
    obj=q/(target+'.o')
    cmd=abi.compile_command(data,q/'candidate-layout.cpp',obj)
    cp=subprocess.run(cmd,cwd=r,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    (q/(target+'-compile.log')).write_bytes(cp.stdout)
    result={'command':cmd,'returncode':cp.returncode}
    results[target]=result
    emit('measurements.json',results)
    if cp.returncode:
        print(target,cp.stdout.decode('utf-8','replace')[-8000:],flush=True)
        raise SystemExit(cp.returncode)
    result.update({'sizes':abi.read_sizes(abi.binutil(data['cxx_path'],'nm'),obj),'object_sha256':sha(obj)})
    emit('measurements.json',results)
    print(target,json.dumps(result['sizes'],sort_keys=True),flush=True)
