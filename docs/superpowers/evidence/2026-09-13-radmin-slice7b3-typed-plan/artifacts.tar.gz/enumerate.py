from pathlib import Path
import hashlib,json,re,subprocess
q=Path(__file__).resolve().parent
r=q/'snapshot'
source=r/'src/firmware_command_authority.h'
text=source.read_text()
meta={
 'cfg':('shared_prepare_apply', 'src/firmware_config.cpp',251),
 'crash':('small_typed_seam', 'src/fw_main.cpp',395),
 'create':('shared_prepare_apply', 'src/firmware_config.cpp',1180),
 'factory':('small_typed_seam', 'src/firmware_commands.cpp',1071),
 'gateway':('shared_prepare_apply', 'src/firmware_config.cpp',692),
 'join':('shared_prepare_apply', 'src/firmware_config.cpp',902),
 'leave':('shared_prepare_apply', 'src/firmware_config.cpp',2422),
 'ota':('existing_entry_primitive_new_binding', 'src/device_ota.cpp',92),
 'reboot_prep':('existing_no_argument_wrapper_typed_binding', 'src/fw_main.cpp',293),
 'regen':('shared_prepare_apply', 'src/firmware_commands.cpp',1031),
 'sleep':('small_typed_seam', 'src/firmware_commands.cpp',1096),
 'team':('shared_prepare_apply', 'src/firmware_config.cpp',2025),
}
rows=[]
all_rows=list(re.finditer(r'\{"([^"]+)", "([^"]+)", CommandClass::(\w+), (true|false)\}',text))
assert len(all_rows)==180
for m in all_rows:
 if m[4]!='true':continue
 verb=m[1]
 family=('cfg' if verb=='cfg set' else 'crash' if verb=='crashtest'
         else 'factory' if verb=='factory_reset' else 'join' if verb.startswith('join')
         else 'reboot_prep' if verb.startswith('reboot') or verb=='prep-restart' else verb)
 tier,path,line=meta[family]
 rows.append({'index':len(rows)+1,'policy_line':text[:m.start()].count('\n')+1,
              'verb':verb,'subverb':m[2],'authority':m[3],'family':family,
              'preparation_tier':tier,'handler_anchor':f'{path}:{line}',
              'exception_recorded':False,'implementation_authorized':False})
assert len(rows)==48
counts={family:sum(row['family']==family for row in rows) for family in meta}
assert sum(counts.values())==48
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
result={'base':'b9d75aaca55a0e350d9707512e9b6eec8a81ab22','policy_sha256':sha(source),
        'all_policy_rows':len(all_rows),'disruptive_rows':len(rows),'family_counts':counts,'rows':rows}
(q/'disruptive-enumeration.json').write_text(json.dumps(result,indent=2)+'\n')
table=['| # | Policy line | Verb | Subverb | Class | Family |', '| --- | --- | --- | --- | --- | --- |']
for row in rows:
 table.append(f"| {row['index']} | {row['policy_line']} | `{row['verb']}` | `{row['subverb']}` | {row['authority']} | {row['family']} |")
(q/'all-48-rows.md').write_text('\n'.join(table)+'\n')
paths=['AGENTS.md','lib/core/node.h','lib/core/node.cpp','lib/core/node_carriers.h','lib/core/mr_features.h',
       'lib/core/remote_session.h','lib/core/identity.h','src/firmware_command_authority.h',
       'src/firmware_command_context.h','src/firmware_commands.cpp','src/firmware_config.cpp',
       'src/firmware_config_parse.h','src/firmware_config_service.h','src/firmware_join_service.h',
       'src/firmware_provisioning_service.h','src/firmware_team_keyring.h','src/device_nv.h',
       'src/device_rng.h','src/device_ota.h','src/device_ota.cpp','src/fw_main.cpp',
       'src/firmware_remote_executor.h','src/firmware_admin_identity.h','tools/probe_board_abi.py',
       'platformio.ini']
sources={p:sha(r/p) for p in paths}
root=Path('/home/staszek/MeshRoute')
live={p:sha(root/p) for p in paths}
assert live==sources,[(p,sources[p],live[p]) for p in paths if live[p]!=sources[p]]
docs=['docs/CODE_GUIDELINES.md',
      'docs/superpowers/plans/2026-09-13-radmin-slice7b3-deferred-actions.md',
      'docs/superpowers/plans/2026-09-03-remote-admin-v2-rulings.md']
(q/'source-audit.json').write_text(json.dumps({'source_hashes':sources,'live_source_equal_to_base':True,
    'authority_hashes':{p:sha(root/p) for p in docs},
    'source_diff_f993191_to_b9d75aa':subprocess.check_output(['git','diff',
     'f993191be7f6980870f440f6032bca72278539a7','b9d75aaca55a0e350d9707512e9b6eec8a81ab22',
     '--','lib','src'],cwd=root,text=True)},indent=2)+'\n')
print(json.dumps(counts),flush=True)
