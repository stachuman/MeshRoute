# Measurement attempt history

The first private compile-only attempt built the native type TU successfully, then
`pio run -e gateway -t idedata` refused with
`UnknownBoard: Unknown board ID 'seeed-xiao-afruitnrf52-nrf52840'`.
The private source archive had omitted the repository's `boards/` directory.
That directory was extracted from the same pinned b9d75aa commit and the complete
three-target measurement was repeated. This was snapshot setup failure, not a
production compile failure. No shared-tree build was run.

The next attempt reached the board build metadata hook, which refused a source
archive without a resolvable Git HEAD. The third attempt uses the existing
`MESHROUTE_GIT_REV_OVERRIDE=b9d75aa` deterministic measurement seam, naming the
actual commit from which this private archive was extracted. No fallback revision
or unverified build identity is used.
