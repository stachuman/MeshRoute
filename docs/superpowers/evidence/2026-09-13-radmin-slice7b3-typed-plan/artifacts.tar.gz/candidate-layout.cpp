// PRIVATE TYPE PRICING ONLY. Not an allocation or implementation proposal for all 48 rows.
#include <cstddef>
#include <cstdint>
#include "node.h"
#include "device_nv.h"
#include "firmware_join_service.h"
#include "firmware_provisioning_service.h"
#include "firmware_config_parse.h"
namespace meshroute {
// CONDITIONAL SMALL-SCOPE COMPARISON: only existing no-argument reboot/prep wrappers and OTA entry.
// Four policy rows, not complete 48-row coverage. All other families still require preparation analysis.
struct CandidateEffectOnlyAction {
    uint64_t request_id, admin_epoch, activate_at_ms;
    uint32_t source_hash, activation_ms;
    uint8_t controller_slot, authority, kind, phase;
    uint8_t backend, trigger;
};
struct CandidateTranscriptHeader {
    uint64_t request_id;
    uint32_t bytes_total;          // retained bytes, not attempted writes after truncation
    uint16_t first_chunk;
    uint8_t frames;                // OUTPUT chunks + mandatory TERMINAL
    uint8_t next_seq_to_send;
    uint8_t controller_slot;
    uint8_t seen_index;
    uint8_t terminal;
    uint8_t state;
    uint16_t chunk_bytes;          // computed once at reservation for the actual return carrier
    uint8_t truncated;
    uint8_t order;                // 0..3 allocation order; no uptime-wrap-dependent scheduling
    uint32_t activation_ms;
};
struct CandidateEffectOnlyState {
    uint8_t     admin_x_secret[32];              // @0   — SECRET. The ADMINISTRATION root's X25519 scalar.
    uint8_t     admin_ed_pub[32];                // @32  — the administration root's Ed25519 public key.
                                                 //        ⛔ NEVER the messaging identity (`_ed_pub`): they are
                                                 //        separate secrets with separate lifetimes, and
                                                 //        `regen` rotates the messaging one alone.
    AdminAclRow acl[kRadminAclSlots];            // @64  — 340: the LIVE image the firmware installs
    uint8_t     readiness;                       // @404 — AdminReadiness
    uint8_t     acl_occupied;                    // @405 — validated occupied rows (0..10)
    uint8_t     root_present;                    // @406 — 1 iff a non-degenerate administration pair is installed
    uint8_t     reserved0;                       // @407 — canonical zero
    uint64_t    epoch[kRadminAclSlots];          // @408 — 80: the per-slot session epoch. 0 = slot UNUSABLE.
    SeenEntry   seen[kRadminSeenSlots];          // @488 — 896
    IngressOperationHeader ingress[kRadminIngressSlots];  // @1384 — 80
    IngressBodySlot        body[kRadminIngressSlots];     // @1464 — 472
    OpenStagingSlot        staging[kRadminStagingSlots];  // @1936 — 128
    CandidateTranscriptHeader      transcripts[kRadminTranscriptSlots];
    TranscriptChunk       chunks[kRadminChunkSlots];
    uint16_t              transcript_exhaustion;
    uint16_t              response_enqueue_failure;
    uint16_t              response_seal_failure;
    OpenCapture           open[kRadminOpenSlots];
    uint16_t              inbound_refusal;
    uint16_t              open_rate_refusal;
    CandidateEffectOnlyAction action;
    uint8_t last_activation_kind;
    uint8_t last_activation_outcome;
};
}
char mr_abi_size__meshroute_LayerConfig[sizeof(meshroute::LayerConfig)];
char mr_abi_align__meshroute_LayerConfig[alignof(meshroute::LayerConfig)];
char mr_abi_size__meshroute_GatewayProvision[sizeof(meshroute::GatewayProvision)];
char mr_abi_align__meshroute_GatewayProvision[alignof(meshroute::GatewayProvision)];
char mr_abi_size__meshroute_Identity[sizeof(meshroute::Identity)];
char mr_abi_align__meshroute_Identity[alignof(meshroute::Identity)];
char mr_abi_size__mrfw_PhyArgs[sizeof(mrfw::PhyArgs)];
char mr_abi_align__mrfw_PhyArgs[alignof(mrfw::PhyArgs)];
char mr_abi_size__mrfw_JoinRequest[sizeof(mrfw::JoinRequest)];
char mr_abi_align__mrfw_JoinRequest[alignof(mrfw::JoinRequest)];
char mr_abi_size__mrfw_TeamRequest[sizeof(mrfw::TeamRequest)];
char mr_abi_align__mrfw_TeamRequest[alignof(mrfw::TeamRequest)];
char mr_abi_size__mrfw_TeamProjection[sizeof(mrfw::TeamProjection)];
char mr_abi_align__mrfw_TeamProjection[alignof(mrfw::TeamProjection)];
char mr_abi_size__mrfw_TeamPlan[sizeof(mrfw::TeamPlan)];
char mr_abi_align__mrfw_TeamPlan[alignof(mrfw::TeamPlan)];
char mr_abi_size__mrfw_ProvSnapshot[sizeof(mrfw::ProvSnapshot)];
char mr_abi_align__mrfw_ProvSnapshot[alignof(mrfw::ProvSnapshot)];
char mr_abi_size__mrfw_ProvPhy[sizeof(mrfw::ProvPhy)];
char mr_abi_align__mrfw_ProvPhy[alignof(mrfw::ProvPhy)];
char mr_abi_size__mrfw_CfgValues[sizeof(mrfw::CfgValues)];
char mr_abi_align__mrfw_CfgValues[alignof(mrfw::CfgValues)];
char mr_abi_size__mrnv_Blob[sizeof(mrnv::Blob)];
char mr_abi_align__mrnv_Blob[alignof(mrnv::Blob)];
char mr_abi_size__mrnv_IdBlob[sizeof(mrnv::IdBlob)];
char mr_abi_align__mrnv_IdBlob[alignof(mrnv::IdBlob)];
char mr_abi_size__mrnv_TeamKeyBlob[sizeof(mrnv::TeamKeyBlob)];
char mr_abi_align__mrnv_TeamKeyBlob[alignof(mrnv::TeamKeyBlob)];
char mr_abi_size__meshroute_TranscriptHeader[sizeof(meshroute::TranscriptHeader)];
char mr_abi_align__meshroute_TranscriptHeader[alignof(meshroute::TranscriptHeader)];
char mr_abi_size__meshroute_RemoteSessionState[sizeof(meshroute::RemoteSessionState)];
char mr_abi_align__meshroute_RemoteSessionState[alignof(meshroute::RemoteSessionState)];
char mr_abi_size__meshroute_Node[sizeof(meshroute::Node)];
char mr_abi_align__meshroute_Node[alignof(meshroute::Node)];
char mr_abi_size__meshroute_CandidateEffectOnlyAction[sizeof(meshroute::CandidateEffectOnlyAction)];
char mr_abi_align__meshroute_CandidateEffectOnlyAction[alignof(meshroute::CandidateEffectOnlyAction)];
char mr_abi_size__meshroute_CandidateTranscriptHeader[sizeof(meshroute::CandidateTranscriptHeader)];
char mr_abi_align__meshroute_CandidateTranscriptHeader[alignof(meshroute::CandidateTranscriptHeader)];
char mr_abi_size__meshroute_CandidateEffectOnlyState[sizeof(meshroute::CandidateEffectOnlyState)];
char mr_abi_align__meshroute_CandidateEffectOnlyState[alignof(meshroute::CandidateEffectOnlyState)];
#if MR_FEAT_RADMIN_ACCEPT
char mr_abi_included__candidate_effect_only_state[1];
#endif
