from pathlib import Path
import hashlib,json
q=Path(__file__).resolve().parent
paths=[p for p in sorted(q.iterdir()) if p.is_file() and p.name!='artifact-sha256.json']
for p in paths:
    if p.suffix in ('.py','.md','.cpp','.json'):
        lines=p.read_text().splitlines()
        assert all(s==s.rstrip() for s in lines),p
hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
(q/'artifact-sha256.json').write_text(json.dumps(hashes,indent=2)+'\n')
print(json.dumps(hashes,indent=2))
