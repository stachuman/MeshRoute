from collections import Counter
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import xml.etree.ElementTree as ET
from work import OUT, ROOT, SIM, inventory, save

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def arithmetic():
    def cases(name):
        doc = ET.parse(OUT/name).getroot()
        return {n.attrib['name'].replace('all eight terminal meanings', 'all allocated terminal meanings'):
                int(n.find('OverallResultsAsserts').attrib['successes'])
                for n in doc.findall('.//TestCase') if n.attrib.get('skipped') != 'true'}
    b, a = cases('base-native-codec.log'), cases('candidate-native-codec.log')
    assert b.keys() <= a.keys()
    added = {k: v for k, v in a.items() if k not in b}
    changed = {k: a[k]-v for k, v in b.items() if a[k] != v}
    assert (len(b), sum(b.values()), len(a), sum(a.values())) == (30, 48489, 33, 58465)
    assert len(added) == 3 and sum(added.values()) == 9970 and sum(changed.values()) == 6
    save('native-arithmetic.json', dict(base_cases=len(b), base_asserts=sum(b.values()),
         final_cases=len(a), final_asserts=sum(a.values()), added=added, changed=changed,
         case_rename='all eight terminal meanings -> all allocated terminal meanings',
         unaffected_cases=2879, unaffected_assertions=125996))
    print('CODEC ARITHMETIC', added, changed)

def corpus():
    b, a = OUT/'corpus-base/streams', OUT/'corpus-final/streams'
    paths = sorted(p.relative_to(b) for p in b.rglob('*.ndjson'))
    assert len(paths) == 36 and paths == sorted(p.relative_to(a) for p in a.rglob('*.ndjson'))
    rows = []
    for path in paths:
        old, new = (b/path).read_bytes(), (a/path).read_bytes()
        assert old == new, path
        rows.append(dict(path=str(path), bytes=len(new), events=new.count(b'\n'),
                         md5=hashlib.md5(new).hexdigest(), sha256=hashlib.sha256(new).hexdigest()))
    images = [sha(OUT/('sim-'+arm)/'orchestrator/lus') for arm in ['base', 'final']]
    command = ['python3', 'tools/run_corpus.py', '--compare', str(OUT/'corpus-base'), str(OUT/'corpus-final')]
    compare = subprocess.run(command, cwd=OUT/'gate', stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    (OUT/'corpus-canonical-compare.log').write_bytes(compare.stdout)
    assert compare.returncode == (0 if images[0] == images[1] else 1)
    provenance = {}
    for arm, repo in [('base', OUT/'base'), ('final', OUT/'gate')]:
        build = OUT/('sim-'+arm)
        command = ['ninja', '-C', str(build), '-t', 'compdb']
        graph = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        assert graph.returncode == 0 and not graph.stderr
        (OUT/('sim-'+arm+'-compdb.json')).write_bytes(graph.stdout)
        commands = json.loads(graph.stdout)
        selected = [c for c in commands if Path(c['file']).name == 'remote_codec.cpp']
        assert len(selected) == 2 and all(Path(c['file']).resolve() == (repo/'lib/core/remote_codec.cpp').resolve() for c in selected)
        log = OUT/('base-sim-build.log' if arm == 'base' else 'simulator-build.log')
        actual = log.read_text()
        assert all(c['command'] in actual for c in selected)
        objects = {str(p.relative_to(build)).replace(str(repo).lstrip('/'), '<meshroute>'): sha(p)
                   for p in build.rglob('*.o')}
        provenance[arm] = dict(compdb_argv=command, compdb_exit=graph.returncode,
            codec_commands=selected, actual_build_log_sha256=sha(log),
            objects=objects, source_sha256=sha(repo/'lib/core/remote_codec.cpp'))
    ob, oa = provenance['base']['objects'], provenance['final']['objects']
    assert ob.keys() == oa.keys()
    changed = [p for p in ob if ob[p] != oa[p]]
    save('corpus-attribution.json', dict(streams=rows, executable_sha256=images,
         canonical_argv=command, canonical_exit=compare.returncode, provenance=provenance, changed_objects=changed))
    print('CORPUS 36/36 IDENTICAL; executable', images, 'changed objects', changed)

def boards():
    from attribute import elf
    all_before = {str(p): sha(p) for p in (OUT/'measure/.pio-measure').glob('*/*/*') if p.is_file()}
    report = {}
    for env in ['gateway', 'heltec_mobile']:
        roots = [OUT/'measure/.pio-measure'/arm/env for arm in ['base', 'final']]
        manifests = [json.loads((r/'manifest.json').read_text()) for r in roots]
        assert manifests[0]['measurements'] == manifests[1]['measurements']
        assert manifests[0]['toolchain'] == manifests[1]['toolchain']
        assert manifests[0]['fixed_identity'] == manifests[1]['fixed_identity']
        assert (roots[0]/'symbols.txt').read_bytes() == (roots[1]/'symbols.txt').read_bytes()
        body_codec_symbols = [line for line in (roots[1]/'symbols.txt').read_text().splitlines()
                              if 'remote_body_encode' in line or 'remote_body_decode' in line]
        if env == 'heltec_mobile':
            assert not body_codec_symbols
        sections = [elf(r/'firmware.elf')[0] for r in roots]
        changed = {}
        for name, before in sections[0].items():
            after = sections[1][name]
            if before['content'] != after['content']:
                changed[name] = dict(allocated=bool(before['flags'] & 2),
                    before_bytes=before['size'], after_bytes=after['size'])
                if before['flags'] & 2:
                    assert env == 'gateway' and name == '.text' and before['size'] == after['size']
                    changed[name]['byte_differences'] = [dict(address=hex(before['address']+i), before=b, after=a)
                        for i, (b,a) in enumerate(zip(before['content'], after['content'])) if b != a]
        if env == 'gateway':
            compiler = Path(manifests[0]['toolchain']['commands']['cxx']['executable_resolved'])
            dump = compiler.with_name('arm-none-eabi-objdump')
            symbol = next(line.split('\t')[0] for line in (roots[0]/'symbols.txt').read_text().splitlines()
                          if 'remote_body_decode' in line)
            for arm, r in zip(['base', 'final'], roots):
                command = [str(dump), '-d', '--disassemble='+symbol, str(r/'firmware.elf')]
                result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
                assert result.returncode == 0
                (OUT/('gateway-decode-'+arm+'.dis')).write_bytes(result.stdout)
            old_dis = (OUT/'gateway-decode-base.dis').read_text().splitlines()[3:]
            new_dis = (OUT/'gateway-decode-final.dis').read_text().splitlines()[3:]
            assert len(old_dis) == len(new_dis)
            differences = [(b, a) for b, a in zip(old_dis, new_dis) if b != a]
            assert len(differences) == 1
            assert '85992:' in differences[0][0] and 'cmp\tr2, #7' in differences[0][0]
            assert '85992:' in differences[0][1] and 'cmp\tr2, #8' in differences[0][1]
        warnings = []
        for r in roots:
            text = re.sub(r'\x1b\[[0-9;]*m', '', (r/'build.log').read_text(errors='replace'))
            warnings.append(Counter(re.sub(r':\d+(?::\d+)?:', ':LINE:', line.strip())
                                    for line in text.splitlines() if 'warning:' in line))
        assert warnings[0] == warnings[1]
        report[env] = dict(measurements=manifests[1]['measurements'],
             artifact_manifests=[m['artifacts'] for m in manifests], changed_sections=changed,
             warning_count=sum(warnings[1].values()), normalized_warning_multisets_equal=True,
             linked_body_codec_symbols=body_codec_symbols)
    assert all(sha(Path(p)) == h for p, h in all_before.items())
    save('board-attribution.json', report)
    print('BOARDS', report)

def mutations():
    selected = json.loads((OUT/'selectors-final.json').read_text())
    rows = []
    for row in selected['rows']:
        path = OUT/('mutations-'+row['target']+'.log')
        if not path.exists(): continue
        text = path.read_text(errors='replace')
        totals = re.findall(r'^mutations: (\d+) RED / (\d+) unusable$', text, re.M)
        if not totals: continue
        red, unusable = map(int, totals[-1])
        assert red+unusable == row['count']
        assert unusable == (1 if row['target'] == 'sliceBmac' else 0)
        workers = min(2, row['count'])
        assert len(re.findall(r'\[w\d+\] +ok +clean baseline 2912 / 184461 / 0', text)) == workers
        assert len(re.findall(r'worker \d+: .*source restored: md5 .*\(MATCHES\)', text)) == workers
        assert 'real tree untouched: all 56 target files byte-identical' in text
        # Classify the merged result column, never words in historical labels
        # (sliceGrx G25's description mentions its old VACUOUS pattern).
        passed = re.findall(r'^  ok   (.*?) -> RED \((\d+) assertion\(s\) failed, match count 1\)$', text, re.M)
        failed = re.findall(r'^  FAIL (.*)$', text, re.M)
        assert len(passed) == red and all(int(n) > 0 for _, n in passed)
        assert len(failed) == unusable
        if failed: assert row['target'] == 'sliceBmac' and failed[0].startswith('M04 ')
        rows.append(dict(target=row['target'], red=red, unusable=unusable, workers=workers,
                         source_sha256=sha(OUT/'mutations'/row['source']), log_sha256=sha(path)))
    save('mutation-outcomes.json', rows)
    print('MUTATIONS COMPLETE', len(rows), '/52 RED', sum(r['red'] for r in rows), 'unusable', sum(r['unusable'] for r in rows))

for mode in sys.argv[1:]:
    {'arithmetic': arithmetic, 'corpus': corpus, 'boards': boards, 'mutations': mutations}[mode]()
