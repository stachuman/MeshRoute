import ast
import hashlib
import json
from pathlib import Path
import subprocess
from work import OUT, ROOT, SIM, inventory, save

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

base = json.loads((OUT/'base-inputs.json').read_text())
current = inventory(ROOT)
changed = [p for p in base if current.get(p) != base[p]]
allowed = ['lib/core/remote_codec.cpp', 'lib/core/remote_codec.h',
           'test/test_remote_codec.cpp', 'tools/probe_ui_model_mutations.py']
assert sorted(changed) == allowed
new = sorted(current.keys() - base.keys())
prefix = 'docs/superpowers/evidence/2026-09-13-radmin-slice7b3'
owned = {prefix+'-0-reference.py', prefix+'-0.md', prefix+'.md'}
owned |= {prefix+'-typed-plan/'+name for name in ['all-48-rows.md', 'artifact-sha256.json',
    'artifacts.tar.gz', 'measurements.json', 'typed-plan-preflight.md', 'published-sha256.json']}
owned |= {prefix+'-0-coder/'+name for name in ['artifact-sha256.json', 'artifacts.tar.gz',
    'native-arithmetic.json', 'mutation-outcomes.json', 'selectors-final.json',
    'board-attribution.json', 'corpus-attribution.json', 'preservation-checkpoint.json',
    'published-sha256.json', 'freeze.json']}
assert set(new) <= owned, sorted(set(new) - owned)
assert inventory(SIM) == json.loads((OUT/'simulator-initial.json').read_text())
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=SIM)
for repo in [ROOT, SIM]:
    subprocess.run(['git', 'diff', '--check'], cwd=repo, check=True)
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT).decode().strip() == 'b9d75aaca55a0e350d9707512e9b6eec8a81ab22'
assert not subprocess.check_output(['git', 'diff', 'f993191', 'b9d75aa', '--',
    'lib', 'src', 'test', 'tools', 'simulation', 'platformio.ini'], cwd=ROOT)
details = {}
for path in allowed:
    details[path] = dict(before=base[path], after=current[path])

def mutations(path, name):
    for n in ast.parse(path.read_text()).body:
        if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == name for t in n.targets):
            return ast.literal_eval(n.value)
    raise AssertionError(name)

repairs = {}
for label, table, src in [('X09', 'MUTS_RADMIN5RX', 'lib/core/node_mac_rx.cpp'),
                          ('R60', 'MUTS_RADMIN2CODEC', 'lib/core/remote_codec.cpp')]:
    versions = []
    for repo in [OUT/'base', ROOT]:
        entry = next(e for e in mutations(repo/'tools/probe_ui_model_mutations.py', table) if e[0].startswith(label))
        versions.append(dict(description=entry[0], search=entry[1], replacement=entry[2],
            search_sha256=hashlib.sha256(entry[1].encode()).hexdigest(),
            replacement_sha256=hashlib.sha256(entry[2].encode()).hexdigest(),
            matches=(repo/src).read_text().count(entry[1]), source_sha256=sha(repo/src)))
    repairs[label] = versions
assert repairs['X09'][0]['matches'] == 0 and repairs['X09'][1]['matches'] == 1
assert repairs['X09'][0]['source_sha256'] == repairs['X09'][1]['source_sha256']
assert repairs['R60'][0]['matches'] == repairs['R60'][1]['matches'] == 1
save('preservation-checkpoint.json', dict(base_count=len(base), preserved=len(base)-len(changed),
    changed=details, new={p: current[p] for p in new}, repairs=repairs,
    brief_sha256=sha(ROOT/'docs/superpowers/plans/2026-09-13-radmin-slice7b3-0-action-busy-codec.md'),
    simulator_unchanged=True, whitespace_clean=True))
print('PRESERVED', len(base)-4, 'base inputs; exactly four fenced implementation inputs changed;',
      len(new), 'coder evidence inputs added; simulator unchanged; whitespace clean')
