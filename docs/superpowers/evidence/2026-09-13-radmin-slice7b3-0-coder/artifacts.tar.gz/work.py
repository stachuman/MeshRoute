import hashlib
import json
import os
from pathlib import Path
import shutil
import stat
import subprocess
import sys
import time

OUT = Path(__file__).parent
ROOT = Path('/home/staszek/MeshRoute')
SIM = Path('/home/staszek/lora-universal-simulator')
ENV = dict(os.environ, MR_LUS_SRC=str(SIM), PYTHONUNBUFFERED='1')

def inventory(root):
    names = sorted(set(subprocess.check_output(['git', 'ls-files', '-z', '--cached', '--others', '--exclude-standard'], cwd=root).decode().split('\0')) - {''})
    values = {}
    for name in names:
        path = root / name
        row = {'mode': oct(stat.S_IMODE(path.lstat().st_mode))}
        if path.is_symlink():
            row['link'] = os.readlink(path)
        else:
            row['sha256'] = hashlib.sha256(path.read_bytes()).hexdigest()
        values[name] = row
    return values

def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + '\n')

def snapshot(name):
    before = inventory(ROOT)
    dest = OUT / name
    assert not dest.exists()
    subprocess.run(['git', 'clone', '--shared', '--quiet', str(ROOT), str(dest)], check=True)
    for rel, row in before.items():
        src, target = ROOT / rel, dest / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        if 'link' in row:
            if not target.is_symlink():
                assert not target.exists()
                target.symlink_to(row['link'])
            assert os.readlink(target) == row['link']
        else:
            shutil.copy2(src, target)
    assert inventory(ROOT) == before == inventory(dest)
    save(name + '-inputs.json', before)
    return dest

def runset(name, repo, commands):
    before = inventory(repo)
    save(name + '-inputs-before.json', before)
    records = []
    for label, command in commands:
        log = OUT / f'{name}-{label}.log'
        assert not log.exists(), log
        print('START', name, label, flush=True)
        started = time.monotonic()
        with log.open('wb') as stream:
            rc = subprocess.run(command, cwd=repo, env=ENV, stdout=stream, stderr=subprocess.STDOUT).returncode
        records.append(dict(name=label, argv=command, cwd=str(repo), rc=rc,
                            seconds=round(time.monotonic()-started, 3), log=str(log),
                            sha256=hashlib.sha256(log.read_bytes()).hexdigest()))
        save(name + '-results.json', records)
        print('END', name, label, rc, records[-1]['seconds'], flush=True)
        if rc and label != 'sliceBmac':
            assert inventory(repo) == before
            raise SystemExit(rc)
    assert inventory(repo) == before
    save(name + '-inputs-after.json', inventory(repo))

if __name__ == '__main__':
    mode = sys.argv[1]
    if mode == 'setup':
        assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT).decode().strip() == 'b9d75aaca55a0e350d9707512e9b6eec8a81ab22'
        assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=SIM).decode().strip() == '06746a97de5764415d6fcef10b97bca90569b9c7'
        assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=SIM)
        save('simulator-initial.json', inventory(SIM))
        (OUT / 'lora-universal-simulator').symlink_to(SIM, target_is_directory=True)
        snapshot('base')
        snapshot('measure')
        print('SNAPSHOTS VERIFIED', flush=True)
    elif mode == 'base':
        r = OUT / 'base'
        build = OUT / 'sim-base'
        runset('base', r, [('native-build', ['pio', 'test', '-e', 'native']),
                          ('native', ['./.pio/build/native/program']),
                          ('native-codec', ['./.pio/build/native/program', '--source-file=*test_remote_codec.cpp', '--reporters=xml']),
                          ('sim-configure', ['cmake', '-S', str(SIM), '-B', str(build), '-G', 'Ninja', '-DMESHROUTE_DIR='+str(r), '-DCMAKE_BUILD_TYPE=Release']),
                          ('sim-build', ['cmake', '--build', str(build), '--target', 'lus', '--parallel', '3', '--verbose']),
                          ('corpus', ['python3', 'tools/run_corpus.py', '--out', str(OUT/'corpus-base'), '--lus', str(build/'orchestrator/lus'), '--jobs', '3', '--require-anchors']),
                          ('validate', ['python3', 'tools/run_corpus.py', '--validate', str(OUT/'corpus-base')])])
    elif mode == 'board-base':
        r = OUT / 'measure'
        runset(mode, r, [('pair', ['python3', 'tools/measure_board.py', 'pair', '--jobs=1', '--output', str(r/'.pio-measure/base')])])
