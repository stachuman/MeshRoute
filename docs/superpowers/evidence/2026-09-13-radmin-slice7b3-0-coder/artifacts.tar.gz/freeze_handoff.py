import hashlib
import json
from pathlib import Path
import subprocess
from work import OUT, ROOT, SIM, inventory

folder = 'docs/superpowers/evidence/2026-09-13-radmin-slice7b3-0-coder'
target = ROOT/folder/'freeze.json'
assert not target.exists()
base = json.loads((OUT/'base-inputs.json').read_text())
gate = json.loads((OUT/'gate-inputs.json').read_text())
current = inventory(ROOT)
source = ['lib/core/remote_codec.cpp', 'lib/core/remote_codec.h',
          'test/test_remote_codec.cpp', 'tools/probe_ui_model_mutations.py']
assert sorted(p for p in base if current.get(p) != base[p]) == source
assert all(current[p] == gate[p] for p in source)
assert all(current[p] == row for p, row in gate.items())
assert inventory(OUT/'gate') == gate
assert inventory(OUT/'mutations') == json.loads((OUT/'mutations-inputs.json').read_text())
assert inventory(SIM) == json.loads((OUT/'simulator-initial.json').read_text())
for path in current.keys() - base.keys():
    p = ROOT/path
    if p.suffix in {'.md', '.py', '.json'}:
        text = p.read_text()
        assert text.endswith('\n') and all(line == line.rstrip() for line in text.splitlines()), path
for repo in [ROOT, SIM]:
    subprocess.run(['git', 'diff', '--check'], cwd=repo, check=True)
payload = dict(
    kind='complete tracked/untracked handoff inputs; this freeze.json alone excluded to avoid self-hash',
    meshroute_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip(),
    simulator_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=SIM).decode().strip(),
    preserved_original_inputs=len(base)-len(source),
    coder_changed_source_inputs=source,
    new_coder_evidence=sorted(current.keys()-base.keys()),
    full_inputs=current,
    simulator_inputs=inventory(SIM),
    source_equal_to_executed_final_gate=True,
    archive_sha256=hashlib.sha256((ROOT/folder/'artifacts.tar.gz').read_bytes()).hexdigest())
target.write_text(json.dumps(payload, indent=2)+'\n')
print('FROZEN', len(current), 'inputs + freeze.json; preserved', len(base)-4,
      'original inputs; simulator unchanged; source equals executed gate')
print('freeze.json sha256', hashlib.sha256(target.read_bytes()).hexdigest())
