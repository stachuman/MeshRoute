import hashlib
import json
import os
from pathlib import Path
import struct

ROOT = Path('/tmp/mr-codex-s7b30-C40uYn')
FINAL = os.environ.get('ATTR_FINAL', 'final')

def elf(path):
    data = path.read_bytes()
    assert data[:4] == b'\x7fELF' and data[5] == 1
    bits = data[4]
    if bits == 1:
        header = struct.unpack_from('<16sHHIIIIIHHHHHH', data)
        fmt, syms = '<IIIIIIIIII', '<IIIBBH'
    else:
        header = struct.unpack_from('<16sHHIQQQIHHHHHH', data)
        fmt, syms = '<IIQQQQIIQQ', '<IBBHQQ'
    offset, stride, count, strings = header[6], header[11], header[12], header[13]
    sections = [struct.unpack_from(fmt, data, offset + i * stride) for i in range(count)]
    names = sections[strings]
    name_data = data[names[4]:names[4]+names[5]]
    result = {}
    for index, section in enumerate(sections):
        name = name_data[section[0]:].split(b'\0', 1)[0].decode()
        content = data[section[4]:section[4]+section[5]] if section[1] != 8 else b''
        result[name] = dict(index=index, size=section[5], flags=section[2], address=section[3],
                            offset=section[4], content=content, sha256=hashlib.sha256(content).hexdigest())
    # Union of defined nonzero symbol extents, Thumb bit removed. Gaps in .text are measured, not assumed.
    text = result['.text'] if '.text' in result else result['.flash.text']
    intervals = []
    for section in sections:
        if section[1] != 2:
            continue
        for at in range(section[4], section[4]+section[5], section[9]):
            row = struct.unpack_from(syms, data, at)
            if bits == 1:
                _, value, size, info, _, idx = row
            else:
                _, info, _, idx, value, size = row
            if idx == text['index'] and size:
                if header[2] == 40 and info & 15 == 2:
                    value &= ~1
                intervals.append((value, value+size))
    end = covered = 0
    for begin, stop in sorted(intervals):
        covered += max(0, stop - max(begin, end))
        end = max(end, stop)
    return result, dict(text_bytes=text['size'], symbol_union_bytes=covered, uncovered_bytes=text['size']-covered)

summary = {}
for env in ('gateway', 'heltec_mobile'):
    paths = [ROOT/'measure'/'.pio-measure'/state/env/'firmware.elf' for state in ('base', FINAL)]
    before, bc = elf(paths[0]); after, ac = elf(paths[1])
    print(env, 'text symbol coverage', bc, ac)
    rows = []
    for name in before.keys() | after.keys():
        b, a = before.get(name), after.get(name)
        if b is None or a is None or (b['size'],b['sha256']) != (a['size'],a['sha256']):
            row = dict(section=name, allocated=bool((b or a)['flags'] & 2),
                       before={k:v for k,v in b.items() if k!='content'} if b else None,
                       after={k:v for k,v in a.items() if k!='content'} if a else None)
            rows.append(row)
            print(name,'ALLOC' if row['allocated'] else 'nonalloc', b['size'] if b else 0, a['size'] if a else 0)
    if env == 'heltec_mobile':
        assert all(not r['allocated'] for r in rows), 'mobile loadable bytes moved'
        payloads = [p.with_name('firmware.bin').read_bytes() for p in paths]
        differences = [i for i,(a,b) in enumerate(zip(*payloads)) if a != b]
        print('mobile payload changed offsets', differences)
        # ESP image patches app descriptor with the input ELF SHA256, then appends image SHA256.
        for index, data in enumerate(payloads):
            digest = hashlib.sha256(paths[index].read_bytes()).digest()
            print('embedded ELF SHA offset', data.find(digest), 'image SHA suffix verified', hashlib.sha256(data[:-32]).digest() == data[-32:])
            assert data.find(digest) >= 0
            assert hashlib.sha256(data[:-32]).digest() == data[-32:]
            cursor, checksum = 24, 0xEF
            for _ in range(data[1]):
                _, length = struct.unpack_from('<II', data, cursor)
                cursor += 8
                for byte in data[cursor:cursor+length]:
                    checksum ^= byte
                cursor += length
            print('segment XOR checksum', checksum, 'at', len(data)-33, data[-33])
            assert checksum == data[-33]
        b,a=payloads
        start=b.find(hashlib.sha256(paths[0].read_bytes()).digest())
        assert start == a.find(hashlib.sha256(paths[1].read_bytes()).digest())
        assert all(start <= i < start+32 or i >= len(b)-33 for i in differences)
    summary[env]=dict(symbol_coverage_before=bc,symbol_coverage_after=ac,changed_sections=rows)
(ROOT/f'elf-attribution-{FINAL}.json').write_text(json.dumps(summary,indent=2)+'\n')
