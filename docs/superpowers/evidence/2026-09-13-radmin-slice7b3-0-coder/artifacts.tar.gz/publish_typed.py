import hashlib
import json
from pathlib import Path
import shutil
import tarfile
from work import ROOT

source = Path('/tmp/mr-codex-s7b3-typed-plan-ZXuR9w')
dest = ROOT/'docs/superpowers/evidence/2026-09-13-radmin-slice7b3-typed-plan'
manifest = json.loads((source/'artifact-sha256.json').read_text())
audit = json.loads((source/'source-audit.json').read_text())
for name, expected in audit['source_hashes'].items():
    assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest() == expected, name
for name, expected in manifest.items():
    assert '/' not in name and hashlib.sha256((source/name).read_bytes()).hexdigest() == expected
dest.mkdir()
# Every original artifact (including the small ABI objects) is retained exactly
# in one inventory-bound archive. Human-readable analysis is copied alongside it.
with tarfile.open(dest/'artifacts.tar.gz', 'w:gz') as archive:
    for name in sorted(manifest):
        archive.add(source/name, arcname=name, recursive=False)
    archive.add(source/'artifact-sha256.json', arcname='artifact-sha256.json', recursive=False)
for name in ['typed-plan-preflight.md', 'all-48-rows.md', 'measurements.json', 'artifact-sha256.json']:
    shutil.copy2(source/name, dest/name)
with tarfile.open(dest/'artifacts.tar.gz', 'r:gz') as archive:
    assert set(archive.getnames()) == set(manifest) | {'artifact-sha256.json'}
    for name, expected in manifest.items():
        assert hashlib.sha256(archive.extractfile(name).read()).hexdigest() == expected
hashes = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(dest.iterdir())}
(dest/'published-sha256.json').write_text(json.dumps(hashes, indent=2)+'\n')
print(json.dumps(hashes, indent=2))
