import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import tarfile
from work import OUT, ROOT, SIM, inventory

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def read(name):
    return json.loads((OUT/name).read_text())

subprocess.run(['python3', str(OUT/'audit.py'), 'mutations'], check=True)
subprocess.run(['python3', str(OUT/'preservation.py')], check=True)
chain = read('chain-results.json')
union = read('mutations-results.json')
outcomes = read('mutation-outcomes.json')
assert len(chain) == 25 and chain[-1]['name'] == 'census' and all(r['rc'] == 0 for r in chain)
assert len(union) == len(outcomes) == 52
assert sum(r['red'] for r in outcomes) == 816 and sum(r['unusable'] for r in outcomes) == 1
assert all(r['rc'] == (1 if r['name'] == 'sliceBmac' else 0) for r in union)
groups = ['base', 'candidate', 'board-base', 'boards', 'simulator', 'chain', 'mutations']
for group in groups:
    assert read(group+'-inputs-before.json') == read(group+'-inputs-after.json'), group
    for row in read(group+'-results.json'):
        assert sha(Path(row['log'])) == row['sha256'], row['log']
for row in read('proof-results.json'):
    assert row['rc'] == row['expected'] and sha(Path(row['log'])) == row['sha256']
tools = (OUT/'chain-tools.log').read_text()
assert 'Ran 343 tests in ' in tools and '\nOK\n' in tools and 'skipped=' not in tools
for name in ['base-native.log', 'candidate-native.log', 'chain-native.log']:
    text = (OUT/name).read_text()
    assert '0 failed' in text and '0 skipped' in text

dest = ROOT/'docs/superpowers/evidence/2026-09-13-radmin-slice7b3-0-coder'
dest.mkdir()
paths = sorted(p for p in OUT.iterdir() if p.is_file() and p.suffix in {'.json', '.log', '.py', '.cpp', '.dis'})
for arm in ['base', 'final']:
    paths.append(OUT/('corpus-'+arm)/'manifest.json')
    for env in ['gateway', 'heltec_mobile']:
        for name in ['manifest.json', 'build.log', 'symbols.txt', 'compiler-state.json']:
            path = OUT/'measure/.pio-measure'/arm/env/name
            if path.is_file(): paths.append(path)
manifest = {str(p.relative_to(OUT)): dict(sha256=sha(p), bytes=p.stat().st_size) for p in paths}
(dest/'artifact-sha256.json').write_text(json.dumps(manifest, indent=2)+'\n')
with tarfile.open(dest/'artifacts.tar.gz', 'w:gz') as archive:
    for path in paths:
        archive.add(path, arcname=str(path.relative_to(OUT)), recursive=False)
with tarfile.open(dest/'artifacts.tar.gz', 'r:gz') as archive:
    assert set(archive.getnames()) == set(manifest)
    for name, row in manifest.items():
        assert hashlib.sha256(archive.extractfile(name).read()).hexdigest() == row['sha256']
for name in ['native-arithmetic.json', 'mutation-outcomes.json', 'selectors-final.json',
             'board-attribution.json', 'corpus-attribution.json', 'preservation-checkpoint.json']:
    shutil.copy2(OUT/name, dest/name)
published = {p.name: sha(p) for p in sorted(dest.iterdir())}
(dest/'published-sha256.json').write_text(json.dumps(published, indent=2)+'\n')
print('ARCHIVED', len(paths), 'artifacts;', (dest/'artifacts.tar.gz').stat().st_size, 'compressed bytes')
print(json.dumps(published, indent=2))
