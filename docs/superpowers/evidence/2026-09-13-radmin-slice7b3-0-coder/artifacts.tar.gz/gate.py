import ast
import json
from pathlib import Path
import shutil
import sys

from work import OUT, ROOT, SIM, inventory, runset, save, snapshot

def selectors(repo):
    values, tables = {}, {}
    for node in ast.parse((repo/'tools/probe_ui_model_mutations.py').read_text()).body:
        if isinstance(node, ast.Assign):
            for target in node.targets:
                if isinstance(target, ast.Name):
                    try:
                        values[target.id] = ast.literal_eval(node.value)
                    except (ValueError, TypeError):
                        if target.id == 'MUTS_BY_TARGET':
                            tables = {ast.literal_eval(k): v.id for k, v in zip(node.value.keys, node.value.values)}
    floor = json.loads((repo/'docs/superpowers/evidence/2026-09-13-radmin-slice7b3-precheck/historical-mutation-floor.json').read_text())['union']
    source_changes = ['lib/core/remote_codec.h', 'lib/core/remote_codec.cpp']
    changed = sorted(t for t, src in values['TARGET_SRC'].items() if src in source_changes)
    union = sorted(set(changed) | set(floor))
    rows = []
    for target in union:
        source = (repo / values['TARGET_SRC'][target]).read_text()
        entries = values[tables[target]]
        rows.append(dict(target=target, source=values['TARGET_SRC'][target], count=len(entries),
                         entries=[dict(label=label, matches=source.count(pattern)) for label, pattern, replacement in entries]))
    return dict(S=changed, H=floor, union=union, patterns=sum(r['count'] for r in rows), rows=rows)

mode = sys.argv[1]
if mode == 'prepare':
    for name in ['gate', 'mutations']:
        snapshot(name)
    audit = selectors(ROOT)
    save('selectors-final.json', audit)
    assert len(audit['union']) == 52 and audit['patterns'] == 817
    assert all(e['matches'] == 1 for r in audit['rows'] for e in r['entries'])
    before = selectors(OUT/'base')
    save('selectors-base.json', before)
    assert len(before['union']) == 52 and before['patterns'] == 815
    broken = [(r['target'], e) for r in before['rows'] for e in r['entries'] if e['matches'] != 1]
    assert len(broken) == 1 and broken[0][0] == 'radmin5rx' and broken[0][1]['label'].startswith('X09')
    for path in ['lib/core/remote_codec.h', 'lib/core/remote_codec.cpp', 'test/test_remote_codec.cpp', 'tools/probe_ui_model_mutations.py']:
        shutil.copy2(ROOT/path, OUT/'measure'/path)
    save('measure-final-inputs.json', inventory(OUT/'measure'))
    print('FINAL SNAPSHOTS; 52 BATTERIES / 817 PATTERNS ALL MATCH ONCE', flush=True)
elif mode == 'mutations':
    targets = json.loads((OUT/'selectors-final.json').read_text())['union']
    targets = ['radmin2codec', 'radmin5rx'] + [t for t in targets if t not in ['radmin2codec', 'radmin5rx']]
    runset(mode, OUT/'mutations', [(t, ['python3', 'tools/probe_ui_model_mutations.py', '--target='+t, '--workers=2']) for t in targets])
elif mode == 'boards':
    r = OUT/'measure'
    runset(mode, r, [('pair', ['python3', 'tools/measure_board.py', 'pair', '--jobs=1', '--output', str(r/'.pio-measure/final')])])
elif mode == 'simulator':
    r = OUT/'gate'; build = OUT/'sim-final'
    runset(mode, r, [('configure', ['cmake', '-S', str(SIM), '-B', str(build), '-G', 'Ninja', '-DMESHROUTE_DIR='+str(r), '-DCMAKE_BUILD_TYPE=Release']),
                    ('build', ['cmake', '--build', str(build), '--target', 'lus', '--parallel', '3', '--verbose']),
                    ('corpus', ['python3', 'tools/run_corpus.py', '--out', str(OUT/'corpus-final'), '--lus', str(build/'orchestrator/lus'), '--jobs', '3', '--require-anchors']),
                    ('validate', ['python3', 'tools/run_corpus.py', '--validate', str(OUT/'corpus-final')])])
elif mode == 'chain':
    r = OUT/'gate'
    measured = r/'.pio-measure/verified-base/gateway'
    measured.mkdir(parents=True)
    for name in ['manifest.json', 'firmware.elf']:
        shutil.copy2(OUT/'measure/.pio-measure/base/gateway'/name, measured/name)
    commands = [('native-build', ['pio', 'test', '-e', 'native']), ('native', ['./.pio/build/native/program']),
                ('abi', ['python3', 'tools/probe_board_abi.py']), ('abi-b278', ['python3', 'tools/probe_b278_row_abi.py'])]
    for probe in ['console_sink', 'inbox_verbs', 'firmware_ui', 'custody_usb', 'ble_line', 'features']:
        commands += [(probe, ['bash', 'tools/probe_'+probe+'/run.sh']),
                     (probe+'-no-neg', ['bash', 'tools/probe_'+probe+'/run.sh', '--no-neg'])]
    commands += [('tools', ['python3', '-m', 'unittest', 'discover', '-s', 'tools', '-p', 'test_*.py']),
                 ('inventory-write', ['python3', 'tools/gen_command_inventory.py', '--write']),
                 ('inventory-bare', ['python3', 'tools/gen_command_inventory.py']),
                 ('inventory-check', ['python3', 'tools/gen_command_inventory.py', '--check']),
                 ('authority', ['python3', 'tools/check_command_authority.py']),
                 ('authority-controls', ['python3', 'tools/check_command_authority.py', '--selftest']),
                 ('a0', ['python3', 'tools/check_a0_matrix.py']),
                 ('literals', ['python3', 'tools/check_data_type_literals.py']),
                 ('census', ['bash', 'tools/warning_census.sh'])]
    runset(mode, r, commands)
