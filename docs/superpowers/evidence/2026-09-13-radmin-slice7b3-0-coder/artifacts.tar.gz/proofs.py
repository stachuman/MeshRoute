import hashlib
from pathlib import Path
import subprocess
import time
from work import OUT, ROOT, ENV, save, inventory

records = []
def run(name, repo, argv, expected=0):
    start = time.monotonic()
    log = OUT / ('proof-' + name + '.log')
    assert not log.exists()
    with log.open('wb') as stream:
        rc = subprocess.run(argv, cwd=repo, env=ENV, stdout=stream, stderr=subprocess.STDOUT).returncode
    records.append(dict(name=name, argv=argv, cwd=str(repo), rc=rc, expected=expected,
                        seconds=round(time.monotonic()-start, 3), log=str(log),
                        sha256=hashlib.sha256(log.read_bytes()).hexdigest()))
    save('proof-results.json', records)
    print(name, rc, 'expected', expected, flush=True)
    assert rc == expected, log

before = inventory(ROOT)
for arm in ['base', 'gate']:
    repo = OUT/arm
    libraries = sorted(str(p) for p in (repo/'.pio/build/native').glob('lib*/*.a'))
    assert libraries
    binary = str(OUT/('domain-proof-'+arm))
    run('compile-'+arm, repo, ['g++', '-std=c++20', '-DMESHROUTE_NATIVE', '-Ilib/core', '-Ilib/monocypher',
        'docs/superpowers/evidence/2026-09-13-radmin-slice7b3-0-precheck/result-domain-proof.cpp',
        '-Wl,--start-group', *libraries, '-Wl,--end-group', '-o', binary])
    run('domain-'+arm, repo, [binary] + (['--allocated'] if arm == 'gate' else []))
    if arm == 'base':
        run('old-ceiling-control', repo, [binary, '--allocated'], expected=1)
repo = OUT/'gate'
reference = ['docs/superpowers/evidence/2026-09-13-radmin-slice7b3-0-reference.py']
python = '/home/staszek/mr-slice2-ref/bin/python'
run('reference', repo, [python, *reference, '--freeze-check', '--compare', 'test/test_remote_codec.cpp', '--selftest'])
run('corruption', repo, [python, *reference, '--compare', str(OUT/'corrupted-literal.cpp')], expected=1)
assert inventory(ROOT) == before
print('ALL FOCUSED PROOFS COMPLETE; shared inputs unchanged', flush=True)
